import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def page(b,w,h):
  pg=await b.new_page(viewport={'width':w,'height':h});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
  await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort());return pg,errs
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      pg,errs=await page(b,w,h)
      await pg.goto(B+'/');await pg.wait_for_timeout(700);boot=await pg.evaluate("!!document.getElementById('dmBoot')")
      await pg.wait_for_timeout(6500)
      r=await pg.evaluate("""()=>({ver:document.body.dataset.version,gateBtns:document.querySelectorAll('#dmGateActs button[data-a]').length,
        gateLink:(document.querySelector('.dmGateExplore')||{}).getAttribute?document.querySelector('.dmGateExplore').getAttribute('href'):null,
        nav:[...document.querySelectorAll('.nav a.dmNavExplore')].map(a=>a.getAttribute('href')),
        rankCards:document.querySelectorAll('.dmTopRCard').length,rankItems:document.querySelectorAll('.dmTopR .tl li').length,chips:document.querySelectorAll('.dmTopRChips a').length,
        aboutOpen:document.querySelector('.dmAbFold').open,projects:document.querySelectorAll('.dmAbProjects li').length,
        interviewInDom:document.body.innerHTML.includes('A good place to swim should be easier to find'),
        hscroll:document.documentElement.scrollWidth>innerWidth})""")
      r['boot']=boot
      await pg.evaluate("document.querySelectorAll('#gate,.gate').forEach(e=>e.style.display='none')")
      el=pg.locator('#rankings');await el.scroll_into_view_if_needed();await el.screenshot(path=f'/tmp/w/s/h_rank_{t}.png')
      el=pg.locator('#about');await el.scroll_into_view_if_needed();await el.screenshot(path=f'/tmp/w/s/h_about_{t}.png')
      await pg.goto(B+'/#about');await pg.wait_for_timeout(500);r['hashOpensAbout']=await pg.evaluate("document.querySelector('.dmAbFold').open")
      r['errors']=errs;R['home_'+t]=r;await pg.close()
      pg,errs=await page(b,w,h);await pg.goto(B+'/rankings');await pg.wait_for_timeout(500)
      R['rank_'+t]={'title':await pg.title(),'links':await pg.evaluate("document.querySelectorAll('a[href^=\"/discover/\"]').length"),'noindex':await pg.evaluate("!!document.querySelector('meta[name=robots]')"),'hscroll':await pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'errors':errs}
      await pg.screenshot(path=f'/tmp/w/s/rank_{t}.png');await pg.close()
      pg,errs=await page(b,w,h);await pg.goto(B+'/whale-watch');await pg.wait_for_timeout(500)
      R['disc_'+t]={'title':await pg.title(),'cards':await pg.evaluate("document.querySelectorAll('li article').length"),'canon':await pg.evaluate("document.querySelector('link[rel=canonical]').href"),'ld':await pg.evaluate("JSON.parse(document.querySelector('script[type=\"application/ld+json\"]').textContent).numberOfItems"),'hscroll':await pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'errors':errs}
      await pg.screenshot(path=f'/tmp/w/s/disc_{t}.png');await pg.close()
      pg,errs=await page(b,w,h);await pg.goto(B+'/explore#been');await pg.wait_for_timeout(2500)
      c=pg.locator('#dmBeen canvas');bb=await c.bounding_box()
      # stop spin by a tap at centre-ish then find country count
      await pg.evaluate("localStorage.clear()")
      await pg.evaluate("window.__dmBeen.toggle('CH');window.__dmBeen.toggle('TH')")
      await pg.mouse.click(bb['x']+bb['width']*0.5,bb['y']+bb['height']*0.45);await pg.wait_for_timeout(300)
      ex=await pg.evaluate("""()=>({countries:+document.querySelector('[data-n=countries]').textContent,list:document.querySelectorAll('.beenList li').length,stored:localStorage.getItem('dm_been_countries'),
        noindex:!!document.querySelector('meta[name=robots]'),canon:document.querySelector('link[rel=canonical]').href,explorer:!!document.getElementById('dipmapper-v3').shadowRoot,hscroll:document.documentElement.scrollWidth>innerWidth})""")
      await pg.reload();await pg.wait_for_timeout(1500);ex['afterReload']=await pg.evaluate("+document.querySelector('[data-n=countries]').textContent")
      ex['errors']=errs;R['explore_'+t]=ex
      await pg.locator('#been').screenshot(path=f'/tmp/w/s/been_{t}.png');await pg.close()
    await b.close();print(json.dumps(R,indent=0))
asyncio.run(main())
