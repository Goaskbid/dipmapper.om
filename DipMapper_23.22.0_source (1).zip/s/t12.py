import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      pg=await b.new_page(viewport={'width':w,'height':h});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
      await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
      await pg.goto(B+'/');await pg.wait_for_timeout(6500)
      r=await pg.evaluate("""()=>({ver:document.body.dataset.version,routes:document.querySelectorAll('.dmGateRoutes a').length,gateBtns:document.querySelectorAll('#dmGateActs button[data-a]').length,
        nav:[...document.querySelectorAll('.nav a.dmNavExplore')].map(a=>a.textContent),pickers:document.querySelectorAll('.dmTopRPick select').length,opts:document.querySelectorAll('.dmTopRPick option').length,
        aboutClosed:!document.querySelector('.dmAbFold').open,hscroll:document.documentElement.scrollWidth>innerWidth})""")
      await pg.screenshot(path=f'/tmp/w/s/g_{t}.png')
      await pg.evaluate("document.querySelectorAll('#gate,.gate').forEach(e=>e.style.display='none');state.center=[47.36,8.54];state.mapCenter=[47.3,8.6];state.zoom=8;try{drawMap()}catch(e){}")
      await pg.wait_for_timeout(1500)
      r['picks']=await pg.evaluate("window.__dmPicks.count()");r['starsVisible']=await pg.evaluate("window.__dmPicks.visible()")
      r['bar']=await pg.evaluate("(document.getElementById('dmPicksBar')||{}).innerText||''")
      st=pg.locator('.dmStar').first
      if await st.count():
        await st.scroll_into_view_if_needed();await st.click(force=True);await pg.wait_for_timeout(300)
        r['popup']=await pg.evaluate("(document.querySelector('.dmStarPop')||{}).innerText||''")
      el=pg.locator('#mapPanel');await el.scroll_into_view_if_needed();await el.screenshot(path=f'/tmp/w/s/map_{t}.png')
      el=pg.locator('#rankings');await el.scroll_into_view_if_needed();await el.screenshot(path=f'/tmp/w/s/rk_{t}.png')
      r['errors']=errs;R['home_'+t]=r;await pg.close()
      pg=await b.new_page(viewport={'width':w,'height':h});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
      await pg.goto(B+'/water-experiences-switzerland');await pg.wait_for_timeout(400)
      R['country_'+t]={'title':await pg.title(),'cards':await pg.evaluate("document.querySelectorAll('li article').length"),'canon':await pg.evaluate("document.querySelector('link[rel=canonical]').href"),'hscroll':await pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'errors':errs}
      await pg.goto(B+'/rankings');await pg.wait_for_timeout(300);R['rank_'+t]={'selects':await pg.evaluate("document.querySelectorAll('.pickers select').length"),'hscroll':await pg.evaluate("document.documentElement.scrollWidth>innerWidth")}
      await pg.screenshot(path=f'/tmp/w/s/rkpage_{t}.png');await pg.close()
    await b.close();print(json.dumps(R,indent=0))
asyncio.run(main())
