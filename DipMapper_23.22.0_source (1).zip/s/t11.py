import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      pg=await b.new_page(viewport={'width':w,'height':h})
      await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
      await pg.goto(B+'/');await pg.wait_for_timeout(7000)
      print(await pg.evaluate("""()=>{const e=document.getElementById('rankings');const r=e.getBoundingClientRect();const p=e.parentElement;return {r:[r.x,r.y,r.width,r.height],parent:p.tagName+'.'+p.className+'#'+p.id,disp:getComputedStyle(p).display,gate:!!document.querySelector('#gate'),gateVis:[...document.querySelectorAll('[id*=Gate],[class*=gate]')].slice(0,3).map(x=>x.id||x.className)}}"""))
      await pg.close()
    await b.close()
asyncio.run(main())
