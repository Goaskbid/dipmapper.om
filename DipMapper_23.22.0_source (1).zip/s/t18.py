import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      ctx=await b.new_context(viewport={'width':w,'height':h},geolocation={'latitude':-8.6,'longitude':115.2},permissions=['geolocation'])
      for path in ['/whale-watch','/rankings','/wildlife-calendar','/best-water-experiences-by-month','/water-experiences-switzerland']:
        pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
        await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
        await pg.goto(B+path);await pg.wait_for_timeout(600)
        before=await pg.evaluate("[...document.querySelectorAll('ol')].find(o=>o.querySelector(':scope>li[data-la]')).querySelector('li h2,li b').textContent")
        await pg.click('.nearT button[data-n=n]');await pg.wait_for_timeout(700)
        after=await pg.evaluate("[...document.querySelectorAll('ol')].find(o=>o.querySelector(':scope>li[data-la]')).querySelector('li h2,li b').textContent")
        msg=await pg.evaluate("(document.querySelector('.nearMsg')||{}).textContent")
        if path in('/whale-watch','/rankings'): await pg.screenshot(path='/tmp/w/s/v8%s_%s.png'%(path.replace('/','_'),t))
        await pg.click('.nearT button[data-n=g]');await pg.wait_for_timeout(300)
        back=await pg.evaluate("[...document.querySelectorAll('ol')].find(o=>o.querySelector(':scope>li[data-la]')).querySelector('li h2,li b').textContent")
        R[t+path]={'before':before[:40],'nearFirst':after[:50],'restored':back==before,'msg':msg[:40],'logo':await pg.evaluate("!!document.querySelector('.bar .logo img[src^=\"data:image/webp\"]')"),'icon':await pg.evaluate("document.querySelector('link[rel=icon]').type"),'hs':await pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'err':errs}
        await pg.evaluate("localStorage.clear()");await pg.close()
      pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:120]));await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
      await pg.goto(B+'/');await pg.wait_for_timeout(6500);await pg.evaluate("document.querySelectorAll('#gate,.gate').forEach(e=>e.style.display='none')")
      await pg.locator('#rankings').scroll_into_view_if_needed();await pg.click('.dmHxTog button[data-hx=n]');await pg.wait_for_timeout(1200)
      await pg.locator('#rankings').screenshot(path=f'/tmp/w/s/v8_home_{t}.png')
      R[t+'/home']={'near':await pg.evaluate("document.querySelectorAll('.dmHxNear li').length"),'first':await pg.evaluate("(document.querySelector('.dmHxNear li b')||{}).textContent"),'gridHidden':await pg.evaluate("document.querySelector('.dmHxGrid').hidden"),
        'icon':await pg.evaluate("[...document.querySelectorAll('link[rel=icon]')].map(l=>l.type)"),'ver':await pg.evaluate("document.body.dataset.version"),'gate':await pg.evaluate("document.querySelectorAll('#dmGateActs button[data-a]').length")}
      await pg.click('.dmHxTog button[data-hx=g]');R[t+'/home']['gridBack']=await pg.evaluate("!document.querySelector('.dmHxGrid').hidden")
      await pg.evaluate("state.center=[47.36,8.54];state.mapCenter=[47.3,8.6];state.zoom=8;try{drawMap()}catch(e){}");await pg.wait_for_timeout(1500);R[t+'/home']['stars']=await pg.evaluate("window.__dmPicks.visible()");R[t+'/home']['err']=errs
      await ctx.close()
    await b.close();print(json.dumps(R,ensure_ascii=False,indent=0))
asyncio.run(main())
