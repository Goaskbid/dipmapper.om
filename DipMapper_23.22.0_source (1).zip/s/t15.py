import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      ctx=await b.new_context(viewport={'width':w,'height':h},geolocation={'latitude':47.27,'longitude':8.65},permissions=['geolocation'])
      for path in ['/whale-watch','/rankings','/best-water-experiences-by-month','/rainy-day-water-experiences','/zurich','/activities','/explore','/imprint','/water-experiences-switzerland']:
        pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
        await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
        await pg.goto(B+path);await pg.wait_for_timeout(900)
        R[t+path]=await pg.evaluate("""()=>({bar:!!document.querySelector('header.bar .nav'),icon:[...document.querySelectorAll('link[rel=icon]')].map(l=>l.type).join(','),cards:document.querySelectorAll('.card').length,ph:document.querySelectorAll('figure.ph').length,minis:document.querySelectorAll('.mini').length,hs:document.documentElement.scrollWidth>innerWidth})""")
        R[t+path]['err']=errs
        if path in ('/whale-watch','/best-water-experiences-by-month','/zurich','/explore','/rankings'): await pg.screenshot(path='/tmp/w/s/v6%s_%s.png'%(path.replace('/','_'),t))
        await pg.close()
      pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:120]));await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
      await pg.goto(B+'/');await pg.wait_for_timeout(6500)
      await pg.evaluate("document.querySelectorAll('#gate,.gate').forEach(e=>e.style.display='none');state.center=[47.36,8.54];state.mapCenter=[47.3,8.6];state.zoom=8;try{drawMap()}catch(e){}");await pg.wait_for_timeout(1500)
      st=pg.locator('.dmStar').first;await st.click(force=True);await pg.wait_for_timeout(300)
      R[t+'/home']={'ver':await pg.evaluate("document.body.dataset.version"),'gate':await pg.evaluate("document.querySelectorAll('#dmGateActs button[data-a]').length"),'stars':await pg.evaluate("window.__dmPicks.visible()"),'pop':await pg.evaluate("(document.querySelector('.dmStarPop h4')||{}).textContent"),'err':errs}
      pg2=await ctx.new_page();await pg2.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort());await pg2.goto(B+'/explore#near');await pg2.wait_for_timeout(1200);await pg2.click('#nearMe');await pg2.wait_for_timeout(1200)
      R[t+'/near']=await pg2.evaluate("({n:document.querySelectorAll('#nearList li').length,k:(document.querySelector('#nearList .k')||{}).textContent})")
      await ctx.close()
    await b.close();print(json.dumps(R,ensure_ascii=False))
asyncio.run(main())
