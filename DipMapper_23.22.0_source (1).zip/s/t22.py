import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    ctx=await b.new_context(viewport={'width':390,'height':844},service_workers='block',geolocation={'latitude':7.896,'longitude':98.296},permissions=['geolocation']);pg=await ctx.new_page();errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:150]));await ctx.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
    await pg.goto(B+'/');await pg.wait_for_timeout(5000)
    R['junk']=await pg.evaluate("""[dmJunk({name:'Lucky Pool Billiard'}),dmJunk({leisure:'swimming_pool',name:'Patong Beach Hotel Pool'}),dmJunk({leisure:'swimming_pool',access:'customers',name:'X'}),dmJunk({leisure:'swimming_pool',name:'Hallenbad City'}),dmJunk({natural:'beach',name:'Patong Beach'}),dmJunk({amenity:'bar',name:'Pool Bar'})]""")
    await pg.evaluate("document.querySelectorAll('#gate').forEach(e=>e.style.display='none');state.center=[7.896,98.296];state.mapCenter=[7.95,98.40];state.zoom=11;drawMap()")
    before=await pg.evaluate("(()=>{var m=els.map.getBoundingClientRect(),c=state.mapCenter,z=state.zoom,cp=project(c[0],c[1],z),u=project(state.center[0],state.center[1],z);return [Math.round(u[0]-cp[0]+m.width/2),Math.round(u[1]-cp[1]+m.height/2)]})()")
    await pg.evaluate("dmZoom(1)")
    after=await pg.evaluate("(()=>{var m=els.map.getBoundingClientRect(),c=state.mapCenter,z=state.zoom,cp=project(c[0],c[1],z),u=project(state.center[0],state.center[1],z);return [Math.round(u[0]-cp[0]+m.width/2),Math.round(u[1]-cp[1]+m.height/2),z]})()")
    R['zoom_user_screen_pos']=[before,after];R['err']=errs
    await pg.goto(B+'/rankings');await pg.wait_for_timeout(800);await pg.locator('.stats').screenshot(path='/tmp/w/s/charts.png');R['charts']=await pg.evaluate("document.querySelectorAll('.stats .chart').length")
    await pg.goto(B+'/explore?show=dive-yanbu');await pg.wait_for_timeout(2500);R['show']=await pg.evaluate("(document.querySelector('.xc.sel h3')||{}).textContent")
    R['err2']=errs;await b.close();print(json.dumps(R,ensure_ascii=False))
asyncio.run(main())
