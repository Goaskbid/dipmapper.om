import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader']);ctx=await b.new_context(viewport={'width':1440,'height':900});pg=await ctx.new_page();seen=[]
    async def rt(r):
      seen.append(r.request.url[:80])
      if r.request.url.startswith(B): return await r.continue_()
      return await r.abort()
    await pg.route('**/*',rt)
    await pg.goto(B+'/');await pg.wait_for_timeout(5000);await pg.evaluate("document.querySelectorAll('#gate,.gate').forEach(e=>e.style.display='none')")
    await pg.evaluate("state.center=[47.36,8.54];state.mapCenter=[47.3,8.6];state.zoom=8;try{drawMap()}catch(e){}");await pg.wait_for_timeout(2500)
    print(await pg.evaluate("[typeof maplibregl, __dmVec.ok, __dmVec.dead, !!navigator.serviceWorker.controller, [...document.scripts].filter(s=>/maplibre/.test(s.src)).map(s=>s.src)]"))
    print([u for u in seen if 'maplibre' in u or 'openfree' in u])
    bx=await pg.locator('#map').bounding_box();x=bx['x']+bx['width']/2;y=bx['y']+bx['height']/2
    print(await pg.evaluate(f"(()=>{{var e=document.elementFromPoint({x},{y});return e.tagName+'.'+e.className+' < '+(e.parentNode.className||'')}})()"))
    await b.close()
asyncio.run(main())
