import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
NOW='2026-11-14T13:00'
times=[f'2026-11-{14+h//24:02d}T{h%24:02d}:00' for h in range(72)]
import math
W={"utc_offset_seconds":25200,"timezone_abbreviation":"GMT+7","current":{"time":NOW,"temperature_2m":30.4,"weather_code":2,"wind_speed_10m":14.2,"wind_gusts_10m":25,"wind_direction_10m":250},"daily":{"uv_index_max":[9.1]}}
M={"utc_offset_seconds":25200,"current":{"time":NOW,"wave_height":1.2,"wave_period":7.5,"wave_direction":240,"sea_surface_temperature":29.3},"hourly":{"time":times,"sea_level_height_msl":[round(0.9*math.sin((h+3)*2*math.pi/12.4),3) for h in range(72)]}}
A={"features":[{"properties":{"event":"High Surf Advisory","headline":"High surf until Monday","areaDesc":"Oahu","expires":"2026-11-16T06:00:00Z"}}]}
async def route(r):
  u=r.request.url
  if u.startswith(B): return await r.continue_()
  if 'marine-api.open-meteo' in u: return await r.fulfill(json=M,headers={'Access-Control-Allow-Origin':'*'})
  if 'api.open-meteo' in u: return await r.fulfill(json=W,headers={'Access-Control-Allow-Origin':'*'})
  if 'api.weather.gov' in u: return await r.fulfill(json=A,headers={'Access-Control-Allow-Origin':'*'})
  return await r.abort()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      ctx=await b.new_context(viewport={'width':w,'height':h},service_workers='block');pg=await ctx.new_page();errs=[]
      pg.on('pageerror',lambda e:errs.append(str(e)[:150]));await ctx.route('**/*',route)
      await pg.goto(B+'/');await pg.wait_for_timeout(6000)
      R[t+'_example']=await pg.evaluate("[(document.querySelector('.dmEx b')||{}).textContent, state.mapCenter, state.zoom]")
      await pg.click('#gateSkip');await pg.wait_for_timeout(500);await pg.locator('#map').scroll_into_view_if_needed();await pg.wait_for_timeout(1800)
      R[t+'_ribbon']=await pg.evaluate("(document.querySelector('.dmCoast')||{}).textContent")
      await pg.click('.dmEx .r button >> nth=2');await pg.wait_for_timeout(1500);R[t+'_area']=await pg.evaluate("[state.mapCenter,state.zoom]")
      await pg.click('.dmCoast button');await pg.wait_for_timeout(400);R[t+'_sheet']=await pg.evaluate("(document.querySelector('.dmCoastD')||{}).innerText.slice(0,900)")
      await pg.screenshot(path=f'/tmp/w/s/coast_{t}.png')
      await pg.evaluate("document.querySelector('.dmCoastD .x').click();state.mapCenter=[21.28,-157.83];state.zoom=12;drawMap()");await pg.wait_for_timeout(1800);await pg.click('.dmCoast button');await pg.wait_for_timeout(300);R[t+'_hirisk']=await pg.evaluate("[...document.querySelectorAll('.dmCoastD .rk')].map(e=>e.innerText.slice(0,120))");await pg.screenshot(path=f'/tmp/w/s/risk_{t}.png');await pg.evaluate("document.querySelector('.dmCoastD .x').click()")
      R[t+'_us']=await pg.evaluate("(document.querySelector('.dmCoast')||{}).textContent")
      await pg.evaluate("state.zoom=4;drawMap()");await pg.wait_for_timeout(400);R[t+'_low']=await pg.evaluate("(document.querySelector('.dmCoast')||{}).textContent")
      ctx2=await b.new_context(viewport={'width':w,'height':h},service_workers='block');await ctx2.add_init_script("localStorage.setItem('dm_loc',JSON.stringify({la:7.9,lo:98.3,t:Date.now()}))");pg2=await ctx2.new_page();await ctx2.route('**/*',route)
      await pg2.goto(B+'/');await pg2.wait_for_timeout(5000);R[t+'_returning']=await pg2.evaluate("[!!document.querySelector('.dmEx'),state.mapCenter]");await ctx2.close()
      await pg.goto(B+'/town-patong');await pg.wait_for_timeout(1500);R[t+'_town']=await pg.evaluate("document.getElementById('cbox').innerText.slice(0,300)")
      await pg.goto(B+'/town-cairns');await pg.wait_for_timeout(1500);R[t+'_cairns']=await pg.evaluate("[...document.querySelectorAll('#cbox .rk')].map(e=>e.querySelector('b').textContent+' '+e.querySelector('.st').textContent)")
      await pg.goto(B+'/whale-watch');await pg.wait_for_timeout(2500);R[t+'_badges']=await pg.evaluate("[...document.querySelectorAll('.rkb')].slice(0,4).map(e=>e.textContent)")
      await pg.goto(B+'/sea-risk-calendar');await pg.wait_for_timeout(500);R[t+'_cal']=await pg.evaluate("[document.querySelectorAll('.rk').length,document.documentElement.scrollWidth>innerWidth]")
      await pg.evaluate("state=undefined") if False else None
      R[t+'_err']=errs;await ctx.close()
    await b.close();print(json.dumps(R,ensure_ascii=False,indent=0))
asyncio.run(main())
