import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831';D='/tmp/w/ml/node_modules/maplibre-gl/dist/'
STYLE=json.dumps({"version":8,"sources":{"l":{"type":"geojson","data":{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[0,40],[20,40],[20,55],[0,55],[0,40]]]},"properties":{}}}},
 "layers":[{"id":"bg","type":"background","paint":{"background-color":"#a8d8f0"}},{"id":"land","type":"fill","source":"l","paint":{"fill-color":"#f2efe6"}}]})
async def route(r,cdn):
  u=r.request.url
  if u.startswith(B): return await r.continue_()
  if cdn and 'maplibre-gl.js' in u: return await r.fulfill(path=D+'maplibre-gl.js',content_type='application/javascript')
  if cdn and 'maplibre-gl.css' in u: return await r.fulfill(path=D+'maplibre-gl.css',content_type='text/css')
  if cdn and 'openfreemap.org/styles' in u: return await r.fulfill(body=STYLE,content_type='application/json')
  return await r.abort()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']);R={}
    for cdn in (False,True):
     for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      ctx=await b.new_context(viewport={'width':w,'height':h},service_workers='block');pg=await ctx.new_page();errs=[]
      pg.on('pageerror',lambda e:errs.append(str(e)[:150]));pg.on('console',lambda m:errs.append('C:'+m.text[:150]) if m.type=='error' else None)
      await ctx.route('**/*',(lambda c:(lambda r:route(r,c)))(cdn))
      await pg.goto(B+'/');await pg.wait_for_timeout(6000);await pg.evaluate("document.querySelectorAll('#gate,.gate').forEach(e=>e.style.display='none')")
      await pg.evaluate("state.center=[47.36,8.54];state.mapCenter=[47.3,8.6];state.zoom=8;try{drawMap()}catch(e){}");await pg.wait_for_timeout(2500)
      k=('vec_' if cdn else 'nocdn_')+t
      r={'ok':await pg.evaluate("__dmVec.ok"),'dead':await pg.evaluate("__dmVec.dead"),'on':await pg.evaluate("document.getElementById('map').classList.contains('dmVecOn')"),
         'order':await pg.evaluate("(()=>{var v=document.querySelector('#map .dmVec');return v?v.nextElementSibling&&v.nextElementSibling.className:null})()"),
         'tilesShown':await pg.evaluate("getComputedStyle(document.querySelector('#map .dmTiles')).display!='none'"),
         'attr':await pg.evaluate("(document.querySelector('.dmAttr')||{}).textContent"),'stars':await pg.evaluate("window.__dmPicks&&__dmPicks.visible()")}
      if cdn:
        r['sync1']=await pg.evaluate("(()=>{var c=__dmVec.m.getCenter();return [+c.lat.toFixed(3),+c.lng.toFixed(3),__dmVec.m.getZoom()]})()")
        await pg.locator('#map').scroll_into_view_if_needed();bx=await pg.locator('#map').bounding_box();x=bx['x']+bx['width']*0.8;y=bx['y']+min(bx['height'],900-bx['y'])*0.8
        r['startEl']=await pg.evaluate(f'(document.elementFromPoint({x},{y})||{{}}).className')
        await pg.mouse.move(x,y);await pg.mouse.down();
        for i in range(1,13): await pg.mouse.move(x-15*i,y-8*i)
        await pg.mouse.up();await pg.wait_for_timeout(400)
        r['afterDrag']=await pg.evaluate("(()=>{var c=__dmVec.m.getCenter(),s=state.mapCenter;return {vec:[+c.lat.toFixed(3),+c.lng.toFixed(3)],state:[+s[0].toFixed(3),+s[1].toFixed(3)]}})()")
        r['align']=await pg.evaluate("(()=>{var mp=document.getElementById('map'),c=state.mapCenter,z=state.zoom,P=[c[0]+0.2,c[1]+0.3],a=project(P[0],P[1],z),o=project(c[0],c[1],z);var ax=(a.x!=null?a.x:a[0])-(o.x!=null?o.x:o[0])+mp.clientWidth/2,ay=(a.y!=null?a.y:a[1])-(o.y!=null?o.y:o[1])+mp.clientHeight/2;var q=__dmVec.m.project([P[1],P[0]]);return [Math.round(ax),Math.round(ay),Math.round(q.x),Math.round(q.y),mp.clientWidth,__dmVec.d.clientWidth]})()")
        await pg.locator('#map').screenshot(path=f'/tmp/w/s/v9_map_{t}.png')
      r['err']=[e for e in errs if 'ERR_FAILED' not in e][:5];r['netFail']=sum('ERR_FAILED' in e for e in errs);R[k]=r;await ctx.close()
    await b.close();print(json.dumps(R,indent=0))
asyncio.run(main())
