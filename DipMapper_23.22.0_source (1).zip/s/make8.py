"""DipMapper 23.12.0: redesigned ranking pages + hub, bold favicon, no emoji flags (Windows shows letters)."""
import json, re, os, html, shutil, collections, urllib.parse
W = '/tmp/w'; SRC = '/tmp/w/base2311'; OUT = W + '/out9'; TODAY = '13 November 2026'; NOWM = 11
shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
esc = html.escape
cat = json.load(open(W + '/pub/data/03_catalogue.json', encoding='utf8')); by = {r['id']: r for r in cat['records']}
# v23.19.0: reviewed results of the GitHub data collector (operator's own website contacts; Wikipedia positions)
import sys as _s; _s.path.insert(0, '/tmp/w/s'); import merge_dc as _M
_srcpk = json.load(open(SRC + '/picks.json', encoding='utf8'))
from collections import Counter as _Cc
_sc = _Cc((_p.get('la'), _p.get('lo')) for _p in _srcpk)
_orig = {_p['id']: (_p.get('la'), _p.get('lo')) for _p in _srcpk}
for _p in _srcpk:
    if _p.get('la') is None: continue
    _a = (_p.get('ar') or '').strip().lower()
    _p['x'] = 2 if _a in ('', (_p.get('c') or '').lower()) else (1 if _sc[(_p['la'], _p['lo'])] > 1 else 0)
_POS = {k: v for k, v in _M.positions(_srcpk).items() if k not in ('shore-bluespring', 'canoe-upper-zambezi', 'canoe-lower-zambezi', 'raft-mendoza', 'raft-xiuguluan', 'wildlife-sardine-run')}
_CON = _M.contacts(_srcpk)
for _k, _v in _CON.items():
    _c = by[_k]['guide_v4']['contact'] if _k in by else None
    if _c is None: continue
    if not _c.get('phones') and _v['tel']: _c['phones'] = list(_v['tel'])
    if not _c.get('emails') and _v['mail']: _c['emails'] = list(_v['mail'])
for _k, (_la, _lo, _t, _u) in _POS.items():
    if _k in by:
        _pl = by[_k].setdefault('geo_v3', {}).setdefault('plot', {}); _pl['latitude'] = _la; _pl['longitude'] = _lo; _pl['source'] = 'wikipedia:' + _t
print('collector merged: positions', len(_POS), 'contacts', len(_CON))
rules = json.load(open(W + '/pub/data/04_evidence_and_rules.json', encoding='utf8'))
src = {s['source_id']: s for s in rules['sources']}
restr = collections.defaultdict(list)
for x in rules['restrictions']:
    for i in x['experience_ids']: restr[i].append(x)
ACT = {'swim': 'Swimming', 'cave_swim': 'Cave swimming', 'scuba': 'Diving', 'snorkel': 'Snorkelling', 'snorkel_excursion': 'Snorkelling trip', 'underwater_art': 'Underwater art',
       'whale_watch': 'Whale watching', 'marine_wildlife': 'Marine wildlife', 'wildlife_boat': 'Wildlife boat trip', 'marine_birds': 'Seabirds', 'shore_wildlife': 'Shore wildlife',
       'turtle_watch': 'Turtle watching', 'kayak': 'Kayaking', 'kayak_rental': 'Kayak rental', 'ferry': 'Ferry', 'scenic_cruise': 'Scenic cruise', 'boat_trip': 'Boat trip',
       'island_boat': 'Island boat trip', 'glass_bottom': 'Glass-bottom boat', 'thermal_bath': 'Thermal bath', 'sauna_swim': 'Sauna & swim', 'water_park': 'Water park', 'surf': 'Surfing',
       'surf_park': 'Surf park', 'wind_sport': 'Wind sports', 'rafting': 'Rafting', 'river_tubing': 'River tubing', 'bioluminescence': 'Bioluminescence', 'glowworm_boat': 'Glow-worm boat',
       'beach': 'Beach', 'aquarium': 'Aquarium'}

BAD = re.compile(r"\b(Do not|Don't|Keep (?:\w+ ){0,4}(?:separate|distinct)|show the|defensible|Not established|must not|should not|never infer|not independently established|supplied evidence|this record|the record|national climate guess|not established by|Store the|Display the|Retain |Generic hidden|mislabel)\b", re.I)
def clean(t, fallback=''):
    out = ' '.join(x for x in re.split(r'(?<=[.!?])\s+', (t or '').strip()) if x and not BAD.search(x))
    return out or fallback
ICO = {'swim':'🏊','cave_swim':'🏊','scuba':'🤿','snorkel':'🤿','snorkel_excursion':'🤿','underwater_art':'🗿','whale_watch':'🐋','marine_wildlife':'🐬','wildlife_boat':'🐬',
       'marine_birds':'🐧','shore_wildlife':'🦭','turtle_watch':'🐢','kayak':'🛶','kayak_rental':'🛶','ferry':'⛴️','scenic_cruise':'🛳️','boat_trip':'🚤','island_boat':'🏝️',
       'glass_bottom':'🚤','thermal_bath':'♨️','sauna_swim':'🧖','water_park':'💦','surf':'🏄','surf_park':'🏄','wind_sport':'🪁','rafting':'🛶','river_tubing':'🛟',
       'bioluminescence':'✨','glowworm_boat':'✨','beach':'🏖️','aquarium':'🐠'}
def ico(r): return ICO.get(r['primary_activity'], '🌊')
def flg(cc): return ('<img class="fl" src="https://flagcdn.com/w40/%s.png" width="20" height="15" alt="" loading="lazy">' % cc.lower()) if re.fullmatch('[A-Z]{2}', cc or '') else ''
def ok_url(u):
    p = urllib.parse.urlsplit(str(u or '')); return p.scheme in ('http', 'https') and bool(p.netloc) and not p.username

ICON_SVG = ("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><defs><linearGradient id='g' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#16c6b8'/>"
            "<stop offset='1' stop-color='#075e6b'/></linearGradient></defs><rect width='64' height='64' rx='15' fill='url(#g)'/>"
            "<path d='M32 7C21.5 7 13 15.3 13 25.6 13 39.4 32 58 32 58s19-18.6 19-32.4C51 15.3 42.5 7 32 7z' fill='#fff'/>"
            "<path d='M32 15.5s-8.2 9.1-8.2 14.4a8.2 8.2 0 0 0 16.4 0c0-5.3-8.2-14.4-8.2-14.4z' fill='#0a8f99'/></svg>")
ICON = open('/tmp/w/s/fav64.uri').read(); LOGO_HD = open('/tmp/w/s/logohd.uri').read()
ICON_LINK = '<link rel="icon" type="image/png" sizes="64x64" href="' + ICON + '">'
MON = 'JFMAMJJASOND'; MONL = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

CSS = """:root{--ink:#06323a;--brand:#0a8a84;--brand2:#0fb3a6;--line:#e2eeec;--muted:#5d7b83;--bg:#f4faf9;--gold:#e6a700}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Manrope,Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:var(--ink);background:var(--bg);line-height:1.55;-webkit-font-smoothing:antialiased}
a{color:var(--brand)}.wrap{max-width:1080px;margin:0 auto;padding:0 20px}
.bar{position:sticky;top:0;z-index:20;background:rgba(255,255,255,.92);backdrop-filter:saturate(1.4) blur(10px);border-bottom:1px solid var(--line)}
.bar .wrap{display:flex;align-items:center;justify-content:space-between;gap:12px;height:62px}
.logo{display:flex;align-items:center;gap:9px;font-weight:800;font-size:19px;color:var(--ink);text-decoration:none;letter-spacing:-.02em}.logo img{height:44px;width:auto;display:block}
.nav{display:flex;gap:6px}.nav a{display:inline-flex;align-items:center;gap:6px;height:38px;padding:0 14px;border-radius:999px;font-weight:700;font-size:14px;text-decoration:none;color:var(--ink);border:1px solid var(--line);background:#fff}
.nav i{font-style:normal}.nav .s{display:none}.nav a.on{background:var(--ink);color:#fff;border-color:var(--ink)}.nav a:hover{border-color:var(--brand)}
.hero{background:radial-gradient(120% 140% at 0% 0%,#063a46 0%,#0a5f6c 55%,#0e8c8f 100%);color:#eafffb;padding:34px 0 30px}
.crumb{font-size:13px;color:#a9e3dc;margin:0 0 10px}.crumb a{color:#d7fffa;text-decoration:none}.crumb a:hover{text-decoration:underline}
.hero h1{margin:0 0 10px;font-size:clamp(30px,5vw,48px);line-height:1.08;letter-spacing:-.03em;color:#fff}
.hero p.lead{margin:0 0 18px;font-size:17px;color:#cdeee9;max-width:760px}
.facts{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 20px;padding:0;list-style:none}.facts li{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:6px 12px;font-size:13.5px;font-weight:600;color:#effffc}
.facts b{color:#fff}
.pick1{display:none}.pick1 span{display:block;font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:#9fe6dc;margin-bottom:5px}.pick1 select{width:100%;height:46px;border-radius:12px;border:0;background:#fff;color:var(--ink);font:600 15px system-ui,sans-serif;padding:0 12px}.pickers{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.pickers label span{display:block;font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:#9fe6dc;margin-bottom:5px}
.pickers select{width:100%;height:46px;border-radius:12px;border:0;background:#fff;color:var(--ink);font:600 15px system-ui,sans-serif;padding:0 12px;box-shadow:0 6px 18px rgba(0,0,0,.15)}
.tools{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;margin:22px 0 6px}
.seg{display:inline-flex;background:#fff;border:1px solid var(--line);border-radius:999px;padding:4px}.seg button{border:0;background:none;border-radius:999px;padding:8px 14px;font:700 14px system-ui,sans-serif;color:var(--muted);cursor:pointer}
.seg button.on{background:var(--ink);color:#fff}.count{font-size:14px;color:var(--muted)}
ol.cards{list-style:none;margin:10px 0 0;padding:0;display:grid;gap:14px}
.card{background:#fff;border:1px solid var(--line);border-radius:20px;padding:18px;display:grid;grid-template-columns:52px 220px 1fr;grid-template-areas:'rk ph bd';gap:4px 18px;align-items:start;box-shadow:0 1px 2px rgba(6,50,58,.04),0 10px 30px rgba(6,50,58,.06)}
.card .rank{grid-area:rk}.card .ph{grid-area:ph}.card .bd{grid-area:bd;min-width:0}.ph{position:relative;margin:0;height:160px;border-radius:14px;overflow:hidden;background:linear-gradient(150deg,#d9f4ef,#b6e4ea 60%,#9fd3e0);display:flex;align-items:center;justify-content:center}.ph .pi{font-size:54px;filter:drop-shadow(0 4px 10px rgba(6,50,58,.18))}.ph img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity .4s}.ph.has img{opacity:1}.ph .cr{position:absolute;right:6px;bottom:6px;font-size:10.5px;background:rgba(0,0,0,.55);color:#fff;padding:2px 6px;border-radius:6px;text-decoration:none;opacity:0}.ph.has .cr{opacity:1}.rank{width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:20px;color:#fff;background:linear-gradient(160deg,#0fb3a6,#0a6f78)}
.rank.top{background:linear-gradient(160deg,#ffd45c,#e69500);color:#3d2700}.rank.star{font-size:22px}
.kick{display:flex;flex-wrap:wrap;gap:6px;align-items:center;font-size:12.5px;color:var(--muted);font-weight:700;letter-spacing:.02em}
.pill{display:inline-block;padding:3px 9px;border-radius:999px;background:#e7f6f4;color:#0a6f69;font-weight:700;font-size:12px}
.card h2{margin:4px 0 6px;font-size:21px;line-height:1.25;letter-spacing:-.015em}.why{margin:0 0 12px;color:#23474f}
.months{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:0 0 12px}.mstrip{display:grid;grid-template-columns:repeat(12,22px);gap:3px}
.mstrip i{height:22px;border-radius:6px;background:#eef3f3;color:#9db1b5;font:700 10px/22px system-ui,sans-serif;text-align:center;font-style:normal}
.mstrip i.y{background:#16b3a5;color:#fff}.mstrip i.now{outline:2px solid var(--ink);outline-offset:1px}
.mtxt{font-size:13px;color:var(--muted);font-weight:600}.mtxt.none{color:#9a6b00}
.acts{display:flex;flex-wrap:wrap;gap:8px}.acts a{display:inline-flex;align-items:center;gap:6px;height:38px;padding:0 13px;border-radius:12px;border:1px solid #cfe5e1;font-weight:700;font-size:13.5px;text-decoration:none;color:#0a6f69;background:#fff}
.gt{margin:0 0 12px;padding:9px 12px;border-radius:12px;background:#f2f8ff;border:1px solid #d6e6f7;font-size:14px;color:#17384a;line-height:1.45}.gt small{display:block;color:#5b7480;font-size:12.5px;margin-top:2px}
.acts a.main{background:linear-gradient(180deg,#14bdb0,#0a8a84);color:#fff;border:0}
.notice{margin:10px 0 0;padding:10px 12px;border-radius:12px;background:#fff6e5;border:1px solid #f3dca5;font-size:14px;color:#5a3d00}
details.more{margin-top:12px;border-top:1px solid var(--line);padding-top:10px}details.more summary{cursor:pointer;font-weight:700;font-size:14px;color:var(--brand);list-style:none}
details.more summary::-webkit-details-marker{display:none}details.more summary:after{content:" ▾"}details.more[open] summary:after{content:" ▴"}
.dl{display:grid;grid-template-columns:150px 1fr;gap:8px 16px;margin:12px 0 0;font-size:14.5px}.dl dt{color:var(--muted);font-weight:700}.dl dd{margin:0}
.src a{margin-right:10px;font-size:13px}
.sect{margin:40px 0 0;padding:24px;border-radius:22px;background:#fff;border:1px solid var(--line)}.sect h2{margin:0 0 6px;font-size:22px;letter-spacing:-.015em}.sect h3{margin:18px 0 8px;font-size:13px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}
.chips{display:flex;flex-wrap:wrap;gap:8px;list-style:none;margin:0;padding:0}.chips a{display:inline-block;padding:7px 12px;border-radius:999px;background:#eef8f6;color:#0a5f5a;font-weight:700;font-size:13.5px;text-decoration:none}
.chips a span{color:#6f9097;font-weight:600}.chips a:hover{background:#dff2ee}
.how{font-size:14px;color:var(--muted)}footer{margin:40px 0 0;padding:24px 0 40px;border-top:1px solid var(--line);font-size:13.5px;color:var(--muted)}footer a{color:var(--muted)}
.eds{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin:24px 0 0}.ed{background:#fff;border:1px solid var(--line);border-radius:20px;padding:18px;display:flex;flex-direction:column;box-shadow:0 10px 30px rgba(6,50,58,.06)}
.ed .tag{font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}.ed h2{margin:4px 0 10px;font-size:19px}.ed h2 a{color:var(--ink);text-decoration:none}
.ed ol{list-style:none;margin:0;padding:0}.ed li{border-top:1px solid #eef4f3;font-size:14.5px;line-height:1.35}.ed li a.row{display:grid;grid-template-columns:24px 30px 1fr;align-items:start;padding:9px 4px;color:inherit;text-decoration:none;border-radius:10px}.ed li a.row:hover{background:#f1f8f7}.ed li a.row:hover b{text-decoration:underline}.ed .ic{font-size:20px;line-height:1}.ed li b{font-weight:700}.ed li small{display:block;color:var(--muted);font-size:12.5px}
.ed li .n{font-weight:800;color:var(--brand)}.ed .go{margin-top:auto;padding-top:10px;font-weight:800;text-decoration:none}
@media(max-width:820px){.eds{grid-template-columns:1fr}}
@media(max-width:700px){.wrap{padding:0 14px}.bar .wrap{height:56px}.logo span{display:none}.nav{gap:4px}.nav a{padding:0 10px;font-size:13px;height:36px}.nav .l{display:none}.nav .s{display:inline}.logo img{height:38px;width:auto}.pickers{display:none}.pick1{display:block}.facts li:nth-child(n+4){display:none}.hero{padding:24px 0 22px}
.card{grid-template-columns:44px 1fr;grid-template-areas:'ph ph' 'rk bd';padding:14px;gap:10px 12px}.ph{height:170px}.rank{width:42px;height:42px;font-size:17px;border-radius:13px}.card h2{font-size:18.5px}.mstrip{grid-template-columns:repeat(12,minmax(0,1fr))}.months{display:block}.mtxt{display:block;margin-top:6px}
.dl{grid-template-columns:1fr}.dl dt{margin-top:6px}.sect{padding:18px}}"""

CSS += '.fl{width:20px;height:15px;border-radius:3px;vertical-align:-2px;margin-right:5px;box-shadow:0 0 0 1px rgba(0,0,0,.1);object-fit:cover}'
def bar(active):
    items = [('/', '🔍', 'Search map', 'map'), ('/rankings', '🏆', 'Rankings', 'rk'), ('/explore', '🌍', 'Explore', 'ex')]
    return ('<header class="bar"><div class="wrap"><a class="logo" href="/" aria-label="DipMapper home"><img src="' + LOGO_HD + '" alt="DipMapper – Find your next swim"></a><nav class="nav">' +
            ''.join('<a href="%s"%s><i>%s</i> <span class="l">%s</span><span class="s">%s</span></a>' % (u, ' class="on"' if k == active else '', i, t, t.replace('Search map', 'Map')) for u, i, t, k in items) + '</nav></div></header>')
FOOT = ('<footer><div class="wrap">© DipMapper.com · Editorial selection from published sources; not first-hand reviews, visitor ratings or safety certificates; no paid placements. · '
        '<a href="/rankings">All rankings</a> · <a href="/imprint.html">Imprint</a> · <a href="/privacy.html">Privacy</a></div></footer>')

def months_html(r):
    lay = [l for l in r['guide_v4']['season'] if l.get('months')]
    ms = sorted({m for l in lay for m in l['months']})
    strip = '<span class="mstrip" aria-hidden="true">' + ''.join('<i class="%s%s">%s</i>' % ('y' if (i + 1) in ms else '', ' now' if i + 1 == NOWM else '', MON[i]) for i in range(12)) + '</span>'
    if not ms:
        return '<div class="months">' + strip + '<span class="mtxt none">Season not confirmed – check with the operator</span></div>', ''
    txt = 'All year' if len(ms) == 12 else 'Best ' + ', '.join(MONL[m - 1] for m in ms)
    return '<div class="months">' + strip + '<span class="mtxt">' + esc(txt) + ('' if len(ms) == 12 else (' · in season now' if NOWM in ms else '')) + '</span></div>', ' '.join(str(m) for m in ms)

from urllib.parse import quote as _q
def getting_there(r):
    t = (r.get('departure_text') or '').strip(); st = r.get('departure_status') or ''; note_extra = ''
    cn = ((r.get('guide_v4') or {}).get('location') or {}).get('countries') or []
    cn = cn[0] if cn else ''
    area = (r.get('area') or '').strip()
    if st == 'not_a_departure' or not t or t == 'None':
        place = area
    else:
        place = re.split(r';|\. (?=[A-Z])', t)[0].strip().rstrip('.')
        place = re.sub(r'\s*,?\s*(exact .*|confirm .*)$', '', place, flags=re.I).strip()
        place = re.sub(r'^(rental points at|meeting point at|departs from)\s+', '', place, flags=re.I)
        if re.search(r'transfer|confirmed|operator|verified|^confirm|viewpoints|gateway', place, re.I):
            m_ = re.match(r'([A-Z][\w\u00C0-\u017F-]+(?: [A-Z][\w\u00C0-\u017F-]+)*)', place)
            first = m_.group(1) if m_ and m_.group(1).lower() not in ('confirm', 'public', 'main', 'the') else ''
            if not st == 'not_verified': note_extra = 'The operator sets the exact pier or meeting place – confirm it when you book.'
            place = first or area
    if st == 'not_a_departure' and r.get('name') and area and area.lower() not in r['name'].lower(): place = r['name'] + ', ' + area
    if not place: place = area
    if not place: return None
    q = place if (not cn or cn.lower() in place.lower()) else place + ', ' + cn
    note = {'operator_confirmation_required': 'Confirm the exact pier or meeting point with your operator when you book.',
            'venue_address_context_not_entrance_pin': "Follow the venue's own directions for the entrance.",
            'not_a_departure': 'Public area – check local access and parking.',
            'not_verified': 'Starting point not confirmed yet – ask the operator.'}.get(st, '')
    if note_extra: note = note_extra
    if st == 'not_verified' or (st != 'not_a_departure' and (not t or t == 'None')): label = 'Area'
    elif st == 'not_a_departure': label = 'Where'
    else: label = 'Starts from'
    return {'label': label, 'place': q, 'note': note, 'url': 'https://www.google.com/maps/dir/?api=1&destination=' + _q(q)}

def card(r, rank, aq):
    g = r['guide_v4']; c = g['contact']; loc = g['location']
    mh, mdata = months_html(r)
    acts = []
    if ok_url(c.get('official_page')): acts.append('<a class="main" href="%s" target="_blank" rel="noopener">Official site ↗</a>' % esc(c['official_page'], True))
    for b in g['booking_actions']:
        if ok_url(b.get('url')) and b['url'] != c.get('official_page'): acts.append('<a href="%s" target="_blank" rel="noopener">%s ↗</a>' % (esc(b['url'], True), esc(b['label'])))
    _gt = getting_there(r)
    if _gt: acts.append('<a href="%s" target="_blank" rel="noopener">🧭 Route</a>' % esc(_gt['url'], True))
    for p in (c.get('phones') or [])[:1]: acts.append('<a href="tel:%s">📞 %s</a>' % (esc(re.sub(r'[^+\d]', '', p)), esc(p)))
    for e in (c.get('emails') or [])[:1]: acts.append('<a href="mailto:%s">✉ E-mail</a>' % esc(e, True))
    why = clean(g['why_go'], clean(g['description'])); desc = clean(g['description'])
    dl = []
    if desc and desc.strip() != why.strip(): dl.append(('What it is', esc(desc)))
    if g['key_attractions']: dl.append(('Highlights', esc(' · '.join(g['key_attractions']))))
    seas = []
    for l in g['season']:
        if l.get('months'):
            s_ = src.get(l.get('source_id'), {})
            seas.append(esc(l['label'].replace('_', ' ').capitalize() + ': ' + l['month_text'] + '. ' + clean(l.get('explanation', ''))) + (' <a href="%s" target="_blank" rel="noopener">source</a>' % esc(s_['url'], True) if ok_url(s_.get('url')) else ''))
    dl.append(('Season', '<br>'.join(seas) if seas else 'Not confirmed in published sources yet. Ask the operator before you plan around a date.'))
    prices = []
    for q in g['price_references']:
        if q.get('amount') is None: continue
        v = '%s %g' % (q['currency'], q['amount']) if isinstance(q['amount'], (int, float)) else str(q['amount'])
        prices.append(esc(v + (' / ' + q['unit'].replace('_', ' ') if q.get('unit') else '')) + (' (as of %s)' % esc(q['reference_date']) if q.get('reference_date') else ''))
    dl.append(('Prices', '<br>'.join(prices) if prices else 'Not published here – see the official site. No price shown does not mean free.'))
    if _gt: dl.append(('Getting there', '%s: %s. %s <a href="%s" target="_blank" rel="noopener">Route in Google Maps from where you are</a>' % (esc(_gt['label']), esc(_gt['place']), esc(_gt['note']), esc(_gt['url'], True))))
    dl.append(('Plan around', esc(clean(g.get('planning_caveat'), 'Check conditions, access and opening with the operator before you go.'))))
    contact = []
    if c.get('phones'): contact.append('Phone: ' + esc('; '.join(c['phones'])))
    if c.get('emails'): contact.append('E-mail: ' + esc('; '.join(c['emails'])))
    if ok_url(c.get('official_page')): contact.append('<a href="%s" target="_blank" rel="noopener">Official visitor page</a>' % esc(c['official_page'], True))
    dl.append(('Contact', '<br>'.join(contact)))
    seen_u = set()
    links = ' '.join('<a href="%s" target="_blank" rel="noopener">%s</a>' % (esc(src[x]['url'], True), esc(src[x].get('publisher') or 'source')) for x in dict.fromkeys(g['source_ids']) if x in src and ok_url(src[x].get('url')) and src[x]['url'] not in seen_u and not seen_u.add(src[x]['url']))
    if links: dl.append(('Sources', '<span class="src">' + links + '</span>'))
    notes = ''.join('<p class="notice"><b>Check before you go:</b> %s</p>' % esc(clean(x['text'], 'Published restriction – check with the operator.')) for x in restr.get(r['id'], []))
    rk = ('<div class="rank star">★</div>' if rank is None else '<div class="rank%s">%s</div>' % (' top' if rank <= 3 else '', rank))
    area = loc.get('area') or ''; ctry = ', '.join(loc.get('countries') or [])
    body = ('<div class="kick"><span class="pill">%s</span>%s</div><h2>%s</h2><p class="why">%s</p>%s%s<div class="acts">%s</div>%s'
            '<details class="more"><summary>Details, prices, season and sources</summary><dl class="dl">%s</dl></details>') % (
        ico(r) + ' ' + esc(ACT.get(r['primary_activity'], r['primary_activity'].replace('_', ' ').capitalize())), ''.join(flg(c) for c in r['country_codes'][:2]) + esc(' · '.join(x for x in (area, ctry) if x)), esc(r['name']), esc(why), mh, (('<p class="gt"><span aria-hidden="true">🚩</span> <b>%s:</b> %s%s</p>' % (_gt['label'], esc(_gt['place']), (' <small>' + esc(_gt['note']) + '</small>') if _gt['note'] else '')) if _gt else ''), ''.join(acts), notes,
        ''.join('<dt>%s</dt><dd>%s</dd>' % (x, y) for x, y in dl))
    pl = ((r.get('geo_v3') or {}).get('plot') or {})
    fig = '<figure class="ph"%s><span class="pi">%s</span></figure>' % ((' data-id="%s" data-q="%s" data-la="%s" data-lo="%s"' % (esc(r['id'], True), esc(r['name'] + ' ' + area, True), pl['latitude'], pl['longitude'])) if pl.get('latitude') is not None else '', ico(r))
    return '<li class="card" id="%s" data-m="%s">%s%s<div class="bd">%s</div></li>' % (esc(r['id'], True), mdata, fig, rk, body)

# ---------- read every ranking page (order, ranks, copy) from the live 23.11.0 files ----------
pages = []
for f in sorted(os.listdir(SRC)):
    if not f.endswith('.html'): continue
    s = open(SRC + '/' + f, encoding='utf8').read()
    if 'DIPMAPPER EDITORIAL EDITION' not in s: continue
    slug = f[:-5]
    title = html.unescape(re.search(r'<h1>(.*?)</h1>', s, re.S).group(1))
    desc = html.unescape(re.search(r'<meta name="description" content="([^"]*)"', s).group(1))
    ps = re.findall(r'</h1><p>(.*?)</p><p>(.*?)</p>', s, re.S)
    intro, trade = (html.unescape(ps[0][0]), html.unescape(ps[0][1])) if ps else (desc, '')
    ents = re.findall(r'<li id="([^"]+)"><article><p class="kicker">.*?</p><h2>(#\d+ )?', s, re.S)
    pages.append({'slug': slug, 'title': title, 'desc': desc, 'intro': intro, 'trade': trade, 'ents': [(i, int(n[1:-1]) if n else None) for i, n in ents], 'aq': 'aquarium' in slug})
assert len(pages) >= 70, len(pages)
hub = open(SRC + '/rankings.html', encoding='utf8').read()
def grp(label):
    m = re.search(r'<b>' + label + r'</b></p><ul class="chips">(.*?)</ul>', hub, re.S)
    return [(a, html.unescape(b), int(c)) for a, b, c in re.findall(r'<a href="/([a-z0-9-]+)">([^<]+?) <span>\((\d+)\)</span></a>', m.group(1))]
G = [('By activity', grp('By activity')), ('By country', grp('By country')), ('By sea, lake and region', grp('By sea, lake and region'))]
EDS = [('top-water-experiences', 'Top 200 water experiences', 200), ('best-public-aquariums', 'Top 100 public aquariums', 100), ('new-curated-discoveries', '147 new discoveries', 147)]
def pickers():
    one = ('<label class="pick1"><span>Jump to a ranking</span><select onchange="if(this.value)location.href=this.value"><option value="">Choose a country, sea, lake or activity…</option>' +
           ''.join('<optgroup label="%s">%s</optgroup>' % (l, ''.join('<option value="/%s">%s (%d)</option>' % (a, esc(b), n) for a, b, n in items)) for l, items in G) + '</select></label>')
    return one + pickers3()
def pickers3():
    return '<div class="pickers">' + ''.join('<label><span>%s</span><select onchange="if(this.value)location.href=this.value"><option value="">Choose…</option>%s</select></label>' % (
        l.replace('By sea, lake and region', 'By sea, lake or region'), ''.join('<option value="/%s">%s (%d)</option>' % (a, esc(b), n) for a, b, n in items)) for l, items in G) + '</div>'
def more(skip=None):
    return ('<section class="sect"><h2>More rankings</h2>' + '<h3>Editions</h3><ul class="chips">' + ''.join('<li><a href="/%s">%s</a></li>' % (a, esc(b)) for a, b, n in EDS if a != skip) + '</ul>' +
            ''.join('<h3>%s</h3><ul class="chips">%s</ul>' % (l, ''.join('<li><a href="/%s">%s <span>%d</span></a></li>' % (a, esc(b), n) for a, b, n in items if a != skip)) for l, items in G) + '</section>')
HOW = ('<details class="sect how"><summary><b>How we rank</b></summary><p>Each pick is judged by our editors on setting (40 %), distinctiveness (35 %) and depth of the experience (25 %), from published sources. '
       'Equal scores share a rank. The aquarium list is a separate editorial order. These are desk-researched selections, not first-hand reviews, visitor ratings or safety certificates, and nobody pays to be listed. '
       'Seasons are typical windows, not live forecasts or opening guarantees.</p></details>')
FILTER_JS = ("<script>(function(){var b=document.querySelectorAll('.seg button'),c=document.querySelectorAll('.card'),n=document.querySelector('.count');function f(m){var k=0;c.forEach(function(x){var s=(x.getAttribute('data-m')||'').split(' ');"
             "var v=m==='all'||s.indexOf('" + str(NOWM) + "')>=0;x.hidden=!v;if(v)k++});if(n)n.textContent=k+' shown';b.forEach(function(y){y.classList.toggle('on',y.getAttribute('data-f')===m)})}"
             "b.forEach(function(y){y.onclick=function(){f(y.getAttribute('data-f'))}})})();</script>")
PHOTO_JS = ("<script>(function(){if(!('IntersectionObserver' in window))return;var K='dm_ph2_';"+"function okPh(p,d,q){if(d>=40)return false;if(/map|flag|logo|locator|coat.of.arms|\\.svg|diagram|chart|icon/i.test(p.thumbnail.source+' '+p.title))return false;var G=/^(the|and|of|de|la|el|island|islands|bay|beach|park|national|lake|river|reef|tour|trip|boat|day|dive|diving|snorkelling|snorkeling|whale|watching|cruise|kayak|kayaking|seasonal|excursion|scenic|water|experience|discovery|outing|aquarium|thermal|bath|baths|sea)$/;var w=String(q).toLowerCase().split(/[^a-z0-9\\u00c0-\\u024f]+/).filter(function(x){return x.length>2&&!G.test(x)}),t=String(p.title).toLowerCase();return d<3||w.some(function(x){return t.indexOf(x)>=0})}"+"function km(a,b,c,d){var r=Math.PI/180,x=Math.sin((c-a)*r/2),y=Math.sin((d-b)*r/2);return 12742*Math.asin(Math.sqrt(x*x+Math.cos(a*r)*Math.cos(c*r)*y*y))}"
 "function set(f,d){if(!d||!d.u)return;var i=new Image();i.alt='';i.decoding='async';i.onload=function(){f.classList.add('has')};i.src=d.u;f.appendChild(i);var a=document.createElement('a');a.className='cr';a.href=d.p;a.target='_blank';a.rel='noopener';a.textContent='Photo: Wikipedia';f.appendChild(a)}"
 "function load(f){var k=K+f.getAttribute('data-id');try{var c=localStorage.getItem(k);if(c){set(f,JSON.parse(c));return}}catch(e){}var la=+f.getAttribute('data-la'),lo=+f.getAttribute('data-lo');"
 "fetch('https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=4&prop=pageimages|coordinates|info&inprop=url&piprop=thumbnail&pithumbsize=640&format=json&origin=*&gsrsearch='+encodeURIComponent(f.getAttribute('data-q'))).then(function(r){return r.json()}).then(function(j){"
 "var ps=j.query&&j.query.pages?Object.keys(j.query.pages).map(function(x){return j.query.pages[x]}).sort(function(a,b){return a.index-b.index}):[],best=null;"
 "ps.forEach(function(p){if(best||!p.thumbnail||!p.coordinates)return;var c=p.coordinates[0];if(okPh(p,km(la,lo,c.lat,c.lon),f.getAttribute('data-q')))best={u:p.thumbnail.source,p:p.fullurl}});"
 "try{localStorage.setItem(k,JSON.stringify(best||{}))}catch(e){}set(f,best)}).catch(function(){})}"
 "var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){io.unobserve(e.target);load(e.target)}})},{rootMargin:'400px'});"
 "document.querySelectorAll('figure.ph[data-q]').forEach(function(f){io.observe(f)})})();</script>")

def head(title, desc, url, ld):
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + esc(title) + '</title>'
            '<meta name="description" content="' + esc(desc[:300], True) + '"><link rel="canonical" href="' + url + '">' + ICON_LINK +
            '<meta property="og:type" content="website"><meta property="og:site_name" content="DipMapper"><meta property="og:title" content="' + esc(title, True) + '"><meta property="og:description" content="' + esc(desc[:300], True) +
            '"><meta property="og:url" content="' + url + '"><meta name="theme-color" content="#06323a"><style>' + CSS + '</style><script type="application/ld+json">' + json.dumps(ld, ensure_ascii=False).replace('<', '\\u003c') + '</script></head><body>')

pagefor = {}
for p_ in pages:
    for i_, n_ in p_['ents']: pagefor.setdefault(i_, p_['slug'])
for p in pages:
    url = 'https://dipmapper.com/' + p['slug']
    recs = [(by[i], n) for i, n in p['ents'] if i in by]
    cc = len({c for r, n in recs for c in r['country_codes']})
    now = sum(1 for r, n in recs if any(NOWM in (l.get('months') or []) for l in r['guide_v4']['season']))
    ld = {'@context': 'https://schema.org', '@type': 'ItemList', 'name': p['title'], 'numberOfItems': len(recs),
          'itemListElement': [{'@type': 'ListItem', 'position': k + 1, 'name': r['name'], 'url': url + '#' + r['id']} for k, (r, n) in enumerate(recs)]}
    bc = {'@context': 'https://schema.org', '@type': 'BreadcrumbList', 'itemListElement': [{'@type': 'ListItem', 'position': 1, 'name': 'DipMapper', 'item': 'https://dipmapper.com/'},
          {'@type': 'ListItem', 'position': 2, 'name': 'Rankings', 'item': 'https://dipmapper.com/rankings'}, {'@type': 'ListItem', 'position': 3, 'name': p['title'], 'item': url}]}
    body = (bar('rk') + '<section class="hero"><div class="wrap"><p class="crumb"><a href="/">DipMapper</a> › <a href="/rankings">Rankings</a> › ' + esc(p['title']) + '</p>'
            '<h1>' + esc(p['title']) + '</h1><p class="lead">' + esc(p['intro']) + '</p><ul class="facts"><li><b>%d</b> picks</li><li><b>%d</b> %s</li><li><b>%d</b> in season in November</li><li>Updated %s</li></ul>' % (
                len(recs), cc, 'country' if cc == 1 else 'countries', now, TODAY) + pickers() + '</div></section>'
            '<main class="wrap"><div class="tools"><div class="seg" role="group" aria-label="Filter"><button class="on" data-f="all">All picks</button><button data-f="now">In season now</button></div><span class="count">%d shown</span></div>' % len(recs) +
            '<ol class="cards">' + ''.join(card(r, n, p['aq']) for r, n in recs) + '</ol>' + ('<p class="how" style="margin-top:14px">' + esc(p['trade']) + '</p>' if p['trade'] else '') + more(p['slug']) + HOW + '</main>' + FOOT + FILTER_JS + PHOTO_JS + '</body></html>')
    html_ = head(p['title'] + ' | DipMapper', p['desc'], url, [ld, bc]) + body
    _m = BAD.search(re.sub(r'<[^>]+>', ' ', html_.split('<body>')[1])); assert not _m, (p['slug'], re.sub(r'<[^>]+>', ' ', html_.split('<body>')[1])[max(0,_m.start()-150):_m.end()+60])
    open(OUT + '/' + p['slug'] + '.html', 'w', encoding='utf8').write(html_)

# ---------- rankings hub ----------
snap = json.load(open(W + '/snap.json', encoding='utf8'))
held = {i for x in rules['restrictions'] for i in x['experience_ids']}
def top5(rows, aq=False):
    return '<ol>' + ''.join('<li><a class="row" href="/%s#%s"><span class="n">%s</span><span class="ic">%s</span><span><b>%s</b><small>%s%s</small></span></a></li>' % (
        pagefor.get(x['id'], 'rankings'), esc(x['id'], True), (x.get('aquarium_rank') if aq else x.get('position')) or '★', ico(by[x['id']]), esc(x['name']),
        ''.join(flg(c) for c in by[x['id']]['country_codes'][:1]), esc(', '.join(by[x['id']]['guide_v4']['location']['countries']))) for x in rows[:5]) + '</ol>'
_seen = set(); newp = []
for x in sorted([x for x in snap['new_research'] if x['id'] not in held], key=lambda x: -(by[x['id']]['assessment_v3'].get('score') or 0)):
    cc_ = (by[x['id']]['country_codes'] or [''])[0]
    if cc_ in _seen: continue
    _seen.add(cc_); newp.append(x)
eds = ''.join('<div class="ed"><span class="tag">%s</span><h2><a href="/%s">%s</a></h2>%s<a class="go" href="/%s">See all %d →</a></div>' % (t, s, h, l, s, n) for t, s, h, l, n in [
    ('Edition', 'top-water-experiences', 'Top 200 water experiences', top5(snap['top_200']), 200), ('Edition', 'best-public-aquariums', 'Top 100 public aquariums', top5(snap['aquarium_top_100'], True), 100),
    ('New · November 2026', 'new-curated-discoveries', '147 new discoveries', top5([dict(x, position=None) for x in newp]), 147)])
allp = [(a, b) for a, b, n in EDS] + [(a, b) for l, items in G for a, b, n in items]
ld = {'@context': 'https://schema.org', '@type': 'CollectionPage', 'name': 'Water rankings', 'url': 'https://dipmapper.com/rankings',
      'mainEntity': {'@type': 'ItemList', 'numberOfItems': len(allp), 'itemListElement': [{'@type': 'ListItem', 'position': k + 1, 'name': b, 'url': 'https://dipmapper.com/' + a} for k, (a, b) in enumerate(allp)]}}
rk_desc = 'The world\'s best water experiences, ranked: Top 200 water experiences, Top 100 public aquariums and 147 new discoveries, by activity, country, sea and lake – with seasons and official contacts.'
rk = (head('Water rankings: the world\'s best water experiences | DipMapper', rk_desc, 'https://dipmapper.com/rankings', ld) + bar('rk') +
      '<section class="hero"><div class="wrap"><p class="crumb"><a href="/">DipMapper</a> › Rankings</p><h1>The world\'s best water experiences</h1>'
      '<p class="lead">605 hand-written picks in 87 countries – whale watching, reefs, thermal baths, aquariums, water parks and more. Pick a country, a sea or lake, or an activity.</p>'
      '<ul class="facts"><li><b>605</b> picks</li><li><b>87</b> countries</li><li><b>%d</b> rankings</li><li>Updated %s</li></ul>' % (len(allp), TODAY) + pickers() + '</div></section>'
      '<main class="wrap"><div class="eds">' + eds + '</div>' + more() + HOW + '</main>' + FOOT + '</body></html>')
open(OUT + '/rankings.html', 'w', encoding='utf8').write(rk)

# ---------- home + explore: bold favicon, no emoji flags ----------
def fav(s):
    s = re.sub(r'<link rel="icon" type="image/png"[^>]*>', '', s)
    return s.replace('</title>', '</title>' + ICON_LINK, 1)
FLAG = re.compile('[\U0001F1E6-\U0001F1FF]{2} ?')
ix = open(SRC + '/index.html', encoding='utf8').read()
assert ix.count('data-version="v23.11.0"') == 1
ix = ix.replace('data-version="v23.11.0"', 'data-version="v23.12.0"').replace('DipMapper version 23.11.0</p>', 'DipMapper version 23.12.0</p>')
a = ix.find('<section class="dmTopR"'); b = ix.find('</section>', a)
ix = ix[:a] + FLAG.sub('', ix[a:b]) + ix[b:]
ix = fav(ix)
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
ex = fav(open(SRC + '/explore.html', encoding='utf8').read())
ex = ex.replace("'<li><span>'+flag(c)+' '+", "'<li><span>'+")
open(OUT + '/explore.html', 'w', encoding='utf8').write(ex)
print('pages', len(pages), 'hub ok', os.path.getsize(OUT + '/whale-watch.html'), os.path.getsize(OUT + '/top-water-experiences.html'))

# ---------- explore: replace been-globe with "top attractions near you" ----------
ex = open(OUT + '/explore.html', encoding='utf8').read()
a = ex.index('<section id="been"'); b = ex.index('</section>', a) + len('</section>')
NEAR = ('<section id="near" class="nearWrap" aria-labelledby="nearT"><div class="nearBox"><div class="nearHead"><div><p class="nearEye">Top attractions near you</p>'
        '<h2 id="nearT">What\'s worth it nearby?</h2><p>The best-rated DipMapper picks closest to you – or to any country you choose.</p></div>'
        '<div class="nearCtl"><button type="button" id="nearMe">📍 Use my location</button><select id="nearCountry" aria-label="Or choose a country"><option value="">or choose a country…</option></select></div></div>'
        '<p class="nearStatus" id="nearStatus" role="status"></p><ol class="nearList" id="nearList"></ol></div></section>')
ex = ex[:a] + NEAR + ex[b:]
ex = ex.replace('<section id="near"', '<section id="been" hidden></section><section id="near"', 1)  # old #been links still land here
ex = re.sub(r'<script>window\.__DM_WORLD=.*?</script><script>\(function\(\)\{\n\'use strict\';.*?window\.__dmBeen=.*?\}\)\(\);\n</script>', '', ex, count=1, flags=re.S)
assert '__DM_WORLD' not in ex and '__dmBeen' not in ex, 'been code still present'
NCSS = ('<style>.nearWrap{max-width:1320px;margin:0 auto;padding:0 20px;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;color:#06323a}'
 '.nearBox{padding:24px;border-radius:24px;background:radial-gradient(120% 140% at 0% 0%,#063a46,#0a5f6c 55%,#0e8c8f);color:#eafffb;box-shadow:0 16px 40px rgba(6,58,70,.22)}'
 '.nearHead{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap}.nearEye{margin:0;font-size:11.5px;letter-spacing:.12em;text-transform:uppercase;font-weight:800;color:#8ff0e2}'
 '.nearHead h2{margin:6px 0 4px;font-size:clamp(24px,3.2vw,34px);color:#fff;letter-spacing:-.02em}.nearHead p{margin:0;color:#cdeee9}'
 '.nearCtl{display:flex;gap:8px;flex-wrap:wrap}.nearCtl button{height:46px;padding:0 18px;border-radius:12px;border:0;background:#14b8a6;color:#fff;font:800 15px system-ui,sans-serif;cursor:pointer}'
 '.nearCtl select{height:46px;border-radius:12px;border:0;padding:0 10px;font:600 15px system-ui,sans-serif;max-width:260px}'
 '.nearStatus{margin:14px 0 0;color:#bfe7e1;font-size:14px}.nearList{list-style:none;margin:14px 0 0;padding:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}'
 '.nearList li{background:#fff;color:#06323a;border-radius:18px;padding:14px 16px;display:flex;flex-direction:column;gap:4px}.nearList .k{font-size:12px;font-weight:700;color:#5d7b83}'
 '.nearList h3{margin:0;font-size:16.5px;line-height:1.25}.nearList p{margin:0;font-size:13.5px;color:#36585f}.nearList .d{font-weight:800;color:#0a8a84;font-size:13px}'
 '.nearList .l{margin-top:auto;display:flex;gap:6px;flex-wrap:wrap;padding-top:6px}.nearList .l a{font-size:13px;font-weight:700;padding:6px 10px;border-radius:10px;border:1px solid #cfe5e1;text-decoration:none;color:#0a6f69}'
 '@media(max-width:900px){.nearList{grid-template-columns:1fr}.nearWrap{padding:0 12px}.nearBox{padding:18px}.nearCtl,.nearCtl button,.nearCtl select{width:100%;max-width:none}}</style>')
ex = re.sub(r'<style>\nbody\{background:#fff\}\.dmX\{.*?</style>', lambda m: m.group(0).split('.dmBeenWrap')[0].rstrip() + '\n</style>' + NCSS, ex, count=1, flags=re.S)
assert '.nearBox' in ex and '.dmBeenWrap' not in ex
NJS = r'''<script>(function(){var P=null,L=document.getElementById('nearList'),S=document.getElementById('nearStatus'),C=document.getElementById('nearCountry');
function E(t){return String(t==null?'':t).replace(/[&<>"]/g,function(m){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]})}
function km(a,b,c,d){var r=Math.PI/180,x=Math.sin((c-a)*r/2),y=Math.sin((d-b)*r/2);return 12742*Math.asin(Math.sqrt(x*x+Math.cos(a*r)*Math.cos(c*r)*y*y))}
function get(cb){if(P)return cb();S.textContent='Loading picks…';fetch('/picks.json').then(function(r){return r.json()}).then(function(j){P=j;var cs={};P.forEach(function(p){if(p.c)cs[p.c]=(cs[p.c]||0)+1});
 Object.keys(cs).sort().forEach(function(c){var o=document.createElement('option');o.value=c;o.textContent=c+' ('+cs[c]+')';C.appendChild(o)});cb()}).catch(function(){S.textContent='Could not load the picks. Please reload.'})}
function show(rows,label){S.textContent=label;L.innerHTML=rows.map(function(x){var p=x[1];return'<li><span class="k">'+E(p.a)+' · '+E(p.c)+(p.ar?' · '+E(p.ar):'')+'</span><h3>'+E(p.n)+'</h3>'+(x[0]!=null?'<span class="d">'+(x[0]<1?'here':Math.round(x[0])+' km away')+'</span>':'')+'<p>'+E(p.w)+'</p><p><b>Season:</b> '+E(p.se)+'</p><div class="l">'+(p.u?'<a href="'+E(p.u)+'" target="_blank" rel="noopener">Official site</a>':'')+(p.p?'<a href="tel:'+E(p.p.replace(/[^+\d]/g,''))+'">Call</a>':'')+'<a href="/'+E(p.pg)+'#'+E(p.id)+'">Full card</a></div></li>'}).join('')}
document.getElementById('nearMe').onclick=function(){get(function(){if(!navigator.geolocation){S.textContent='Location is not available here – choose a country instead.';return}S.textContent='Finding your location…';
 navigator.geolocation.getCurrentPosition(function(g){var a=g.coords.latitude,b=g.coords.longitude;var r=P.map(function(p){return[km(a,b,p.la,p.lo),p]}).sort(function(x,y){return x[0]-y[0]}).slice(0,12);
  show(r,'The 12 closest top picks to you. Positions are approximate areas, not entrances.')},function(){S.textContent='Location was not shared – choose a country instead.'},{timeout:10000,maximumAge:600000})})};
C.onchange=function(){var c=C.value;if(!c)return;get(function(){var r=P.filter(function(p){return p.c===c}).sort(function(x,y){return y.s-x.s}).slice(0,12).map(function(p){return[null,p]});show(r,'Top picks in '+c+', best first.')})};
get(function(){S.textContent='Tap "Use my location", or choose a country.'});})();</script>'''
ex = ex.replace('</body></html>', NJS + '</body></html>', 1)
open(OUT + '/explore.html', 'w', encoding='utf8').write(ex)
# home: globe links become "near me"
ix = open(OUT + '/index.html', encoding='utf8').read()
for a_, b_ in [('<a href="/explore#been"><b>🌍 Your globe</b><small>Mark where you have been</small></a>', '<a href="/explore#near"><b>📍 Near me</b><small>Top attractions close to you</small></a>'),
               ('<a class="dmTopRCta alt" href="/explore#been">🌍 Your been-there globe</a>', '<a class="dmTopRCta alt" href="/explore#near">📍 Top picks near me</a>')]:
    assert ix.count(a_) == 1, a_[:40]; ix = ix.replace(a_, b_)
ix = re.sub(r', and <a href="/explore#been">your globe</a> colours in every country you have been to\.', '.', ix)
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
print('explore/near ok', os.path.getsize(OUT + '/explore.html'))

# picks.json: same clean-up for the map popups / near-me list
pk = json.load(open(SRC + '/picks.json', encoding='utf8'))
def pseason(r):
    ms = sorted({m for l in r['guide_v4']['season'] for m in (l.get('months') or [])})
    return 'Season not confirmed – check with the operator' if not ms else ('All year' if len(ms) == 12 else 'Best ' + ', '.join(MONL[m - 1] for m in ms))
for x in pk: x['se'] = pseason(by[x['id']]); x['a'] = ACT.get(by[x['id']]['primary_activity'], by[x['id']]['primary_activity'].replace('_', ' ').capitalize())
for x in pk: x['w'] = clean(by[x['id']]['guide_v4']['why_go'], clean(by[x['id']]['guide_v4']['description']))[:260]
json.dump(pk, open(OUT + '/picks.json', 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))
print('picks cleaned', len(pk))

# ================= 23.13.0 additions =================
pagefor = {}
for p in pages:
    for i, n in p['ents']: pagefor.setdefault(i, p['slug'])
def mset(r): return sorted({m for l in r['guide_v4']['season'] for m in (l.get('months') or [])})
def score(r): return r['assessment_v3'].get('score') or 0
def mini(r):
    ms = mset(r); strip = '<span class="mstrip">' + ''.join('<i class="%s">%s</i>' % ('y' if i + 1 in ms else '', MON[i]) for i in range(12)) + '</span>'
    return ('<li class="mini"><span class="mi">%s</span><span class="mt"><a href="/%s#%s"><b>%s</b></a><small>%s · %s</small>%s</span></li>' % (
        ico(r), pagefor.get(r['id'], 'rankings'), esc(r['id'], True), esc(r['name']), esc(ACT.get(r['primary_activity'], r['primary_activity'].replace('_', ' ').capitalize())),
        ''.join(flg(c) for c in r['country_codes'][:1]) + esc(', '.join(r['guide_v4']['location']['countries'])), strip))
MINI_CSS = ('.monthgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-top:22px}.mcard{background:#fff;border:1px solid var(--line);border-radius:20px;padding:18px}'
            '.mcard.now{border:2px solid var(--brand)}.mcard h2{margin:0 0 6px;font-size:20px}.mcard h2 span{font-size:12px;font-weight:800;color:#fff;background:var(--brand);border-radius:999px;padding:3px 8px;margin-left:8px;vertical-align:middle}'
            '.mcard ol{list-style:none;margin:0;padding:0}.mini{display:grid;grid-template-columns:38px 1fr;gap:10px;padding:10px 0;border-top:1px solid #eef4f3}.mi{font-size:26px;line-height:1}'
            '.mt a{color:var(--ink);text-decoration:none}.mt a:hover{text-decoration:underline}.mt small{display:block;color:var(--muted);font-size:12.5px;margin:2px 0 6px}.mini .mstrip{grid-template-columns:repeat(12,16px)}.mini .mstrip i{height:16px;font-size:8px;line-height:16px;border-radius:4px}'
            '@media(max-width:820px){.monthgrid{grid-template-columns:1fr}}')
RECS = [r for r in cat['records'] if r['id'] in pagefor]
# --- best by month ---
months_html_ = ''
for m in range(1, 13):
    pick = sorted([r for r in RECS if m in mset(r) and len(mset(r)) < 12], key=lambda r: -score(r))[:8]
    months_html_ += '<section class="mcard%s" id="%s"><h2>%s%s</h2><ol>%s</ol></section>' % (' now' if m == NOWM else '', MONL[m - 1].lower(), ['January','February','March','April','May','June','July','August','September','October','November','December'][m - 1],
                                                                                        '<span>now</span>' if m == NOWM else '', ''.join(mini(r) for r in pick))
url = 'https://dipmapper.com/best-water-experiences-by-month'
d_ = 'When to go: the best seasonal water experiences for every month – whale migrations, reef seasons, summer lake cruises and more, with month-by-month season strips.'
ld = {'@context': 'https://schema.org', '@type': 'CollectionPage', 'name': 'Best water experiences by month', 'url': url, 'description': d_}
pg = (head('Best water experiences by month: when to go | DipMapper', d_, url, ld).replace('</style>', MINI_CSS + '</style>', 1) + bar('rk') +
      '<section class="hero"><div class="wrap"><p class="crumb"><a href="/">DipMapper</a> › <a href="/rankings">Rankings</a> › By month</p><h1>When to go: the best for every month</h1>'
      '<p class="lead">Seasonal highlights only – whale migrations, reef seasons, summer cruises. Year-round places are in the other rankings.</p>' + pickers() + '</div></section>'
      '<main class="wrap"><div class="monthgrid">' + months_html_ + '</div>' + more() + HOW + '</main>' + FOOT + '</body></html>')
open(OUT + '/best-water-experiences-by-month.html', 'w', encoding='utf8').write(pg)
# --- rainy day / indoor ---
indoor = sorted([r for r in RECS if r['primary_activity'] in ('aquarium', 'thermal_bath', 'sauna_swim')], key=lambda r: -score(r))[:40]
rows, last, rk_ = [], None, 0
for k, r in enumerate(indoor, 1):
    if score(r) != last: rk_, last = k, score(r)
    rows.append((r, rk_))
url = 'https://dipmapper.com/rainy-day-water-experiences'
d_ = 'Rainy-day and winter water experiences: the best aquariums, thermal baths and sauna-and-swim places, with seasons, prices and official contacts.'
ld = {'@context': 'https://schema.org', '@type': 'ItemList', 'name': 'Rainy-day water experiences', 'numberOfItems': len(rows),
      'itemListElement': [{'@type': 'ListItem', 'position': k + 1, 'name': r['name'], 'url': url + '#' + r['id']} for k, (r, n) in enumerate(rows)]}
pg = (head('Rainy-day water experiences: aquariums, thermal baths, saunas | DipMapper', d_, url, ld) + bar('rk') +
      '<section class="hero"><div class="wrap"><p class="crumb"><a href="/">DipMapper</a> › <a href="/rankings">Rankings</a> › Rainy day</p><h1>Rainy-day water experiences</h1>'
      '<p class="lead">When the weather turns: the best aquariums, thermal baths and sauna-and-swim places in our selection.</p><ul class="facts"><li><b>%d</b> picks</li><li>🐠 aquariums</li><li>♨️ thermal baths</li><li>🧖 saunas</li></ul>' % len(rows) + pickers() + '</div></section>'
      '<main class="wrap"><ol class="cards">' + ''.join(card(r, n, False) for r, n in rows) + '</ol>' + more() + HOW + '</main>' + FOOT + PHOTO_JS + '</body></html>')
open(OUT + '/rainy-day-water-experiences.html', 'w', encoding='utf8').write(pg)
# --- wildlife & underwater calendar ---
WILD_ACT = {'whale_watch', 'marine_wildlife', 'wildlife_boat', 'marine_birds', 'shore_wildlife', 'turtle_watch', 'scuba', 'snorkel', 'snorkel_excursion', 'bioluminescence', 'glowworm_boat'}
KW = [('whale shark', '🦈', 'Whale sharks'), ('whale_shark', '🦈', 'Whale sharks'), ('shark', '🦈', 'Sharks'), ('manta', '🐟', 'Manta rays'), ('sunfish', '🐟', 'Ocean sunfish'),
      ('sardine', '🐟', 'Sardine run'), ('humpback', '🐋', 'Humpback whales'), ('gray whale', '🐋', 'Gray whales'), ('gray_whale', '🐋', 'Gray whales'), ('right_whale', '🐋', 'Southern right whales'),
      ('right whale', '🐋', 'Southern right whales'), ('minke', '🐋', 'Minke whales'), ('orca', '🐋', 'Orcas'), ('sperm', '🐋', 'Sperm whales'), ('blue whale', '🐋', 'Blue whales'),
      ('whale', '🐋', 'Whales'), ('cetacean', '🐬', 'Whales & dolphins'), ('dolphin', '🐬', 'Dolphins'), ('turtle', '🐢', 'Sea turtles'), ('manatee', '🦭', 'Manatees'), ('seal', '🦭', 'Seals'),
      ('puffin', '🐧', 'Puffins'), ('penguin', '🐧', 'Penguins'), ('seabird', '🐦', 'Seabirds'), ('gannet', '🐦', 'Seabirds'), ('coral', '🪸', 'Coral spawning'), ('cichlid', '🐠', 'Cichlids'),
      ('biolum', '✨', 'Bioluminescence'), ('glow', '✨', 'Bioluminescence'), ('visibility', '🤿', 'Best diving conditions'), ('reef', '🤿', 'Reef diving seasons'), ('dive', '🤿', 'Diving seasons'),
      ('diving', '🤿', 'Diving seasons'), ('snorkel', '🤿', 'Snorkelling seasons')]
def wild(r):
    lay = [l for l in r['guide_v4']['season'] if l.get('months') and len(l['months']) < 12]
    if not lay: return None
    txt = ' '.join([r['name']] + [l['label'] for l in lay] + r['guide_v4']['key_attractions']).lower()
    if r['primary_activity'] not in WILD_ACT and not any(k in txt for k, _, _ in KW[:30]): return None
    for k, e, g in KW:
        if k in txt: return (g, e, sorted({m for l in lay for m in l['months']}))
    return None
W_EV = []
for r in RECS:
    w = wild(r)
    if w: W_EV.append((w[0], w[1], w[2], r))
GROUPS = collections.OrderedDict()
for g, e, ms, r in sorted(W_EV, key=lambda x: -score(x[3])): GROUPS.setdefault((g, e), []).append((ms, r))
GROUPS = collections.OrderedDict(sorted(GROUPS.items(), key=lambda kv: (kv[0][1] == '🤿', -len(kv[1]))))
def wrow(ms, r, e):
    strip = '<span class="mstrip">' + ''.join('<i class="%s%s">%s</i>' % ('y' if i + 1 in ms else '', ' now' if i + 1 == NOWM else '', MON[i]) for i in range(12)) + '</span>'
    return ('<li class="mini"><span class="mi">%s</span><span class="mt"><a href="/%s#%s"><b>%s</b></a><small>%s%s · best %s</small>%s</span></li>' % (
        e, pagefor.get(r['id'], 'rankings'), esc(r['id'], True), esc(r['name']), ''.join(flg(c) for c in r['country_codes'][:1]), esc(', '.join(r['guide_v4']['location']['countries'])),
        esc(', '.join(MONL[m - 1] for m in ms)), strip))
NOW_EV = [(ms, r, e) for g, e, ms, r in W_EV if NOWM in ms]
NOW_EV.sort(key=lambda x: -score(x[1]))
def slug_(t): return re.sub(r'[^a-z0-9]+', '-', t.lower()).strip('-')
grp_html = ''.join('<section class="mcard" id="%s"><h2>%s %s <small class="cnt">%d</small></h2><ol>%s</ol></section>' % (
    slug_(g), e, esc(g), len(v), ''.join(wrow(ms, r, e) for ms, r in v)) for (g, e), v in GROUPS.items())
jump = '<ul class="chips" style="margin-top:18px">' + ''.join('<li><a href="#%s">%s %s <span>%d</span></a></li>' % (slug_(g), e, esc(g), len(v)) for (g, e), v in GROUPS.items()) + '</ul>'
now_html = '<section class="mcard now" id="now"><h2>Right now: November<span>now</span></h2><ol>' + ''.join(wrow(ms, r, e) for ms, r, e in NOW_EV[:12]) + '</ol></section>'
url = 'https://dipmapper.com/wildlife-calendar'
d_ = 'Wildlife and underwater calendar: when to see humpback, gray and right whales, whale sharks, mantas, turtles, seals, puffins and coral spawning – month by month, with operators and official sources.'
ld = {'@context': 'https://schema.org', '@type': 'ItemList', 'name': 'Wildlife and underwater calendar', 'numberOfItems': len(W_EV),
      'itemListElement': [{'@type': 'ListItem', 'position': k + 1, 'name': r['name'], 'url': 'https://dipmapper.com/%s#%s' % (pagefor.get(r['id'], 'rankings'), r['id'])} for k, (g, e, ms, r) in enumerate(W_EV)]}
pg = (head('Wildlife & underwater calendar: whales, sharks, mantas, turtles by month | DipMapper', d_, url, ld).replace('</style>', MINI_CSS + '.mcard .cnt{font-size:13px;color:var(--muted);font-weight:600}.mcard.now{margin-top:22px}.mstrip i.now{outline:2px solid var(--ink);outline-offset:1px}</style>', 1) + bar('rk') +
      '<section class="hero"><div class="wrap"><p class="crumb"><a href="/">DipMapper</a> › <a href="/rankings">Rankings</a> › Wildlife calendar</p><h1>Wildlife &amp; underwater calendar</h1>'
      '<p class="lead">When the whales pass, the whale sharks feed, the mantas gather, turtles nest and corals spawn – %d seasonal encounters worldwide, month by month.</p>'
      '<ul class="facts"><li><b>%d</b> encounters</li><li><b>%d</b> species groups</li><li><b>%d</b> in season now</li></ul>' % (len(W_EV), len(W_EV), len(GROUPS), len(NOW_EV)) + pickers() + '</div></section>'
      '<main class="wrap">' + jump + now_html + '<div class="monthgrid">' + grp_html + '</div>' + more() + HOW + '</main>' + FOOT + '</body></html>')
open(OUT + '/wildlife-calendar.html', 'w', encoding='utf8').write(pg)
print('wildlife events', len(W_EV), 'groups', len(GROUPS), 'now', len(NOW_EV))

COLL = [('wildlife-calendar', '🐋 Wildlife calendar'), ('best-water-experiences-by-month', '📅 Best by month'), ('rainy-day-water-experiences', '🌧️ Rainy-day picks')]
# collections into every ranking page's "More rankings" + hub
for f in os.listdir(OUT):
    if not f.endswith('.html') or f in ('index.html', 'explore.html'): continue
    t = open(OUT + '/' + f, encoding='utf8').read()
    if '<section class="sect"><h2>More rankings</h2><h3>Editions</h3><ul class="chips">' in t:
        t = t.replace('<section class="sect"><h2>More rankings</h2><h3>Editions</h3><ul class="chips">',
                      '<section class="sect"><h2>More rankings</h2><h3>Editions</h3><ul class="chips">' + ''.join('<li><a href="/%s">%s</a></li>' % c for c in COLL if c[0] + '.html' != f), 1)
        open(OUT + '/' + f, 'w', encoding='utf8').write(t)
# hub: best this month strip
hubt = open(OUT + '/rankings.html', encoding='utf8').read()
now = sorted([r for r in RECS if NOWM in mset(r) and len(mset(r)) < 12], key=lambda r: -score(r))[:6]
strip = ('<section class="sect"><h2>📅 Best right now: November</h2><p class="how">Seasonal highlights at their best this month. <a href="/best-water-experiences-by-month">All months →</a></p>'
         '<ol class="minigrid">' + ''.join(mini(r) for r in now) + '</ol></section>')
hubt = hubt.replace('</style>', MINI_CSS + '.minigrid{list-style:none;margin:10px 0 0;padding:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0 18px}@media(max-width:820px){.minigrid{grid-template-columns:1fr}}</style>', 1)
assert hubt.count('<section class="sect"><h2>More rankings</h2>') == 1
hubt = hubt.replace('<section class="sect"><h2>More rankings</h2>', strip + '<section class="sect"><h2>More rankings</h2>', 1)
open(OUT + '/rankings.html', 'w', encoding='utf8').write(hubt)

# ---------- one header everywhere: explore + guide/legal pages ----------
BAR_CSS = ('.bar{position:sticky;top:0;z-index:2000;background:rgba(255,255,255,.95);backdrop-filter:blur(10px);border-bottom:1px solid #e2eeec;font-family:Manrope,Inter,system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}'
           '.bar .wrap{max-width:1080px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;height:62px}'
           '.bar .logo{display:flex;align-items:center;gap:9px;font-weight:800;font-size:19px;color:#06323a;text-decoration:none}.bar .logo img{height:44px;width:auto;display:block}'
           '.bar .nav{display:flex;gap:6px;margin:0!important;font-size:14px}.bar .nav a{display:inline-flex;align-items:center;gap:6px;height:38px;padding:0 14px;border-radius:999px;font-weight:700;font-size:14px;text-decoration:none;color:#06323a;border:1px solid #e2eeec;background:#fff}'
           '.bar .nav a.on{background:#06323a;color:#fff;border-color:#06323a}.bar .nav i{font-style:normal}.bar .nav .s{display:none}'
           '@media(max-width:700px){.bar .wrap{padding:0 14px;height:56px}.bar .logo img{height:38px}.bar .nav{gap:4px}.bar .nav a{padding:0 10px;font-size:13px;height:36px}.bar .nav .l{display:none}.bar .nav .s{display:inline}}')
def unify(t, active):
    t = re.sub(r'<link rel="icon"[^>]*>', '', t)
    t = t.replace('</head>', ICON_LINK + '<style>' + BAR_CSS + '</style></head>', 1)
    return re.sub(r'(<body[^>]*>)', lambda m: m.group(1) + bar(active), t, count=1)
ex = open(OUT + '/explore.html', encoding='utf8').read()
ex = re.sub(r'<header class="dmX">.*?</header>', '', ex, count=1, flags=re.S)
ex = unify(ex, 'ex')
# near-me cards get activity icons
ex = ex.replace("'<li><span class=\"k\">'+E(p.a)", "'<li><span class=\"k\">'+(p.i?p.i+' ':'')+E(p.a)")
open(OUT + '/explore.html', 'w', encoding='utf8').write(ex)
GUIDES = ['activities', 'swim', 'zurich', 'meilen', 'miami', 'palma', 'rhodes', 'rostock', 'sup-lake-zurich', 'boat-rental-lake-zurich', 'diving-lake-zurich', 'sailing-lake-zurich',
          'surfing-switzerland', 'kitesurfing-switzerland', 'unique-water-experiences', 'water-sports-lake-zurich', 'imprint', 'privacy', 'cookies', 'terms', 'disclaimer', 'advertising', 'safety', 'sources']
for g in GUIDES:
    t = open(SRC + '/' + g + '.html', encoding='utf8').read()
    assert 'class="bar"' not in t
    open(OUT + '/' + g + '.html', 'w', encoding='utf8').write(unify(t, 'map'))
# picks.json: activity icon
pk = json.load(open(OUT + '/picks.json', encoding='utf8'))
for x in pk: x['i'] = ico(by[x['id']]); x['cc'] = (by[x['id']]['country_codes'] or [''])[0]
json.dump(pk, open(OUT + '/picks.json', 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))
# home: version
ix = open(OUT + '/index.html', encoding='utf8').read()
ix = ix.replace('data-version="v23.12.0"', 'data-version="v23.13.0"').replace('DipMapper version 23.12.0</p>', 'DipMapper version 23.13.0</p>')
assert ix.count("<h4>★ '+E(p.n)")==1; ix = ix.replace("<h4>★ '+E(p.n)", "<h4>'+(p.i||'★')+' '+E(p.n)")
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
# sitemap
sm = open(SRC + '/sitemap.xml', encoding='utf8').read()
sm = sm.replace('</urlset>', ''.join('  <url><loc>https://dipmapper.com/%s</loc><lastmod>2026-11-13</lastmod><changefreq>monthly</changefreq><priority>0.8</priority></url>\n' % c for c, _ in COLL) + '</urlset>')
open(OUT + '/sitemap.xml', 'w', encoding='utf8').write(sm)
print('23.13 additions ok', len(os.listdir(OUT)))

# ---------- home: rankings section rebuilt (clickable rows, icons, flags, wildlife, neutral) ----------
HUBI = {'swimming-discoveries': '🏊', 'scuba': '🤿', 'snorkel': '🤿', 'snorkel-excursion': '🚤', 'whale-watch': '🐋', 'kayak': '🛶', 'ferry': '⛴️', 'scenic-cruise': '🛳️', 'thermal-bath': '🌴', 'sauna-swim': '🧖', 'water-park': '💦', 'rafting': '🛶', 'beach': '🏖️', 'aquariums-in-shopping-malls': '🐠'}
def hrow(x, n):
    r = by[x['id']]
    return ('<li><a href="/%s#%s"><span class="n">%s</span><span class="ic">%s</span><span class="t"><b>%s</b><small>%s%s</small></span></a></li>' % (
        pagefor.get(r['id'], 'rankings'), esc(r['id'], True), n, ico(r), esc(r['name']), ''.join(flg(c) for c in r['country_codes'][:1]), esc(', '.join(r['guide_v4']['location']['countries']))))
cards = [('🏆', 'Top 200 water experiences', 'top-water-experiences', 200, [hrow(x, x.get('position')) for x in snap['top_200'][:5]]),
         ('🐠', 'Top 100 public aquariums', 'best-public-aquariums', 100, [hrow(x, x.get('aquarium_rank')) for x in snap['aquarium_top_100'][:5]]),
         ('✨', '147 new discoveries', 'new-curated-discoveries', 147, [hrow(x, '★') for x in newp[:5]])]
ix = open(OUT + '/index.html', encoding='utf8').read()
a = ix.find('<section class="dmTopR"'); b = ix.find('</section>', a) + len('</section>')
old = ix[a:b]
picker = re.search(r'<div class="dmTopRPick">.*?</select></label></div>', old, re.S).group(0)
acts_ = G[0][1]
home = ('<section class="dmTopR dmHx" id="rankings" aria-labelledby="dmTopRT"><div class="dmHxHead"><div><p class="dmHxEye">🏆 DipMapper rankings · 605 picks · 87 countries</p>'
        '<h2 id="dmTopRT">The world\'s best water experiences</h2><p>Hand-written picks with seasons, prices and official contacts – ranked by activity, country, sea and lake. Picks near your search show as ★ on the map.</p></div>'
        '<div class="dmHxCtas"><a class="dmHxCta" href="/rankings">All rankings →</a><a class="dmHxCta alt" href="/wildlife-calendar">🐋 Wildlife calendar</a><a class="dmHxCta alt" href="/explore#near">📍 Near me</a></div></div>'
        + picker + '<div class="dmHxGrid">' + ''.join('<div class="dmHxCard"><h3><a href="/%s"><span>%s</span> %s</a></h3><ol>%s</ol><a class="dmHxMore" href="/%s">See all %d →</a></div>' % (sl, ic, t, ''.join(rows), sl, n) for ic, t, sl, n, rows in cards) + '</div>'
        '<div class="dmHxNow"><h3>🐋 Under water &amp; wildlife this month</h3><ol>' + ''.join(
            '<li><a href="/%s#%s"><span class="ic">%s</span><span class="t"><b>%s</b><small>%s%s · best %s</small></span></a></li>' % (
                pagefor.get(r['id'], 'rankings'), esc(r['id'], True), e, esc(r['name']), ''.join(flg(c) for c in r['country_codes'][:1]), esc(', '.join(r['guide_v4']['location']['countries'])),
                esc(', '.join(MONL[m - 1] for m in ms))) for ms, r, e in NOW_EV[:6]) + '</ol><a class="dmHxMore" href="/wildlife-calendar">Full wildlife calendar →</a></div>'
        '<ul class="dmHxChips">' + ''.join('<li><a href="/%s">%s %s <span>%d</span></a></li>' % (sl, HUBI.get(sl, '🌊'), esc(t), n) for sl, t, n in acts_ if sl not in ('top-water-experiences', 'best-public-aquariums', 'new-curated-discoveries')) +
        ''.join('<li><a href="/%s">%s</a></li>' % c for c in COLL) + '</ul></section>')
ix = ix[:a] + home + ix[b:]
HCSS = """
/* v23.14.0: home rankings rebuilt */
.dmHx{max-width:1180px;margin:28px auto 8px;padding:26px;border-radius:26px;background:linear-gradient(160deg,#ecfbf8,#fffdf6);border:1px solid #dcebe8;box-shadow:0 12px 34px rgba(7,52,59,.08);font-family:Manrope,Inter,system-ui,-apple-system,"Segoe UI",sans-serif;color:#06323a}
.dmHxHead{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap}.dmHxEye{margin:0;font:800 12px/1.2 system-ui,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#0a7d78}
.dmHx h2{margin:6px 0 6px;font-size:clamp(24px,3.2vw,34px);letter-spacing:-.025em}.dmHxHead p{margin:0;color:#47656d;max-width:640px}
.dmHxCtas{display:flex;gap:8px;flex-wrap:wrap}.dmHxCta{display:inline-flex;align-items:center;min-height:44px;padding:0 16px;border-radius:12px;background:linear-gradient(180deg,#14bdb0,#0a8a84);color:#fff!important;font-weight:800;text-decoration:none}
.dmHxCta.alt{background:#fff;color:#0a6f69!important;border:1px solid #cfe5e1}
.dmHxGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin:18px 0 14px}
.dmHxCard,.dmHxNow{background:#fff;border:1px solid #e1eeeb;border-radius:20px;padding:16px;display:flex;flex-direction:column}
.dmHxCard h3,.dmHxNow h3{margin:0 0 8px;font-size:18px}.dmHxCard h3 a{color:#06323a;text-decoration:none}.dmHxCard h3 a:hover{text-decoration:underline}
.dmHx ol{list-style:none;margin:0;padding:0}.dmHx ol li{border-top:1px solid #eef5f3}
.dmHx ol li a{display:grid;grid-template-columns:24px 30px 1fr;align-items:start;gap:0;padding:9px 4px;color:#06323a;text-decoration:none;border-radius:10px}
.dmHxNow ol li a{grid-template-columns:30px 1fr}.dmHx ol li a:hover{background:#f1f8f7}.dmHx ol li a:hover b{text-decoration:underline}
.dmHx .n{font-weight:800;color:#0a7d78}.dmHx .ic{font-size:20px;line-height:1.1}.dmHx .t b{font-weight:700;font-size:14.5px;line-height:1.3}.dmHx .t small{display:block;color:#6b8790;font-size:12.5px;margin-top:2px}
.dmHx .fl{width:18px;height:13px;border-radius:2px;vertical-align:-2px;margin-right:5px;box-shadow:0 0 0 1px rgba(0,0,0,.1);object-fit:cover}
.dmHxMore{margin-top:auto;padding-top:10px;font-weight:800;color:#0a7d78;text-decoration:none;font-size:14px}
.dmHxNow{margin:0 0 14px}.dmHxNow ol{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));column-gap:18px}
.dmHxChips{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:8px}.dmHxChips a{display:inline-block;padding:8px 13px;border-radius:999px;background:#fff;border:1px solid #dcebe8;color:#0a5f5a;font-weight:700;font-size:13.5px;text-decoration:none}
.dmHxChips a:hover{border-color:#0a8a84}.dmHxChips a span{color:#7a959c;font-weight:600;margin-left:2px}
@media(max-width:860px){.dmHx{margin:18px 12px 6px;padding:18px 14px;border-radius:22px}.dmHxGrid{grid-template-columns:1fr;gap:10px}.dmHxNow ol{grid-template-columns:1fr}.dmHx ol li:nth-child(n+4){display:none}.dmHxChips li:nth-child(n+10){display:none}.dmHxCtas{width:100%}.dmHxCta{flex:1;justify-content:center}}
"""
ix = ix.replace('</style>\n</head><body data-version', HCSS + '</style>\n</head><body data-version', 1)
assert '.dmHxGrid' in ix and ix.count('id="rankings"') == 1
ix = ix.replace('data-version="v23.13.0"', 'data-version="v23.14.0"').replace('DipMapper version 23.13.0</p>', 'DipMapper version 23.14.0</p>')
ix = ix.replace('<a href="/explore#near"><b>📍 Near me</b><small>Top attractions close to you</small></a>', '<a href="/wildlife-calendar"><b>🐋 Wildlife</b><small>Whales, sharks &amp; more by month</small></a><a href="/explore#near"><b>📍 Near me</b><small>Top attractions close to you</small></a>')
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
sm = open(OUT + '/sitemap.xml', encoding='utf8').read()
if '/wildlife-calendar' not in sm: sm = sm.replace('</urlset>', '  <url><loc>https://dipmapper.com/wildlife-calendar</loc><lastmod>2026-11-13</lastmod><changefreq>monthly</changefreq><priority>0.8</priority></url>\n</urlset>')
open(OUT + '/sitemap.xml', 'w', encoding='utf8').write(sm)
print('home rebuilt', len(ix))
ix = open(OUT + '/index.html', encoding='utf8').read()
ix = ix.replace('#dmGateActs .dmGateRoutes{display:grid;grid-template-columns:1fr 1fr;', '#dmGateActs .dmGateRoutes{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));', 1)
ix = ix.replace('/* v23.14.0: home rankings rebuilt */', '/* v23.14.0: home rankings rebuilt */\n@media(max-width:520px){#dmGateActs .dmGateRoutes{grid-template-columns:1fr 1fr}#dmGateActs .dmGateRoutes a:last-child{grid-column:1/-1}}', 1)
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)

# ================= 23.15.0: one logo + Global / Near-me toggle everywhere =================
PL = {}
for r in cat['records']:
    pl = ((r.get('geo_v3') or {}).get('plot') or {})
    if pl.get('latitude') is not None: PL[r['id']] = (pl['latitude'], pl['longitude'])
def geo(i): return (' data-la="%s" data-lo="%s"' % PL[i]) if i in PL else ''
TOGGLE = '<div class="seg nearT" role="group" aria-label="Order"><button class="on" data-n="g">🌍 Global</button><button data-n="n">📍 Near me</button></div>'
NEAR_CSS = ('.nearT{margin-right:8px}.km{display:inline-block;margin-left:6px;padding:2px 8px;border-radius:999px;background:#06323a;color:#fff;font-size:11.5px;font-weight:800;vertical-align:1px}'
            '.nearMsg{font-size:13.5px;color:var(--muted);margin:6px 0 0}.nofar{opacity:.55}')
NEAR_JS = r'''<script>(function(){var T=document.querySelectorAll('.nearT');if(!T.length)return;var M=document.querySelector('.nearMsg');
function km(a,b,c,d){var r=Math.PI/180,x=Math.sin((c-a)*r/2),y=Math.sin((d-b)*r/2);return 12742*Math.asin(Math.sqrt(x*x+Math.cos(a*r)*Math.cos(c*r)*y*y))}
var lists=[].slice.call(document.querySelectorAll('ol')).filter(function(o){return o.querySelector(':scope>li[data-la]')});
lists.forEach(function(o){[].slice.call(o.children).forEach(function(li,i){li.setAttribute('data-i',i)})});
function mark(m){T.forEach(function(t){t.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-n')===m)})})}
function glob(){lists.forEach(function(o){var l=[].slice.call(o.children);l.sort(function(a,b){return a.getAttribute('data-i')-b.getAttribute('data-i')});l.forEach(function(li){li.classList.remove('nofar');var k=li.querySelector('.km');if(k)k.remove();o.appendChild(li)})});mark('g');if(M)M.textContent='';try{localStorage.setItem('dm_order','g')}catch(e){}}
function near(){if(!navigator.geolocation){if(M)M.textContent='Location is not available in this browser.';return}if(M)M.textContent='Finding your location…';
 navigator.geolocation.getCurrentPosition(function(g){var a=g.coords.latitude,b=g.coords.longitude;lists.forEach(function(o){var l=[].slice.call(o.children);
  l.forEach(function(li){var la=li.getAttribute('data-la');li._d=la==null?1e9:km(a,b,+la,+li.getAttribute('data-lo'));var k=li.querySelector('.km');if(k)k.remove();
   if(li._d<1e9){var s=document.createElement('span');s.className='km';s.textContent=(li._d<1?'here':Math.round(li._d).toLocaleString('en')+' km');var h=li.querySelector('h2,b');if(h)h.appendChild(s)}else li.classList.add('nofar')});
  l.sort(function(x,y){return x._d-y._d});l.forEach(function(li){o.appendChild(li)})});mark('n');if(M)M.textContent='Sorted by distance from you. Places without a map position are listed last.';try{localStorage.setItem('dm_order','n')}catch(e){}},
 function(){if(M)M.textContent='Location was not shared – showing the global ranking.';glob()},{timeout:10000,maximumAge:600000})}
T.forEach(function(t){t.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;b.getAttribute('data-n')==='n'?near():glob()})});
try{if(localStorage.getItem('dm_order')==='n')near()}catch(e){}})();</script>'''
for f in os.listdir(OUT):
    if not f.endswith('.html') or f in ('index.html', 'explore.html') or f[:-5] in GUIDES: continue
    t = open(OUT + '/' + f, encoding='utf8').read()
    t = re.sub(r'<li class="card" id="([^"]+)"', lambda m: '<li class="card" id="%s"%s' % (m.group(1), geo(html.unescape(m.group(1)))), t)
    t = re.sub(r'<li class="mini">(<span class="mi">[^<]*</span><span class="mt"><a href="/[^"#]*#([^"]+)")', lambda m: '<li class="mini"%s>%s' % (geo(html.unescape(m.group(2))), m.group(1)), t)
    t = re.sub(r'<li>(<a class="row" href="/[^"#]*#([^"]+)")', lambda m: '<li%s>%s' % (geo(html.unescape(m.group(2))), m.group(1)), t)
    if 'data-la=' not in t: continue
    if '<div class="tools">' in t:
        t = t.replace('<div class="tools">', '<div class="tools"><div style="display:flex;flex-wrap:wrap;gap:8px">' + TOGGLE, 1).replace('<span class="count">', '</div><span class="count">', 1)
        t = t.replace('</div><ol class="cards">', '</div><p class="nearMsg"></p><ol class="cards">', 1)
    else:
        t = t.replace('<main class="wrap">', '<main class="wrap"><div class="tools">' + TOGGLE + '</div><p class="nearMsg"></p>', 1)
    t = t.replace('</style>', NEAR_CSS + '</style>', 1).replace('</body></html>', NEAR_JS + '</body></html>', 1)
    assert t.count('class="seg nearT"') == 1, f
    open(OUT + '/' + f, 'w', encoding='utf8').write(t)
# ---------- home: Global / Near-me toggle + one favicon ----------
ix = open(OUT + '/index.html', encoding='utf8').read()
ix = re.sub(r'<link rel="icon"[^>]*>', '', ix).replace('</title>', '</title>' + ICON_LINK, 1)
ix = ix.replace('data-version="v23.14.0"', 'data-version="v23.15.0"').replace('DipMapper version 23.14.0</p>', 'DipMapper version 23.15.0</p>')
HTOG = '<div class="dmHxTog" role="group" aria-label="Order"><button type="button" class="on" data-hx="g">🌍 Global</button><button type="button" data-hx="n">📍 Near me</button></div>'
assert ix.count('<div class="dmHxGrid">') == 1
ix = ix.replace('<div class="dmHxGrid">', HTOG + '<p class="dmHxMsg"></p><div class="dmHxNear" hidden><ol></ol><a class="dmHxMore" href="/explore#near">More near you →</a></div><div class="dmHxGrid">', 1)
HJS = r'''<script>(function(){var box=document.querySelector('.dmHx');if(!box)return;var T=box.querySelector('.dmHxTog'),N=box.querySelector('.dmHxNear'),G=box.querySelector('.dmHxGrid'),W=box.querySelector('.dmHxNow'),M=box.querySelector('.dmHxMsg'),P=null;
function E(t){return String(t==null?'':t).replace(/[&<>"]/g,function(m){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]})}
function km(a,b,c,d){var r=Math.PI/180,x=Math.sin((c-a)*r/2),y=Math.sin((d-b)*r/2);return 12742*Math.asin(Math.sqrt(x*x+Math.cos(a*r)*Math.cos(c*r)*y*y))}
function mark(m){T.querySelectorAll('button').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-hx')===m)})}
function glob(){N.hidden=true;G.hidden=false;if(W)W.hidden=false;M.textContent='';mark('g')}
function near(){if(!navigator.geolocation){M.textContent='Location is not available in this browser.';return}M.textContent='Finding your location…';
 navigator.geolocation.getCurrentPosition(function(g){var a=g.coords.latitude,b=g.coords.longitude;(P?Promise.resolve(P):fetch('/picks.json').then(function(r){return r.json()})).then(function(j){P=j;
  var r=P.map(function(p){return[km(a,b,p.la,p.lo),p]}).sort(function(x,y){return x[0]-y[0]}).slice(0,12);
  N.querySelector('ol').innerHTML=r.map(function(x){var p=x[1];return'<li><a href="/'+E(p.pg)+'#'+E(p.id)+'"><span class="n">'+(x[0]<1?'0':Math.round(x[0]))+'<small>km</small></span><span class="ic">'+E(p.i||'★')+'</span><span class="t"><b>'+E(p.n)+'</b><small>'+(p.cc?'<img class="fl" src="https://flagcdn.com/w40/'+p.cc.toLowerCase()+'.png" width="18" height="13" alt="" loading="lazy">':'')+E(p.c)+' · '+E(p.a)+'</small></span></a></li>'}).join('');
  N.hidden=false;G.hidden=true;if(W)W.hidden=true;M.textContent='The 12 top picks closest to you.';mark('n')}).catch(function(){M.textContent='Could not load the picks. Please reload.'})},
 function(){M.textContent='Location was not shared – showing the global ranking.';glob()},{timeout:10000,maximumAge:600000})}
T.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;b.getAttribute('data-hx')==='n'?near():glob()})})();</script>'''
HCSS2 = ('.dmHxTog{display:inline-flex;background:#fff;border:1px solid #dcebe8;border-radius:999px;padding:4px;margin:16px 0 0}.dmHxTog button{border:0;background:none;border-radius:999px;padding:9px 16px;font:800 14px system-ui,sans-serif;color:#5d7b83;cursor:pointer}'
         '.dmHxTog button.on{background:#06323a;color:#fff}.dmHxMsg{font-size:13.5px;color:#5d7b83;margin:6px 0 0;min-height:1px}.dmHxNear{background:#fff;border:1px solid #e1eeeb;border-radius:20px;padding:16px;margin:14px 0}'
         '.dmHxNear ol{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));column-gap:18px}.dmHxNear .n{font-size:15px;line-height:1.1}.dmHxNear .n small{display:block;font-size:10px;color:#6b8790;font-weight:700}'
         '.dmHxNear ol li a{grid-template-columns:44px 30px 1fr}@media(max-width:860px){.dmHx .dmHxNear ol{grid-template-columns:1fr}.dmHx .dmHxNear ol li:nth-child(n+4){display:block}}')
ix = ix.replace('/* v23.14.0: home rankings rebuilt */', '/* v23.14.0: home rankings rebuilt */\n' + HCSS2, 1)
ix = ix.replace('</body>', HJS + '</body>', 1) if ix.count('</body>') == 1 else ix[::-1].replace('>ydob/<', ('>ydob/<' + HJS[::-1]), 1)[::-1]
assert 'dmHxTog' in ix and HJS in ix
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
ex = open(OUT + '/explore.html', encoding='utf8').read()
open(OUT + '/explore.html', 'w', encoding='utf8').write(ex)
print('23.15 ok')

# ================= 23.16.0: sharp vector base map (OpenFreeMap via MapLibre), raster stays as fallback =================
VEC_JS = r'''<script>(function(){var V={m:null,ok:false,dead:false,loading:false,sig:'',sz:''};window.__dmVec=V;
var JS='https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.js',CSS='https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.css',STYLE='https://tiles.openfreemap.org/styles/liberty';
var ATTR='<a href="https://openfreemap.org" target="_blank" rel="noopener">OpenFreeMap</a> © <a href="https://www.openmaptiles.org/" target="_blank" rel="noopener">OpenMapTiles</a> Data from <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>';
function host(){return document.getElementById('map')}
function webgl(){try{var c=document.createElement('canvas');return !!(c.getContext('webgl2')||c.getContext('webgl'))}catch(e){return false}}
function load(){if(V.loading||V.dead)return;V.loading=true;if(!webgl()){V.dead=true;return}
 var l=document.createElement('link');l.rel='stylesheet';l.href=CSS;document.head.appendChild(l);
 var s=document.createElement('script');s.src=JS;s.async=true;s.onload=init;s.onerror=function(){V.dead=true};document.head.appendChild(s);
 setTimeout(function(){if(!V.ok&&!V.dead){V.dead=true;off()}},15000)}
function off(){var mp=host();if(mp)mp.classList.remove('dmVecOn');if(V.d&&V.d.parentNode)V.d.parentNode.removeChild(V.d)}
function init(){var mp=host();if(!mp||!window.maplibregl||typeof state==='undefined'){V.dead=true;return}var c=state.mapCenter||state.center||[39,12];
 var d=document.createElement('div');d.className='dmVec';V.d=d;place();
 try{V.m=new maplibregl.Map({container:d,style:STYLE,interactive:false,attributionControl:false,center:[c[1],c[0]],zoom:(state.zoom||12)-1,fadeDuration:0,pixelRatio:Math.min(2,window.devicePixelRatio||1)});
  V.m.once('load',function(){V.ok=true;var m=host();if(m)m.classList.add('dmVecOn');attr()});
  V.m.on('error',function(){if(!V.ok){V.dead=true;off()}})}catch(e){V.dead=true;off()}}
function place(){var mp=host();if(!mp||!V.d)return;var ov=mp.querySelector('.dmOverlay');if(V.d.parentNode!==mp||(ov&&V.d.nextSibling!==ov)){if(ov)mp.insertBefore(V.d,ov);else mp.appendChild(V.d)}}
function attr(){var a=host()&&host().querySelector('.dmAttr');if(a&&a.innerHTML.indexOf('OpenFreeMap')<0)a.innerHTML=ATTR}
function tick(){requestAnimationFrame(tick);if(V.dead)return;var mp=host();if(!mp||typeof state==='undefined')return;var c=state.mapCenter||state.center;if(!c||!mp.offsetWidth)return;
 if(!V.m){load();return}place();if(V.ok)attr();var z=state.zoom||12,s=c[0]+','+c[1]+','+z,sz=mp.offsetWidth+'x'+mp.offsetHeight;
 if(sz!==V.sz){V.sz=sz;try{V.m.resize()}catch(e){}V.sig=''}if(s===V.sig)return;V.sig=s;try{V.m.jumpTo({center:[c[1],c[0]],zoom:z-1})}catch(e){}}
function go(){setTimeout(function(){requestAnimationFrame(tick)},400)}if(document.readyState==='complete')go();else addEventListener('load',go,{once:true})})();</script>'''
VEC_CSS = '\n/* v23.16.0: vector base map */\n#map .dmVec{position:absolute;inset:0;z-index:0;pointer-events:none}#map .dmVec .maplibregl-canvas{outline:none}#map.dmVecOn .dmTiles{display:none}\n'
ix = open(OUT + '/index.html', encoding='utf8').read()
ix = ix.replace('data-version="v23.15.0"', 'data-version="v23.16.0"').replace('DipMapper version 23.15.0</p>', 'DipMapper version 23.16.0</p>')
ix = ix.replace('data-version="v23.16.0"','data-version="v23.16.1"').replace('DipMapper version 23.16.0</p>','DipMapper version 23.16.1</p>')
ix = ix.replace('/* v23.14.0: home rankings rebuilt */', VEC_CSS + '/* v23.14.0: home rankings rebuilt */', 1)
ix = ix.replace('</body>', VEC_JS + '</body>', 1) if ix.count('</body>') == 1 else ix[::-1].replace('>ydob/<', ('>ydob/<' + VEC_JS[::-1]), 1)[::-1]
assert '__dmVec' in ix and '.dmVecOn .dmTiles' in ix
ix = ix.replace('<link rel="preconnect" href="https://tile.openstreetmap.org" crossorigin>', '<link rel="preconnect" href="https://tiles.openfreemap.org" crossorigin><link rel="preconnect" href="https://unpkg.com" crossorigin><link rel="preconnect" href="https://tile.openstreetmap.org" crossorigin>', 1)
ix = ix.replace("connect-src 'self' https:;", "connect-src 'self' https:; worker-src 'self' blob:; child-src 'self' blob:;", 1)
assert 'worker-src' in ix
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
print('23.16 vector map ok')

# ================= 23.16.0 UX pass: mobile tab bar, compact start screen, near-me deep link, social previews =================
TAB_CSS = '''<style>/* v23.16.0 mobile tab bar */
.dmTab{display:none}
@media (max-width:760px){
.dmTab{display:flex;position:fixed;left:0;right:0;bottom:0;z-index:55;justify-content:space-around;align-items:stretch;gap:2px;padding:6px 6px calc(env(safe-area-inset-bottom,0px) + 6px);
 background:rgba(255,255,255,.96);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border-top:1px solid #d6ebe7;box-shadow:0 -6px 22px rgba(6,52,60,.10)}
.dmTab a{flex:1 1 0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;min-height:48px;border-radius:14px;color:#33555d;text-decoration:none;
 font:700 10.5px/1.1 system-ui,-apple-system,"Segoe UI",sans-serif;letter-spacing:.01em}
.dmTab a .i{font-size:20px;line-height:1;filter:saturate(1.1)}
.dmTab a.on{background:#e3f5f2;color:#06343C}.dmTab a.on .i{transform:scale(1.08)}
.dmTab a:active{background:#d2efea}
body.dmHasTab{padding-bottom:calc(env(safe-area-inset-bottom,0px) + 68px)}
}
@media print{.dmTab{display:none}}</style>'''
TABS = [('/', '🗺️', 'Map'), ('/rankings', '🏆', 'Rankings'), ('/explore#near', '📍', 'Near me'), ('/wildlife-calendar', '🐋', 'Wildlife'), ('/best-water-experiences-by-month', '📅', 'Seasons')]
def tabbar(active):
    return ('<nav class="dmTab" aria-label="Quick navigation">' +
            ''.join('<a href="%s"%s><span class="i" aria-hidden="true">%s</span>%s</a>' % (h, ' class="on" aria-current="page"' if h == active else '', i, l) for h, i, l in TABS) +
            '</nav><script>(function(){document.body.classList.add("dmHasTab");var n=document.querySelector(".dmTab");if(!n)return;'
            'n.addEventListener("click",function(e){var a=e.target.closest("a");if(!a)return;var h=a.getAttribute("href");'
            'if(h==="/"&&(location.pathname==="/"||location.pathname==="/index.html")){var m=document.getElementById("map");if(m){e.preventDefault();var g=document.getElementById("gate");if(g&&getComputedStyle(g).display!=="none"){var s=document.getElementById("gateSkip");if(s)s.click()}m.scrollIntoView({behavior:"smooth",block:"center"})}}'
            'else if(h==="/rankings#near"&&(location.pathname==="/rankings"||location.pathname==="/rankings.html")){e.preventDefault();var b=document.querySelector(".nearT button[data-n=n]");if(b){b.click();b.scrollIntoView({behavior:"smooth",block:"center"})}}})})();</script>')

GATE_CSS = '''<style>/* v23.16.0 start screen: search and location first */
#gate .gateSearch{display:flex!important;flex-direction:row!important;flex-wrap:nowrap!important;gap:8px;align-items:stretch;height:auto!important;margin:12px 0 0!important}#gate .gateSearch .input{flex:1 1 auto;min-width:0;width:auto!important;margin:0!important}#gate .gateSearch #gateSearch{flex:0 0 auto;width:auto!important;padding:0 20px;margin:0!important}
#gate .actions{display:flex!important;flex-direction:row!important;gap:8px;flex-wrap:wrap;margin:8px 0 0!important;height:auto!important}#gate .actions button{flex:1 1 150px;width:auto!important;margin:0!important}
#gate #gateLoc::before{content:"📍 "}
#dmGateBrowse .dmGateOr{display:flex;align-items:center;gap:10px;margin:16px auto 8px;max-width:560px;color:#7a959c;font:600 12px system-ui,sans-serif;text-transform:uppercase;letter-spacing:.1em}
#dmGateBrowse .dmGateOr:before,#dmGateBrowse .dmGateOr:after{content:"";flex:1;height:1px;background:#dcebe8}
#dmGateBrowse .dmGateRoutes{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;max-width:560px;margin:0 auto}
#dmGateBrowse .dmGateRoutes a{display:block;text-align:left;padding:10px 12px;border-radius:14px;background:#fff;border:1px solid #d5e9e5;text-decoration:none;color:#06343C}
#dmGateBrowse .dmGateRoutes b{display:block;font-size:14px}#dmGateBrowse .dmGateRoutes small{display:block;color:#5f8189;font-size:12px;margin-top:2px}
#dmGateBrowse .dmGateRoutes a:hover{border-color:#0b8f86}
@media (max-width:760px){
 #gate .dmGateLogo{height:84px!important;width:auto!important;max-width:70%}#gate .dmGateHero{margin-bottom:0}
 #gate .gateBox>p.muted:not(#gateHint){font-size:13.5px;line-height:1.4;margin:4px 0 10px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
 #gate h1{font-size:24px;margin:4px 0 2px}
 #gate .dmGateRow{flex-wrap:nowrap!important;overflow-x:auto;justify-content:flex-start!important;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding:2px 2px 6px;scroll-snap-type:x proximity}
 #gate .dmGateRow::-webkit-scrollbar{display:none}#gate .dmGateRow button{flex:0 0 auto;scroll-snap-align:start}
 #gate .gateSearch .input,#gate .gateSearch #gateSearch,#gate .actions button{min-height:48px;height:48px}
 #gate .actions button{flex:1 1 0;padding:0 8px;font-size:14px;white-space:nowrap}
 #gate .dmBubbles,#gate .dmWater{display:none}
 #filters.dmCollapsed{flex-wrap:nowrap!important;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding-bottom:4px;mask-image:linear-gradient(90deg,#000 88%,transparent)}#filters.dmCollapsed::-webkit-scrollbar{display:none}#filters.dmCollapsed>button{flex:0 0 auto}
 #dmGateBrowse .dmGateRoutes{grid-template-columns:1fr 1fr}#dmGateBrowse .dmGateRoutes a:last-child{grid-column:1/-1}
 #gate .dmGateLogo{height:72px!important}
}</style>'''
GATE_JS = '''<script>(function(){var n=0;(function mv(){var g=document.getElementById('gate'),r=g&&g.querySelector('#dmGateActs .dmGateRoutes'),o=g&&g.querySelector('#dmGateActs .dmGateOr'),a=g&&g.querySelector('.actions'),s=g&&g.querySelector('.gateSearch'),q=g&&g.querySelector('#dmGateActs');
 if(r&&o&&a&&s&&q){q.parentNode.insertBefore(s,q.nextSibling);s.parentNode.insertBefore(a,s.nextSibling);var w=document.createElement('div');w.id='dmGateBrowse';w.appendChild(o);w.appendChild(r);a.parentNode.insertBefore(w,a.nextSibling);return}
 if(++n<60)setTimeout(mv,100)})()})();</script>'''

ix = open(OUT + '/index.html', encoding='utf8').read()
ix = ix.replace('placeholder="Rhodes, Palma, Zurich, lake, island..."', 'placeholder="Beach, lake or town – e.g. Bali"', 1)
assert "e.g. Bali" in ix
ix = ix.replace('</head>', TAB_CSS + GATE_CSS + '</head>', 1)
k = ix.rfind('</body>'); ix = ix[:k] + GATE_JS + tabbar('/') + ix[k:]
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)

TAB_ACT = {'rankings.html': '/rankings', 'wildlife-calendar.html': '/wildlife-calendar', 'best-water-experiences-by-month.html': '/best-water-experiences-by-month'}
OG = '<meta property="og:image" content="https://dipmapper.com/dipmapper-logo-hires.png"><meta property="og:image:alt" content="DipMapper – find your next swim"><meta name="twitter:card" content="summary_large_image">'
cnt = 0
for f in sorted(os.listdir(OUT)):
    if not f.endswith('.html') or f == 'index.html': continue
    t = open(OUT + '/' + f, encoding='utf8').read()
    if 'class="dmTab"' in t or '</body>' not in t: continue
    t = t.replace("try{if(localStorage.getItem('dm_order')==='n')near()}catch(e){}", "try{if(location.hash==='#near'||localStorage.getItem('dm_order')==='n')near()}catch(e){}")
    if 'og:image' not in t: t = t.replace('</head>', OG + '</head>', 1)
    t = t.replace('</head>', TAB_CSS + '</head>', 1)
    k = t.rfind('</body>'); t = t[:k] + tabbar(TAB_ACT.get(f, '')) + t[k:]
    open(OUT + '/' + f, 'w', encoding='utf8').write(t); cnt += 1
print('23.16 UX pass ok', cnt, 'pages')

# ================= 23.17.0: getting there (starting point + route from your location) =================
_cat = json.load(open('/tmp/w/pub/data/03_catalogue.json', encoding='utf8')); _cat = _cat['records'] if isinstance(_cat, dict) else _cat
_byid = {x['id']: x for x in _cat}
pk = json.load(open(OUT + '/picks.json', encoding='utf8')); _n = 0
for p in pk:
    r = _byid.get(p['id'])
    gt = getting_there(r) if r else None
    if gt: p['g'] = gt['place']; p['gl'] = gt['label']; p['gn'] = gt['note']; _n += 1
json.dump(pk, open(OUT + '/picks.json', 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))
ROUTE = "(p.g?'<a href=\"https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(p.g)+'\" target=\"_blank\" rel=\"noopener\">🧭 Route</a>':'')"
GTP = "(p.g?'<p class=\"dmGt\">🚩 <b>'+E(p.gl||'Starts from')+':</b> '+E(p.g)+(p.gn?'<br><small>'+E(p.gn)+'</small>':'')+'</p>':'')"
ix = open(OUT + '/index.html', encoding='utf8').read()
a = "l.push('<a href=\"/'+E(p.pg)+'#'+E(p.id)+'\">Full card</a>');\n o.innerHTML="
assert ix.count(a) == 1
ix = ix.replace(a, "if(p.g)l.push(" + ROUTE + ");" + a, 1)
b = "<p><b>Season:</b> '+E(p.se)+'</p><div class=\"l\">'+l.join('')"
assert ix.count(b) == 1
ix = ix.replace(b, "<p><b>Season:</b> '+E(p.se)+'</p>'+" + GTP + "+'<div class=\"l\">'+l.join('')", 1)
ix = ix.replace('</head>', '<style>.dmStarPop .dmGt{margin:6px 0;padding:7px 9px;border-radius:10px;background:#f2f8ff;border:1px solid #d6e6f7;font-size:13px;line-height:1.4}.dmStarPop .dmGt small{color:#5b7480}</style></head>', 1)
ix = ix.replace('data-version="v23.16.1"', 'data-version="v23.17.1"').replace('DipMapper version 23.16.1</p>', 'DipMapper version 23.17.1</p>')
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
# near-me lists on guide pages (show())
c_ = 0
for f in os.listdir(OUT):
    if not f.endswith('.html') or f == 'index.html': continue
    t = open(OUT + '/' + f, encoding='utf8').read()
    o_ = "<p><b>Season:</b> '+E(p.se)+'</p><div class=\"l\">'+(p.u?"
    if o_ in t:
        t = t.replace(o_, "<p><b>Season:</b> '+E(p.se)+'</p>'+" + GTP.replace('dmGt', 'gt') + "+'<div class=\"l\">'+" + ROUTE + "+(p.u?")
        open(OUT + '/' + f, 'w', encoding='utf8').write(t); c_ += 1
print('23.17 getting there ok', _n, 'picks;', c_, 'near lists')

# ================= 23.17.0: dead links from the GitHub link check (404/410) =================
import urllib.parse as _U
_lc = json.load(open('/tmp/chk2/linkcheck.json', encoding='utf8'))
_dead = [p['url'] for p in _lc['problems'] if p['status'] in (404, 410) and '${' not in p['url'] and "'+" not in p['url'] and 'openstreetmap.org/' not in p['url'] and 'wikidata.org/wiki/' not in p['url']]
_fix = 0
for f in sorted(os.listdir(OUT)):
    if not (f.endswith('.html') or f == 'picks.json'): continue
    t = open(OUT + '/' + f, encoding='utf8').read(); t0 = t
    for u in _dead:
        if u not in t: continue
        sp = _U.urlsplit(u)
        if 'latitude.to' in sp.netloc:
            t = re.sub(r'<a [^>]*href="' + re.escape(u) + r'"[^>]*>(.*?)</a>', r'\1', t).replace(u, sp.scheme + '://' + sp.netloc + '/')
        else:
            t = t.replace(u, sp.scheme + '://' + sp.netloc + '/')
    if t != t0:
        open(OUT + '/' + f, 'w', encoding='utf8').write(t); _fix += 1
_left = sum(open(OUT + '/' + f, encoding='utf8').read().count(u) for f in os.listdir(OUT) if f.endswith('.html') or f == 'picks.json' for u in _dead)
print('23.17 dead links fixed in', _fix, 'files; remaining', _left)

# picks.json: precision flags for map positions (x=1 shared area centre, x=2 country-level only)
pk = json.load(open(OUT + '/picks.json', encoding='utf8'))
for p in pk:
    if p['id'] in _POS: p['la'], p['lo'] = _POS[p['id']][0], _POS[p['id']][1]
    v = _CON.get(p['id'])
    if v:
        if not p.get('p') and v['tel']: p['p'] = v['tel'][0]
        if not p.get('e') and v['mail']: p['e'] = v['mail'][0]
from collections import Counter as _C
_cc = _C((p.get('la'), p.get('lo')) for p in pk)
for p in pk:
    p.pop('x', None)
    if p.get('la') is None: continue
    if p['id'] in _POS: continue
    if (p.get('ar') or '').strip().lower() in ('', (p.get('c') or '').lower()): p['x'] = 2
    elif _sc[_orig.get(p['id'], (p['la'], p['lo']))] > 1: p['x'] = 1
json.dump(pk, open(OUT + '/picks.json', 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))
print('precision flags', _C(p.get('x', 0) for p in pk))
# ================= 23.18.0: new location-first Explore (map + photos + near me); old explorer kept at /explore-classic =================
import shutil
_old = open(OUT + '/explore.html', encoding='utf8').read()
if 'id="xList"' not in _old:
    _old = _old.replace('<link rel="canonical" href="https://dipmapper.com/explore', '<link rel="canonical" href="https://dipmapper.com/explore-classic')
    _old = _old.replace('<title>', '<meta name="robots" content="noindex,follow"><title>', 1)
    open(OUT + '/explore-classic.html', 'w', encoding='utf8').write(_old)
XCSS = '''
.xhero{background:linear-gradient(135deg,#06343c,#0b6f78 60%,#11a3a0);color:#fff;padding:22px 0 18px}.xhero h1{margin:0 0 4px;font-size:30px;letter-spacing:-.02em}.xhero p{margin:0;color:#d8f1ee}
.xtools{position:sticky;top:0;z-index:20;background:rgba(246,251,250,.97);backdrop-filter:blur(8px);border-bottom:1px solid #dcebe8;padding:10px 0}
.xrow{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.xseg{display:inline-flex;background:#fff;border:1px solid #d5e9e5;border-radius:999px;padding:3px}
.xseg button{border:0;background:none;border-radius:999px;padding:9px 14px;font:700 14px system-ui,sans-serif;color:#33555d;cursor:pointer}.xseg button.on{background:#06343c;color:#fff}
#xCountry{height:40px;border-radius:999px;border:1px solid #d5e9e5;padding:0 12px;font:600 14px system-ui,sans-serif;background:#fff;max-width:220px}
.xchips{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;padding:8px 0 2px}.xchips::-webkit-scrollbar{display:none}
.xchips button{flex:0 0 auto;display:inline-flex;align-items:center;gap:6px;border:1px solid #d5e9e5;background:#fff;border-radius:999px;padding:8px 13px;font:700 13.5px system-ui,sans-serif;color:#0a4f55;cursor:pointer}
.xchips button span{font-size:17px}.xchips button.on{background:#e3f5f2;border-color:#0b8f86;color:#06343c}
#xLoc{font-size:13.5px;color:#33555d}#xStat{font-size:13px;color:#6b8790;font-weight:600;margin:12px 0 8px}
.xgrid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.15fr);gap:20px;align-items:start;margin-top:14px}
.xmapw{position:sticky;top:120px;height:calc(100vh - 140px);min-height:420px;border-radius:20px;overflow:hidden;border:1px solid #d5e9e5;background:#dbeff3}
#xMap{position:absolute;inset:0}#xMap.off{display:flex;align-items:center;justify-content:center;color:#5f8189;font-size:14px}#xMap.off:after{content:"Map not available in this browser – the list works as usual."}
.xmk{width:32px;height:32px;border-radius:50%;border:2px solid #fff;background:#0b8f86;font-size:16px;line-height:28px;text-align:center;cursor:pointer;box-shadow:0 3px 10px rgba(6,52,60,.35);padding:0;opacity:.75}.xmk.on{opacity:1;background:#ffbf3c}
.xme{width:18px;height:18px;border-radius:50%;background:#1a73e8;border:3px solid #fff;box-shadow:0 0 0 6px rgba(26,115,232,.25)}
#xList{list-style:none;margin:0;padding:0;display:grid;gap:14px}
.xc{display:grid;grid-template-columns:190px 1fr;gap:14px;background:#fff;border:1px solid #dcebe8;border-radius:20px;padding:12px;box-shadow:0 8px 26px rgba(6,50,58,.06);scroll-margin:140px}.xc.sel{outline:3px solid #ffbf3c}
.xp{position:relative;margin:0;border-radius:14px;overflow:hidden;min-height:150px;background:linear-gradient(150deg,#d9f4ef,#b6e4ea 60%,#9fd3e0);display:flex;align-items:center;justify-content:center}
.xp img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity .4s}.xp.has img{opacity:1}.xp.has .xi{display:none}.xi{font-size:52px;filter:drop-shadow(0 4px 10px rgba(6,50,58,.2))}
.xd{position:absolute;left:8px;top:8px;background:rgba(6,52,60,.85);color:#fff;font:800 12.5px system-ui,sans-serif;padding:5px 9px;border-radius:999px}.xd.rk{background:#ffbf3c;color:#3d2700}
.xs{position:absolute;right:8px;top:8px;background:#16b3a5;color:#fff;font:800 11px system-ui,sans-serif;padding:4px 8px;border-radius:999px}
.xp .cr{position:absolute;right:6px;bottom:4px;font-size:10px;color:#fff;text-shadow:0 1px 2px #000;text-decoration:none}
.xb{min-width:0}.xk{margin:2px 0 2px;font-size:12.5px;font-weight:700;color:#5f8189}.xb h3{margin:0 0 6px;font-size:18px;line-height:1.25}.xw{margin:0 0 8px;font-size:14px;color:#23474f;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.xms{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 8px}.xms small{font-size:12px;color:#5f8189;font-weight:600}.xm{display:inline-grid;grid-template-columns:repeat(12,15px);gap:2px}
.xm i{height:16px;border-radius:4px;background:#eef3f3;color:#9db1b5;font:700 9px/16px system-ui,sans-serif;text-align:center;font-style:normal}.xm i.y{background:#16b3a5;color:#fff}.xm i.now{outline:2px solid #06343c;outline-offset:1px}
.xg{margin:0 0 8px;padding:7px 10px;border-radius:10px;background:#f2f8ff;border:1px solid #d6e6f7;font-size:13px;line-height:1.4}.xg small{display:block;color:#5b7480}
.xh{margin:0 0 8px;font-size:13px;color:#7a4b00}
.xa{display:flex;flex-wrap:wrap;gap:6px}.xa a{display:inline-flex;align-items:center;gap:5px;height:36px;padding:0 12px;border-radius:11px;border:1px solid #cfe5e1;font:700 13px system-ui,sans-serif;text-decoration:none;color:#0a6f69;background:#fff}
.xa a.main{background:linear-gradient(180deg,#14bdb0,#0a8a84);color:#fff;border:0}
#xMore{display:block;margin:16px auto;height:46px;padding:0 22px;border-radius:999px;border:1px solid #0b8f86;background:#fff;color:#06343c;font:800 15px system-ui,sans-serif;cursor:pointer}
.xclassic{margin:26px 0 10px;padding:16px 18px;border-radius:18px;background:#fff;border:1px solid #dcebe8;font-size:14.5px}
@media(max-width:900px){.xgrid{grid-template-columns:1fr;margin-top:10px}.xmapw{position:relative;top:0;height:240px;min-height:0}.xhero h1{font-size:22px;margin:0}.xhero p{display:none}.xhero{padding:12px 0 10px}.xtools{position:static}#xLoc{flex-basis:100%}
 .xc{grid-template-columns:1fr;padding:10px}.xp{min-height:170px}.xtools{padding:8px 0}.xseg button{padding:8px 11px;font-size:13px}#xCountry{max-width:150px;font-size:13px}}
'''
_x_ld = {'@context': 'https://schema.org', '@type': 'CollectionPage', 'name': 'Explore water experiences near you', 'url': 'https://dipmapper.com/explore'}
_xh = head('Explore water experiences near you – map, photos and routes | DipMapper',
           'Find the best water experiences near you or anywhere: beaches, snorkelling, diving, whale watching, boat trips, aquariums and thermal baths – on a map, with seasons, starting points and routes.',
           'https://dipmapper.com/explore', _x_ld)
_xh = _xh.replace('</style>', XCSS + '</style>' + TAB_CSS.replace('<style>', '<style>', 1), 1).replace('</head>', OG + '</head>', 1)
_xb = (bar('ex') + '<section class="xhero"><div class="wrap"><h1>Explore water experiences</h1><p>Nearest first when you share your location – with photos, a map, seasons, starting points and a route from where you are.</p></div></section>'
       '<div class="xtools"><div class="wrap"><div class="xrow"><div class="xseg" role="group" aria-label="Order"><button type="button" data-m="near">📍 Near me</button><button type="button" data-m="top" class="on">🏆 Top rated</button><button type="button" data-m="season">🗓️ In season</button></div>'
       '<select id="xCountry" aria-label="Country"><option value="">🌍 All countries</option></select><span id="xLoc" aria-live="polite"></span></div><div class="xchips" role="group" aria-label="Activity"></div></div></div>'
       '<main class="wrap"><div class="xgrid"><div class="xmapw"><div id="xMap" role="region" aria-label="Map of the places"></div></div><div><p id="xStat" aria-live="polite">Loading places…</p><ol id="xList"></ol><button type="button" id="xMore" hidden>Show more</button>'
       '<p class="xclassic">🧳 Looking for the water passport, side-by-side compare or all 605 catalogue entries? <a href="/explore-classic">Open the full catalogue →</a></p></div></div></main>'
       + FOOT + '<script>' + open('/tmp/w/s/explore_js.txt', encoding='utf8').read() + '</script>' + tabbar('') + '</body></html>')
open(OUT + '/explore.html', 'w', encoding='utf8').write(_xh + _xb)
# save the location whenever a near-me toggle succeeds elsewhere, so Explore can open nearest-first
for f in os.listdir(OUT):
    if not f.endswith('.html'): continue
    t = open(OUT + '/' + f, encoding='utf8').read()
    k_ = 'navigator.geolocation.getCurrentPosition(function(g){var a=g.coords.latitude,b=g.coords.longitude;'
    if k_ in t:
        t = t.replace(k_, k_ + "try{localStorage.setItem('dm_loc',JSON.stringify({la:a,lo:b,t:Date.now()}))}catch(e){}")
        open(OUT + '/' + f, 'w', encoding='utf8').write(t)
ix = open(OUT + '/index.html', encoding='utf8').read()
ix = ix.replace('data-version="v23.17.1"', 'data-version="v23.19.0"').replace('DipMapper version 23.17.1</p>', 'DipMapper version 23.19.0</p>')
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
print('23.18 explore ok', os.path.getsize(OUT + '/explore.html'))
ix = open(OUT + '/index.html', encoding='utf8').read()
k_ = "  const acc=Math.round(pos.coords.accuracy||0);\n  state.center=[pos.coords.latitude,pos.coords.longitude];"
assert ix.count(k_) == 1
ix = ix.replace(k_, "  const acc=Math.round(pos.coords.accuracy||0);try{localStorage.setItem('dm_loc',JSON.stringify({la:pos.coords.latitude,lo:pos.coords.longitude,t:Date.now()}))}catch(e){}\n  state.center=[pos.coords.latitude,pos.coords.longitude];", 1)
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
print('app location memory ok')

os.makedirs(OUT + '/_tools', exist_ok=True); shutil.copy('/tmp/w/dc/collect.py', OUT + '/_tools/collect.py')

shutil.copy('/tmp/w/sm/sitemap.py', OUT + '/_tools/sitemap.py')

# ================= 23.20.0: zoom to you, junk-place filter, working detail links, audited photos, charts =================
ix = open(OUT + '/index.html', encoding='utf8').read()
# 1) zoom buttons zoom towards your position (when it is on screen); mouse wheel + double-click zoom at the pointer
zo = "$('#zin').onclick=()=>{state.zoom=Math.min(18,state.zoom+1);drawMap()};$('#zout').onclick=()=>{state.zoom=Math.max(2,state.zoom-1);drawMap()};"
assert ix.count(zo) == 1
ix = ix.replace(zo, "$('#zin').onclick=()=>dmZoom(1);$('#zout').onclick=()=>dmZoom(-1);", 1)
ZJS = r'''<script>function dmZoom(dz,ax,ay){var m=els&&els.map;if(!m)return;var r=m.getBoundingClientRect(),z=state.zoom,nz=Math.max(2,Math.min(18,z+dz));if(nz===z)return;var c=state.mapCenter||state.center;if(!c){state.zoom=nz;drawMap();return}
 var cp=project(c[0],c[1],z);if(ax==null&&state.center){var up=project(state.center[0],state.center[1],z),sx=up[0]-cp[0]+r.width/2,sy=up[1]-cp[1]+r.height/2;if(sx>=0&&sx<=r.width&&sy>=0&&sy<=r.height){ax=sx;ay=sy}}
 if(ax!=null){var wx=cp[0]-r.width/2+ax,wy=cp[1]-r.height/2+ay,k=Math.pow(2,nz-z);state.mapCenter=unproject(wx*k-(ax-r.width/2),wy*k-(ay-r.height/2),nz)}state.zoom=nz;drawMap()}
(function(){var t=0;function hook(){var m=els&&els.map;if(!m){if(++t<50)setTimeout(hook,200);return}
 m.addEventListener('wheel',function(e){if(e.target.closest('.dmStarPop,.dmAttr'))return;e.preventDefault();var b=m.getBoundingClientRect();if(!m._wz||Date.now()-m._wz>160){m._wz=Date.now();dmZoom(e.deltaY<0?1:-1,e.clientX-b.left,e.clientY-b.top)}},{passive:false});
 m.addEventListener('dblclick',function(e){if(e.target.closest('button,a,.dmStarPop'))return;var b=m.getBoundingClientRect();dmZoom(1,e.clientX-b.left,e.clientY-b.top)})}
 if(document.readyState==='loading')addEventListener('DOMContentLoaded',hook);else hook()})();</script>'''
k = ix.rfind('</body>'); ix = ix[:k] + ZJS + ix[k:]
# 2) no billiard halls, pool bars, hotel/members-only pools in the place search
ao = "if(t.access==='private'||t.access==='no'||t.access==='permit')return null;"
assert ix.count(ao) == 1
ix = ix.replace(ao, ao + "if(dmJunk(t))return null;", 1)
JJS = r'''<script>function dmJunk(t){var n=String([t.name,t['name:en'],t.description,t.operator,t.brand].join(' ')).toLowerCase();
 if(/billiard|billard|snooker|pool ?hall|pool ?bar|pool ?table|8 ?ball|car ?pool|pool ?party|pool ?villa|pool ?service|pool ?supply|pool ?shop|pool ?cleaning|pool ?construction|poolside bar|sports bar|karaoke/.test(n))return true;
 if(/^(customers|members|residents|guests|delivery|private|no|permit|discouraged)$/.test(String(t.access||'')))return true;
 if(t.shop||t.craft||t.office||/^(pub|bar|restaurant|cafe|nightclub|fast_food|casino)$/.test(t.amenity||''))return true;
 var pool=t.leisure==='swimming_pool'||/\bpool\b/.test(n);
 if(pool&&(/^(hotel|motel|hostel|guest_house|apartment|resort|chalet)$/.test(t.tourism||'')||/hotel|resort|villa|condo|residence|residences|apartment|serviced|hostel|guesthouse|guest house|boutique|spa resort/.test(n))&&!/public|municipal|community|city|stadtbad|hallenbad|freibad|piscine municipale|aquatic/.test(n)&&!(t.fee||t.opening_hours))return true;
 return false}</script>'''
ix = ix.replace('</head>', JJS + '</head>', 1)
ix = ix.replace('data-version="v23.19.0"', 'data-version="v23.20.0"').replace('DipMapper version 23.19.0</p>', 'DipMapper version 23.20.0</p>')
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)

# 3) every "Details" link must land on a page that really shows that card
_cards = {}
for f in sorted(os.listdir(OUT)):
    if f.endswith('.html') and f not in ('index.html', 'explore.html', 'explore-classic.html'):
        for i in re.findall(r'<li class="card" id="([^"]+)"', open(OUT + '/' + f, encoding='utf8').read()): _cards.setdefault(i, []).append(f[:-5])
pk = json.load(open(OUT + '/picks.json', encoding='utf8')); _fx = _sh = 0
for p in pk:
    pg = _cards.get(p['id'], [])
    if p.get('pg') in pg: continue
    if pg: p['pg'] = pg[0]; _fx += 1
    else: p['pg'] = 'explore?show=' + p['id']; _sh += 1
json.dump(pk, open(OUT + '/picks.json', 'w', encoding='utf8'), ensure_ascii=False, separators=(',', ':'))
print('detail links fixed', _fx, 'shown in explore', _sh)
print('23.20 index ok')

# 4) SEO: click-worthy titles/descriptions + richer ItemList (TouristAttraction with coordinates) on every ranking page
import html as _h
def _setmeta(t, title, desc):
    t = re.sub(r'<title>.*?</title>', '<title>' + esc(title) + '</title>', t, 1, flags=re.S)
    t = re.sub(r'(<meta name="description" content=")[^"]*', lambda m: m.group(1) + esc(desc, True), t, 1)
    t = re.sub(r'(<meta property="og:title" content=")[^"]*', lambda m: m.group(1) + esc(title, True), t, 1)
    t = re.sub(r'(<meta property="og:description" content=")[^"]*', lambda m: m.group(1) + esc(desc, True), t, 1)
    return t
_seo = 0
for f in sorted(os.listdir(OUT)):
    if not f.endswith('.html') or f in ('index.html', 'explore.html', 'explore-classic.html'): continue
    t = open(OUT + '/' + f, encoding='utf8').read()
    cards = re.findall(r'<li class="card" id="([^"]+)"[^>]*><figure class="ph"(?: data-id="[^"]*" data-q="[^"]*" data-la="([^"]*)" data-lo="([^"]*)")?[^>]*>.*?<h2>(.*?)</h2>', t, re.S)
    h1 = re.search(r'<h1>(.*?)</h1>', t, re.S)
    if len(cards) < 3 or not h1: continue
    n = len(cards); top = _h.unescape(h1.group(1)).strip()
    ncc = len(set(re.findall(r'flagcdn\.com/w40/([a-z]{2})\.png', t)))
    tc = ' '.join(w if (w.isupper() or w.lower() in ('in', 'and', 'of', 'the', 'by')) else w[:1].upper() + w[1:] for w in top.split())
    if ':' in tc or re.match(r'(?i)top \d', tc): title = tc.split(':')[0] + ' (2026): Seasons, Routes & Tickets | DipMapper'
    elif top.lower().startswith(('best', 'top')): title = tc + ' (2026): %d Top Picks | DipMapper' % n
    else: title = '%d Best %s (2026) | DipMapper' % (n, tc)
    nice = top[0].lower() + top[1:] if not top.lower().startswith(('best', 'top')) else top.split(' ', 1)[1]
    desc = ('%d hand-picked %s%s, ranked. Best months, where trips start, a route from your location, prices and official contacts. No paid placements.' % (n, nice, (' in %d countries' % ncc) if ncc > 1 else ''))[:300]
    t = _setmeta(t, title, desc)
    # enrich ItemList
    m = re.search(r'<script type="application/ld\+json">(.*?)</script>', t, re.S)
    if m:
        try:
            ld0 = json.loads(m.group(1)); lds = ld0 if isinstance(ld0, list) else [ld0]; geo = {i: (la, lo, _h.unescape(re.sub('<[^>]+>', '', nm)).strip()) for i, la, lo, nm in cards}
            for ld in lds:
                if ld.get('@type') != 'ItemList': continue
                for it in ld.get('itemListElement', []):
                    i = it.get('url', '').split('#')[-1]
                    if i in geo:
                        la, lo, nm = geo[i]; ob = {'@type': 'TouristAttraction', 'name': nm, 'url': it['url']}
                        if la and lo: ob['geo'] = {'@type': 'GeoCoordinates', 'latitude': float(la), 'longitude': float(lo)}
                        it['item'] = ob; it.pop('url', None); it.pop('name', None)
            t = t[:m.start(1)] + json.dumps(ld0, ensure_ascii=False).replace('<', '\\u003c') + t[m.end(1):]
        except Exception as e:
            print('ld skip', f, e)
    open(OUT + '/' + f, 'w', encoding='utf8').write(t); _seo += 1
print('SEO titles/descriptions/ItemList upgraded on', _seo, 'pages')

# 5) charts: "The selection in numbers" (inline SVG, no scripts) on the rankings hub
_pk = json.load(open(OUT + '/picks.json', encoding='utf8'))
def _ms(se):
    if re.search('all year', se or '', re.I): return list(range(1, 13))
    return [i + 1 for i, m in enumerate(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']) if re.search(r'\b' + m + r'\b', se or '')]
_mon = [0] * 12
for p in _pk:
    _m_ = _ms(p.get('se'))
    if len(_m_) < 12:
        for m in _m_: _mon[m - 1] += 1
W_, H_ = 640, 220; mx = max(_mon) or 1; bw = (W_ - 40) / 12
bars = ''.join('<g><rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="6" fill="%s"><title>%s: %d places in season</title></rect><text x="%.1f" y="%d" text-anchor="middle" class="cl">%s</text><text x="%.1f" y="%.1f" text-anchor="middle" class="cv">%d</text></g>' % (
    30 + i * bw + 4, 180 - 150 * v / mx, bw - 8, 150 * v / mx, '#ffbf3c' if i + 1 == NOWM else '#16b3a5', MONL[i], v, 30 + i * bw + bw / 2, 202, MON[i], 30 + i * bw + bw / 2, 174 - 150 * v / mx, v) for i, v in enumerate(_mon))
ch1 = '<figure class="chart"><figcaption>📅 Seasonal places at their best, month by month <small>(year-round places not counted; this month highlighted)</small></figcaption><svg viewBox="0 0 %d %d" role="img" aria-label="Number of places in season per month">%s</svg></figure>' % (W_, H_, bars)
# scatter: latitude vs months in season, coloured by group
GRP = [('aqua', '🐠 Aquariums', '#5b8def', r'aquarium'), ('wild', '🐋 Wildlife', '#8e5bd6', r'whale|wildlife|seabird|turtle|shark|dolphin|biolum|glow'), ('under', '🤿 Snorkel & dive', '#0bb5c9', r'snorkel|div|wreck|underwater'),
       ('boat', '⛴️ Boats', '#ff8a3d', r'cruise|ferry|boat|sail'), ('other', '🏖️ Beaches & more', '#16b37a', r'.')]
def _g(a):
    for k, l, c, rx in GRP:
        if re.search(rx, (a or '').lower()): return k, c
pts = ''
import random as _r; _r.seed(7)
for p in _pk:
    ms = _ms(p.get('se'))
    if not ms or p.get('la') is None or p.get('x') == 2: continue
    k, c = _g(p.get('a'))
    x = 50 + (len(ms) - 1) / 11 * 560 + _r.uniform(-9, 9); y = 20 + (70 - max(-60, min(70, p['la']))) / 130 * 260
    pts += '<circle cx="%.1f" cy="%.1f" r="4.2" fill="%s" fill-opacity=".72"><title>%s – %s, %d months in season</title></circle>' % (x, y, c, esc(p['n']), esc(p['c']), len(ms))
axes = ''.join('<line x1="50" x2="610" y1="%.1f" y2="%.1f" class="gl"/><text x="44" y="%.1f" text-anchor="end" class="cl">%s</text>' % (20 + (70 - l) / 130 * 260, 20 + (70 - l) / 130 * 260, 24 + (70 - l) / 130 * 260, ('%d°%s' % (abs(l), 'N' if l > 0 else 'S')) if l else 'Equator') for l in (60, 30, 0, -30, -60))
axes += ''.join('<text x="%.1f" y="298" text-anchor="middle" class="cl">%d</text>' % (50 + (m - 1) / 11 * 560, m) for m in (1, 3, 6, 9, 12))
leg = ''.join('<span><i style="background:%s"></i>%s</span>' % (c, l) for k, l, c, rx in GRP)
ch2 = ('<figure class="chart"><figcaption>🌍 Season length by latitude <small>(each dot is one place; right = longer season)</small></figcaption><svg viewBox="0 0 640 310" role="img" aria-label="Scatter plot of latitude against months in season">%s%s<text x="330" y="310" text-anchor="middle" class="cl">months in season</text></svg><div class="lg">%s</div></figure>' % (axes, pts, leg))
# activity bars
from collections import Counter as _Cn
_ac = _Cn(_g(p.get('a'))[0] for p in _pk); mxa = max(_ac.values())
ch3 = '<figure class="chart"><figcaption>🧭 What is in the selection</figcaption><div class="hb">' + ''.join('<div><span>%s</span><b style="width:%.0f%%;background:%s"></b><em>%d</em></div>' % (l, 100 * _ac[k] / mxa, c, _ac[k]) for k, l, c, rx in GRP) + '</div></figure>'
_ct = _Cn((p['c'], p.get('cc', '')) for p in _pk).most_common(10); mxc = _ct[0][1]
ch4 = '<figure class="chart"><figcaption>🏳️ Most picks by country</figcaption><div class="hb">' + ''.join('<div><span>%s%s</span><b style="width:%.0f%%"></b><em>%d</em></div>' % (flg(cc), esc(c), 100 * v / mxc, v) for (c, cc), v in _ct) + '</div></figure>'
CCSS = ('<style>.stats{margin:34px 0 0}.stats h2{font-size:24px;margin:0 0 4px;letter-spacing:-.015em}.stats>p{color:#5f8189;margin:0 0 14px}.cg{display:grid;grid-template-columns:1fr 1fr;gap:14px}'
        '.chart{margin:0;background:#fff;border:1px solid #dcebe8;border-radius:20px;padding:16px;box-shadow:0 8px 26px rgba(6,50,58,.06)}.chart figcaption{font-weight:800;margin:0 0 8px;font-size:15px}.chart figcaption small{font-weight:600;color:#6b8790}'
        '.chart svg{width:100%;height:auto;display:block}.chart .cl{font:600 11px system-ui,sans-serif;fill:#6b8790}.chart .cv{font:800 10px system-ui,sans-serif;fill:#06343c}.chart .gl{stroke:#e6efee;stroke-width:1}'
        '.lg{display:flex;flex-wrap:wrap;gap:6px 12px;font-size:12.5px;color:#33555d;margin-top:6px}.lg i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px;vertical-align:0}'
        '.hb>div{display:grid;grid-template-columns:150px 1fr 34px;align-items:center;gap:8px;margin:7px 0;font-size:13.5px}.hb b{display:block;height:14px;border-radius:7px;background:#16b3a5;min-width:4px}.hb em{font-style:normal;font-weight:800;color:#06343c;text-align:right}'
        '@media(max-width:820px){.cg{grid-template-columns:1fr}.hb>div{grid-template-columns:120px 1fr 30px}}</style>')
sec = ('<section class="stats" aria-labelledby="stT"><h2 id="stT">📊 The selection in numbers</h2><p>%d mapped picks in %d countries. Hover or tap a bar or dot for details.</p><div class="cg">%s%s%s%s</div></section>'
       % (len(_pk), len({p['c'] for p in _pk}), ch1, ch2, ch3, ch4))
rk = open(OUT + '/rankings.html', encoding='utf8').read()
if 'class="stats"' not in rk:
    i = rk.find('<footer>'); assert i > 0
    j = rk.rfind('</main>', 0, i)
    pos = j if j > 0 else i
    rk = rk[:pos] + ('<div class="wrap">' + sec + '</div>' if j < 0 else sec) + rk[pos:]
    rk = rk.replace('</head>', CCSS + '</head>', 1)
    open(OUT + '/rankings.html', 'w', encoding='utf8').write(rk)
print('charts ok', _mon)

# ================= 23.21.0: V9 waterfront towns, beach activities, emergency numbers, golden light =================
V9 = '/tmp/w/v9/x/'
_wf = json.load(open(V9 + '02_waterfront_places.json', encoding='utf8'))
_ba = json.load(open(V9 + '03_beach_activities.json', encoding='utf8'))['activities']
_cp = json.load(open(V9 + '04_coastal_profiles.json', encoding='utf8'))
_src = {s['id']: s for s in json.load(open(V9 + '05_sources_and_providers.json', encoding='utf8'))['sources']}
_prof = {p['place_id']: p for p in _cp['profiles']}; _emg = _cp['emergency_by_country']
_pk = json.load(open(OUT + '/picks.json', encoding='utf8'))
CN = {'ES': 'Spain', 'DE': 'Germany', 'TH': 'Thailand', 'ID': 'Indonesia', 'VN': 'Vietnam', 'PH': 'Philippines', 'EG': 'Egypt', 'PT': 'Portugal', 'AU': 'Australia', 'US': 'United States', 'GB': 'United Kingdom', 'ZA': 'South Africa', 'IT': 'Italy'}
def _km(a, b, c, d):
    from math import radians, sin, cos, asin, sqrt
    x = sin(radians(c - a) / 2); y = sin(radians(d - b) / 2); return 12742 * asin(sqrt(x * x + cos(radians(a)) * cos(radians(c)) * y * y))
def _srcs(ids):
    o = []
    for i in ids or []:
        s = _src.get(i)
        if s and s.get('url'): o.append('<li><a href="%s" target="_blank" rel="noopener">%s</a></li>' % (esc(s['url'], True), esc(s.get('title') or s['url'])))
    return ''.join(dict.fromkeys(o))
TCSS = '''<style>.thero{position:relative;color:#fff;background:linear-gradient(135deg,#06343c,#0b6f78 60%,#11a3a0);overflow:hidden}.thero .wrap{position:relative;z-index:1;padding:34px 16px 26px}
.thero h1{margin:6px 0 6px;font-size:34px;letter-spacing:-.02em}.thero p{margin:0;max-width:720px;color:#e3f6f3;font-size:16px}.thero .kick{font-weight:800;font-size:13px;letter-spacing:.06em;text-transform:uppercase;color:#bff0ea}
.thero figure.ph{position:absolute;inset:0;margin:0;opacity:.35}.thero figure.ph img{width:100%;height:100%;object-fit:cover}.thero figure.ph .pi{display:none}.thero figure.ph .cr{position:absolute;right:8px;bottom:6px;font-size:11px;color:#fff}
.tgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:20px 0}.tbox{background:#fff;border:1px solid #dcebe8;border-radius:18px;padding:16px 18px;box-shadow:0 8px 24px rgba(6,50,58,.05)}
.tbox h2{margin:0 0 6px;font-size:18px}.tbox p{margin:0;color:#23474f;line-height:1.55}.tbox.w{grid-column:1/-1}.tbox ul{margin:6px 0 0;padding-left:18px;color:#23474f;line-height:1.55}
.emg{background:#fff5f3;border-color:#f6d2c9}.emg a.call{display:inline-flex;align-items:center;gap:8px;margin:6px 8px 0 0;padding:10px 16px;border-radius:12px;background:#c63b22;color:#fff;font-weight:800;text-decoration:none;font-size:16px}
.gl{background:#fff8e8;border-color:#f3e0ae}.gl b{font-size:17px}.chip2{display:inline-block;margin:6px 6px 0 0;padding:5px 10px;border-radius:999px;background:#eef6f5;font-size:12.5px;font-weight:700;color:#0a5a57}
.near li{margin:6px 0}.act{border-top:1px solid #e6f0ee;padding:10px 0}.act:first-child{border-top:0}.act b{font-size:15.5px}.ev{font-size:11.5px;font-weight:800;padding:3px 8px;border-radius:999px;margin-left:6px}
.ev.op{background:#e3f5f2;color:#0a6f69}.ev.ar{background:#f1eefb;color:#5b3fb0}.ev.fa{background:#fff2dc;color:#8a5a00}.tcards{list-style:none;padding:0;margin:16px 0;display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px}
.tcards a{display:block;height:100%;background:#fff;border:1px solid #dcebe8;border-radius:18px;padding:16px;text-decoration:none;color:#06343c;box-shadow:0 6px 18px rgba(6,50,58,.05)}.tcards a:hover{border-color:#0b8f86}
.tcards b{display:block;font-size:17px;margin:4px 0}.tcards small{color:#5f8189}.tcards p{margin:6px 0 0;font-size:14px;color:#23474f}.srcs{font-size:13px;color:#5f8189}.srcs a{color:#0a6f69}
@media(max-width:760px){.tgrid{grid-template-columns:1fr}.thero h1{font-size:26px}.thero .wrap{padding:22px 16px 18px}}</style>'''
GL_JS = r'''<script>(function(){var el=document.getElementById('gl');if(!el)return;var la=+el.dataset.la,lo=+el.dataset.lo,tz=el.dataset.tz;
function alt(d){var rad=Math.PI/180,jd=d/864e5+2440587.5,n=jd-2451545,L=(280.46+.9856474*n)%360,g=(357.528+.9856003*n)*rad,lam=(L+1.915*Math.sin(g)+.02*Math.sin(2*g))*rad,eps=(23.439-4e-7*n)*rad,
dec=Math.asin(Math.sin(eps)*Math.sin(lam)),ra=Math.atan2(Math.cos(eps)*Math.sin(lam),Math.cos(lam)),gmst=(280.46061837+360.98564736629*n)%360,ha=(gmst+lo)*rad-ra;
return Math.asin(Math.sin(la*rad)*Math.sin(dec)+Math.cos(la*rad)*Math.cos(dec)*Math.cos(ha))/rad}
var now=new Date(),f=new Intl.DateTimeFormat('en-GB',{timeZone:tz,hour:'2-digit',minute:'2-digit'}),df=new Intl.DateTimeFormat('en-GB',{timeZone:tz,weekday:'long',day:'numeric',month:'long'});
var parts=new Intl.DateTimeFormat('en-CA',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
var start=new Date(parts+'T00:00:00Z').getTime()-12*3600e3,w=[],cur=null;for(var t=start;t<start+48*3600e3;t+=2*60e3){var a=alt(t),inb=a>=0&&a<=6;if(inb&&!cur)cur=[t,t];else if(inb)cur[1]=t;else if(cur){w.push(cur);cur=null}}
var dayKey=function(t){return new Intl.DateTimeFormat('en-CA',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(t))};
w=w.filter(function(x){return dayKey(x[0])===parts});
el.innerHTML='<b>'+(w.length?w.map(function(x,i){return(x[0]<start+24*3600e3&&i===0&&w.length>1?'🌅 ':'🌇 ')+f.format(new Date(x[0]))+'–'+f.format(new Date(x[1]))}).join(' · '):'No low-sun window today')+'</b><br><small>Local time, '+df.format(now)+'. Sun between 0° and 6° above the horizon – a light estimate only, not a swimming recommendation.</small>'})();</script>'''
def town_page(p):
    slug = p['id']; cc = p['country_code']; cn = CN.get(cc, cc); pr = _prof.get(p['id'], {}); em = _emg.get(pr.get('emergency_country') or cc)
    la, lo = p['center']['lat'], p['center']['lon']
    am = p.get('amenities') or {}
    ICO = [('culture', '🏛️', 'Culture'), ('food', '🍜', 'Food'), ('shopping', '🛍️', 'Shopping'), ('wellness', '💆', 'Wellness'), ('nightlife', '🌙', 'Nightlife')]
    boxes = ''.join('<div class="tbox"><h2>%s %s</h2><p>%s</p></div>' % (i, l, esc(am[k])) for k, i, l in ICO if am.get(k))
    near = sorted([(_km(la, lo, q['la'], q['lo']), q) for q in _pk if q.get('la') is not None and q.get('x') != 2], key=lambda z: z[0])
    near = [z for z in near if z[0] <= 60][:8]
    nl = ''.join('<li>%s <a href="/%s#%s">%s</a> <small>– %s km</small></li>' % (q.get('i', '🌊'), esc(q['pg'], True) if '?' not in q['pg'] else esc(q['pg'], True), esc(q['id'], True), esc(q['n']), ('%.0f' % d) if d >= 1 else '<1') for d, q in near)
    acts = [a for a in _ba if a.get('place_id') == p['id']]
    def act(a):
        lv = a.get('evidence_level', ''); cls, lab = ('op', 'Named operator') if lv == 'named_operator' else (('fa', 'Named facility') if lv == 'named_facility' else ('ar', 'Activity area – no provider confirmed'))
        pr_ = a.get('price_reference') or {}
        price = (' · from %s %s (%s; published reference, not a live quote)' % (pr_['currency'], pr_['amount'], esc(pr_.get('unit', '')))) if pr_.get('amount') is not None else ''
        bk = a.get('booking_source_url') or ''
        s_ = _srcs(a.get('source_ids'))
        return ('<div class="act"><b>%s</b><span class="ev %s">%s</span><p>%s%s</p>%s%s</div>' % (esc(a['name']), cls, lab, esc(a.get('description', '')), esc(price) if False else price,
                ('<p><small>📍 Meeting area: %s</small></p>' % esc(a['meeting_area'])) if a.get('meeting_area') else '', ('<p class="srcs">Source: <a href="%s" target="_blank" rel="noopener">official page</a></p>' % esc(bk, True)) if bk.startswith('http') else ''))
    actbox = ('<div class="tbox w"><h2>🏄 Beach activities here</h2>%s</div>' % ''.join(act(a) for a in acts)) if acts else ''
    tide = (pr.get('tidal_service') or {}).get('interpretation'); ctx = pr.get('coastal_context') or []
    coast = ('<div class="tbox"><h2>🌊 Coast and water</h2><p><b>%s</b> · %s</p>%s%s</div>' % (esc(pr.get('waterbody') or p.get('waterbody', '')), esc({'sea': 'Sea', 'lake': 'Lake', 'ocean': 'Ocean'}.get(pr.get('water_kind'), pr.get('water_kind') or '')),
            ('<p style="margin-top:6px">🌗 %s</p>' % esc(tide)) if tide else '', ('<ul>%s</ul>' % ''.join('<li>%s</li>' % esc(c) for c in ctx)) if ctx else ''))
    emb = ''
    if em:
        emb = '<div class="tbox emg"><h2>🚨 Emergency numbers in %s</h2>%s<p style="margin-top:8px"><small>%s</small></p></div>' % (esc(cn), ''.join('<a class="call" href="%s">📞 %s <small style="font-weight:600">%s</small></a>' % (esc(n['dial_uri'], True), esc(n['number']), esc(n['label'])) for n in em['numbers']), esc(em.get('note', '')))
    cau = ''.join('<li>%s</li>' % esc(c) for c in p.get('planning_cautions') or [])
    legal = (_wf.get('legal_panels') or {}).get(p.get('legal_module') or '', None)
    legal = ('<div class="tbox w"><h2>🧾 %s</h2><p>%s</p></div>' % (esc(legal['title']), esc(legal['text']))) if isinstance(legal, dict) and legal.get('text') else ''
    title = '%s Waterfront Guide (2026): Beaches, Food, Culture & Activities | DipMapper' % p['name']
    desc = ('%s, %s: %s Food, culture, shopping, wellness, beach activities, emergency numbers and today\'s golden light.' % (p['name'], cn, p.get('headline', '')))[:300]
    ld = [{'@context': 'https://schema.org', '@type': 'TouristDestination', 'name': p['name'], 'description': p.get('description', ''), 'url': 'https://dipmapper.com/' + slug,
           'geo': {'@type': 'GeoCoordinates', 'latitude': la, 'longitude': lo}, 'containedInPlace': {'@type': 'Country', 'name': cn}},
          {'@context': 'https://schema.org', '@type': 'BreadcrumbList', 'itemListElement': [{'@type': 'ListItem', 'position': 1, 'name': 'Waterfront towns', 'item': 'https://dipmapper.com/waterfront-towns'}, {'@type': 'ListItem', 'position': 2, 'name': p['name'], 'item': 'https://dipmapper.com/' + slug}]}]
    h = head(title, desc, 'https://dipmapper.com/' + slug, ld).replace('</head>', TCSS + TAB_CSS + OG + '</head>', 1)
    body = (bar('') + '<section class="thero"><figure class="ph" data-id="%s" data-q="%s" data-la="%s" data-lo="%s"><span class="pi"></span></figure><div class="wrap"><div class="kick">%s %s · Waterfront town</div><h1>%s</h1><p>%s</p></div></section>' % (
        esc(slug, True), esc(p['name'] + ' ' + cn, True), la, lo, flg(cc), esc(cn), esc(p['name']), esc(p.get('headline', ''))) +
        '<main class="wrap"><p style="margin:18px 0 0;font-size:16.5px;line-height:1.6;color:#23474f">%s</p>' % esc(p.get('description', '')) +
        '<p style="margin:10px 0 0"><a class="chip2" href="https://www.google.com/maps/dir/?api=1&amp;destination=%s" target="_blank" rel="noopener">🧭 Route from where you are</a><a class="chip2" href="/explore#near">📍 Water experiences near you</a><a class="chip2" href="/waterfront-towns">🏙️ All waterfront towns</a></p>' % esc(_U.quote(p['name'] + ', ' + cn), True) +
        '<div class="tgrid">' + boxes + coast + '<div class="tbox gl"><h2>🌅 Golden light today</h2><p id="gl" data-la="%s" data-lo="%s" data-tz="%s">Calculating…</p></div>' % (la, lo, esc(p.get('timezone', 'UTC'), True)) + emb +
        (('<div class="tbox"><h2>⚠️ Plan around</h2><ul>%s</ul></div>' % cau) if cau else '') +
        (('<div class="tbox"><h2>⭐ Ranked water experiences nearby</h2><ul class="near">%s</ul></div>' % nl) if nl else '') + actbox + legal + '</div>' +
        '<p class="srcs">This is a waterfront place, not a swimming spot. Written from published sources (desk research, reviewed %s); opening times, prices and conditions change – check before you go. Sources:</p><ul class="srcs">%s</ul></main>' % (esc(p.get('reviewed_at', '')), _srcs(p.get('source_ids'))) +
        FOOT + PHOTO_JS + GL_JS + tabbar('') + '</body></html>')
    return h + body
_tn = 0
for p in _wf['places']:
    open(OUT + '/' + p['id'] + '.html', 'w', encoding='utf8').write(town_page(p)); _tn += 1
# hub
_byc = {}
for p in _wf['places']: _byc.setdefault((p.get('continent', ''), CN.get(p['country_code'], p['country_code']), p['country_code']), []).append(p)
cards = ''
for (cont, cn, cc), ps in sorted(_byc.items()):
    cards += '<h2 style="margin:26px 0 0">%s %s <small style="color:#6b8790;font-size:14px">%s</small></h2><ul class="tcards">%s</ul>' % (flg(cc), esc(cn), esc(cont), ''.join(
        '<li><a href="/%s"><small>%s</small><b>%s</b><p>%s</p></a></li>' % (esc(p['id'], True), ' · '.join(t.replace('-', ' ') for t in (p.get('tags') or [])[:3]), esc(p['name']), esc(p.get('headline', ''))) for p in ps))
_hld = {'@context': 'https://schema.org', '@type': 'ItemList', 'name': 'Waterfront towns', 'itemListElement': [{'@type': 'ListItem', 'position': i + 1, 'url': 'https://dipmapper.com/' + p['id'], 'name': p['name']} for i, p in enumerate(_wf['places'])]}
hub = head('28 Best Waterfront Towns for a Beach Holiday (2026): Food, Culture & Activities | DipMapper',
           'Waterfront towns from Patong and Hua Hin to Palma, Westerland, Bondi and Waikiki: food, culture, shopping, wellness, beach activities, emergency numbers and golden-light times.',
           'https://dipmapper.com/waterfront-towns', _hld).replace('</head>', TCSS + TAB_CSS + OG + '</head>', 1)
hub += (bar('') + '<section class="thero"><div class="wrap"><div class="kick">🏙️ Waterfront towns</div><h1>Where to stay by the water</h1><p>28 towns and resorts in 13 countries – what is there besides the beach, which activities run from the shore, and who to call in an emergency.</p></div></section>'
        '<main class="wrap">' + cards + '<p style="margin:26px 0"><a class="chip2" href="/beach-activities">🏄 Beach activities and prices</a><a class="chip2" href="/explore">🌍 Explore water experiences</a></p></main>' + FOOT + tabbar('') + '</body></html>')
open(OUT + '/waterfront-towns.html', 'w', encoding='utf8').write(hub)
# beach activities hub
_pn = {p['id']: p for p in _wf['places']}
rows = ''
for pid in dict.fromkeys(a['place_id'] for a in _ba):
    p = _pn.get(pid)
    if not p: continue
    lst = ''
    for a in [a for a in _ba if a['place_id'] == pid]:
        lv = a.get('evidence_level', ''); cls, lab = ('op', 'Named operator') if lv == 'named_operator' else (('fa', 'Named facility') if lv == 'named_facility' else ('ar', 'Activity area'))
        pr_ = a.get('price_reference') or {}
        lst += '<div class="act"><b>%s</b><span class="ev %s">%s</span><p>%s%s</p></div>' % (esc(a['name']), cls, lab, esc(a.get('description', '')), (' <b>From %s %s</b> <small>(%s; published reference)</small>' % (esc(pr_['currency']), pr_['amount'], esc(pr_.get('unit', '')))) if pr_.get('amount') is not None else '')
    rows += '<div class="tbox w" style="margin:12px 0"><h2>%s <a href="/%s">%s</a> <small style="color:#6b8790">%s</small></h2>%s</div>' % (flg(p['country_code']), esc(p['id'], True), esc(p['name']), esc(CN.get(p['country_code'], '')), lst)
ba = head('Beach Activities and Prices (2026): Parasailing, SUP, Surf, Kayak, Jet Ski | DipMapper',
          '27 researched beach-activity leads – parasailing, SUP, surfing, sailing, kayaking and jet skis – with published price references and a clear line between named operators and activity areas.',
          'https://dipmapper.com/beach-activities', {'@context': 'https://schema.org', '@type': 'CollectionPage', 'name': 'Beach activities', 'url': 'https://dipmapper.com/beach-activities'}).replace('</head>', TCSS + TAB_CSS + OG + '</head>', 1)
ba += (bar('') + '<section class="thero"><div class="wrap"><div class="kick">🏄 Beach activities</div><h1>Beach activities and published prices</h1><p>Named operators are marked as such; an "activity area" means the activity is documented there, but no provider, phone number or boarding point has been confirmed.</p></div></section>'
       '<main class="wrap">' + rows + '<p class="srcs">Prices are published references from the operators\' own pages, not live quotes. Check the final price, extras and conditions when booking.</p></main>' + FOOT + tabbar('') + '</body></html>')
open(OUT + '/beach-activities.html', 'w', encoding='utf8').write(ba)
# entry points: rankings hub + explore
rk = open(OUT + '/rankings.html', encoding='utf8').read()
if 'href="/waterfront-towns"' not in rk:
    rk = rk.replace('<section class="stats"', '<p style="margin:26px 0 0"><a class="chip2" style="font-size:15px;padding:10px 16px" href="/waterfront-towns">🏙️ 28 waterfront towns: food, culture, activities →</a> <a class="chip2" style="font-size:15px;padding:10px 16px" href="/beach-activities">🏄 Beach activities and prices →</a></p><section class="stats"', 1)
    rk = rk.replace('</head>', '<style>.chip2{display:inline-block;margin:6px 6px 0 0;padding:5px 10px;border-radius:999px;background:#eef6f5;font-weight:700;color:#0a5a57;text-decoration:none}</style></head>', 1)
    open(OUT + '/rankings.html', 'w', encoding='utf8').write(rk)
xp = open(OUT + '/explore.html', encoding='utf8').read()
xp = xp.replace('<p class="xclassic">', '<p class="xclassic">🏙️ Staying in a beach town? <a href="/waterfront-towns">28 waterfront town guides</a> – food, culture, activities and emergency numbers.</p><p class="xclassic">', 1)
open(OUT + '/explore.html', 'w', encoding='utf8').write(xp)
ix = open(OUT + '/index.html', encoding='utf8').read()
ix = ix.replace('data-version="v23.20.0"', 'data-version="v23.21.0"').replace('DipMapper version 23.20.0</p>', 'DipMapper version 23.21.0</p>')
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
print('23.21 towns', _tn, 'activities', len(_ba))

# ================= 23.22.0: live coastal conditions (Open-Meteo weather + marine, NWS alerts), Palma example start =================
shutil.copy('/tmp/w/v9/b/coastal.js', OUT + '/coastal.js')
ix = open(OUT + '/index.html', encoding='utf8').read()
if '/coastal.js' not in ix:
    k = ix.rfind('</body>'); ix = ix[:k] + '<script src="/coastal.js" defer></script>' + ix[k:]
ix = ix.replace('<link rel="preconnect" href="https://tiles.openfreemap.org" crossorigin>', '<link rel="preconnect" href="https://tiles.openfreemap.org" crossorigin><link rel="preconnect" href="https://api.open-meteo.com" crossorigin><link rel="preconnect" href="https://marine-api.open-meteo.com" crossorigin>', 1)
ix = ix.replace('data-version="v23.21.0"', 'data-version="v23.22.0"').replace('DipMapper version 23.21.0</p>', 'DipMapper version 23.22.0</p>')
open(OUT + '/index.html', 'w', encoding='utf8').write(ix)
_n = 0
for p in _wf['places']:
    f = OUT + '/' + p['id'] + '.html'; t = open(f, encoding='utf8').read()
    box = ('<div class="tbox w" id="cnow"><h2>🌊 Sea, tide and weather now</h2><div id="cbox" data-la="%s" data-lo="%s"></div></div>' % (p['center']['lat'], p['center']['lon']))
    t = t.replace('<div class="tgrid">', '<div class="tgrid">' + box, 1)
    t = t.replace('</body>', '<script src="/coastal.js"></script><script>(function(){var b=document.getElementById("cbox");if(b&&window.dmCoastBox)dmCoastBox(b,+b.dataset.la,+b.dataset.lo,"")})();</script></body>', 1)
    t = t.replace('</head>', '<style>#cbox .note{font-size:12.5px;color:#5f7d86}#cbox h3{margin:12px 0 4px;font-size:15px}#cbox p{margin:0 0 4px}#cbox a.call{display:inline-block;margin:4px 6px 0 0;padding:8px 12px;border-radius:10px;background:#c63b22;color:#fff;font-weight:800;text-decoration:none}#cbox .src{font-size:12px;color:#6b8790}#cbox .alert{background:#fff2ef;border-left:4px solid #c63b22;padding:6px 10px;border-radius:8px}</style></head>', 1)
    open(f, 'w', encoding='utf8').write(t); _n += 1
print('23.22 coastal live on map +', _n, 'town pages')

# ================= 23.22.0 (cont.): risk timing everywhere + sea-risk calendar page =================
shutil.copy('/tmp/w/v9/b/coastal.js', OUT + '/coastal.js')
_rk = json.load(open('/tmp/w/v9/b/risks.json', encoding='utf8'))
_cnt = 0
for f in sorted(os.listdir(OUT)):
    if not f.endswith('.html') or f in ('index.html',) or f.startswith('town-'): continue
    t = open(OUT + '/' + f, encoding='utf8').read()
    if '/coastal.js' in t or ('data-la="' not in t and f != 'explore.html'): continue
    t = t.replace('</body>', '<script src="/coastal.js" defer></script></body>', 1); open(OUT + '/' + f, 'w', encoding='utf8').write(t); _cnt += 1
MONS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
def _strip(r):
    if r.get('lunar'): return '<p class="note">Every month: about %d–%d days after the full moon (see the live dates on the map).</p>' % tuple(r['lunar'])
    return '<span class="rs">' + ''.join('<i class="%s%s" title="%s">%s</i>' % ('pk' if (i + 1) in r.get('peak', []) else ('on' if (i + 1) in r['months'] else ''), ' now' if i + 1 == NOWM else '', m, m[0]) for i, m in enumerate(MONS)) + '</span>'
rows = ''.join('<div class="rk"><h2>%s %s</h2>%s<p>%s</p><p class="note">Source: %s</p></div>' % (r['icon'], esc(r['name']), _strip(r), esc(r['what']), ' · '.join('<a href="%s" target="_blank" rel="noopener">%s</a>' % (esc(u, True), esc(n)) for n, u in r['src'])) for r in _rk)
RCAL_CSS = ('<style>.rk{background:#fff;border:1px solid #dcebe8;border-left:5px solid #c63b22;border-radius:16px;padding:14px 16px;margin:12px 0;box-shadow:0 6px 18px rgba(6,50,58,.05)}.rk h2{margin:0 0 6px;font-size:18px}.rk p{margin:6px 0 0;color:#23474f}.rk .note{font-size:13px;color:#5f8189}'
            '.rs{display:flex;gap:3px;margin:6px 0;max-width:420px}.rs i{flex:1;height:22px;border-radius:5px;background:#eef3f3;color:#9db1b5;font:800 11px/22px system-ui,sans-serif;text-align:center;font-style:normal}.rs i.on{background:#f3a28f;color:#fff}.rs i.pk{background:#c63b22;color:#fff}.rs i.now{outline:2px solid #06343c;outline-offset:1px}'
            '.lg2 span{display:inline-flex;align-items:center;gap:6px;margin-right:14px;font-size:13px}.lg2 i{width:14px;height:14px;border-radius:4px;display:inline-block}</style>')
rc = head('Sea Risk Calendar (2026): Hurricane, Typhoon, Cyclone, Box Jellyfish & Sargassum Seasons | DipMapper',
          'When are the risky months at the beach? Hurricane, typhoon and cyclone seasons, box jellyfish and stinger seasons, monsoon red-flag months and sargassum season – month by month, with official sources.',
          'https://dipmapper.com/sea-risk-calendar', {'@context': 'https://schema.org', '@type': 'WebPage', 'name': 'Sea risk calendar', 'url': 'https://dipmapper.com/sea-risk-calendar'}).replace('</head>', TCSS + RCAL_CSS + TAB_CSS + OG + '</head>', 1)
rc += (bar('') + '<section class="thero"><div class="wrap"><div class="kick">⚠️ Risk timing</div><h1>Sea risk calendar</h1><p>Storm seasons, dangerous jellyfish and seaweed – the months when the beach needs extra care. The map shows the same risks for wherever you look, and Hawaii box-jellyfish dates are calculated live from the moon.</p></div></section>'
       '<main class="wrap"><p class="lg2" style="margin:16px 0 0"><span><i style="background:#c63b22"></i>Peak months</span><span><i style="background:#f3a28f"></i>Season</span><span><i style="background:#fff;outline:2px solid #06343c"></i>This month</span></p>' + rows +
       '<p class="note" style="color:#5f8189;font-size:13px">A risk season does not mean every day is dangerous, and outside it the sea is not automatically safe: rip currents, weather and local hazards apply all year. Always follow beach flags, lifeguards and official warnings.</p></main>' + FOOT + tabbar('') + '</body></html>')
open(OUT + '/sea-risk-calendar.html', 'w', encoding='utf8').write(rc)
for f in ['rankings.html', 'wildlife-calendar.html', 'waterfront-towns.html']:
    t = open(OUT + '/' + f, encoding='utf8').read()
    if 'href="/sea-risk-calendar"' in t: continue
    link = '<p style="margin:18px 0"><a class="chip2" style="font-size:15px;padding:10px 16px;background:#fff1ed;color:#a3311b" href="/sea-risk-calendar">⚠️ Sea risk calendar: storm, jellyfish and seaweed seasons →</a></p>'
    t = t.replace('<section class="stats"', link + '<section class="stats"', 1) if f == 'rankings.html' else t.replace('<footer>', '<div class="wrap">' + link + '</div><footer>', 1)
    if '.chip2{' not in t: t = t.replace('</head>', '<style>.chip2{display:inline-block;margin:6px 6px 0 0;padding:5px 10px;border-radius:999px;background:#eef6f5;font-weight:700;color:#0a5a57;text-decoration:none}</style></head>', 1)
    open(OUT + '/' + f, 'w', encoding='utf8').write(t)
for p in _wf['places']:
    f = OUT + '/' + p['id'] + '.html'; t = open(f, encoding='utf8').read()
    t = t.replace('<a class="chip2" href="/waterfront-towns">', '<a class="chip2" href="/sea-risk-calendar">⚠️ Sea risk calendar</a><a class="chip2" href="/waterfront-towns">', 1); open(f, 'w', encoding='utf8').write(t)
print('risk timing: coastal.js on', _cnt, 'pages + calendar page')
