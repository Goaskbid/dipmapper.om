import json, re, urllib.parse
from collections import Counter
DC = json.load(open('/tmp/chk2/data-collect.json', encoding='utf8'))
GEN = set('island islands isle bay national park reef lake beach state marine the of county river springs spring cave monument area islet key coast'.split())
def toks(s): return set(t for t in re.split(r'[^a-z0-9À-ɏ]+', s.lower()) if t)
def reg(host):
    h = host.lower().split(':')[0]; h = h[4:] if h.startswith('www.') else h
    p = h.split('.'); return '.'.join(p[-3:]) if len(p) > 2 and len(p[-1]) == 2 and p[-2] in ('co', 'com', 'org', 'net', 'gov', 'ac') else '.'.join(p[-2:])
def positions(picks):
    out = {}
    for p in picks:
        hits = DC['positions'].get(p['id']) or []
        name = toks(p['n'])
        for h in hits:
            t = toks(re.sub(r'\(.*?\)', '', h['title'])) - GEN
            if not t or not t <= name: continue
            lim = 2600 if p.get('x') == 2 else 300
            if h['km_from_old'] > lim: continue
            out[p['id']] = (h['la'], h['lo'], h['title'], h['url']); break
    return out
def contacts(picks):
    dom = Counter(reg(urllib.parse.urlsplit(p['u']).netloc) for p in picks if p.get('u'))
    out = {}
    for p in picks:
        r = DC['contacts'].get(p['id']) or {}
        if not p.get('u') or r.get('error'): continue
        d = reg(urllib.parse.urlsplit(p['u']).netloc)
        if dom[d] > 2: continue  # portal / tourism board shared by many picks: not the provider's own contact
        tel = [t for t in (r.get('tel') or []) if 'http' not in t and 7 <= len(re.sub(r'\D', '', t)) <= 15]
        tel.sort(key=lambda t: not t.strip().startswith('+'))
        mail = [m for m in (r.get('mail') or []) if reg(m.split('@')[-1]) == d]
        if tel or mail: out[p['id']] = {'tel': tel[:1], 'mail': mail[:1], 'src': (r.get('src') or [p['u']])[0]}
    return out
