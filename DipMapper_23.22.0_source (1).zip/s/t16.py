import asyncio
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1440,'height':900})
    await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
    await pg.goto(B+'/');await pg.wait_for_timeout(6500)
    await pg.evaluate("document.querySelectorAll('#gate,.gate').forEach(e=>e.style.display='none');state.center=[47.36,8.54];state.mapCenter=[47.3,8.6];state.zoom=8;try{drawMap()}catch(e){}");await pg.wait_for_timeout(1500)
    await pg.evaluate("document.querySelector('.dmStar').click()");await pg.wait_for_timeout(300)
    print('star->',await pg.evaluate("(document.querySelector('.dmStarPop h4')||{}).textContent"))
    await pg.evaluate("document.querySelector('.dmStarPop .x').click();document.querySelector('#dmPicksBar button').click()");await pg.wait_for_timeout(300)
    print('bar->',await pg.evaluate("(document.querySelector('.dmStarPop h4')||{}).textContent"))
    await b.close()
asyncio.run(main())
