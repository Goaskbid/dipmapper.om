import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831';D='/tmp/w/ml/node_modules/maplibre-gl/dist/'
STYLE=json.dumps({"version":8,"sources":{},"layers":[{"id":"bg","type":"background","paint":{"background-color":"#cfe9f2"}}]})
async def route(r):
  u=r.request.url
  if u.startswith(B): return await r.continue_()
  if 'maplibre-gl.js' in u: return await r.fulfill(path=D+'maplibre-gl.js',content_type='application/javascript')
  if 'maplibre-gl.css' in u: return await r.fulfill(path=D+'maplibre-gl.css',content_type='text/css')
  if 'openfreemap.org/styles' in u: return await r.fulfill(body=STYLE,content_type='application/json')
  return await r.abort()
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader']);R={}
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      ctx=await b.new_context(viewport={'width':w,'height':h},service_workers='block',geolocation={'latitude':7.896,'longitude':98.296},permissions=['geolocation']);pg=await ctx.new_page();errs=[]
      pg.on('pageerror',lambda e:errs.append(str(e)[:150]));await ctx.route('**/*',route)
      await pg.goto(B+'/explore');await pg.wait_for_timeout(3000)
      R[t+'_auto']=await pg.evaluate("__dmX.mode()")
      await pg.click('.xseg button[data-m=near]');await pg.wait_for_timeout(2500)
      R[t+'_near']=await pg.evaluate("__dmX.view().slice(0,6).map(p=>p.n+' '+Math.round(p._d)+'km')")
      R[t+'_loc']=await pg.evaluate("document.getElementById('xLoc').textContent")
      R[t+'_cards']=await pg.evaluate("document.querySelectorAll('.xc').length")
      R[t+'_marks']=await pg.evaluate("document.querySelectorAll('.xmk').length")
      await pg.screenshot(path=f'/tmp/w/s/x_{t}.png')
      await pg.click('.xchips button[data-g=under]');await pg.wait_for_timeout(500)
      R[t+'_under']=await pg.evaluate("__dmX.view().slice(0,3).map(p=>p.n+' '+Math.round(p._d)+'km')")
      await pg.click('.xseg button[data-m=season]');await pg.wait_for_timeout(500);R[t+'_season']=await pg.evaluate("document.getElementById('xStat').textContent")
      await pg.click('.xchips button[data-g=all]');await pg.click('.xseg button[data-m=top]');await pg.wait_for_timeout(300);R[t+'_top']=await pg.evaluate("__dmX.view().slice(0,2).map(p=>p.n)")
      await pg.click('#xMore');await pg.wait_for_timeout(300);R[t+'_more']=await pg.evaluate("document.querySelectorAll('.xc').length")
      R[t+'_hs']=await pg.evaluate("document.documentElement.scrollWidth>innerWidth")
      pg2=await ctx.new_page();await pg2.goto(B+'/explore');await pg2.wait_for_timeout(2500);R[t+'_remember']=await pg2.evaluate("__dmX.mode()")
      R[t+'_err']=errs;await ctx.close()
    await b.close();print(json.dumps(R,ensure_ascii=False,indent=0))
asyncio.run(main())
