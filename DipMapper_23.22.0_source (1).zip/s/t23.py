import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      ctx=await b.new_context(viewport={'width':w,'height':h},service_workers='block');pg=await ctx.new_page();errs=[]
      pg.on('pageerror',lambda e:errs.append(str(e)[:150]));await ctx.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
      for u in ['/town-patong','/town-westerland','/town-riva','/waterfront-towns','/beach-activities','/town-arenal']:
        await pg.goto(B+u);await pg.wait_for_timeout(500)
        R[t+u]=[await pg.evaluate("(document.getElementById('gl')||{}).textContent||''"),await pg.evaluate("document.documentElement.scrollWidth>innerWidth"),await pg.evaluate("document.querySelectorAll('.tbox').length")]
      await pg.goto(B+'/town-patong');await pg.wait_for_timeout(500);await pg.screenshot(path=f'/tmp/w/s/town_{t}.png',full_page=True)
      R[t+'err']=errs;await ctx.close()
    await b.close();print(json.dumps(R,ensure_ascii=False,indent=0))
asyncio.run(main())
