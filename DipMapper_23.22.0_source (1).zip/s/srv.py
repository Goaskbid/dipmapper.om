import http.server,os,sys
class H(http.server.SimpleHTTPRequestHandler):
  def translate_path(self,p):
    f=super().translate_path(p)
    if not os.path.exists(f) and os.path.exists(f+'.html'): return f+'.html'
    return f
  def log_message(self,*a):pass
os.chdir(sys.argv[1]);http.server.ThreadingHTTPServer(('127.0.0.1',int(sys.argv[2])),H).serve_forever()
