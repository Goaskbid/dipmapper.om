import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      ctx=await b.new_context(viewport={'width':w,'height':h},service_workers='block',geolocation={'latitude':7.896,'longitude':98.296},permissions=['geolocation']);pg=await ctx.new_page();errs=[]
      pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
      await ctx.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
      await pg.goto(B+'/');await pg.wait_for_timeout(6000);await pg.click('#gateSkip');await pg.wait_for_timeout(500)
      await pg.evaluate("state.center=[8.2,98.1];state.mapCenter=[8.2,98.1];state.zoom=8;try{drawMap()}catch(e){}");await pg.wait_for_timeout(1500)
      await pg.locator('#map').scroll_into_view_if_needed()
      st=pg.locator('.dmStar').first;await st.click(force=True);await pg.wait_for_timeout(500)
      R[t+'_pop']=await pg.evaluate("(()=>{var o=document.querySelector('.dmStarPop');return o?[o.querySelector('h4').textContent,(o.querySelector('.dmGt')||{}).textContent,[...o.querySelectorAll('.l a')].map(a=>a.textContent+' '+a.href.slice(0,80))]:null})()")
      await pg.locator('.dmStarPop').screenshot(path=f'pop_{t}.png')
      await pg.goto(B+'/water-experiences-thailand');await pg.wait_for_timeout(800)
      R[t+'_card']=await pg.evaluate("(()=>{var c=document.getElementById('dive-similan');return [c.querySelector('.gt').textContent,[...c.querySelectorAll('.acts a')].map(a=>a.textContent+' '+a.href.slice(0,90))]})()")
      await pg.locator('#dive-similan').screenshot(path=f'card_{t}.png')
      R[t+'_err']=errs;await ctx.close()
    await b.close();print(json.dumps(R,ensure_ascii=False,indent=0))
asyncio.run(main())
