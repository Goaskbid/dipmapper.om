import asyncio,json,sys
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for w,h in [(390,844),(1440,900)]:
      pg=await b.new_page(viewport={'width':w,'height':h});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
      await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort())
      await pg.goto(B+'/');await pg.wait_for_timeout(7000)
      r=await pg.evaluate("""()=>({url:location.pathname,ver:document.body&&document.body.dataset.version,gate:document.querySelectorAll('#dmGateActs button[data-a]').length,routes:document.querySelectorAll('.dmGateRoutes a').length,boot:!!document.getElementById('dmBoot'),title:document.title})""")
      await pg.evaluate("document.querySelectorAll('#gate,.gate').forEach(e=>e.style.display='none');state.center=[47.36,8.54];state.mapCenter=[47.3,8.6];state.zoom=8;try{drawMap()}catch(e){}")
      await pg.wait_for_timeout(1500);r['stars']=await pg.evaluate("window.__dmPicks?window.__dmPicks.visible():-1");r['errors']=errs;print(w,json.dumps(r))
      await pg.close()
    await b.close()
asyncio.run(main())
