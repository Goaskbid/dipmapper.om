import asyncio,json
from playwright.async_api import async_playwright
B='http://127.0.0.1:8831'
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch();R={}
    for w,h,t in [(390,844,'ph'),(1440,900,'pc')]:
      ctx=await b.new_context(viewport={'width':w,'height':h},geolocation={'latitude':47.27,'longitude':8.65},permissions=['geolocation'])
      async def page():
        pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:150]))
        await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(B) else r.abort());return pg,errs
      pg,errs=await page();await pg.goto(B+'/whale-watch');await pg.wait_for_timeout(500)
      r={'cards':await pg.evaluate("document.querySelectorAll('.card').length"),'hs':await pg.evaluate("document.documentElement.scrollWidth>innerWidth")}
      await pg.screenshot(path=f'/tmp/w/s/r5_{t}.png')
      await pg.click('.seg button[data-f=now]');r['inSeason']=await pg.evaluate("document.querySelectorAll('.card:not([hidden])').length")
      await pg.click('.seg button[data-f=all]')
      await pg.locator('.card details').first.click();await pg.wait_for_timeout(200);await pg.locator('.card').first.screenshot(path=f'/tmp/w/s/card5_{t}.png')
      r['errors']=errs;R['rank_'+t]=r;await pg.close()
      pg,errs=await page();await pg.goto(B+'/rankings');await pg.wait_for_timeout(400);await pg.screenshot(path=f'/tmp/w/s/hub5_{t}.png',full_page=False)
      R['hub_'+t]={'eds':await pg.evaluate("document.querySelectorAll('.ed').length"),'selects':await pg.evaluate("document.querySelectorAll('.pickers select').length"),'hs':await pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'errors':errs};await pg.close()
      pg,errs=await page();await pg.goto(B+'/explore#near');await pg.wait_for_timeout(1500)
      await pg.click('#nearMe');await pg.wait_for_timeout(1500)
      R['near_'+t]={'items':await pg.evaluate("document.querySelectorAll('#nearList li').length"),'first':await pg.evaluate("(document.querySelector('#nearList li h3')||{}).textContent"),
        'been':await pg.evaluate("!!window.__dmBeen"),'explorer':await pg.evaluate("!!document.getElementById('dipmapper-v3').shadowRoot"),'hs':await pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'errors':errs}
      await pg.locator('#near').screenshot(path=f'/tmp/w/s/near5_{t}.png');await pg.close()
      pg,errs=await page();await pg.goto(B+'/');await pg.wait_for_timeout(6500)
      R['home_'+t]={'ver':await pg.evaluate("document.body.dataset.version"),'routes':await pg.evaluate("[...document.querySelectorAll('.dmGateRoutes a')].map(a=>a.getAttribute('href'))"),
        'icon':await pg.evaluate("[...document.querySelectorAll('link[rel=icon]')].map(l=>l.type)"),'gate':await pg.evaluate("document.querySelectorAll('#dmGateActs button[data-a]').length"),'errors':errs}
      await pg.evaluate("document.querySelectorAll('#gate,.gate').forEach(e=>e.style.display='none');state.center=[47.36,8.54];state.mapCenter=[47.3,8.6];state.zoom=8;try{drawMap()}catch(e){}")
      await pg.wait_for_timeout(1500);R['home_'+t]['stars']=await pg.evaluate("window.__dmPicks.visible()");await pg.close();await ctx.close()
    await b.close();print(json.dumps(R,indent=0,ensure_ascii=False))
asyncio.run(main())
