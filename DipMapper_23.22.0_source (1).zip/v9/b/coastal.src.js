/* DipMapper coastal conditions (v23.22): weather + marine model data from Open-Meteo, official US alerts (NWS),
   locally calculated golden light, emergency numbers and official hazard sources. Never claims "safe" or "no hazards". */
(function(){'use strict';
var D=__DATA__,MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function E(t){return String(t==null?'':t).replace(/[&<>"]/g,function(m){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]})}
function km(a,b,c,d){var r=Math.PI/180,x=Math.sin((c-a)*r/2),y=Math.sin((d-b)*r/2);return 12742*Math.asin(Math.sqrt(x*x+Math.cos(a*r)*Math.cos(c*r)*y*y))}
var WC={0:['☀️','Clear'],1:['🌤️','Mainly clear'],2:['⛅','Partly cloudy'],3:['☁️','Overcast'],45:['🌫️','Fog'],48:['🌫️','Fog'],51:['🌦️','Drizzle'],53:['🌦️','Drizzle'],55:['🌦️','Drizzle'],61:['🌧️','Rain'],63:['🌧️','Rain'],65:['🌧️','Heavy rain'],66:['🌧️','Freezing rain'],67:['🌧️','Freezing rain'],71:['🌨️','Snow'],73:['🌨️','Snow'],75:['🌨️','Snow'],77:['🌨️','Snow'],80:['🌦️','Showers'],81:['🌧️','Showers'],82:['⛈️','Violent showers'],85:['🌨️','Snow showers'],86:['🌨️','Snow showers'],95:['⛈️','Thunderstorm'],96:['⛈️','Thunderstorm, hail'],99:['⛈️','Thunderstorm, hail']};
function dir(d){return d==null?'':['N','NE','E','SE','S','SW','W','NW'][Math.round(d/45)%8]}
function sunAlt(t,la,lo){var rad=Math.PI/180,n=t/864e5+2440587.5-2451545,L=(280.46+.9856474*n)%360,g=(357.528+.9856003*n)*rad,lam=(L+1.915*Math.sin(g)+.02*Math.sin(2*g))*rad,eps=(23.439-4e-7*n)*rad,
 dec=Math.asin(Math.sin(eps)*Math.sin(lam)),ra=Math.atan2(Math.cos(eps)*Math.sin(lam),Math.cos(lam)),gmst=(280.46061837+360.98564736629*n)%360,ha=(gmst+lo)*rad-ra;
 return Math.asin(Math.sin(la*rad)*Math.sin(dec)+Math.cos(la*rad)*Math.cos(dec)*Math.cos(ha))/rad}
function golden(la,lo,off){var now=Date.now(),w=[],cur=null;for(var t=now;t<now+30*3600e3;t+=2*60e3){var a=sunAlt(t,la,lo),inb=a>=0&&a<=6;if(inb&&!cur)cur=[t,t];else if(inb)cur[1]=t;else if(cur){w.push(cur);cur=null}if(w.length>=2)break}return w}
function hm(t,off){var d=new Date(t+off*1000);return('0'+d.getUTCHours()).slice(-2)+':'+('0'+d.getUTCMinutes()).slice(-2)}
function day(t,off){var d=new Date(t+off*1000),n=new Date(Date.now()+off*1000);return d.getUTCDate()===n.getUTCDate()?'today':MON[d.getUTCMonth()]+' '+d.getUTCDate()}
function place(la,lo){var best=null,bd=1e9;D.towns.forEach(function(t){var d=km(la,lo,t[3],t[4]);if(d<bd){bd=d;best=t}});return bd<=150?{town:best,d:bd,cc:best[2]}:null}
function tides(h,off){if(!h||!h.time||!h.sea_level_height_msl)return null;var v=h.sea_level_height_msl,ts=h.time.map(function(x){return Date.parse(x+'Z')-off*1000}),now=Date.now(),o=[];
 for(var i=1;i<v.length-1;i++){if(v[i]==null||v[i-1]==null||v[i+1]==null||ts[i]<now)continue;if(v[i]>v[i-1]&&v[i]>=v[i+1])o.push(['High',ts[i],v[i]]);else if(v[i]<v[i-1]&&v[i]<=v[i+1])o.push(['Low',ts[i],v[i]])}
 var range=Math.max.apply(null,v.filter(function(x){return x!=null}))-Math.min.apply(null,v.filter(function(x){return x!=null}));return{ev:o.slice(0,4),range:range}}

var RK=__RISKS__,SYN=29.530588853,FM0=Date.UTC(2000,0,21,4,40);
function pip(la,lo,poly){var ins=false;for(var i=0,j=poly.length-1;i<poly.length;j=i++){var yi=poly[i][0],xi=poly[i][1],yj=poly[j][0],xj=poly[j][1];if(((yi>la)!==(yj>la))&&(lo<(xj-xi)*(la-yi)/(yj-yi)+xi))ins=!ins}return ins}
function lunarWins(w,from,n){var o=[],k=Math.floor((from-FM0)/(SYN*864e5))-1;while(o.length<n){var fm=FM0+k*SYN*864e5,a=fm+w[0]*864e5,b=fm+(w[1]+1)*864e5;if(b>from)o.push([a,b]);k++}return o}
function fmtD(t){var d=new Date(t);return d.getUTCDate()+' '+MON[d.getUTCMonth()]}
function risksAt(la,lo,now){now=now||Date.now();var m=new Date(now).getUTCMonth()+1,out=[];
 RK.forEach(function(r){if(!r.poly.some(function(p){return pip(la,lo,p)}))return;var o={r:r};
  if(r.lunar){var w=lunarWins(r.lunar,now,3);o.wins=w;o.now=w[0][0]<=now;o.soon=!o.now&&w[0][0]-now<12*864e5;o.label=o.now?'Now, until '+fmtD(w[0][1]-864e5):'Next '+fmtD(w[0][0])+'–'+fmtD(w[0][1]-864e5)}
  else{o.now=r.months.indexOf(m)>=0;o.peak=(r.peak||[]).indexOf(m)>=0;var nx=0;for(var i=1;i<=12&&!o.now;i++){if(r.months.indexOf((m-1+i)%12+1)>=0){nx=(m-1+i)%12+1;break}}o.soon=!o.now&&nx&&((nx-m+12)%12)<=1;
   o.label=o.now?(o.peak?'Now – peak months':'Now – in season'):('Starts '+MON[nx-1])}
  out.push(o)});
 var P={'🪼':1,'🚩':2,'🟤':3,'🌀':4};out.sort(function(a,b){return(b.now-a.now)||(b.soon-a.soon)||((P[a.r.icon]||9)-(P[b.r.icon]||9))});return out}
window.dmRisks=risksAt;
function strip(r){if(r.lunar)return'';var m=new Date().getUTCMonth()+1;return'<span class="rs">'+MON.map(function(x,i){var on=r.months.indexOf(i+1)>=0,pk=(r.peak||[]).indexOf(i+1)>=0;return'<i class="'+(pk?'pk':on?'on':'')+(i+1===m?' now':'')+'" title="'+x+'">'+x[0]+'</i>'}).join('')+'</span>'}
function riskHTML(rs){if(!rs.length)return'<p>No regional storm, stinger or seaweed season on DipMapper\'s risk calendar for this point. That is not an all-clear – rip currents, weather and local hazards apply everywhere.</p>';
 return rs.map(function(o){var r=o.r;return'<div class="rk'+(o.now?' act':o.soon?' soon':'')+'"><b>'+r.icon+' '+E(r.name)+'</b> <span class="st">'+E(o.label)+'</span>'+strip(r)+
  (o.wins?'<p class="note">Next windows: '+o.wins.map(function(w){return fmtD(w[0])+'–'+fmtD(w[1]-864e5)}).join(' · ')+' (calculated from the moon phase)</p>':'')+'<p>'+E(r.what)+'</p><p class="note">Source: '+r.src.map(function(s){return'<a href="'+E(s[1])+'" target="_blank" rel="noopener">'+E(s[0])+'</a>'}).join(' · ')+'</p></div>'}).join('')}
function riskChip(rs){var a=rs.filter(function(o){return o.now||o.soon})[0];if(!a)return'';return'<span class="al">'+a.r.icon+' '+E(a.r.name.split(' (')[0].replace(' season',''))+': '+E(a.now?'now':a.label)+'</span>'}
var RCSS='.rk{border-left:4px solid #d6e2e0;padding:6px 10px;margin:8px 0;border-radius:8px;background:#f7faf9}.rk.act{border-color:#c63b22;background:#fff3f0}.rk.soon{border-color:#e69b00;background:#fff9ec}.rk .st{font-size:12px;font-weight:800;color:#c63b22;margin-left:4px}.rk.soon .st{color:#a06a00}.rk:not(.act):not(.soon) .st{color:#5f7d86}'
+'.rs{display:flex;gap:2px;margin:5px 0}.rs i{flex:1;max-width:22px;height:16px;border-radius:4px;background:#eef3f3;color:#9db1b5;font:700 9px/16px system-ui,sans-serif;text-align:center;font-style:normal}.rs i.on{background:#f3a28f;color:#fff}.rs i.pk{background:#c63b22;color:#fff}.rs i.now{outline:2px solid #06343c;outline-offset:1px}'
+'.rkb{position:absolute;left:8px;bottom:8px;z-index:2;background:rgba(198,59,34,.93);color:#fff;font:800 11.5px system-ui,sans-serif;padding:4px 8px;border-radius:999px}.rkb.soon{background:rgba(201,128,0,.93)}';
var cache={};
function get(u,sig){if(cache[u]&&Date.now()-cache[u].t<9e5)return Promise.resolve(cache[u].v);return fetch(u,{signal:sig}).then(function(r){if(!r.ok)throw new Error(r.status);return r.json()}).then(function(j){cache[u]={t:Date.now(),v:j};return j})}
function load(la,lo,sig){la=+la.toFixed(3);lo=+lo.toFixed(3);
 var w=get('https://api.open-meteo.com/v1/forecast?latitude='+la+'&longitude='+lo+'&current=temperature_2m,weather_code,wind_speed_10m,wind_gusts_10m,wind_direction_10m&daily=uv_index_max&timezone=auto&forecast_days=1',sig).catch(function(){return null});
 var m=get('https://marine-api.open-meteo.com/v1/marine?latitude='+la+'&longitude='+lo+'&current=wave_height,wave_period,wave_direction,sea_surface_temperature&hourly=sea_level_height_msl&timezone=auto&forecast_days=3',sig).catch(function(){return null});
 var us=la>18&&la<72&&lo>-180&&lo<-64,a=us?fetch('https://api.weather.gov/alerts/active?point='+la+','+lo,{signal:sig,headers:{Accept:'application/geo+json'}}).then(function(r){return r.ok?r.json():null}).catch(function(){return null}):Promise.resolve(undefined);
 return Promise.all([w,m,a]).then(function(x){return{la:la,lo:lo,w:x[0],m:x[1],a:x[2],p:place(la,lo)}})}
function model(r){var w=r.w,m=r.m,off=(w&&w.utc_offset_seconds)||(m&&m.utc_offset_seconds)||0,o={off:off,tz:(w&&w.timezone_abbreviation)||'UTC'};
 if(w&&w.current){var c=w.current,k=WC[c.weather_code]||['🌡️',''];o.wx={i:k[0],t:k[1],temp:c.temperature_2m,wind:c.wind_speed_10m,gust:c.wind_gusts_10m,wd:dir(c.wind_direction_10m),uv:w.daily&&w.daily.uv_index_max&&w.daily.uv_index_max[0],at:c.time}}
 if(m&&m.current&&m.current.wave_height!=null){var mc=m.current;o.wave={h:mc.wave_height,p:mc.wave_period,d:dir(mc.wave_direction),sst:mc.sea_surface_temperature,at:mc.time}}
 o.tide=m?tides(m.hourly,off):null;if(o.tide&&o.tide.range<0.15)o.tide.small=true;
 o.gold=golden(r.la,r.lo);o.risks=risksAt(r.la,r.lo);o.p=r.p;o.alerts=r.a===undefined?undefined:(r.a&&r.a.features?r.a.features.map(function(f){return f.properties}):null);return o}
function chips(o){var c=[];var rc=riskChip(o.risks||[]);if(rc)c.push(rc);
 if(o.wx)c.push('<span>'+o.wx.i+' '+Math.round(o.wx.temp)+'°C</span><span>💨 '+Math.round(o.wx.wind)+' km/h '+o.wx.wd+'</span>');
 if(o.wave)c.push('<span>🌊 '+o.wave.h.toFixed(1)+' m'+(o.wave.p?' · '+Math.round(o.wave.p)+' s':'')+'</span>');
 if(o.wave&&o.wave.sst!=null)c.push('<span>🌡️ Sea '+Math.round(o.wave.sst)+'°C</span>');
 if(o.tide&&o.tide.ev.length&&!o.tide.small){var e=o.tide.ev[0];c.push('<span>'+(e[0]==='High'?'⬆️':'⬇️')+' '+e[0]+' '+hm(e[1],o.off)+'</span>')}
 if(o.gold.length)c.push('<span>🌅 '+hm(o.gold[0][0],o.off)+'</span>');
 if(o.alerts&&o.alerts.length)c.push('<span class="al">⚠️ '+o.alerts.length+' official alert'+(o.alerts.length>1?'s':'')+'</span>');
 return c.join('')}
function detail(o){var h='<h3 style="margin-top:2px">⚠️ Risk timing here</h3>'+riskHTML(o.risks||[]),s='<p class="src">';
 h+='<h3>'+(o.wx?o.wx.i+' Weather':'Weather')+'</h3>'+(o.wx?'<p><b>'+Math.round(o.wx.temp)+'°C, '+E(o.wx.t)+'</b> · wind '+Math.round(o.wx.wind)+' km/h '+o.wx.wd+', gusts '+Math.round(o.wx.gust)+' km/h'+(o.wx.uv!=null?' · UV max '+Math.round(o.wx.uv):'')+'</p>':'<p>Weather data not available right now.</p>');
 h+='<h3>🌊 Sea</h3>'+(o.wave?'<p><b>Waves '+o.wave.h.toFixed(1)+' m</b>'+(o.wave.p?', period '+Math.round(o.wave.p)+' s':'')+(o.wave.d?', from '+o.wave.d:'')+(o.wave.sst!=null?' · sea surface '+Math.round(o.wave.sst)+'°C':'')+'</p><p class="note">Model forecast for open water near this point – not a measurement of the breaking waves on a beach.</p>':'<p>No sea data for this point (inland, lake or outside the marine model).</p>');
 if(o.tide&&o.tide.ev.length){h+='<h3>🌗 Tide (model)</h3>'+(o.tide.small?'<p>Very small tidal range here (under 15 cm in the model).</p>':'<p>'+o.tide.ev.map(function(e){return(e[0]==='High'?'⬆️ ':'⬇️ ')+'<b>'+e[0]+'</b> '+hm(e[1],o.off)+' '+day(e[1],o.off)}).join(' · ')+'</p>')+'<p class="note">Sea level from a global model, local time ('+E(o.tz)+'). Limited accuracy near coasts – not for navigation. High or low water does not mean calm or safe water.</p>'}
 h+='<h3>🌅 Golden light</h3><p>'+(o.gold.length?o.gold.map(function(g){return hm(g[0],o.off)+'–'+hm(g[1],o.off)+' '+day(g[0],o.off)}).join(' · '):'No low-sun window in the next 30 hours')+'</p><p class="note">Sun 0–6° above the horizon, calculated on your device. A light estimate, not a swimming recommendation.</p>';
 h+='<h3>📢 Official alerts and closures</h3>';
 if(o.alerts&&o.alerts.length)h+=o.alerts.slice(0,5).map(function(a){return'<p class="alert"><b>'+E(a.event)+'</b> – '+E(a.headline||'')+'<br><small>'+E(a.areaDesc||'')+(a.expires?' · until '+E(new Date(a.expires).toLocaleString()):'')+'</small></p>'}).join('')+'<p class="note">Official alerts from the US National Weather Service (weather.gov).</p>';
 else if(o.alerts&&!o.alerts.length)h+='<p>No active official NWS weather alerts for this point. This does not cover sharks, jellyfish, water quality or beach closures.</p>';
 var cc=o.p&&o.p.cc,rt=cc&&D.routes[cc];
 h+=(rt?'<p>Official sources to check for this area:</p><ul>'+rt.map(function(r){return'<li><a href="'+E(r[1])+'" target="_blank" rel="noopener">'+E(r[0])+'</a> <small>('+E(r[2])+')</small></li>'}).join('')+'</ul>':'')+'<p class="note">DipMapper has no live shark, jellyfish or closure feed here. No report on this page does not mean there are no hazards – follow beach flags, lifeguards and local notices.</p>';
 if(cc&&D.emg[cc])h+='<h3>🚨 Emergency numbers</h3><p>'+D.emg[cc].map(function(n){return'<a class="call" href="tel:'+E(n[0])+'">📞 '+E(n[0])+' <small>'+E(n[1])+'</small></a>'}).join('')+'</p><p class="note">For '+E(o.p.town[1])+' area ('+E(cc)+'). Check that you are in this country before dialling.</p>';
 else h+='<h3>🚨 Emergency numbers</h3><p class="note">The country for this map position is not resolved, so no number is shown. Use the local emergency number of the country you are in (112 works in the EU and on many mobile networks).</p>';
 h+='<p class="src">Weather and marine data: <a href="https://open-meteo.com/" target="_blank" rel="noopener">Open-Meteo</a> (CC BY 4.0)'+(o.alerts!==undefined?' · Alerts: <a href="https://www.weather.gov/" target="_blank" rel="noopener">NWS</a>':'')+'. Updated '+(o.wx?E(o.wx.at.replace('T',' ')):'–')+' local.</p>';
 return h}
var CSS='.dmCoast{position:absolute;left:8px;right:8px;top:8px;z-index:4;display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;pointer-events:auto}.dmCoast::-webkit-scrollbar{display:none}'
+'.dmCoast button{flex:0 0 auto;display:flex;gap:10px;align-items:center;border:0;border-radius:999px;background:rgba(255,255,255,.95);box-shadow:0 4px 14px rgba(6,52,60,.18);padding:7px 12px;font:700 13px system-ui,-apple-system,sans-serif;color:#06343c;cursor:pointer;white-space:nowrap}'
+'.dmCoast .al{color:#b4231a}.dmCoast .ld{opacity:.6;font-weight:600}.dmCoastD{position:fixed;inset:auto 0 0 0;z-index:200;max-height:82vh;overflow:auto;background:#fff;border-radius:22px 22px 0 0;box-shadow:0 -10px 40px rgba(0,0,0,.25);padding:18px 18px calc(env(safe-area-inset-bottom,0px) + 18px);font:15px/1.5 system-ui,-apple-system,sans-serif;color:#17384a}'
+'@media(min-width:761px){.dmCoastD{left:auto;right:20px;bottom:20px;width:420px;border-radius:22px}}.dmCoastD h2{margin:0 30px 6px 0;font-size:19px}.dmCoastD h3{margin:14px 0 4px;font-size:15px}.dmCoastD p{margin:0 0 4px}.dmCoastD .note{font-size:12.5px;color:#5f7d86}.dmCoastD .src{font-size:12px;color:#6b8790;margin-top:12px}'
+'.dmCoastD .x{position:absolute;right:12px;top:10px;border:0;background:#eef5f4;border-radius:50%;width:34px;height:34px;font-size:18px;cursor:pointer}.dmCoastD a.call{display:inline-block;margin:4px 6px 0 0;padding:8px 12px;border-radius:10px;background:#c63b22;color:#fff;font-weight:800;text-decoration:none}'
+'.dmCoastD .alert{background:#fff2ef;border-left:4px solid #c63b22;padding:6px 10px;border-radius:8px}.dmCoastD ul{margin:4px 0;padding-left:18px}'
+'.dmEx{position:absolute;left:8px;bottom:30px;z-index:4;max-width:min(560px,calc(100% - 16px));background:rgba(6,52,60,.92);color:#fff;border-radius:16px;padding:10px 12px;font:600 13px/1.4 system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.25)}'
+'.dmEx b{display:block;font-size:14px}.dmEx .r{display:flex;gap:6px;overflow-x:auto;margin-top:6px;scrollbar-width:none}.dmEx .r button{flex:0 0 auto;border:0;border-radius:999px;background:#fff;color:#06343c;font:700 12.5px system-ui,sans-serif;padding:6px 10px;cursor:pointer}.dmEx .x{position:absolute;right:6px;top:4px;background:none;border:0;color:#fff;font-size:16px;cursor:pointer}';
var st=document.createElement('style');st.textContent=CSS+RCSS;document.head.appendChild(st);
var cur=null,sheet=null;
function openSheet(o,title){if(sheet)sheet.remove();sheet=document.createElement('div');sheet.className='dmCoastD';sheet.setAttribute('role','dialog');sheet.setAttribute('aria-label','Conditions');
 sheet.innerHTML='<button class="x" type="button" aria-label="Close">×</button><h2>'+E(title)+'</h2>'+detail(o);document.body.appendChild(sheet);sheet.querySelector('.x').onclick=function(){sheet.remove();sheet=null}}
/* public API: render into an element for a fixed point (town pages) */
window.dmCoastBox=function(el,la,lo,title){el.innerHTML='<p class="note">Loading conditions…</p>';load(la,lo).then(function(r){var o=model(r);el.innerHTML='<div class="dmCoast" style="position:static;margin:0 0 8px">'+'<button type="button">'+chips(o)+'</button></div>'+detail(o).replace('<h3>','<h3 style="margin-top:4px">');}).catch(function(){el.innerHTML='<p>Conditions not available right now.</p>'})};
/* main map binding */
function bindMap(){var mp=document.getElementById('map');if(!mp||typeof state==='undefined')return false;
 var bar=document.createElement('div');bar.className='dmCoast';bar.innerHTML='<button type="button" class="ld">🌊 Loading sea and weather…</button>';mp.appendChild(bar);
 var sig='',tmr=0,gen=0,ctl=null,last=null;
 bar.addEventListener('click',function(){if(last)openSheet(last,'Conditions here'+(last.p?' · near '+last.p.town[1]:''))});
 function vis(){var r=mp.getBoundingClientRect();return!document.hidden&&r.bottom>0&&r.top<innerHeight&&r.width>0}
 (function tick(){requestAnimationFrame(tick);var c=state.mapCenter||state.center;if(!c||!vis())return;var z=state.zoom||3;if(z<6){if(sig!=='lowzoom'){sig='lowzoom';bar.innerHTML='<button type="button" class="ld">🔍 Zoom in to see sea, tide and weather</button>';last=null}return}
  var s=c[0].toFixed(2)+','+c[1].toFixed(2);if(s===sig)return;sig=s;clearTimeout(tmr);bar.innerHTML='<button type="button" class="ld">🌊 Updating…</button>';last=null;
  tmr=setTimeout(function(){var g=++gen;if(ctl)try{ctl.abort()}catch(e){}ctl=window.AbortController?new AbortController():null;
   load(c[0],c[1],ctl&&ctl.signal).then(function(r){if(g!==gen)return;last=model(r);bar.innerHTML='<button type="button" aria-label="Show sea, tide, weather and safety details">'+(chips(last)||'Conditions not available')+'<span style="opacity:.6">ⓘ</span></button>'}).catch(function(){if(g===gen)bar.innerHTML='<button type="button" class="ld">Conditions not available right now</button>'})},600)})();
 return true}
/* Palma example start, only when nothing is known about the visitor's location */
function example(){var mp=document.getElementById('map');if(!mp||typeof state==='undefined')return;var known=false;try{known=!!localStorage.getItem('dm_loc')}catch(e){}
 if(known||state.center||location.search||(location.hash&&location.hash.length>1))return;var S=D.start;state.mapCenter=[S.c[0],S.c[1]];state.zoom=S.z;try{drawMap()}catch(e){}
 var ex=document.createElement('div');ex.className='dmEx';ex.innerHTML='<button class="x" type="button" aria-label="Close example">×</button><b>📍 Example: Bay of Palma, Mallorca</b>Not your location – search a place or use “Near me” to see your own area. Six contrasting beaches here:<div class="r">'+S.areas.map(function(a,i){return'<button type="button" data-i="'+i+'" title="'+E(a[3])+'">'+E(a[0])+'</button>'}).join('')+'</div>';
 mp.appendChild(ex);ex.querySelector('.x').onclick=function(){ex.remove()};ex.querySelector('.r').onclick=function(e){var b=e.target.closest('button');if(!b)return;var a=S.areas[+b.dataset.i];state.mapCenter=[a[1],a[2]];state.zoom=14;try{drawMap()}catch(_){}};
 var t0=state.center;(function w(){if(!ex.isConnected)return;if(state.center&&state.center!==t0){ex.remove();return}requestAnimationFrame(w)})()}
function start(){var n=0;(function go(){if(document.getElementById('map')&&typeof state!=='undefined'&&typeof drawMap==='function'){example();bindMap()}else if(++n<60)setTimeout(go,150)})()}
function badges(root){(root||document).querySelectorAll('figure[data-la]:not([data-rk])').forEach(function(f){f.setAttribute('data-rk',1);var la=+f.getAttribute('data-la'),lo=+f.getAttribute('data-lo');if(!la&&!lo)return;var a=risksAt(la,lo).filter(function(o){return o.now||o.soon})[0];if(!a)return;var b=document.createElement('span');b.className='rkb'+(a.now?'':' soon');b.title=a.r.name;b.textContent=a.r.icon+' '+a.r.name.split(' (')[0]+(a.now?' – now':' – '+a.label);if(getComputedStyle(f).position==='static')f.style.position='relative';f.appendChild(b)})}
window.dmRiskBadges=badges;if(!document.getElementById('map')){var nb=0;(function bg(){badges();if(++nb<20)setTimeout(bg,1500)})()}
if(document.getElementById('map')){if(document.readyState==='complete')start();else addEventListener('load',start,{once:true})}
})();
