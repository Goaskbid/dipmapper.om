import asyncio,sys,json
from playwright.async_api import async_playwright
BASE=sys.argv[1]
async def run(p,w,h,tag):
  b=await p.chromium.launch();pg=await b.new_page(viewport={'width':w,'height':h})
  errs=[];pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
  await pg.route('**/*',lambda r:r.continue_() if r.request.url.startswith(BASE) else r.abort())
  await pg.goto(BASE+'/index.html');await pg.wait_for_timeout(700)
  boot=await pg.evaluate("!!document.getElementById('dmBoot')")
  await pg.wait_for_timeout(6500)
  r=await pg.evaluate("""()=>{const g=document.getElementById('dmGateActs');const e=g&&g.querySelector('.dmGateExplore');
   const nav=document.querySelector('.nav a.dmNavExplore');const pr=document.querySelectorAll('.dmAbProjects li a');
   return {gateRadios:g?g.querySelectorAll('button[data-a]').length:0,gateExplore:e?e.getAttribute('href'):null,
   gateExploreVisible:e?e.getBoundingClientRect().width>0:false,navExplore:nav?nav.getAttribute('href'):null,
   projects:pr.length,mnemika:/mnemika/i.test(document.documentElement.innerHTML),
   stoff:document.body.innerText.includes('Stoffknacker'),hscroll:document.documentElement.scrollWidth>innerWidth,
   ver:document.body.dataset.version,bootGone:!document.getElementById('dmBoot')||getComputedStyle(document.getElementById('dmBoot')).display==='none'||document.getElementById('dmBoot').getBoundingClientRect().height===0}}""")
  r['bootSeen']=boot;r['errors']=errs
  await pg.screenshot(path=f'/tmp/w/s/{tag}_gate.png')
  await pg.evaluate("document.querySelector('.dmAbProjects')&&document.querySelector('.dmAbProjects').scrollIntoView()")
  await pg.wait_for_timeout(400);await pg.screenshot(path=f'/tmp/w/s/{tag}_about.png')
  if r['gateExplore']:
    await pg.goto(BASE+'/explore.html');await pg.wait_for_timeout(1500)
    r['exploreTitle']=await pg.title()
    await pg.get_by_role('button',name='Back to the map').first.click();await pg.wait_for_timeout(800)
    r['backTo']=pg.url
  print(tag,json.dumps(r));await b.close()
async def main():
  async with async_playwright() as p:
    for w,h,t in [(390,844,sys.argv[2]+'_ph'),(1440,900,sys.argv[2]+'_pc')]: await run(p,w,h,t)
asyncio.run(main())
