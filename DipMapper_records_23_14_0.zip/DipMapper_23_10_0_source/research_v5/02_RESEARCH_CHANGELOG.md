# V5 research and implementation change report

Research edition: 13 November 2026. **605 actual experiences; 4,580 requested; 3,975 outstanding.** This is a partial curated expansion, not completion of the requested scale.

## New research totals

147 distinct additions across 21 already-covered countries/territories. The full catalogue remains at 87 countries/territories. A second Niihama row was merged into its existing identity, not counted as an addition. The 152 new evidence records reference 151 distinct URLs. There are 22 new numeric price references with identified currencies, 16 public telephone references and one email reference. Phones were not called and email delivery was not tested.

| Activity | Unique additions |
| --- | ---: |
| Public aquariums | 41 |
| Thermal baths | 35 |
| Sauna and swimming | 18 |
| Marine wildlife | 1 |
| Water parks | 34 |
| Beaches | 3 |
| Kayaking | 10 |
| Scenic cruises | 3 |
| Boat trips | 2 |

## Page | old behaviour | new behaviour | reason

| Page or module | Old paragraph or behaviour | New paragraph or behaviour | Reason |
| --- | --- | --- | --- |
| Research catalogue | 458 distinct records | 605, with 147 exact new IDs and one in-place update | Count actual entities, not repeated list appearances or rides within a venue |
| Explore | Only retained ranking shortcuts | New research shortcut shows all 147 additions, including explicit holds and unresolved seasons | Make new content easy to inspect without promoting it all to a global Top list |
| Aquarium directory | 120 records, 25 inside malls | 161 records, 28 inside malls; retained Top 100 unchanged | Distinguish new discoveries from fabricated world positions |
| Dates and restrictions | Generic facility labels alone could mislead | Volcano Bay stays held until reviewed; Ramayana Wednesdays are excluded | Planned dates and seasonal format do not establish current availability |
| Family/access filters | Added venue facts were not connected | Linsberg minimum 16; Opuke family product and accessible toilet are separately scoped | Avoid treating every thermal venue or every accessibility feature as interchangeable |
| Personal checklist | 100 KB import ceiling | 1 MB bounded import ceiling with 4,580 long-ID round-trip fixture | A legitimate scale export must be able to import again |
| Map | Existing neutral search | All normal results and order preserved; new stars require identity review | Editorial discovery must not bias or remove ordinary map results |
| Publication | Prior draft pages | One additional 147-card research page; no combinatorial filter-page generation | Useful, readable content without pretending unknowns are verified |
| Existing sources | Old research potentially mistaken for new | Prior dates retained and inherited-not-rechecked flags visible | Do not manufacture freshness |

## Evidence decisions

Universal's maintenance notice is held without an automatic reopening. An old headline park-hours value does not override the dated notice. Ramayana's ordinary Wednesday rule does not imply every public-holiday exception has been researched. Opuke's toilet evidence does not become a step-free or pool-hoist claim. An ambiguous dollar price remains held rather than guessing currency. Source water at 47 degrees is not a pool-temperature instruction. Individual Great Wolf locations remain separate physical venues, but their slides and package variants do not become additional places. Aquarium combinations with spas or neighbouring attractions are not automatically mall aquariums.

Every source can be cached. Newly reviewed is not live-tested. A source's name, URL and evidence method are attached in 04_evidence_and_rules.json. New factual copy is original summary; publisher photographs and long source descriptions are not licensed by these links.

## Exact additions

Each row links to the official publisher used for that record. Full attractions, reasons, seasons, ticket/contact routes and limitations are in the guide and catalogue.

| ID | Name | Activity | Country | Area | Publisher |
| --- | --- | --- | --- | --- | --- |
| `v5-mystic` | Mystic Aquarium | Public aquariums | US | Mystic, Connecticut | [Official reference](https://www.mysticaquarium.org/) |
| `v5-maritime-norwalk` | The Maritime Aquarium at Norwalk | Public aquariums | US | Norwalk, Connecticut | [Official reference](https://www.maritimeaquarium.org/) |
| `v5-adventure-camden` | Adventure Aquarium | Public aquariums | US | Camden waterfront, New Jersey | [Official reference](https://www.adventureaquarium.com/explore/attractions/) |
| `v5-newport` | Newport Aquarium | Public aquariums | US | Newport, Kentucky | [Official reference](https://www.newportaquarium.com/things-to-do/exhibits/) |
| `v5-loveland` | Loveland Living Planet Aquarium | Public aquariums | US | Draper, Utah | [Official reference](https://livingplanetaquarium.org/) |
| `v5-odysea` | OdySea Aquarium | Public aquariums | US | Scottsdale, Arizona | [Official reference](https://www.odyseaaquarium.com/experiences/featured-animals-and-exhibits/) |
| `v5-wonders-wildlife` | Wonders of Wildlife Aquarium Adventure | Public aquariums | US | Springfield, Missouri | [Official reference](https://wondersofwildlife.org/) |
| `v5-ripley-smokies` | Ripley's Aquarium of the Smokies | Public aquariums | US | Gatlinburg, Tennessee | [Official reference](https://www.ripleys.com/attractions/ripleys-aquarium-of-the-smokies) |
| `v5-ripley-myrtle` | Ripley's Aquarium of Myrtle Beach | Public aquariums | US | Broadway at the Beach, Myrtle Beach, South Carolina | [Official reference](https://www.ripleys.com/attractions/ripleys-aquarium-of-myrtle-beach/exhibits/dangerous-reef) |
| `v5-new-york` | New York Aquarium | Public aquariums | US | Coney Island, Brooklyn, New York | [Official reference](https://nyaquarium.com/) |
| `v5-7132-vals` | 7132 Thermal Baths Vals | Thermal baths | CH | Vals, Graubunden | [Official reference](https://www.myswitzerland.com/en-us/experiences/7132-therme/) |
| `v5-saillon` | Les Bains de Saillon | Thermal baths | CH | Saillon, Valais | [Official reference](https://www.myswitzerland.com/en-us/experiences/saillon-thermal-baths/) |
| `v5-sole-uno` | Sole uno wellness world | Thermal baths | CH | Rheinfelden | [Official reference](https://www.myswitzerland.com/en-us/experiences/sole-uno-wellness-world/) |
| `v5-fortyseven` | FORTYSEVEN thermal spa | Thermal baths | CH | Baden, Aargau | [Official reference](https://www.myswitzerland.com/en-us/experiences/fortyseven-thermal-wellness-spa/) |
| `v5-leukerbad-therme` | Leukerbad Therme | Thermal baths | CH | Leukerbad, Valais | [Official reference](https://www.myswitzerland.com/en-us/experiences/leukerbad-thermal-spa/) |
| `v5-huerlimannbad` | Huerlimannbad and Spa Zurich | Thermal baths | CH | Enge, Zurich | [Official reference](https://www.myswitzerland.com/en-us/experiences/thermal-baths-spa-zurich/) |
| `v5-tamina` | Tamina Therme | Thermal baths | CH | Bad Ragaz | [Official reference](https://www.myswitzerland.com/en-us/experiences/tamina-therme-bad-ragaz-thermal-baths/) |
| `v5-brigerbad` | Thermalbad Brigerbad | Thermal baths | CH | Brigerbad, Valais | [Official reference](https://www.myswitzerland.com/en-us/experiences/thermal-spa-brigerbad/) |
| `v5-aquandeer` | Aquandeer mineral spa | Thermal baths | CH | Andeer, Graubunden | [Official reference](https://www.myswitzerland.com/en-us/experiences/aquandeer-mineral-spa-andeer/) |
| `v5-zurzach` | Therme Zurzach | Thermal baths | CH | Bad Zurzach, Aargau | [Official reference](https://www.myswitzerland.com/en-us/experiences/therme-zurzach/) |
| `v5-ovronnaz` | Les Bains d'Ovronnaz | Thermal baths | CH | Ovronnaz, Valais | [Official reference](https://www.myswitzerland.com/en-us/experiences/thermal-baths-in-ovronnaz/) |
| `v5-lavey` | Les Bains de Lavey | Thermal baths | CH | Lavey-les-Bains, Vaud | [Official reference](https://www.myswitzerland.com/en-us/experiences/bains-de-lavey-thermal-spa/) |
| `v5-samedan` | Mineralbad and Spa Samedan | Thermal baths | CH | Samedan, Graubunden | [Official reference](https://www.myswitzerland.com/en-us/experiences/samedan-mineral-baths-amp-spa/) |
| `v5-rigi-kaltbad` | Mineralbad and Spa Rigi Kaltbad | Thermal baths | CH | Rigi Kaltbad, Lucerne | [Official reference](https://www.myswitzerland.com/en-us/experiences/mineral-baths-spa-rigikaltbad/) |
| `v5-therme-laa` | Therme Laa | Thermal baths | AT | Laa an der Thaya | [Official reference](https://www.therme-laa.at/en/) |
| `v5-h2o-waltersdorf` | H2O Hotel-Therme-Resort | Thermal baths | AT | Bad Waltersdorf, Styria | [Official reference](https://www.hoteltherme.at/en/index.html) |
| `v5-sonnentherme` | Sonnentherme Lutzmannsburg | Thermal baths | AT | Lutzmannsburg, Burgenland | [Official reference](https://www.sonnentherme.at/en/) |
| `v5-aquapulco` | Aquapulco and Eurothermen Bad Schallerbach | Thermal baths | AT | Bad Schallerbach, Upper Austria | [Official reference](https://www.eurothermen.at/en/bad-schallerbach/) |
| `v5-parktherme` | Parktherme Bad Radkersburg | Thermal baths | AT | Bad Radkersburg, Styria | [Official reference](https://www.parktherme.at/en/) |
| `v5-kaerntentherme` | KaerntenTherme | Thermal baths | AT | Warmbad-Villach, Carinthia | [Official reference](https://www.kaerntentherme.com/en/) |
| `v5-bad-ischl` | Salzkammergut-Therme Bad Ischl | Thermal baths | AT | Bad Ischl, Upper Austria | [Official reference](https://www.eurothermen.at/en/bad-ischl/) |
| `v5-therme-wien` | Therme Wien | Thermal baths | AT | Oberlaa, Vienna | [Official reference](https://www.thermewien.at/en/all-areas/) |
| `v5-loipersdorf` | Thermal Resort Loipersdorf | Thermal baths | AT | Loipersdorf, Styria | [Official reference](https://www.therme.at/en/) |
| `v5-bad-blumau` | Rogner Bad Blumau | Thermal baths | AT | Bad Blumau, Styria | [Official reference](https://www.blumau.com/en/no_cache.html) |
| `v5-st-martins` | St. Martins Therme | Thermal baths | AT | Frauenkirchen, Burgenland | [Official reference](https://www.stmartins.at/en) |
| `v5-linsberg` | Linsberg Asia | Thermal baths | AT | Bad Erlach, Lower Austria | [Official reference](https://www.linsbergasia.at/en/) |
| `v5-allas` | Allas Pool | Sauna and swimming | FI | Market Square, Helsinki | [Official reference](https://www.allaspool.fi/en/) |
| `v5-lonna` | Lonna island sauna | Sauna and swimming | FI | Lonna island, Helsinki | [Official reference](https://www.lonna.fi/en/services/sauna/) |
| `v5-loyly` | Loyly Helsinki | Sauna and swimming | FI | Hernesaari, Helsinki | [Official reference](https://www.loylyhelsinki.fi/) |
| `v5-flou` | FLOU sauna restaurant | Sauna and swimming | FI | Tammerkoski, Tampere | [Official reference](https://www.flousauna.fi/) |
| `v5-kuuma` | Saunaravintola Kuuma | Sauna and swimming | FI | Tampere | [Official reference](https://www.saunaravintolakuuma.fi/en/home/) |
| `v5-sataman-viilu` | Sataman Viilu | Sauna and swimming | FI | Jyvaskyla harbour | [Official reference](https://satamanviilu.fi/in-english/) |
| `v5-saana-kuopio` | Kuopion Saana | Sauna and swimming | FI | Kuopio, Lake Kallavesi | [Official reference](https://www.kuopionsaana.fi/en/frontpage/) |
| `v5-luoto-kuopio` | Luoto Kuopio | Sauna and swimming | FI | Lake Kallavesi, Kuopio | [Official reference](https://www.luotokuopio.fi/) |
| `v5-kesarafla` | Kesarafla Sauna and WNTR Sauna | Sauna and swimming | FI | Kemijoki, Rovaniemi | [Official reference](https://www.laplandhotels.com/en/hotels-and-destinations/rovaniemi/lapland-hotels-ounasvaara-chalets/kesarafla-sauna) |
| `v5-isokenkaisten` | Isokenkaisten Klubi smoke sauna | Sauna and swimming | FI | Kuusamo | [Official reference](https://www.ikk.fi/) |
| `v5-kaarna` | Saunaravintola Kaarna | Sauna and swimming | FI | Kaarina, near Turku | [Official reference](https://saunaravintolakaarna.fi/) |
| `v5-sea-life-birmingham` | National SEA LIFE Centre Birmingham | Public aquariums | GB | Birmingham | [Official reference](https://www.visitsealife.com/birmingham/) |
| `v5-sea-life-blackpool` | SEA LIFE Blackpool | Public aquariums | GB | Blackpool promenade | [Official reference](https://www.visitsealife.com/blackpool/) |
| `v5-sea-life-great-yarmouth` | SEA LIFE Great Yarmouth | Public aquariums | GB | Great Yarmouth | [Official reference](https://www.visitsealife.com/great-yarmouth/) |
| `v5-cornish-seal-sanctuary` | Cornish Seal Sanctuary | Marine wildlife | GB | Gweek, Cornwall | [Official reference](https://sealsanctuary.sealifetrust.org/en/) |
| `v5-sea-life-hunstanton` | SEA LIFE Hunstanton | Public aquariums | GB | Hunstanton, Norfolk | [Official reference](https://www.visitsealife.com/hunstanton/) |
| `v5-sea-life-loch-lomond` | SEA LIFE Loch Lomond | Public aquariums | GB | Loch Lomond Shores, Balloch | [Official reference](https://www.visitsealife.com/loch-lomond/) |
| `v5-sea-life-scarborough` | SEA LIFE Scarborough | Public aquariums | GB | Scarborough, North Yorkshire | [Official reference](https://www.visitsealife.com/scarborough/) |
| `v5-sea-life-weymouth` | SEA LIFE Weymouth Adventure Park | Public aquariums | GB | Weymouth, Dorset | [Official reference](https://www.visitsealife.com/weymouth/) |
| `v5-sea-life-hannover` | SEA LIFE Hannover | Public aquariums | DE | Hannover | [Official reference](https://www.visitsealife.com/hannover/en/) |
| `v5-sea-life-konstanz` | SEA LIFE Konstanz | Public aquariums | DE | Konstanz, Lake Constance | [Official reference](https://www.visitsealife.com/konstanz/en/) |
| `v5-sea-life-munich` | SEA LIFE Munich | Public aquariums | DE | Olympiapark, Munich | [Official reference](https://www.visitsealife.com/muenchen/en/) |
| `v5-sea-life-oberhausen` | SEA LIFE Oberhausen | Public aquariums | DE | Oberhausen | [Official reference](https://www.visitsealife.com/oberhausen/en/) |
| `v5-sea-life-timmendorfer` | SEA LIFE Timmendorfer Strand | Public aquariums | DE | Timmendorfer Strand, Baltic coast | [Official reference](https://www.visitsealife.com/timmendorfer-strand/en/) |
| `v5-sea-life-benalmadena` | SEA LIFE Benalmadena | Public aquariums | ES | Benalmadena | [Official reference](https://www.visitsealife.com/benalmadena/) |
| `v5-sea-life-blankenberge` | SEA LIFE Blankenberge | Public aquariums | BE | Blankenberge | [Official reference](https://www.visitsealife.com/blankenberge/) |
| `v5-sea-life-helsinki` | SEA LIFE Helsinki | Public aquariums | FI | Helsinki | [Official reference](https://www.visitsealife.com/helsinki/) |
| `v5-sea-life-carlsbad` | SEA LIFE Aquarium Carlsbad | Public aquariums | US | Carlsbad, California | [Official reference](https://www.legoland.com/california/things-to-do/sea-life-aquarium/) |
| `v5-sea-life-florida` | SEA LIFE Florida | Public aquariums | US | Winter Haven, Florida | [Official reference](https://www.legoland.com/florida/things-to-do/sea-life-florida/) |
| `v5-sea-life-orlando` | SEA LIFE Orlando | Public aquariums | US | ICON Park, Orlando, Florida | [Official reference](https://www.visitsealife.com/orlando/) |
| `v5-sea-life-sunshine-coast` | SEA LIFE Sunshine Coast | Public aquariums | AU | Mooloolaba, Queensland | [Official reference](https://www.visitsealife.com/sunshine-coast/) |
| `v5-lost-spring` | The Lost Spring | Thermal baths | NZ | Whitianga, Coromandel | [Official reference](https://www.thelostspring.co.nz/) |
| `v5-onsen-queenstown` | Onsen Hot Pools | Thermal baths | NZ | Arthurs Point, Queenstown | [Official reference](https://www.onsen.co.nz/) |
| `v5-wai-ariki` | Wai Ariki Hot Springs and Spa | Thermal baths | NZ | Rotorua lakefront | [Official reference](https://www.wai-ariki.co.nz/) |
| `v5-ngawha-springs` | Ngawha Springs | Thermal baths | NZ | Ngawha, near Kaikohe, Northland | [Official reference](https://www.ngawha.nz/) |
| `v5-tekapo-springs` | Tekapo Springs | Thermal baths | NZ | Lake Tekapo, Canterbury | [Official reference](https://tekaposprings.co.nz/) |
| `v5-omarama-hot-tubs` | Hot Tubs Omarama | Thermal baths | NZ | Omarama, Waitaki | [Official reference](https://www.hottubsomarama.co.nz/) |
| `v5-waikite-valley` | Waikite Valley Thermal Pools | Thermal baths | NZ | Waikite Valley, Rotorua region | [Official reference](https://www.hotpools.co.nz/) |
| `v5-opuke-pools` | Opuke Thermal Pools and Spa | Thermal baths | NZ | Methven, Canterbury | [Official reference](https://opuke.nz/soak/discovery/) |
| `v5-hanmer-springs` | Hanmer Springs Thermal Pools and Spa | Thermal baths | NZ | Hanmer Springs, Canterbury | [Official reference](https://hanmersprings.co.nz/) |
| `v5-great-wolf-southern-california` | Great Wolf Lodge water park: Garden Grove, California | Water parks | US | Garden Grove, California | [Official reference](https://www.greatwolf.com/southern-california) |
| `v5-great-wolf-georgia` | Great Wolf Lodge water park: LaGrange, Georgia | Water parks | US | LaGrange, Georgia | [Official reference](https://www.greatwolf.com/georgia) |
| `v5-great-wolf-maryland` | Great Wolf Lodge water park: Perryville, Maryland | Water parks | US | Perryville, Maryland | [Official reference](https://www.greatwolf.com/maryland) |
| `v5-great-wolf-concord` | Great Wolf Lodge water park: Concord, North Carolina | Water parks | US | Concord, North Carolina | [Official reference](https://www.greatwolf.com/concord) |
| `v5-great-wolf-illinois` | Great Wolf Lodge water park: Gurnee, Illinois | Water parks | US | Gurnee, Illinois | [Official reference](https://www.greatwolf.com/illinois) |
| `v5-great-wolf-mason` | Great Wolf Lodge water park: Mason, Ohio | Water parks | US | Mason, Ohio | [Official reference](https://www.greatwolf.com/mason) |
| `v5-great-wolf-colorado-springs` | Great Wolf Lodge water park: Colorado Springs, Colorado | Water parks | US | Colorado Springs, Colorado | [Official reference](https://www.greatwolf.com/colorado-springs) |
| `v5-great-wolf-grapevine` | Great Wolf Lodge water park: Grapevine, Texas | Water parks | US | Grapevine, Texas | [Official reference](https://www.greatwolf.com/grapevine) |
| `v5-great-wolf-grand-mound` | Great Wolf Lodge water park: Grand Mound, Washington | Water parks | US | Grand Mound, Washington | [Official reference](https://www.greatwolf.com/grand-mound) |
| `v5-great-wolf-webster` | Great Wolf Lodge water park: Webster, Texas | Water parks | US | Webster, Texas | [Official reference](https://www.greatwolf.com/webster) |
| `v5-great-wolf-kansas-city` | Great Wolf Lodge water park: Kansas City, Kansas | Water parks | US | Kansas City, Kansas | [Official reference](https://www.greatwolf.com/kansas-city) |
| `v5-great-wolf-connecticut` | Great Wolf Lodge water park: Mashantucket, Connecticut | Water parks | US | Mashantucket, Connecticut | [Official reference](https://www.greatwolf.com/connecticut) |
| `v5-great-wolf-minnesota` | Great Wolf Lodge water park: Bloomington, Minnesota | Water parks | US | Bloomington, Minnesota | [Official reference](https://www.greatwolf.com/minnesota) |
| `v5-great-wolf-naples` | Great Wolf Lodge water park: Naples, Florida | Water parks | US | Naples, Florida | [Official reference](https://www.greatwolf.com/naples) |
| `v5-great-wolf-new-england` | Great Wolf Lodge water park: Fitchburg, Massachusetts | Water parks | US | Fitchburg, Massachusetts | [Official reference](https://www.greatwolf.com/new-england) |
| `v5-great-wolf-niagara` | Great Wolf Lodge water park: Niagara Falls, Ontario | Water parks | CA | Niagara Falls, Ontario | [Official reference](https://www.greatwolf.com/niagara) |
| `v5-great-wolf-poconos` | Great Wolf Lodge water park: Scotrun, Pennsylvania | Water parks | US | Scotrun, Pennsylvania | [Official reference](https://www.greatwolf.com/poconos) |
| `v5-great-wolf-northern-california` | Great Wolf Lodge water park: Manteca, California | Water parks | US | Manteca, California | [Official reference](https://www.greatwolf.com/northern-california) |
| `v5-great-wolf-sandusky` | Great Wolf Lodge water park: Sandusky, Ohio | Water parks | US | Sandusky, Ohio | [Official reference](https://www.greatwolf.com/sandusky) |
| `v5-great-wolf-arizona` | Great Wolf Lodge water park: Scottsdale / Salt River, Arizona | Water parks | US | Scottsdale / Salt River, Arizona | [Official reference](https://www.greatwolf.com/arizona) |
| `v5-great-wolf-traverse-city` | Great Wolf Lodge water park: Traverse City, Michigan | Water parks | US | Traverse City, Michigan | [Official reference](https://www.greatwolf.com/traverse-city) |
| `v5-great-wolf-williamsburg` | Great Wolf Lodge water park: Williamsburg, Virginia | Water parks | US | Williamsburg, Virginia | [Official reference](https://www.greatwolf.com/williamsburg) |
| `v5-great-wolf-wisconsin-dells` | Great Wolf Lodge water park: Wisconsin Dells, Wisconsin | Water parks | US | Wisconsin Dells, Wisconsin | [Official reference](https://www.greatwolf.com/wisconsin-dells) |
| `v5-lainesauna` | Lainesauna public sauna raft | Sauna and swimming | FI | Oulu River, Oulu | [Official reference](https://www.visitfinland.com/en/product/7bdb051f-646b-4c88-93e7-9edbe3390209/sauna-ticket-for-public-sauna/) |
| `v5-lauteet` | Avantosauna Lauteet | Sauna and swimming | FI | Siilinlahti, Siilinjarvi | [Official reference](https://www.visitfinland.com/en/product/f159762f-3ea9-419a-ac8a-ae774a672c95/sauna-and-ice-swimming-experience/) |
| `v5-olosauna` | Olosauna shared sauna | Sauna and swimming | FI | Oulu River delta, Oulu | [Official reference](https://www.visitfinland.com/en/product/3751499a-91b6-4c92-ae3a-e0b679ed3209/public-sauna-experience/) |
| `v5-niemi-kapee` | Niemi-Kapee public smoke sauna | Sauna and swimming | FI | Lake Nasijarvi, Tampere region | [Official reference](https://www.visitfinland.com/en/product/04824583-b578-4e5b-afd5-3f8630d634ca/relaxing-public-smoke-sauna/) |
| `v5-kairosmaja` | Kairosmaja winter sauna | Sauna and swimming | FI | Lake Pyhajarvi, Pelkosenniemi | [Official reference](https://www.visitfinland.com/en/product/57ad68ba-fba9-4e92-9354-5d2b010afc0c/sauna-and-ice-swimming/) |
| `v5-viikinsaari` | Viikinsaari island public sauna | Sauna and swimming | FI | Viikinsaari, Lake Pyhajarvi, Tampere | [Official reference](https://www.visitfinland.com/en/product/b0ee3b3b-b90b-43a4-9686-2e3c48387970/viikinsaari-islands-public-sauna/) |
| `v5-vihkosaari` | Vihkosaari beach and recreation area | Beaches | FI | Illinsaari, Ii | [Official reference](https://www.visitfinland.com/en/product/14236ce2-8f58-4573-83e9-0ea2ae4ef189/vihkosaari-beach-and-recreation-area/) |
| `v5-konnevesi-tres-hombres` | Etela-Konnevesi three-day kayak journey | Kayaking | FI | Southern Konnevesi; transfer from Tampere | [Official reference](https://www.visitfinland.com/en/product/14392eb4-3021-4123-9e5f-19fe8f421cdd/kayaking-tour-from-tampere-to-etela-konnevesi-national-park/) |
| `v5-yyteri` | Yyteri beach and dunes | Beaches | FI | Pori | [Official reference](https://www.visitfinland.com/en/product/a6e0f40d-5989-42da-9dd7-296b07ae2973/pori-yyteri-beach-soft-sand-and-the-warmth-of-the-sun/) |
| `v5-pielisjoki-jarven-taiga` | Jarven Taiga Pielisjoki kayaking | Kayaking | FI | Pielisjoki River, Joensuu | [Official reference](https://www.visitfinland.com/en/product/cdbe6b14-d4c8-4c6b-86c8-aed35542b59f/pielisjoki-kayaking/) |
| `v5-helsinki-canal-stromma` | Stromma Beautiful Canal Cruise | Scenic cruises | FI | Market Square, Helsinki | [Official reference](https://www.visitfinland.com/en/product/04c866b7-f882-4049-adad-696652401883/beautiful-canal-cruise/) |
| `v5-helsinki-city-kayak` | Natura Viva Helsinki City Kayak | Kayaking | FI | Kaisaniemenranta, Helsinki | [Official reference](https://www.visitfinland.com/en/product/58540267-5d03-48eb-a1b6-952d724c1ac3/helsinki-city-kayak/) |
| `v5-nagu-seakayak` | Nagu Seakayak guided archipelago trips | Kayaking | FI | Nagu, Archipelago Sea | [Official reference](https://www.visitfinland.com/en/product/8975ceb1-06b8-4ffd-a0e1-dc1b7a36aafd/guided-kayaking-tours/) |
| `v5-oulu-delta-safari` | Nallikari Oulu Delta kayaking safari | Kayaking | FI | Nallikari and Oulu River delta | [Official reference](https://www.visitfinland.com/en/product/c375399e-06b0-486d-a349-72d6c1864a75/kayaking-safari-nallikari-oulu/) |
| `v5-archipelago-tres-hombres` | Tres Hombres Archipelago National Park expedition | Kayaking | FI | Archipelago Sea; transfer from Tampere | [Official reference](https://www.visitfinland.com/en/product/f852432b-af2d-4792-9143-f6ee6d9cd298/kayaking-tour-from-tampere-to-archipelago-national-park/) |
| `v5-olo-saimaa-paddle` | Olo Center Saimaa guided paddling | Kayaking | FI | Matkolahti, Lake Saimaa, Enonkoski | [Official reference](https://www.visitfinland.com/en/product/116afc2e-0031-4079-b01d-31c46936fab3/guided-paddling-tour-in-saimaa-kayak-canoe-sup/) |
| `v5-levi-lake-ferry` | Levi lake ferry and sauna outing | Boat trips | FI | Lakes Sirkkajarvi and Levijarvi, Levi | [Official reference](https://www.visitfinland.com/en/product/cfbfd816-28cd-4f8f-a4f7-32b3a293c223/ferry-cruise/) |
| `v5-repovesi-saimaan-palju` | Saimaan Palju Repovesi kayak outing | Kayaking | FI | Lapinsalmi, Repovesi National Park | [Official reference](https://www.visitfinland.com/en/product/96b525f7-da78-4d36-9732-636f0b965d1f/kayaking-trip-in-repovesi-national-park/) |
| `v5-kolovesi-jarven-taiga` | Jarven Taiga Kolovesi kayak day | Kayaking | FI | Kolovesi National Park; transfer from Joensuu | [Official reference](https://www.visitfinland.com/en/product/7a44e820-4712-4b32-afd1-7b07ca728ae2/kayaking-trip-to-kolovesi-national-park-from-joensuu/) |
| `v5-korpo-naawa` | Naawa Korpo introductory kayaking | Kayaking | FI | Korpo archipelago | [Official reference](https://www.visitfinland.com/en/product/c30c1b42-1416-437d-8162-f21d6785c9fa/beginners-kayaking-tour/) |
| `v5-hiukka` | Hiukka beach and sand ridges | Beaches | FI | Lake Sapsojarvi, Sotkamo | [Official reference](https://www.visitfinland.com/en/product/5ffa065f-e7ba-4e83-8d38-b62e28a8edf1/hiukka-beach-in-sotkamo/) |
| `v5-savonlinna-elviira` | MS Elviira Savonlinna archipelago cruise | Scenic cruises | FI | Savonlinna, Lake Saimaa | [Official reference](https://www.visitfinland.com/en/product/e6d65d64-5042-4cf0-bca6-5630d210c919/cruise-to-the-savonlinna-archipelago-on-ms-elviira-lake-saimaa-region/) |
| `v5-runeberg-porvoo` | MS J.L. Runeberg Helsinki-Porvoo cruise | Scenic cruises | FI | Linnanlaituri, Helsinki to Porvoo | [Official reference](https://www.visitfinland.com/en/product/ef972851-e246-431c-991e-1ab79550b4b4/cruise-from-helsinki-to-porvoo-on-historical-ms-j-l-runeberg/) |
| `v5-punkaharju-cycle-cruise` | Harjun Portti cycling and Polaris 1 cruise | Boat trips | FI | Punkaharju, Lake Saimaa | [Official reference](https://www.visitfinland.com/en/product/02046198-5f19-49bc-ac79-06da7d12c6ca/cycling-adventure-cruise-in-punkaharju-lake-saimaa-region/) |
| `v5-vesaniemi` | Vesaniemi sauna and beach | Sauna and swimming | FI | Lake Vesijarvi, Kangasala | [Official reference](https://www.visitfinland.com/en/product/4fa97c9e-998f-4c37-986f-197dbd16dde4/vesaniemen-uimaranta-ja-sauna/) |
| `v5-sealife-kansas-city` | SEA LIFE Kansas City | Public aquariums | US | Crown Center, Kansas City, Missouri | [Official reference](https://www.visitsealife.com/kansas-city/) |
| `v5-sealife-san-antonio` | SEA LIFE San Antonio | Public aquariums | US | Shops at Rivercenter, San Antonio, Texas | [Official reference](https://www.visitsealife.com/san-antonio/) |
| `v5-sealife-changfeng` | Shanghai Changfeng Ocean World | Public aquariums | CN | Changfeng, Shanghai | [Official reference](https://www.visitsealife.com/shanghai-changfeng-ocean-world/) |
| `v5-sealife-shenyang` | SEA LIFE Shenyang | Public aquariums | CN | Third floor, Shenyang K11 Shopping Art Center | [Official reference](https://www.visitsealife.com/sea-life-shenyang/) |
| `v5-sealife-malaysia` | SEA LIFE Malaysia | Public aquariums | MY | LEGOLAND Malaysia Resort, Iskandar Puteri | [Official reference](https://www.legoland.com.my/explore/sea-life-aquarium/) |
| `v5-sealife-nagoya` | SEA LIFE Nagoya | Public aquariums | JP | LEGOLAND Japan Resort, Nagoya | [Official reference](https://www.legoland.jp/resort-guide/sealife-nagoya/) |
| `v5-sealife-scheveningen` | SEA LIFE Scheveningen | Public aquariums | NL | Scheveningen, The Hague | [Official reference](https://www.visitsealife.com/scheveningen/) |
| `v5-atlantis-billund` | Atlantis by SEA LIFE at LEGOLAND Billund | Public aquariums | DK | Imagination Zone, LEGOLAND Billund | [Official reference](https://www.legoland.dk/udforsk/parken/forlystelser/atlantis-by-sea-life/) |
| `v5-world-waterpark-edmonton` | World Waterpark at West Edmonton Mall | Water parks | CA | West Edmonton Mall, Edmonton, Alberta | [Official reference](https://www.wem.ca/play/attractions/world-waterpark) |
| `v5-valley-waves` | Valley of Waves | Water parks | ZA | Sun City, North West | [Official reference](https://www.suninternational.com/sun-city/activities/valley-of-waves) |
| `v5-oasiria` | Oasiria Marrakech | Water parks | MA | Marrakech | [Official reference](https://oasiria.com/en/) |
| `v5-ramayana` | Ramayana Water Park | Water parks | TH | Pattaya area | [Official reference](https://www.ramayanawaterpark.com/) |
| `v5-vana-nava` | Vana Nava Water Jungle | Water parks | TH | Hua Hin | [Official reference](https://www.vananavahuahin.com/) |
| `v5-aquaventure-dubai` | Aquaventure Waterpark Dubai | Water parks | AE | Atlantis The Palm, Palm Jumeirah, Dubai | [Official reference](https://www.aquaventureworld.com/aquaventure-waterpark/discover-attractions) |
| `v5-yas-waterworld` | Yas Waterworld Abu Dhabi | Water parks | AE | Yas Island, Abu Dhabi | [Official reference](https://www.yaswaterworld.com/en/faq) |
| `v5-beach-park-brazil` | Beach Park Aqua Park | Water parks | BR | Porto das Dunas, Aquiraz, Ceara | [Official reference](https://beachpark.com.br/en/experiences/aqua-park/attractions/) |
| `v5-volcano-bay` | Universal Volcano Bay | Water parks | US | Universal Orlando Resort, Orlando, Florida | [Official reference](https://www.universalorlando.com/web/en/us/theme-parks/volcano-bay) |
| `v5-disney-typhoon` | Disney's Typhoon Lagoon | Water parks | US | Walt Disney World Resort, Florida | [Official reference](https://disneyworld.disney.go.com/destinations/water-parks/) |
| `v5-disney-blizzard` | Disney's Blizzard Beach | Water parks | US | Walt Disney World Resort, Florida | [Official reference](https://disneyworld.disney.go.com/destinations/water-parks/) |
| `v5-aquaworld-oarai` | Aqua World Ibaraki Oarai Aquarium | Public aquariums | JP | Oarai, Ibaraki | [Official reference](https://en.aquaworld-oarai.com/floor/zone/) |
| `v5-umi-kirara` | Kujukushima Aquarium Umi Kirara | Public aquariums | JP | Kujukushima Pearl Sea Resort, Sasebo, Nagasaki | [Official reference](https://www.pearlsea.jp/en/educational_trip/school_trip_umikirara/) |
| `v5-shikoku` | Shikoku Aquarium | Public aquariums | JP | Utazurinkai Park, Utazu, Kagawa | [Official reference](https://www.shikoku-aquarium.jp/en/) |
| `v5-marine-world-fukuoka` | Marine World Uminonakamichi | Public aquariums | JP | Uminonakamichi, Fukuoka | [Official reference](https://www.crossroadfukuoka.jp/en/experience/12373) |

## Prior V4 report, retained historical context

The following is the earlier report. Its counts and research date describe V4, not the V5 totals above. Its existing-site findings are not newly verified deployment claims.

# DipMapper V4: research findings and implementation changes

Research edition: 12 November 2026. The written guide and JSON contain the content, rather than a request for Claude to invent it. This report separates new aquarium research, editing of inherited water data and unverified production integration.

## Actual expansion

120 new public-aquarium profiles in 45 countries and territories. A Top 100 aquarium edition and a separate 25-venue inside-mall list are ordered and written. The existing Top 200 water set and all 338 V3 IDs remain intact. The complete catalogue is 458 records across 87 countries and territories.

Every new aquarium has an individual description, reason, three key attractions, locality context, venue relationship, season interpretation, caveat, official planning route and evidence links. This pass also rewrites 138 previously duplicated water-ranking rationales and improves 24 leading water introductions. The Top 200 now has distinct introduction and reason fields on every card. Those edits use the retained source facts; they are not labelled fresh independent verification of the original water destinations.

## Practical findings that change the product

| Subject | Evidence finding | Implementation |
| --- | --- | --- |
| Aquaria Phuket | The operator identifies B1 in Central Phuket Floresta. Accessible toilets are on the ground floor; wheelchairs are available through the ticket counter. | Exact mall relationship; field-level access facts; official phone and ticket route. No invented entrance coordinates. |
| Fort Fisher / Discovery Bay | The main aquarium reports construction closure. Discovery Bay is a separate mini-aquarium inside Independence Mall. A government announcement describes the ordinary visit as complimentary. | Only the actual mini-aquarium is added as the available research record. Do not make a free mall visit look like admission to the closed full aquarium. |
| COEX, Singapore, Atlantis and Leon | Publisher material uses updated aquarium names. | Store former names as search aliases, not duplicate attractions. |
| Aquaria KLCC | Venue is beneath the convention centre, not simply an aquarium inside the adjacent mall. | Exclude from inside-mall filter. |
| Cebu Ocean Park | Official visitor information places it opposite SM Seaside. | Mall-adjacent, not inside mall. |
| Gdynia calendar | An earlier search excerpt appeared inconsistent. Final opened English and Polish pages both state Monday closure November through February and named holiday closures. | Final pages supersede the excerpt. Recurring month and weekday rules are tested. No unresolved February conflict remains in the delivered data. |
| Genoa admission | Fixed-date starting price, ticket-office fare, Open Flexi and combined village tickets differ. | EUR 26 retained as a starting fixed-date reference, not a universal admission price. |
| Nausicaa admission | Off-season and peak-season adult references differ. Child-age wording overlaps at the age-12 boundary. | EUR 30 off-season reference with EUR 31.50 peak context; no automatic child quote at the ambiguous boundary. |
| Kyoto admission | Adult, school and age-three-plus child categories differ; annual and special evening products are separate. | JPY 2,600 general adult reference and official ticket route, not a special-event quote. |
| Churaumi admission | General adult, school, group and documented-concession categories differ. | JPY 2,180 adult reference, public contact and category caveats. |
| Zoo, science and theme-park aquariums | Some aquariums are components of larger paid venues. | Preserve included-admission and separate-entry context rather than inventing a standalone aquarium fare. |
| Partial works | Publisher references contain construction or exhibit restrictions at several venues. | Display those notices separately from an all-month venue-format season. No blanket currently-open claim. |

Primary links for the findings above:

- https://aquaria-phuket.com/location.php
- https://www.ncaquariums.com/fort-fisher
- https://www.dncr.nc.gov/news/press-releases/2026/07/08/nc-aquariums-welcome-visitors-unique-underwater-experience-independence-mall-wilmington
- https://www.cebuoceanpark.com/tickets-and-hours/
- https://akwarium.gdynia.pl/en/opening/
- https://akwarium.gdynia.pl/godziny-i-dni-otwarcia/
- https://www.acquariodigenova.it/en/tickets-and-prices
- https://www.nausicaa.fr/en/my-visit/rates
- https://www.kyoto-aquarium.com/about/price/
- https://churaumi.okinawa/en/guide/info/

The source register holds the remaining aquarium references. Some links and search excerpts reflect cached publisher material. The research date is the desk-review date, not proof of an on-site visit, a successful booking or live operator availability.

## Exact change report

| Page or feature | Old paragraph or behaviour | New paragraph or behaviour | Reason |
| --- | --- | --- | --- |
| Explore | One mixed Top 200 edition and short record summaries | Preserve Top 200 water, add separate Top 100 aquariums and a longer aquarium directory | New indoor discovery without replacing swimming and outdoor content |
| Ranking cards | Rationale and season strip, little practical detail | Individual introduction, reason, attractions, location, season, caveat, price reference and official actions | A ranking becomes usable for an actual visit |
| Water editorial copy | 138 Top 200 records repeated the introduction as the reason | Distinct destination-specific editorial reasons on all Top 200 cards | Explain the choice instead of repeating a source note |
| Aquarium ranking | No aquarium edition | Explicit authored positions, with method and limitations | Give readers a clear shortlist without pretending to measure objective quality |
| Mall discovery | Mall name could imply adjacency or membership | Exact inside-mall relationship; exclude mall-adjacent, resort and convention-centre venues | Make the user filter mean what it says |
| Ticketing | Generic cost/reference section | Official route plus currency, product unit, age/height category, starting/dated/unknown status | Do not compare a child ticket, permit, flexible fare and general admission as one price |
| Contact | Source links only | Dedicated official contact route, published phones/emails where found | Give users a practical next action without fabricating local contacts |
| Indoor seasons | Potential twelve-month opening implication | All-month venue-format interpretation plus actual restrictions | Indoors is not the same as open every day |
| Recurring closures | Date-window checks only | Month and weekday checks, plus annual review policy | Prevent a Monday rule from closing every day or a summer visit |
| Names | Former attraction branding could create duplicates | Search aliases on the existing entity | Preserve discovery and prevent duplicate map records |
| Static pages | Short ranking paragraphs | Full readable cards and sources without JavaScript | Content remains useful outside the app |
| Cookie passport | 338 slots | Append 120; old prefix and cookie name unchanged | Preserve saved wanted/visited states |
| Map stars | Existing verified-join adapter | Retain adapter and add curated aquarium selections as optional highlights | No name-only matching, invented pins or paid reorder |
| Neutral map | Existing result order | Unchanged | The editorial layer must not replace comprehensive nearby search |
| Homepage load | Optional existing Explore | Lazy-loaded rankings and activity shards | Keep the normal swimming experience lightweight |

## Written ranking method

The water ranking retains the earlier coarse 40/35/25 component method. It is an editorial selection, with genuine tied scores. The aquarium list is deliberately different: an authored order based on distinctive exhibits, regional interpretation, visit depth and itinerary usefulness. Its positions are opinions, not arithmetic proof, user ratings or independent animal-welfare assurance.

A separate zoo, science-centre or mall context can increase itinerary usefulness but does not create a superior welfare claim. A large tank is not enough on its own to justify a ranking position. Each aquarium has an individual reason and a practical trade-off.

No claimed first-hand visits, operator certification, fabricated reviews, review counts or paid-rank influence. Existing fields that describe coarse compatibility scores remain for the application, but the aquarium UI explains the actual authored ordering instead.

## SEO implementation

The supplied static builder creates 19 substantive ranked pages and a navigation overview. The two new primary routes are `/discover/best-public-aquariums/` and `/discover/aquariums-in-shopping-malls/`. Existing route and swimming guides remain. Do not create a near-duplicate Top 120 aquarium page solely to gain another indexed URL; the longer directory belongs in Explore.

Publish the content through the existing templates after a named publisher review. Canonical URLs must match actual deployed paths and preferred host. Merge the sitemap fragment. Use truthful meaningful content dates, not daily build timestamps. The review gate applies to new pages only, never the current production site.

Retain crawlable anchors, visible reasons and practical facts in initial HTML. App-only filters remain interactive states unless a separately written page has a distinct purpose. No country x month x species x age x accessibility page factory. Validate ItemList markup against the visible list. Do not emit aggregateRating, reviewCount, live availability or Product offers from editorial ranks and indicative prices.

Google's reviews documentation covers ranked recommendation lists and emphasises substantive analysis rather than thin summaries. That supports the content approach, not a promise of ranking, rich-result eligibility, indexing or traffic.

- https://developers.google.com/search/docs/appearance/reviews-system
- https://developers.google.com/search/docs/specialty/ecommerce/write-high-quality-reviews
- https://developers.google.com/crawling/docs/faceted-navigation
- https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap
- https://developers.google.com/search/docs/appearance/structured-data/sd-policies

Track actual deployment, Search Console impressions/clicks and meaningful use of cards, official routes and saved lists. Keep branded and non-branded traffic distinct. No Search Console, Google position, backlink or traffic gain was measured in this package.

## Freshness and evidence rules

Keep three dates separate: publisher validity, source review and selected visit. A new desk-review timestamp does not renew an expired ticket or programme. Store a fetched page's digest and semantic changes if the owner later adds a refresh job, but do not auto-publish changed facts or mark a source verified solely because an HTTP request succeeded.

Numeric prices are reference amounts, not complete trip budgets. Use the official page where prices are date-dependent, hidden in checkout or not established. Never fill null with zero or guess a currency. Direct public phone/email fields are untested business contacts. Exact entrance/departure coordinates and photo rights remain absent unless independently supplied.

Original short factual paraphrases are supplied. No source photography or copied full publisher articles are bundled. No permission for bulk mirroring or future scraping is asserted. The live weather interface remains unconnected; current commercial provider terms and licence suitability require the actual deployment decision.

## Inherited V3 research context

The following section is retained as historical context from the prior delivery. Its V3 counts and earlier proposed changes describe that edition, not the final V4 totals. Use the current README, catalogue and QA report for delivered scope.


# Research expansion and change report

Research edition: 12 November 2026. This report describes supplied code and research, not changes deployed to dipmapper.com.

## What was researched

The earlier 301-record catalogue remains intact. V3 adds 37 beach records, season research for existing experiences, explicit waterbody joins, family/accessibility evidence and a global editorial assessment. The consolidated register has 384 source records covering 369 distinct URLs. Of these, 110 source entries and distinct URLs are newly researched in V3; 274 entries are inherited and explicitly not represented as rechecked.

New research uses primary operators, park and local authorities, national/regional tourism publishers, transport authorities and specialist diving publishers where relevant. Of the 110 new references, 96 were reviewed through publisher search excerpts and 14 through opened pages. The complete register identifies the method and scope. An excerpt is not a fully archived source or live operator check. Confirm the specific current pages and product conditions during publication review.

Only original factual summaries and the supplied original interface/code are included. Publication rights to source text, databases and photographs are not inferred. No licensed attraction photographs are supplied. Simplified globe land shapes use Natural Earth public-domain data, credited in the interface and geography file.

## Findings that materially change the product

| Experience or area | Finding | Data/UI consequence | Primary source |
| --- | --- | --- | --- |
| Milford Sound kayaking | Operator describes winter conditions as often calmer, with route-specific participant requirements | Warmest month is not a universal kayaking preference; retain named trip conditions | https://www.roscosmilfordkayaks.com/faqs/ |
| Dry Tortugas | Park describes seasonal weather differences, including windier winter conditions | Distinguish the regional weather pattern from a current snorkelling forecast | https://www.nps.gov/drto/learn/nature/weather.htm |
| Soča River | Published boating window runs 15 March to 31 October | Exact access dates override a broad warm-weather score; no winter rafting suggestion from attractiveness alone | https://www.soca-valley.com/en/in-search-of-adventure/nature/2020120910545268/the-soca-river/ |
| Lake Brienz | Publisher lists the 2026 season from 3 April to 6 December | Retain supported late-autumn boating; do not assume summer-only service | https://www.bls.ch/de/freizeit-und-ferien/ausfluege/schifffahrt-brienzersee |
| Lake Brienz family offer | Supervised Globi cabin for children from four on a named ship | This is a particular onboard service, not a universal minimum age for the cruise | https://www.bls.ch/de/freizeit-und-ferien/ausfluege/schifffahrt-brienzersee |
| Bürgenstock boat | Publisher describes year-round service and specific access facilities | A year-round operating reference is possible without inventing a sailing time | https://www.lakelucerne.ch/en/information/our-fleet/motor-vessel-buergenstock/ |
| Lake Como | Current search excerpt and opened cached text point to different timetable periods | Conflict flag; do not promote the conflicting window as a confirmed current programme | https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/ |
| AQUA DOME | Published maintenance affects children's pool/slides on 9-13 November 2026 | A partial family-area notice must not close the entire facility or disappear in a general year-round label | https://www.aqua-dome.at/de/revisionen/ |
| Quicksilver / Agincourt | Access differs by vessel and platform; the platform lift has stated limits | Separate boarding, viewing, toilets and assisted water entry; no universal wheelchair badge | https://quicksilver-cruises.com/reef-tour/disability-access/index.html |
| Kings Beach | Council's accessible-beach information includes works affecting equipment from April 2026 | Exclude an equipment-dependent suggestion during the affected period without treating the whole beach as closed | https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program |
| Great Ocean Road beaches | Accessible equipment calendars differ from swimming advice; a shore-access programme does not mean water entry is advised | Access-equipment-only evidence cannot qualify as a general activity season | https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches |
| Lake Zurich ships | Network information includes ship-specific wheelchair/accessible-toilet exceptions | Preserve route and ship conditions instead of a lake-wide access claim | https://www.zvv.ch/en/service/travel-without-barriers/limited-mobility/ships.html |
| Oahu North Shore | Winter surf and summer beach conditions support different activities | Separate surf viewing from swimming; neither the season nor score authorises entering the water | https://oceansafety.hawaii.gov/hawaiis-surf-seasons/ |
| Phuket | Tourism authority distinguishes the named beaches and current warning flags | Join Patong, Kata and Karon to Phuket; do not equate all Thai destinations with Phuket | https://www.tourismthailand.org/Destinations/Provinces/Phuket/350 |
| Great Ocean Road regional climate | Regional travel guidance provides summer context | Label climate transfer as regional interpretation, not exact beach water conditions | https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html |
| Sunshine Coast climate | Destination publisher describes seasonal patterns | Climate context is labelled as such; beach-specific safety still needs local evidence | https://www.visitsunshinecoast.com/website-ai-overview-visit-sunshine-coast |
| Tropical Islands | Detailed accessibility services and park-family rules exist | Separate physical access facts and adult-supervision rules | https://www.tropical-islands.de/en/relevante-informationen/inclusion-accessibility/special-services |
| Wild Wild Wet | Park rules specify supervision responsibilities | Family fit remains conditional rather than becoming an unrestricted child-safe label | https://www.wildwildwet.com/park-regulations/park-rules-regulations |
| Milford cruise vessels | General and ship-specific accessibility statements differ, including toilet implications | Retain the named-vessel information and hold ambiguous toilet access rather than overclaiming | https://www.realnz.com/en/experiences/day-cruises/milford-sound-classic-cruise/ |
| Lake Malawi | Specialist destination guidance discusses year-round diving and a distinct cichlid period | Species selection has a separate calendar from general operating possibility | https://www.padi.com/diving-in/malawi/ |

A reference date does not establish that a temporary condition remains true indefinitely. The engine ages operational information and preserves conflicts. The table describes what the research captured; the publisher and competent operator remain the sources for the exact visit.

## Exact change report

| Page or feature | Old paragraph or behavior | New paragraph or behavior | Reason |
| --- | --- | --- | --- |
| Existing homepage | Swimming-first global map | Retain; add an optional Explore action without eager loading | Preserve DipMapper's identity and normal use |
| Existing map ranking | Neutral result order | Same results and order, optional star from reviewed identity join | Add discovery value without turning search into a curated-only list |
| Editorial star | Not implemented in V2 | "DipMapper editorial selection" with explanation and evidence | Avoid a misleading five-star rating or safety certificate |
| Season coverage | Many records have no seasonal layer | Every record has a season profile; 239 have a researched/interpreted window, 99 are explicit research gaps | Consistent UI without inventing all-year availability |
| Experience ranking | Diversity/discovery ordering | Separate overall attractiveness and seasonal-fit sorting | Answer two distinct visitor decisions |
| Activity pages | A few general guides plus dynamic discovery | 29 actual activity lists; 13 substantial activity-page previews | Publish true scope and avoid fake Top 200 titles |
| Geographic search | Country/place text | Named water hierarchy and reviewed aliases | Mediterranean, Garda and Phuket need different joins |
| Family filter | Limited fields and general conditions | Conditional family requirement with optional age | Avoid treating incomplete evidence as child suitability |
| Accessibility | Often unknown | Five separately sourced facets and equipment conditions | A ramp does not prove accessible toilets or water entry |
| Saved discovery | V2 local lists | New cookie-only wanted/visited passport; existing favourites untouched | Meet the new persistence constraint without breaking prior data |
| Globe | Not included | Local Canvas globe, approximate clusters, keyboard/list alternative | Visually support discovery without a map SDK or tile requests |
| Return visit | V2 saved notices/almanac | Keep V2; add upcoming windows for saved wanted experiences | Offer a concrete reason to return without forced subscriptions |
| Weather/day ideas | Not a live service | Conservative forecast validation and unscheduled local day ideas | Avoid invented current conditions and travel times |
| SEO filters | Potential combinatorial query space | Useful curated pages; interactive facets do not automatically become landing pages | Avoid large volumes of duplicate thin URLs |
| Review publication | General content approval | Named evidence and score approval, review queue and sitemap fragments | Sources substantiate facts, not the subjective score |
| Query interaction | Captured a delayed event target | Capture the typed value before the debounce | Fix a browser-observed ShadowRoot event bug |
| Checklist import | Referenced the event target after awaiting the file | Capture the file input before the async operation | Fix a browser-observed post-import exception |
| Saved-place globe | Could ignore active filters | Same filtered rows as the saved-place list | Keep the map/globe and results consistent |
| Species evidence | Mixed strings and inherited arrays | Explicit species extraction and matching | Preserve inherited formats and avoid missing single-species filters |

## Research priorities for the next actual review

Use `python 12_build.py review-queue --out /tmp/dipmapper-v3-review.json`. The output covers actual records and their missing fields. It is not a claim that a recurring collector is active.

First, review the human editorial scores and exact source text for the intended Top 200 release. Second, fill seasons for uncovered activity groups and important destinations rather than adding numbers to reach 1,000. Third, expand family and accessibility facts by exact product, vessel, venue and access method. Fourth, verify exact departure identities before mapping stars. Then address current prices, tariff units and licensed pictures.

The ten activity types without an eligible ranked record are boat rental, conservation paddle, culinary cruise, jet ski, pool, shark watching, snorkel trail, submarine, underwater heritage and wreck diving. These activities remain in the underlying catalogue and production map; no false global ranking is published for them yet. Their filters show an honest empty evidence result until the relevant seasonal research is approved.

The full known/unknown state is in the data, not hidden in a prose claim. The following section is generated from those records so Claude can work directly on the remaining seasonal gaps.

## Actual remaining season gaps (99)

| ID | Experience | Activity | Existing evidence to revisit |
| --- | --- | --- | --- |
| cruise-lindau | Lindau and Bregenz Bay sightseeing cruise | scenic_cruise | https://www.bsb.de/de/bodensee-erlebnisse/rundfahrten/lindau/bregenzer-bucht |
| shark-gansbaai | Gansbaai shark-cage experience | shark_watch | https://sharkwatchsa.com/rates-and-info/ |
| ferry-manly | Sydney F1 Manly ferry | ferry | https://transportnsw.info/routes/details/sydney-ferries-network/f1/090f1 |
| cruise-bosphorus | Istanbul municipal Bosphorus tour | scenic_cruise | https://sehirhatlari.istanbul/en/price-list/bosphorus-tours-78 |
| ferry-miyajima | Miyajimaguchi to Miyajima crossing | ferry | https://miyajima-matsudai.co.jp/en/price.html |
| park-wildwildwet | Wild Wild Wet Singapore | water_park | https://www.wildwildwet.com/visitor-information/guest-services |
| whale-chanaral | Chanaral de Aceituno marine wildlife | whale_watch | https://wwhandbook.iwc.int/en/country-profiles/chile |
| snorkel-tangalooma | Moreton Island wreck snorkelling | snorkel | https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland |
| snorkel-buck-island | Buck Island underwater trail | snorkel_trail | https://www.nps.gov/places/buck-island-underwater-trail.htm |
| snorkel-trunk-bay | Trunk Bay underwater interpretation trail | snorkel_trail | https://www.nps.gov/places/trunk-bay.htm |
| wreck-biscayne | Biscayne Maritime Heritage Trail | wreck_dive | https://www.nps.gov/bisc/learn/historyculture/maritime-heritage-trail.htm |
| wreck-fathom-five | Fathom Five freshwater wreck exploration | wreck_dive | https://parks.canada.ca/amnc-nmca/on/fathomfive/activ/plong-dive |
| dive-saguenay | Saguenay-St Lawrence cold-water diving | scuba | https://parks.canada.ca/amnc-nmca/qc/saguenay/activ/plongee-diving |
| boat-wakulla | Wakulla Springs riverboat wildlife outing | wildlife_boat | https://www.visitflorida.com/places-to-go/north-central/wakulla-springs/ |
| thermal-gudlaug | Gudlaug coastal baths | thermal_bath | https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/ |
| thermal-nautholsvik | Nautholsvik geothermal beach | thermal_bath | https://www.visiticeland.com/things-to-do/nautholsvik-geothermal-beach/ |
| pool-akureyri | Akureyri geothermal swimming pools | pool | https://www.visiticeland.com/things-to-do/akureyri-swimming-pool/ |
| sauna-son | Son Spa sauna rafts | sauna_swim | https://www.visitnorway.com/listings/son-spa-sauna-rafts/217304/ |
| boat-elgol | Elgol to Loch Coruisk boat outing | scenic_cruise | https://www.visitscotland.com/info/tours/misty-isle-boat-trips-3d7bab4f |
| reef-bluebay | Blue Bay snorkel and glass-bottom discovery | glass_bottom | https://mauritiusnow.com/blog/things-to-do/blue-bay-marine-park/ |
| boat-benitiers | Ile aux Benitiers lagoon boat day | island_boat | https://mauritiusnow.com/blog/things-to-do/ile-aux-benitiers/ |
| kayak-grandriver | Grand River South East waterfall paddle | kayak | https://mauritiusnow.com/blog/things-to-do/kayaking/ |
| wildlife-plettenberg | Plettenberg Bay dolphin and coastal wildlife | wildlife_boat | https://www.southafrica.net/gl/en/travel/article/dolphin-tours-in-south-africa-thousands-of-kilometres-of-coastline-offering-the-best-dolphin-spotting-opportunities |
| dive-protea | Protea Banks specialist dive | scuba | https://www.southafrica.net/gl/en/travel/article/embrace-the-outdoors-hibiscus-coast-kwazulu-natal |
| safari-tofo | Tofo ocean safari | wildlife_boat | https://www.tofoscuba.com/prices |
| snorkel-tanikely | Nosy Tanikely marine-park snorkelling | snorkel | https://www.tanikely.com/en/national-marine-park/ |
| kayak-pelicanpoint | Pelican Point seal kayak outing | kayak | https://www.mola-namibia.com/kayaking-experience/ |
| snorkel-langtengah | Lang Tengah snorkel-stay discovery | snorkel | https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/ |
| snorkel-kapas | Kapas island snorkelling | snorkel | https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/ |
| reef-shiraho | Shiraho blue-coral viewing | glass_bottom | https://www.japan.travel/en/spot/567/ |
| boat-minamijima | Minamijima guided island-water visit | island_boat | https://www.japan.travel/en/sports/diving/travel/minamijima-ogasawara/ |
| dive-yonaguni | Yonaguni underwater formations | scuba | https://www.japan.travel/en/spot/564/ |
| submarine-seogwipo | Seogwipo submarine reef viewing | submarine | https://english.visitkorea.or.kr/svc/whereToGo/locIntrdn/rgnContentsView.do?vcontsId=90740 |
| paddle-soesokkak | Soesokkak estuary paddle discovery | kayak | https://english.visitkorea.or.kr/svc/whereToGo/locIntrdn/rgnContentsView.do?vcontsId=94895 |
| cruise-lucerne-brunch | Lake Lucerne Sunday brunch cruise | culinary_cruise | https://webshop.lakelucerne.ch/en/stories/brunch-cruise |
| cruise-garda | Lake Garda scheduled sightseeing boats | scenic_cruise | https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-garda/ |
| ferry-intra-laveno | Intra-Laveno Lake Maggiore ferry | ferry | https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-maggiore/ |
| cruise-three-lakes | Swiss Three-Lakes waterway cruise | scenic_cruise | https://www.myswitzerland.com/en-us/experiences/lake-neuchatel-cruises/ |
| cruise-greifensee | Greifensee small-lake cruises | scenic_cruise | https://www.myswitzerland.com/en-ch/experiences/lake-greifen-cruises/ |
| dive-attersee | Attersee underwater heritage interpretation | scuba | https://b2b.austria.info/en-gb/media/story-ideas/adventures-rivers-lakes-austria/ |
| park-area47 | AREA 47 water activity park | water_park | https://www.imst.at/en/experience-water.html |
| swim-piburger | Piburger See mountain-lake swim | swim | https://www.imst.at/en/experience-water.html |
| paddle-pontdugard | Pont du Gard canoe viewpoint | kayak | https://www.france.fr/en/article/france-along-the-water/ |
| paddle-dordogne | Dordogne castle-view canoe journey | kayak | https://www.france.fr/en/article/france-along-the-water/ |
| paddle-chenonceau | Chenonceau from the water | kayak | https://www.france.fr/en/article/france-along-the-water/ |
| boat-ill | Alsace flat-bottomed river outing | scenic_cruise | https://www.france.fr/en/article/france-along-the-water/ |
| paddle-midi | Canal du Midi paddle outing | kayak | https://www.canal-du-midi.com/en/frequently-asked-questions/ |
| rental-garonne | Fourques-sur-Garonne small-boat rental | boat_rental | https://www.valdegaronne-tourisme.com/en/activities/emerald-rental/ |
| paddle-estany | Estany des Peix lagoon paddling | kayak | https://www.formentera.es/en/explore/activities/water-sports/ |
| paddle-cala-saona | Cala Saona coastal kayaking | kayak | https://www.formentera.es/en/explore/activities/water-sports/ |
| dive-tabarca | Tabarca island diving | scuba | https://www.comunitatvalenciana.com/en/be-inspired/water-activities-costa-blanca |
| paddle-altea | Altea coastal paddling | kayak | https://www.comunitatvalenciana.com/en/be-inspired/water-activities-costa-blanca |
| boat-albufeira | Albufeira cave and coastal boat trips | scenic_cruise | https://visitalbufeira.pt/experiencias/experiencias-no-mar/en/ |
| rental-albufeira | Albufeira powered-water rental discovery | jet_ski | https://visitalbufeira.pt/experiencias/experiencias-no-mar/en/ |
| paddle-terceira | Terceira coastal paddling | kayak | https://www.exploreterceiraisland.com/en/experiencias/kayaking/ |
| boat-bled | Lake Bled pletna boat outing | scenic_cruise | https://www.slovenia.info/en/stories/let-s-take-a-trip-on-water |
| paddle-kolpa | Kolpa river paddling | kayak | https://www.slovenia.info/en/stories/let-s-take-a-trip-on-water |
| paddle-dugi-otok | Dugi Otok kayak and snorkel outing | kayak | https://www.zadar.hr/en/experience/explore/top-island-ideas-dugi-otok |
| wind-nin | Nin Zdrijac kitesurf discovery | wind_sport | https://www.zadar.hr/en/experience/nature-adventure/water-sports-on-sea |
| heritage-greece-underwater | Greek underwater archaeology and dry interpretation | underwater_heritage | https://euaculture.gr/en/ |
| paddle-zakynthos | Zakynthos Blue Caves kayak discovery | kayak | https://www.discovergreece.com/outdoor-activities-greece |
| raft-voidomatis | Voidomatis river rafting | rafting | https://www.discovergreece.com/outdoor-activities-greece |
| wind-paros | Paros wind-sport discovery | wind_sport | https://www.discovergreece.com/outdoor-activities-greece |
| raft-pacuare | Pacuare river rafting | rafting | https://www.visitcostarica.com/planning-your-trip/climate |
| snorkel-punta-uva | Punta Uva snorkel discovery | snorkel | https://www.visitcostarica.com/planning-your-trip/climate |
| ferry-paquera | Puntarenas-Paquera Gulf of Nicoya crossing | ferry | https://www.visitcostarica.com/things-to-do/adventure |
| wildlife-tortuguero | Tortuguero waterways and turtle-season planning | marine_wildlife | https://www.visitcostarica.com/things-to-do/sustainable-tourism |
| raft-boquete | Boquete river-rafting discovery | rafting | https://www.tourismpanama.com/outdoors-and-nature/outdoor-adventure/ |
| dive-malpelo | Malpelo specialist expedition diving | scuba | https://www.parquesnacionales.gov.co/nuestros-parques/sff-malpelo/ |
| tube-navua | Navua river tubing and village outing | river_tubing | https://www.fiji.travel/things-to-do/thrilling/unforgettable-river-adventures-in-fiji |
| raft-upper-navua | Upper Navua conservation-area rafting | rafting | https://www.fiji.travel/things-to-do/thrilling/unforgettable-river-adventures-in-fiji |
| surf-frigates | Frigates Passage surf-boat discovery | surf | https://www.fiji.travel/places-to-go/pacific-harbour/locations/adventures-in-pacific-harbour |
| snorkel-niue | Niue tide-led west-coast snorkelling | snorkel | https://www.niueisland.com/discover-niue/blog/post/best-snorkelling-holidays-in-the-south-pacific |
| kayak-purple-island | Purple Island mangrove paddling | kayak | https://visitqatar.com/intl-en/things-to-do/beach-holiday/purple |
| dive-yanbu | Yanbu Red Sea reef diving | scuba | https://www.visitsaudi.com/en/see-do/destinations/yanbu |
| kayak-kivu | Lake Kivu coastal kayaking | kayak | https://visitrwanda.com/interests/kayaking/ |
| kayak-malawi | Lake Malawi lakeshore kayak discovery | kayak | https://www.malawitourism.com/experiences/lake/kayaking-sailing/ |
| canoe-upper-zambezi | Upper Zambezi guided canoe safari | kayak | https://www.zambiatourism.com/safaris/canoeing-safaris/ |
| canoe-lower-zambezi | Lower Zambezi guided canoe safari | kayak | https://www.zambiatourism.com/safaris/canoeing-safaris/ |
| kayak-trangan | Trang An self-paddle discovery | kayak | https://sodulich.ninhbinh.gov.vn/en/news-events/kayaking-service-rolls-out-new-way-to-discover-trang-an-complex-352.html |
| raft-xiuguluan | Xiuguluan River rafting | rafting | https://www.eastcoast-nsa.gov.tw/en/travel/waters/boating/ |
| kayak-green-copenhagen | Copenhagen GreenKayak clean-up paddle | conservation_paddle | https://www.greenkayak.org/faq/ |
| rental-soomaa | Soomaa Holiday Village canoe rental | kayak_rental | https://soomaa.com/canoe-rental/ |
| paddle-biesbosch | Biesbosch freshwater-tide paddling | kayak | https://www.beleefdebiesbosch.com/see-do/to-sail |
| boat-biesbosch | Biesbosch quiet electric-boat outing | boat_rental | https://www.beleefdebiesbosch.com/see-do/to-sail |
| ferry-rotterdam | Rotterdam-Dordrecht and Kinderdijk Waterbus | ferry | https://www.rotterdam.info/en/visit/finder-locations/waterbus |
| snorkel-sucuri | Rio Sucuri freshwater float | snorkel | https://www.visitbrasil.com/en/location/bonito-en/ |
| snorkel-prata | Olho dAgua and Prata river float | snorkel | https://feel.visitbrasil.com/en/flutuacao-no-rio-da-prata-2/ |
| raft-maipo | Maipo river rafting discovery | rafting | https://chile.travel/en/activities/adventure-and-sports/river-experiences/ |
| raft-trancura | Trancura river rafting discovery | rafting | https://chile.travel/en/activities/adventure-and-sports/river-experiences/ |
| raft-alumine | Alumine River whitewater discovery | rafting | https://www.argentina.gob.ar/viaja-por-argentina/que-hacer/vivir-una-aventura-de-rafting-en-el-rio-alumine |
| kayak-huaypo | Lake Huaypo highland kayaking | kayak | https://www.peru.travel/experiences/kayaking-on-cusco-s-lakes |
| surf-waco | Waco inland surfing and separate waterpark options | surf_park | https://wacosurf.com/surf/ |
| park-wildwadi | Wild Wadi waterpark | water_park | https://www.wildwadi.com/en |
| surf-abudhabi | Surf Abu Dhabi discovery session | surf_park | https://www.surfabudhabi.com/experiences/discovery |
| surf-alaia | Alaia Bay alpine surf sessions | surf_park | https://booking.alaiabay.ch/ |
| surf-bristol | The Wave Bristol surf sessions | surf_park | https://www.thewave.com/surf/ |
| surf-urbn-melbourne | URBNSURF Melbourne | surf_park | https://urbnsurf.com/learn/ |
| beach-cala-brandinchi | Cala Brandinchi beach | beach | https://www.sardegnaturismo.it/it/esplora/cala-brandinchi?language=it |

## Other ranking hold

- jetski-ratsada: Editorial comparison, not operator verification. Unverified jet-ski operations are held from highlights.
