/** DipMapper V4. Pure ranking, season and fit logic. No network, tracking or persistence. */
export const VERSION='5.0.0';
export const MONTHS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
export function normalize(s){return String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();}
export function speciesNames(rule){return (Array.isArray(rule.species)?rule.species:[rule.species]).filter(x=>typeof x==='string'&&x.trim()).map(x=>x.trim());}
export function hasSpecies(rule,value){return speciesNames(rule).some(x=>normalize(x)===normalize(value));}
export function escapeHTML(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
export function safeURL(s){try{const u=new URL(s);return ['https:','http:'].includes(u.protocol)&&!u.username&&!u.password?u.href:null;}catch{return null;}}
export function localDate(s){
 if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))throw new TypeError('Use a destination-local YYYY-MM-DD date.');
 const t=Date.parse(s+'T12:00:00Z');if(!Number.isFinite(t)||new Date(t).toISOString().slice(0,10)!==s)throw new RangeError('Invalid date.');return s;
}
export function dayDiff(a,b){return Math.round((Date.parse(localDate(b)+'T12:00Z')-Date.parse(localDate(a)+'T12:00Z'))/86400000);}
export function withinWindow(date,window){
 localDate(date);if(!window)return true;
 const {start,end}=window;
 if((start&&/^\d{4}-/.test(start))||(end&&/^\d{4}-/.test(end))){
  if(start)localDate(start);if(end)localDate(end);return(!start||date>=start)&&(!end||date<=end);
 }
 if(!start||!end)throw new TypeError('Recurring windows require two MM-DD bounds.');
 for(const v of [start,end]){if(!/^\d{2}-\d{2}$/.test(v))throw new TypeError('Invalid window.');localDate('2000-'+v);}
 const md=date.slice(5);return start<=end?md>=start&&md<=end:md>=start||md<=end;
}
export function inValidity(date,v){const start=v?.start||v?.from||null,end=v?.end||v?.to||null;return (!start&&!end)||withinWindow(date,{start,end});}
function groupBy(rows,key){const m=new Map();for(const r of rows){const k=r[key];if(!m.has(k))m.set(k,[]);m.get(k).push(r);}return m;}
export function createModel(catalogue,rules,geography){
 const records=catalogue.records||[];const byId=new Map(records.map(r=>[r.id,r]));if(byId.size!==records.length)throw new Error('Duplicate IDs.');
 const scopes=new Map(geography.scopes.map(s=>[s.id,s]));
 const ancestors=new Map();
 function walk(id,seen=new Set()){
  if(seen.has(id))throw new Error('Geography cycle.');if(!scopes.has(id))throw new Error('Unknown scope '+id);
  if(ancestors.has(id))return ancestors.get(id);const next=new Set([...seen,id]);const set=new Set([id]);
  for(const p of scopes.get(id).parents||[])for(const a of walk(p,next))set.add(a);
  ancestors.set(id,set);return set;
 }
 for(const id of scopes.keys())walk(id);
 const aliases=new Map();for(const s of scopes.values())for(const a of [s.label,s.id,...s.aliases]){const n=normalize(a);if(!aliases.has(n))aliases.set(n,new Set());aliases.get(n).add(s.id);}
 const countryById=new Map(geography.countries.map(c=>[c.code,c]));
 const sourceById=new Map(rules.sources.map(s=>[s.source_id,s]));
 for(const r of records){for(const s of r.source_ids||[])if(!sourceById.has(s))throw new Error('Missing source '+s);for(const s of r.geo_v3.scope_ids)if(!scopes.has(s))throw new Error('Unknown scope '+s);}
 const restrictionsById=new Map();for(const x of rules.restrictions)for(const id of x.experience_ids){if(!restrictionsById.has(id))restrictionsById.set(id,[]);restrictionsById.get(id).push(x);}
 return {catalogue,rules,geography,records,byId,scopes,ancestors,aliases,countryById,sourceById,seasonsById:groupBy(rules.seasons,'experience_id'),restrictionsById,offersById:groupBy(rules.offers.records||[],'experience_id'),researchDate:catalogue.research_date};
}
export function expandedScopes(model,record){const set=new Set();for(const s of record.geo_v3.scope_ids)for(const x of model.ancestors.get(s)||[])set.add(x);return set;}
export function resolveScope(model,query){return [...(model.aliases.get(normalize(query))||[])];}
export function layerStatus(rule,date,asOf){
 localDate(date);localDate(asOf);
 const months=rule.months||[];
 let state=!months.length||rule.inside_state==='unknown'?'unknown':months.includes(Number(date.slice(5,7)))&&withinWindow(date,rule.date_window)?'match':'outside';
 if(!inValidity(date,rule.validity))state='outside_published_dates';
 const age=rule.reviewed_at?dayDiff(rule.reviewed_at,asOf):Infinity;
 const operational=['dated_programme','operator_program','operator_pattern','regional_operator_reference'].includes(rule.dimension);
 const ttl=operational?90:730;
 if(age<0||age>ttl||rule.evidence_conflict)state='needs_recheck';
 return {...rule,state,review_age_days:age,live:false};
}
export function restrictionsAt(model,record,date,asOf=model.asOf||model.researchDate){
 localDate(date);localDate(asOf);
 return (model.restrictionsById.get(record.id)||[]).map(rule=>{
  let active=true;
  if(rule.activity_scope?.length&&!rule.activity_scope.includes(record.primary_activity)&&!record.tags.some(t=>rule.activity_scope.includes(t)))active=false;
  if(!inValidity(date,{from:rule.valid_from,to:rule.valid_to}))active=false;
  if(rule.date_window&&!withinWindow(date,rule.date_window))active=false;
  if(rule.months?.length&&!rule.months.includes(Number(date.slice(5,7))))active=false;
  if(rule.weekdays?.length&&!rule.weekdays.includes(new Date(date+'T12:00:00Z').getUTCDay()))active=false;
  const age=rule.reviewed_at?dayDiff(rule.reviewed_at,asOf):Infinity;
  const futureAnnual=rule.annual_review_required&&date.slice(0,4)>asOf.slice(0,4);
  const stale=age<0||age>90||futureAnnual;
  return {...rule,active,effective_effect:!active?'inactive':stale?'needs_confirmation':rule.effect,stale};
 });
}
const WILDLIFE=new Set(['whale_watch','marine_wildlife','wildlife_boat','marine_birds','shore_wildlife','shark_watch','manta_watch','turtle_watch']);
export function seasonAt(model,record,date,{asOf=model.asOf||model.researchDate,species='',accessFacet=''}={}){
 localDate(date);
 const layers=(model.seasonsById.get(record.id)||[]).map(x=>layerStatus(x,date,asOf));
 const seasonal=layers.filter(x=>x.dimension!=='access_equipment');
 let relevant=seasonal;
 if(species)relevant=seasonal.filter(x=>hasSpecies(x,species));
 else if(WILDLIFE.has(record.primary_activity)){
  const wildlife=seasonal.filter(x=>['species_presence','wildlife','natural_phenomenon'].includes(x.dimension));if(wildlife.length)relevant=wildlife;
 }
 if(accessFacet&&layers.some(x=>x.dimension==='access_equipment'))relevant=[...relevant,...layers.filter(x=>x.dimension==='access_equipment')];
 const matching=relevant.filter(x=>x.state==='match');
 const restriction=restrictionsAt(model,record,date,asOf).filter(x=>x.active);
 const blocked=restriction.some(x=>x.effective_effect==='deny');
 const conditional=restriction.some(x=>['needs_confirmation','requires_confirmation'].includes(x.effective_effect));
 const waterDenied=restriction.some(x=>x.effective_effect==='deny_water');
 const partial=restriction.some(x=>x.effective_effect==='partial');
 let status='unknown',tier=0;
 if(matching.length){const finite=matching.some(x=>x.months.length<12);status=finite?'typical_window':'year_round_reference';tier=finite?3:2;}
 else if(relevant.some(x=>['outside','outside_published_dates'].includes(x.state))){status='outside_listed_window';tier=-1;}
 else if(relevant.some(x=>x.state==='needs_recheck'))status='needs_recheck';
 if(blocked){status='restriction_applies';tier=-3;}else if(conditional){status='access_needs_confirmation';tier=-2;}
 return {status,tier,layers,matching,restrictions:restriction,blocked,conditional,waterDenied,partial,live:false,
  text:({typical_window:'In a listed seasonal window',year_round_reference:record.primary_activity==='aquarium'?'All-month venue format; check opening':'Year-round reference',unknown:'Season still needs research',outside_listed_window:'Outside the listed window',needs_recheck:'Source needs another check',restriction_applies:'Published restriction applies',access_needs_confirmation:'Access needs confirmation'})[status]};
}
export function fitAt(record,{family=false,age=null,accessFacet='',date=null}={}){
 const checks=[];let level='not_requested';let match=true;
 if(family){
  const f=record.fit_v3.family;let state=f.status;
  if(age!==null){if(!Number.isFinite(age)||age<0||age>120)throw new RangeError('Invalid age.');if(f.min_age!==null&&age<f.min_age)state='no';}
  checks.push({facet:'family',...f,status:state});
 }
 if(accessFacet){const f=record.fit_v3.accessibility[accessFacet];if(!f)throw new TypeError('Unknown access facet.');let state=f.status;
  if(date&&f.months&&!f.months.includes(Number(localDate(date).slice(5,7))))state='outside_equipment_window';
  checks.push({facet:accessFacet,...f,status:state});
 }
 if(checks.length){
  if(checks.some(x=>['no','outside_equipment_window'].includes(x.status))){level='does_not_match';match=false;}
  else if(checks.some(x=>x.status==='unknown')){level='unknown';match=false;}
  else {level=checks.some(x=>x.status==='conditional')?'conditional':'documented';}
 }
 return {level,match,checks,not_a_personal_clearance:true};
}
export function filterRecord(model,r,f={}){
 const editions=model.catalogue.editorial_editions_v4||{};
 if(f.edition==='new_v5'&&r.record_origin!=='new_v5_curated_research')return false;
 if(f.edition==='water200'&&!editions.water_top_200_ids?.includes(r.id))return false;
 if(f.edition==='aquarium100'&&!editions.aquarium_top_100_ids?.includes(r.id))return false;
 if(f.edition==='mall'&&!editions.mall_aquarium_ids?.includes(r.id))return false;
 if(f.mallOnly&&r.venue_v4?.complex_relation!=='inside_mall')return false;
 if(f.country&&!r.country_codes.includes(f.country))return false;
 if(f.continent&&!r.continent_codes.includes(f.continent))return false;
 if(f.activity&&f.activity!=='all'&&r.primary_activity!==f.activity)return false;
 const scopes=expandedScopes(model,r);
 if(f.scope&&!scopes.has(f.scope))return false;
 if(f.query){
  const q=normalize(f.query);const resolved=resolveScope(model,q);if(resolved.length){if(!resolved.some(x=>scopes.has(x)))return false;}
  else{const scopeText=[...scopes].flatMap(s=>[model.scopes.get(s).label,...model.scopes.get(s).aliases]);
   const hay=normalize([r.name,r.area,r.summary,r.venue_v4?.complex_name||'',...(r.guide_v4?.key_attractions||[]),...(r.aliases_v4||[]),...r.country_codes.map(c=>model.countryById.get(c)?.name||c),...(r.tags||[]),...scopeText].join(' '));
   if(!q.split(/\s+/).every(w=>hay.includes(w)))return false;
  }
 }
 return true;
}
export function rankExperiences(model,filters={}){
 const date=localDate(filters.date||model.researchDate),mode=filters.mode||'all_time';
 const rows=[];
 for(const r of model.records){
  if(!filterRecord(model,r,filters))continue;
  if(!r.v3_rank_eligibility.all_time&&!(filters.edition==='new_v5'&&mode==='all_time'))continue;
  const season=seasonAt(model,r,date,{asOf:filters.asOf||model.asOf||model.researchDate,species:filters.species||'',accessFacet:filters.accessFacet||''});
  const fit=fitAt(r,{family:filters.family,age:filters.age??null,accessFacet:filters.accessFacet||'',date});
  if(filters.accessFacet&&season.restrictions.some(x=>x.effective_effect==='partial'&&String(x.scope_note||x.subarea).includes('wheelchair'))){fit.match=false;fit.level='does_not_match';fit.checks.push({facet:filters.accessFacet,status:'no',conditions:'Current works affect the relevant wheelchair equipment.'});}
  if((filters.family||filters.accessFacet)&&!fit.match&&!(filters.includeUnknownFit&&fit.level==='unknown'))continue;
  if(mode==='for_date'&&(season.tier<1||season.blocked||season.conditional||season.waterDenied))continue;
  if(filters.species&&!season.layers.some(s=>hasSpecies(s,filters.species)))continue;
  rows.push({record:r,score:r.assessment_v3.score,season,fit});
 }
 const aquariumOrder=filters.activity==='aquarium'||['aquarium100','mall'].includes(filters.edition)||filters.mallOnly;
 rows.sort((a,b)=>{
  if(mode==='for_date'&&a.season.tier!==b.season.tier)return b.season.tier-a.season.tier;
  if((filters.family||filters.accessFacet)&&a.fit.match!==b.fit.match)return Number(b.fit.match)-Number(a.fit.match);
  if(aquariumOrder)return (a.record.ranking_v4?.aquarium_editorial_rank??9999)-(b.record.ranking_v4?.aquarium_editorial_rank??9999);
  return b.score-a.score||a.record.id.localeCompare(b.record.id,'en');
 });
 let prev=null,sharedRank=0;
 rows.forEach((x,i)=>{const key=[mode==='for_date'?x.season.tier:0,x.score,x.fit.match].join(':');if(key!==prev)sharedRank=i+1;prev=key;x.position=i+1;x.tiedRank=sharedRank;x.poolSize=rows.length;x.aquariumRank=x.record.ranking_v4?.aquarium_editorial_rank??null;if(aquariumOrder){x.tiedRank=i+1;x.rankKind=x.aquariumRank?'ordered_editorial_selection':'discovery_directory_not_world_rank';}else x.rankKind='coarse_score_with_ties';});
 return rows;
}
export function globalHighlights(model,limit=200){const ids=model.catalogue.editorial_editions_v4?.water_top_200_ids;const rows=rankExperiences(model,{mode:'all_time',...(ids?{edition:'water200'}:{})});return rows.slice(0,limit);}
export function monthStrip(model,record,year=Number(model.researchDate.slice(0,4))){return MONTHS.map((name,i)=>{const date=`${year}-${String(i+1).padStart(2,'0')}-15`;return {name,month:i+1,...seasonAt(model,record,date)};});}
export function futureWindows(model,ids,from,{days=180,limit=12}={}){
 localDate(from);const list=[];
 for(const id of ids){const r=model.byId.get(id);if(!r)continue;let before=seasonAt(model,r,from).tier;
  for(let i=1;i<=days;i++){const date=new Date(Date.parse(from+'T12:00Z')+i*86400000).toISOString().slice(0,10);const v=seasonAt(model,r,date);if(v.tier>=1&&before<1){list.push({id,name:r.name,date,label:'A published seasonal window begins',not_live:true});break;}before=v.tier;}
 }
 return list.sort((a,b)=>a.date.localeCompare(b.date)).slice(0,limit);
}
export function semanticDifference(before,after){
 const pick=r=>JSON.stringify({name:r.name,assessment:r.assessment_v3?.components,season:r.season_profile_v3?.evidence_signature||r.season_profile_v3?.layer_ids,fit:r.fit_v3,source_ids:r.source_ids});
 const old=new Map(before.map(r=>[r.id,r]));return after.filter(r=>old.has(r.id)&&pick(old.get(r.id))!==pick(r)).map(r=>({id:r.id,kind:'content_changed'}));
}
export function pricesFor(model,r,date){
 return (model.offersById.get(r.id)||[]).map(o=>{
  const amount=Number.isFinite(o.amount)&&o.amount>=0&&/^[A-Z]{3}$/.test(o.currency||'')?o.amount:null;
  const validity=inValidity(date,{from:o.valid_from,to:o.valid_to});const age=o.reviewed_at?dayDiff(o.reviewed_at,model.asOf||model.researchDate):Infinity;
  return {...o,display_amount:amount,valid_reference:validity&&o.price_type!=='held'&&age>=0&&age<=90,all_in:false};
 });
}
export function tentativeCalendar(record,date){
 localDate(date);const next=new Date(Date.parse(date+'T12:00Z')+86400000).toISOString().slice(0,10);
 const esc=s=>String(s).replace(/\\/g,'\\\\').replace(/\r\n|\r|\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');
 const lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//DipMapper//Water Passport//EN','BEGIN:VEVENT',`UID:${record.id}-${date}@dipmapper.com`,`DTSTAMP:${new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d+Z$/,'Z')}`,`DTSTART;VALUE=DATE:${date.replaceAll('-','')}`,`DTEND;VALUE=DATE:${next.replaceAll('-','')}`,`SUMMARY:${esc('Idea: '+record.name)}`,'STATUS:TENTATIVE','TRANSP:TRANSPARENT',`DESCRIPTION:${esc('Unbooked planning idea. Confirm access, weather, requirements, price and exact departure. No travel time or opening has been established.')}`,`LOCATION:${esc(record.area)}`,'END:VEVENT','END:VCALENDAR'];
 return lines.map(line=>{let a='',n=0,out=[];for(const c of line){const bytes=new TextEncoder().encode(c).length;if(n+bytes>75){out.push(a);a=' ';n=1;}a+=c;n+=bytes;}out.push(a);return out.join('\r\n');}).join('\r\n')+'\r\n';
}
