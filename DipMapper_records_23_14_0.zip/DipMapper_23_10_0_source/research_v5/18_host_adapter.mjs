/** Additive host boundary. Never sort, remove or invent production-map places. */
import {safeURL,localDate,seasonAt,fitAt} from './06_ranking.mjs';
export function decorateNeutralResults(results,verifiedJoins,highlights){
 const highlight=new Map(highlights.map(x=>[x.record?.id||x.id,{position:x.position??null,score:x.score??null}]));
 const joins=new Map();
 for(const j of verifiedJoins||[]){
  if(j.status!=='verified_identity_join'||!j.hostPlaceId||!j.experienceId||!j.reviewedBy)continue;
  if(!joins.has(j.hostPlaceId))joins.set(j.hostPlaceId,[]);joins.get(j.hostPlaceId).push(j.experienceId);
 }
 return results.map(r=>{const ids=(joins.get(r.id)||[]).filter(id=>highlight.has(id));return {...r,dipmapperHighlight:ids.length?{symbol:'star',label:'DipMapper editorial selection',experienceIds:ids,notUserRating:true,doesNotChangeOrder:true}:null};});
}
export function mapRequest(record,verifiedJoins=[]){
 const j=verifiedJoins.find(x=>x.experienceId===record.id&&x.status==='verified_identity_join'&&x.reviewedBy&&x.hostPlaceId);
 return j?{kind:'existing_place',experienceId:record.id,existingPlaceId:j.hostPlaceId,navigationAllowed:false}:{kind:'area_context',experienceId:record.id,areaLabel:record.area,scopeIds:record.geo_v3.scope_ids,navigationAllowed:false,coordinates:null};
}
export function forecastState(forecast,{now=new Date().toISOString(),date,scopeId,maxAgeHours=6}={}){
 localDate(date);
 const missing=reason=>({state:'unavailable',reason,live:false,canAssertSafety:false});
 if(!forecast)return missing('No current forecast has been loaded.');
 if(!safeURL(forecast.sourceUrl)||!forecast.provider||!forecast.licenceUrl||!safeURL(forecast.licenceUrl)||forecast.commercialUsePermitted!==true)return missing('Provider provenance or commercial-use permission is missing.');
 const current=Date.parse(now),issued=Date.parse(forecast.issuedAt);
 if(!Number.isFinite(current)||!Number.isFinite(issued)||issued>current+300000||(current-issued)>maxAgeHours*3600000)return missing('Forecast is stale or its issue time is invalid.');
 if(!forecast.destinationTimezone||!forecast.scopeIds?.includes(scopeId))return missing('Forecast geography or destination time zone does not match.');
 if(!forecast.days?.[date])return missing('No forecast for the selected destination-local day.');
 try{new Intl.DateTimeFormat('en',{timeZone:forecast.destinationTimezone}).format(new Date());}catch{return missing('Invalid destination time zone.');}
 const row=forecast.days[date];if(!row.validFrom||!row.validTo||Date.parse(row.validFrom)>Date.parse(row.validTo)||!Number.isFinite(Date.parse(row.validFrom))||!Number.isFinite(Date.parse(row.validTo)))return missing('Forecast validity is incomplete.');
 const localDay=t=>new Intl.DateTimeFormat('en-CA',{timeZone:forecast.destinationTimezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(t));
 if(date<localDay(row.validFrom)||date>localDay(row.validTo))return missing('Forecast validity does not cover the selected local day.');
 const fields={};for(const [k,v] of Object.entries(row.values||{})){if(!v||!Number.isFinite(v.value)||typeof v.unit!=='string')continue;fields[k]={value:v.value,unit:v.unit};}
 if(!Object.keys(fields).length)return missing('No usable values with units.');
 return {state:'fresh_forecast',provider:forecast.provider,issuedAt:forecast.issuedAt,timezone:forecast.destinationTimezone,values:fields,alerts:row.alerts||[],sourceUrl:forecast.sourceUrl,licenceUrl:forecast.licenceUrl,live:false,canAssertSafety:false};
}
export function evaluateDayIdea(model,record,{date,asOf=model.asOf||model.researchDate,fit={},forecast=null,scopeId='',now,preference='any'}={}){
 const season=seasonAt(model,record,localDate(date),{asOf,accessFacet:fit.accessFacet||''});
 const personal=fitAt(record,{...fit,date});const weather=forecastState(forecast,{date,scopeId,now});
 const blockers=[];
 if(season.tier<1)blockers.push('No current, matching published seasonal window for this day.');
 if(fit.accessFacet&&season.restrictions.some(x=>x.effective_effect==='partial'&&String(x.scope_note||x.subarea).includes('wheelchair')))blockers.push('Current works affect the required wheelchair equipment.');
 if(season.blocked||season.waterDenied)blockers.push('A published restriction affects this activity.');
 if(season.conditional)blockers.push('Access information needs current confirmation.');
 if((fit.family||fit.accessFacet)&&!personal.match)blockers.push(personal.level==='unknown'?'Required fit information is unknown.':'A stated requirement does not match.');
 if(weather.state==='fresh_forecast'&&weather.alerts.some(a=>a.scopeIds?.includes(scopeId)&&a.active===true&&a.effect==='avoid_water'))blockers.push('A supplied authority alert advises against the relevant water activity.');
 const indoorEvidence=(model.seasonsById.get(record.id)||[]).some(s=>s.dimension==='facility_indoor')||['park-erding','park-suntago','park-tropical-islands'].includes(record.id);
 if(preference==='indoor'&&!indoorEvidence)blockers.push('No documented indoor alternative for this record.');
 return {id:record.id,status:blockers.length?'not_a_day_candidate':'idea_to_verify',blockers,season,fit:personal,weather,indoorEvidence,scheduled:false,checks:['Confirm operating hours and any reservation.','Confirm the exact starting point and travel time.','Check current authority warnings, water conditions and requirements.'],notPersonalSafetyAdvice:true};
}
export function assembleVerifiedDay(ideas,{date,transfers=[],startMinutes=540,endMinutes=1080}={}){
 localDate(date);if(!Number.isInteger(startMinutes)||!Number.isInteger(endMinutes)||startMinutes<0||endMinutes>1440||startMinutes>=endMinutes)throw new RangeError('Invalid day limits.');
 if(ideas.length>8)throw new RangeError('Too many stops.');let cursor=startMinutes;const output=[];
 for(let i=0;i<ideas.length;i++){
  const x=ideas[i];if(!x.id||x.status!=='operator_confirmed'||x.date!==date||!safeURL(x.sourceUrl)||!Number.isFinite(x.durationMinutes)||x.durationMinutes<=0||!Number.isInteger(x.openMinutes)||!Number.isInteger(x.closeMinutes)||x.openMinutes>=x.closeMinutes)return {status:'unscheduled',reason:'Each stop needs confirmed date, hours, duration and source.',ideas:ideas.map(x=>x.id)};
  if(i){const t=transfers.find(t=>t.from===ideas[i-1].id&&t.to===x.id&&t.date===date);if(!t||t.status!=='verified'||!Number.isFinite(t.minutes)||t.minutes<0)return {status:'unscheduled',reason:'Travel time is unverified.',ideas:ideas.map(x=>x.id)};cursor+=t.minutes;}
  cursor=Math.max(cursor,x.openMinutes);if(cursor+x.durationMinutes>Math.min(endMinutes,x.closeMinutes))return {status:'does_not_fit',reason:'The verified stops do not fit this day.',ideas:ideas.map(x=>x.id)};
  output.push({id:x.id,startMinutes:cursor,endMinutes:cursor+x.durationMinutes});cursor+=x.durationMinutes;
 }
 return {status:'provisional_schedule',date,stops:output,bookingMade:false,weatherClearance:false};
}
