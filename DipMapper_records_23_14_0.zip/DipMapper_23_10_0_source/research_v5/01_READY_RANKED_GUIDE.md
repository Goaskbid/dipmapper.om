# DipMapper: ready ranked discovery guide

Research edition: 2026-11-13

This file contains the written ranking cards, not a content brief. The Top 100 aquariums is an authored editorial order. The Top 200 water selection retains the earlier edition and coarse score ties. There are 605 complete-format catalogue cards in the JSON, including 161 aquarium profiles. This edition adds 147 unique records and refreshes one existing venue. The 4,580 target is not complete. Some practical fields remain explicitly unknown; a contact route is supplied instead of an invented price or telephone.

The aquarium order weighs distinctive exhibits, regional interpretation, visit depth and itinerary usefulness qualitatively. Close positions are judgments, not measured gaps. No first-hand visit, independent welfare inspection or visitor-rating average is claimed. Mall lists retain the global aquarium order, so their global ranks do not restart at one.

An all-month aquarium visit-format label is an inference from the indoor or mixed setting, not a promise of 365-day opening. Source descriptions, conditions, currencies and partial closures remain part of the record. Existing water research is retained and clearly marked, not relabelled as newly verified.

## Editions at a glance

| Edition | Actual records |
| --- | ---: |
| Top water experiences | 200 |
| Top public aquariums | 100 |
| Aquarium discovery directory | 161 |
| Inside shopping malls | 28 |

## Top 100 public aquariums

### Global aquarium #1: Monterey Bay Aquarium

**Location:** Cannery Row, Monterey, California, United States.

A coastal aquarium that connects a living kelp forest and open-ocean viewing with the marine environments of California.

**Why go:** The connection between the living kelp display and the adjacent Pacific gives the exhibits a strong sense of place, rather than a generic collection.

**Key attractions:** Living kelp forest; Open Sea gallery; California coastal interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.montereybayaquarium.org/visit/exhibits).

**Plan around:** Book the official dated admission. Do not assume every temporary gallery or programme is included or operating.

**Published price reference:** USD 65 / adult aged 18-69. published reference. Adult admission reference shown in the publisher search excerpt; the opened page did not expose the numeric fare. Online ticket purchase is required; confirm the chosen date. Not a live or all-in quote. [Publisher](https://www.montereybayaquarium.org/visit/admission-tickets).

**Tickets/access:** [Official ticket / operator information](https://www.montereybayaquarium.org/visit/admission-tickets).

**Contact:** [Official visitor/contact route](https://www.montereybayaquarium.org/visit/exhibits).

**Evidence:** [Monterey Bay Aquarium / official publisher](https://www.montereybayaquarium.org/visit/exhibits); [Monterey Bay Aquarium](https://www.montereybayaquarium.org/visit/exhibits/exhibit-sensory-guides); [Monterey Bay Aquarium](https://www.montereybayaquarium.org/visit/accessibility-inclusion); [Monterey Bay Aquarium / official publisher](https://www.montereybayaquarium.org/visit/admission-tickets). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #2: Oceanario de Lisboa

**Location:** Parque das Nacoes, Lisbon, Portugal.

A central ocean aquarium links four ocean habitats, giving the visit a clear theme of connected seas rather than isolated tanks.

**Why go:** A coherent ocean narrative and substantial permanent route make this a strong aquarium-led city visit, rather than a brief shopping stop.

**Key attractions:** Central ocean aquarium; Four ocean habitats; Temporary exhibitions.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://oceanario.pt/en/exhibitions/).

**Plan around:** Read the current exhibition and ticket descriptions; special experiences have their own terms.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tickets.oceanario.pt/en/1548-online/9576-visita-ao-oceanario-de-lisboa).

**Contact:** [Official visitor/contact route](https://oceanario.pt/en/contact-us/). Email: info@oceanario.pt.

**Evidence:** [Oceanario de Lisboa / official publisher](https://oceanario.pt/en/exhibitions/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #3: Okinawa Churaumi Aquarium

**Location:** Ocean Expo Park, Motobu, Okinawa, Japan.

The Kuroshio Sea display anchors a visit that also explores Okinawan coral, deep-sea environments and shark research.

**Why go:** The Kuroshio theme links a large pelagic display with the marine environment around Okinawa, giving the visit more depth than a single tank.

**Key attractions:** Kuroshio Sea tank; Coral and deep-sea displays; Shark Research Lab.

**Venue format:** mixed; within park; Ocean Expo Park.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://churaumi.okinawa/en/area/the-kuroshio/).

**Plan around:** Allow for travel to northern Okinawa. Animals and individual viewing areas can be unavailable.

**Published price reference:** JPY 2180 / adult general admission. published reference. General adult tariff. Group tickets, school categories and certificate-based concessions are distinct. Children under six are listed free; confirm eligibility and current tariffs. Not a live or all-in quote. [Publisher](https://churaumi.okinawa/en/guide/info/).

**Tickets/access:** [Official ticket / operator information](https://churaumi.okinawa/en/guide/info/).

**Contact:** [Official visitor/contact route](https://churaumi.okinawa/en/area/the-kuroshio/). Telephone: +81 980 48 3748.

**Evidence:** [Okinawa Churaumi Aquarium / official publisher](https://churaumi.okinawa/en/area/the-kuroshio/); [Okinawa Churaumi Aquarium / official publisher](https://churaumi.okinawa/en/guide/info/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #4: Georgia Aquarium

**Location:** Downtown Atlanta, Georgia, United States.

An ocean-scale viewing experience built around Ocean Voyager, with whale sharks, manta rays and an underwater tunnel.

**Why go:** The scale of the pelagic exhibit provides a viewing experience that is difficult to reproduce in a smaller urban aquarium.

**Key attractions:** Ocean Voyager viewing window; Whale sharks and manta rays; Underwater tunnel.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.georgiaaquarium.org/gallery/ocean-voyager/).

**Plan around:** Marine-mammal presentations and animal experiences have separate reservation and welfare considerations; admission does not guarantee presentation seating.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.georgiaaquarium.org/tickets/).

**Contact:** [Official visitor/contact route](https://www.georgiaaquarium.org/frequently-asked-questions/). Telephone: +14045814000. Email: hospitality@georgiaaquarium.org.

**Evidence:** [Georgia Aquarium / official publisher](https://www.georgiaaquarium.org/gallery/ocean-voyager/); [Georgia Aquarium](https://www.georgiaaquarium.org/accessibility-at-georgia-aquarium/); [Georgia Aquarium](https://www.georgiaaquarium.org/frequently-asked-questions/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #5: Osaka Aquarium Kaiyukan

**Location:** Tempozan, Osaka, Japan.

A Pacific-focused route builds around a large central aquarium in Osaka's Tempozan waterfront district.

**Why go:** A multi-level Pacific journey makes this a substantial destination aquarium and a natural companion to the harbour district.

**Key attractions:** Pacific-focused aquarium route; Large central viewing tank; Tempozan waterfront setting.

**Venue format:** indoor; mall adjacent; Tempozan Marketplace nearby.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.japan.travel/en/spot/1113/).

**Plan around:** Use the aquarium ticket link, not lookalike sellers. Tempozan Marketplace is nearby; the aquarium is not classified as inside that mall.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.kaiyukan.com/info/ticket/kaiyukan/).

**Contact:** [Official visitor/contact route](https://www.kaiyukan.com/).

**Evidence:** [Osaka Aquarium Kaiyukan / official publisher](https://www.japan.travel/en/spot/1113/); [Osaka tourism](https://osaka-info.jp/en/special/dc/event/detail382/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #6: Nausicaa

**Location:** Boulogne-sur-Mer, France.

A high-seas gallery inspired by Malpelo combines a large ocean window with interpretation of the wider marine environment.

**Why go:** Its high-seas interpretation turns a dramatic viewing window into a fuller explanation of pelagic habitats.

**Key attractions:** Malpelo-inspired high-seas gallery; Large ocean viewing window; Ocean interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.nausicaa.fr/en/my-visit/tour-routes/journey-high-seas).

**Plan around:** Admission products and temporary events vary. Check the current visit plan rather than relying on expired family promotions.

**Published price reference:** EUR 30 / adult off-season day ticket, publisher label aged 12+. published reference. Off-season adult reference. The same page shows EUR 31.50 peak-season adult admission. Do not turn the off-season price into an all-date quote. Child age wording overlaps at age 12; use the checkout for that boundary. Not a live or all-in quote. [Publisher](https://www.nausicaa.fr/en/my-visit/rates).

**Tickets/access:** [Official ticket / operator information](https://www.nausicaa.fr/en/my-visit/rates).

**Contact:** [Official visitor/contact route](https://www.nausicaa.fr/en/my-visit/tour-routes/journey-high-seas).

**Evidence:** [Nausicaa / official publisher](https://www.nausicaa.fr/en/my-visit/tour-routes/journey-high-seas); [Nausicaa / official publisher](https://www.nausicaa.fr/en/my-visit/rates). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #7: Oceanografic Valencia

**Location:** City of Arts and Sciences, Valencia, Spain.

An extensive aquatic attraction linking Mediterranean, polar and ocean environments through a mixed indoor and outdoor visit.

**Why go:** The range of aquatic environments supports a longer visit with clear comparisons between climates and habitats.

**Key attractions:** Mediterranean habitats; Arctic and Antarctic zones; Oceans tunnel.

**Venue format:** mixed; within park; City of Arts and Sciences.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.oceanografic.org/en/).

**Plan around:** This is a mixed indoor and outdoor complex, not an entirely sheltered rainy-day route. Captive marine-mammal exhibits and presentations are part of the offering.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://entradas.oceanografic.org/buy-oceanografic-tickets).

**Contact:** [Official visitor/contact route](https://www.oceanografic.org/en/). Telephone: +34960470647.

**Evidence:** [Oceanografic Valencia / official publisher](https://www.oceanografic.org/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #8: Singapore Oceanarium

**Location:** Resorts World Sentosa, Singapore, Singapore.

An oceanarium on Sentosa that connects ocean habitats, coastlines and the interpretation of marine environments.

**Why go:** The expanded oceanarium offers a destination-scale aquatic visit within a broader island day, with its own identity distinct from the former S.E.A. Aquarium.

**Key attractions:** Ocean and coastline interpretation; Large ocean habitats; Sentosa visitor setting.

**Venue format:** indoor; resort; Resorts World Sentosa.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.singaporeoceanarium.com/en/visit.html).

**Plan around:** Use the Singapore Oceanarium name and current ticket product. Do not duplicate it as a separate S.E.A. Aquarium listing.

**Published price reference:** SGD 55 / adult 13-59 admission. published reference. Published visitor-page reference. Child 4-12 and senior 60+ SGD 43. The retrieved page can be cached; verify the selected date and product. Not a live or all-in quote. [Publisher](https://www.singaporeoceanarium.com/en/ticketing.html).

**Tickets/access:** [Official ticket / operator information](https://www.singaporeoceanarium.com/en/ticketing.html).

**Contact:** [Official visitor/contact route](https://www.singaporeoceanarium.com/en/visit.html).

**Evidence:** [Singapore Oceanarium / official publisher](https://www.singaporeoceanarium.com/en/visit.html); [Singapore Oceanarium](https://www.singaporeoceanarium.com/en/visit.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #9: Acquario di Genova

**Location:** Porto Antico, Genoa, Italy.

Aquatic habitat galleries occupy Genoa's historic harbour, placing the aquarium within a broader waterfront visit.

**Why go:** The aquarium adds substantial marine interpretation to a harbour visit and works as a destination in its own right.

**Key attractions:** Aquatic habitat galleries; Blue Planet introduction; Historic harbour setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.acquariodigenova.it/en/genova-s-aquarium).

**Plan around:** One-use admission and combination products require attention. The separate children's museum is not automatically part of an aquarium-only ticket.

**Published price reference:** EUR 26 / adult fixed-date ticket starting price. from price. Starting online fixed-date fare, not the EUR 34 ticket-office reference or EUR 38 Open Flexi product. Combined AcquarioVillage tickets are separate. Check the selected date and age category. Not a live or all-in quote. [Publisher](https://www.acquariodigenova.it/en/tickets-and-prices).

**Tickets/access:** [Official ticket / operator information](https://www.acquariodigenova.it/en/tickets-and-prices).

**Contact:** [Official visitor/contact route](https://www.acquariodigenova.it/en/contacts).

**Evidence:** [Acquario di Genova / official publisher](https://www.acquariodigenova.it/en/genova-s-aquarium); [Acquario di Genova / official publisher](https://www.acquariodigenova.it/en/tickets-and-prices). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #10: National Aquarium

**Location:** Inner Harbor, Baltimore, Maryland, United States.

Reef, Australian and rainforest environments give this harbour aquarium a route that connects aquatic life with surrounding habitats.

**Why go:** The range from coastal habitats to rainforest environments makes this more than a single-tank attraction and gives families several distinct subjects to explore.

**Key attractions:** Atlantic Coral Reef; Australia: Wild Extremes; Rainforest interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://aqua.org/visit).

**Plan around:** Strollers are not permitted through the exhibit route. Check carrying options and access arrangements before arrival.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://aqua.org/visit).

**Contact:** [Official visitor/contact route](https://aqua.org/visit).

**Evidence:** [National Aquarium / official publisher](https://aqua.org/visit). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #11: Tennessee Aquarium

**Location:** Chattanooga riverfront, Tennessee, United States.

Separate River Journey and Ocean Journey buildings make freshwater ecosystems a central part of the visit, rather than an introduction to marine tanks.

**Why go:** Its freshwater story is a useful counterweight to ocean-only aquariums, following rivers before introducing marine environments.

**Key attractions:** River Journey; Ocean Journey; Freshwater and turtle habitats.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://tnaqua.org/explore/).

**Plan around:** Plan for two buildings. IMAX and other add-ons are separate products unless the selected ticket states otherwise.

**Published price reference:** USD 39.95 / adult admission. published reference. Published adult reference; River Journey and Ocean Journey included. Youth 4-17 USD 29.95; ages 0-3 free. Confirm the final dated quote. Not a live or all-in quote. [Publisher](https://tnaqua.org/visit/).

**Tickets/access:** [Official ticket / operator information](https://tnaqua.org/visit/).

**Contact:** [Official visitor/contact route](https://tnaqua.org/explore/).

**Evidence:** [Tennessee Aquarium / official publisher](https://tnaqua.org/explore/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #12: Shedd Aquarium

**Location:** Museum Campus, Chicago, Illinois, United States.

Great Lakes, reef, Amazon and Pacific Northwest environments connect Chicago's lakeside setting with a wider aquatic journey.

**Why go:** The combination of local Great Lakes ecology and contrasting world habitats provides a strong educational reason to choose it.

**Key attractions:** Great Lakes habitats; Wild Reef; Amazon and Pacific Northwest exhibits.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.sheddaquarium.org/exhibits/).

**Plan around:** Stingray Touch is seasonal. Presentations, timed admissions and selected quiet sessions require their own schedule checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.sheddaquarium.org/plan-a-visit).

**Contact:** [Official visitor/contact route](https://www.sheddaquarium.org/plan-a-visit/accessibility).

**Evidence:** [Shedd Aquarium / official publisher](https://www.sheddaquarium.org/exhibits/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #13: Aquarium of the Pacific

**Location:** Long Beach, California, United States.

Southern California, Northern Pacific and tropical environments provide three distinct ways to explore the Pacific Ocean.

**Why go:** The three-part Pacific structure gives the visit geographic coherence and supports a useful comparison with nearby coastal outings.

**Key attractions:** Southern California waters; Northern Pacific habitats; Tropical Pacific displays.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquariumofpacific.org/exhibits).

**Plan around:** Whale-watching combinations are different ticket products; aquarium admission alone is not a boat booking.

**Published price reference:** USD 49.95 / adult admission. published reference. Published adult reference. Child 3-11 USD 34.95; senior 62+ USD 46.95. Parking is a separate published charge. Not a live or all-in quote. [Publisher](https://www.aquariumofpacific.org/visit).

**Tickets/access:** [Official ticket / operator information](https://www.aquariumofpacific.org/visit).

**Contact:** [Official visitor/contact route](https://www.aquariumofpacific.org/exhibits). Telephone: +15625903100.

**Evidence:** [Aquarium of the Pacific / official publisher](https://www.aquariumofpacific.org/exhibits). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #14: Aquamarine Fukushima

**Location:** Onahama, Iwaki, Fukushima, Japan.

The meeting of ocean currents provides the theme for a regional marine-science aquarium with a triangular viewing tunnel.

**Why go:** The meeting of the Kuroshio and Oyashio currents supplies a genuinely place-specific story and a strong reason for the aquarium's design.

**Key attractions:** Shiome meeting-of-currents tank; Triangular viewing tunnel; Regional marine-science interpretation.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.aquamarine.or.jp/).

**Plan around:** Outdoor experiential areas, food programmes and research displays have different schedules. A visit does not guarantee a particular workshop.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aquamarine.or.jp/).

**Contact:** [Official visitor/contact route](https://www.aquamarine.or.jp/). Email: amf@aquamarine.or.jp.

**Evidence:** [Aquamarine Fukushima / official publisher](https://www.aquamarine.or.jp/); [Government of Japan](https://www.gov-online.go.jp/hlj/en/september_2024/september_2024-02.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #15: Two Oceans Aquarium

**Location:** V&A Waterfront, Cape Town, South Africa.

Kelp-forest and Southern African marine displays make the Cape's own waters a central attraction, alongside shark viewing.

**Why go:** Local marine ecosystems, especially kelp, give this a clear Cape Town identity rather than an interchangeable global aquarium format.

**Key attractions:** Kelp forest; Southern African marine habitats; Shark viewing.

**Venue format:** indoor; mall adjacent; V&A Waterfront precinct.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquarium.co.za/exhibits).

**Plan around:** Animal encounters and diving are separate activities with their own eligibility rules. Waterfront proximity does not mean the aquarium is inside a shopping mall.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aquarium.co.za/).

**Contact:** [Official visitor/contact route](https://www.aquarium.co.za/exhibits).

**Evidence:** [Two Oceans Aquarium / official publisher](https://www.aquarium.co.za/exhibits). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #16: Steinhart Aquarium

**Location:** California Academy of Sciences, San Francisco, United States.

A Philippine coral reef and deep-reef exhibits connect with the living rainforest of the California Academy of Sciences.

**Why go:** A substantial reef display inside a wider science museum supports a rich all-weather visit with links between marine and terrestrial ecosystems.

**Key attractions:** Philippine Coral Reef; Deep-reef interpretation; Aquatic connection to a living rainforest.

**Venue format:** indoor; science centre; California Academy of Sciences.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.calacademy.org/exhibits/steinhart-aquarium).

**Plan around:** The ticket is for the California Academy of Sciences, not an aquarium-only attraction. Planetarium and special event conditions differ.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.calacademy.org/plan-your-visit).

**Contact:** [Official visitor/contact route](https://www.calacademy.org/exhibits/steinhart-aquarium).

**Evidence:** [Steinhart Aquarium / official publisher](https://www.calacademy.org/exhibits/steinhart-aquarium). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #17: Mote Science Education Aquarium

**Location:** University Town Center Drive, Sarasota, Florida, United States.

Florida and Indo-Pacific habitats sit alongside visible science and learning laboratories in Mote's newer education aquarium.

**Why go:** A new public aquarium built around visible science gives the visit a reason beyond tank size and connects regional habitats with marine research.

**Key attractions:** Florida coastal habitats; Indo-Pacific marine galleries; Visible science and learning laboratories.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://mote.org/aquarium/).

**Plan around:** Use the new SEA visitor address, not the older City Island aquarium address. Laboratory activities and animal displays vary.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://ticketing.mote.org/).

**Contact:** [Official visitor/contact route](https://mote.org/aquarium/). Telephone: +19413886683.

**Evidence:** [Mote Science Education Aquarium / official publisher](https://mote.org/aquarium/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #18: Den Bla Planet

**Location:** Kastrup, Copenhagen, Denmark.

Nordic waters, the Amazon and a large ocean environment form a broad aquatic route near Copenhagen.

**Why go:** Contrasting Nordic, tropical freshwater and ocean habitats make a compact but varied aquatic itinerary near Copenhagen.

**Key attractions:** Ocean tank; Amazon habitats; Nordic aquatic environments.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://denblaaplanet.dk/en/welcome/).

**Published restriction:** Rainforest lift reported temporarily unavailable on the homepage; confirm access for the intended visit. [Source](https://denblaaplanet.dk/en/welcome/).

**Plan around:** The publisher currently reports the rainforest lift out of service. Do not translate general accessibility information into an unconditional step-free claim.

**Published price reference:** DKK 219 / adult online off-peak admission. published reference. Published 2026 reference; adult online peak/weekend DKK 229 and door prices differ. Check the official calendar and category. Not a live or all-in quote. [Publisher](https://denblaaplanet.dk/en/visit-us/prices-and-opening-hours/).

**Tickets/access:** [Official ticket / operator information](https://denblaaplanet.dk/en/visit-us/prices-and-opening-hours/).

**Contact:** [Official visitor/contact route](https://denblaaplanet.dk/en/about-the-blue-planet/contact-us/). Telephone: +4544222244. Email: info@denblaaplanet.dk.

**Evidence:** [Den Bla Planet / official publisher](https://denblaaplanet.dk/en/welcome/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #19: Oceanopolis

**Location:** Brest, Brittany, France.

Brittany and tropical marine habitats sit alongside an ocean laboratory and otter trail, with renovation notices affecting the current route.

**Why go:** Its combination of regional science and different climatic environments gives it a strong interpretive role beyond a conventional tank collection.

**Key attractions:** Renewed Tropical Pavilion; Brittany marine habitats; Oceanolab and otter trail.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.oceanopolis.com/en/discover-the-park/your-visit/tropical-pavilion/).

**Published restriction:** Austral Pavilion redevelopment: current publisher text targets early 2027. Other areas remain listed; opening is not guaranteed by the target date. [Source](https://www.oceanopolis.com/en/discover-the-park/your-visit/tropical-pavilion/).

**Plan around:** The Austral Pavilion is reported closed for redevelopment, with an early-2027 opening target. Do not promise the full historic polar route.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.oceanopolis.com/en/plan-your-visit/entrance-fees/).

**Contact:** [Official visitor/contact route](https://www.oceanopolis.com/en/frequently-asked-questions/). Email: contact@oceanopolis.com.

**Evidence:** [Oceanopolis / official publisher](https://www.oceanopolis.com/en/discover-the-park/your-visit/tropical-pavilion/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #20: Aquarium La Rochelle

**Location:** Quai Louis Prunier, La Rochelle, France.

A harbour-side aquarium presents marine ecosystems as a dedicated water-focused addition to a visit to La Rochelle.

**Why go:** A substantial marine visit in a working Atlantic city provides a useful indoor counterpoint to island and coastal excursions.

**Key attractions:** Marine ecosystem galleries; Harbour-side aquarium; Ocean interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquarium-larochelle.com/en/about-aquarium/about-the-aquarium/).

**Plan around:** Check the dated schedule and optional audio guide; a year-round programme does not establish today's last admission.

**Published price reference:** EUR 18.5 / adult admission. published reference. Published reference. Junior 13-17 EUR 14.50; child 3-12 EUR 12.50; under 3 free. Audio guide is separate. Not a live or all-in quote. [Publisher](https://www.aquarium-larochelle.com/en/visit/prices-and-online-purchase/).

**Tickets/access:** [Official ticket / operator information](https://www.aquarium-larochelle.com/en/visit/prices-and-online-purchase/).

**Contact:** [Official visitor/contact route](https://www.aquarium-larochelle.com/en/about-aquarium/about-the-aquarium/).

**Evidence:** [Aquarium La Rochelle / official publisher](https://www.aquarium-larochelle.com/en/about-aquarium/about-the-aquarium/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #21: Vancouver Aquarium

**Location:** Stanley Park, Vancouver, Canada.

British Columbia's coast and Pacific Canadian habitats provide the regional focus, alongside jellyfish and other aquatic galleries.

**Why go:** A regional marine focus gives meaning to a Stanley Park visit and makes it a useful companion to outdoor coastal exploration.

**Key attractions:** British Columbia coast; Pacific Canadian habitats; Jellyfish displays.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.vanaqua.org/explore/exhibits/).

**Plan around:** Admission varies by date and taxes may be additional. Temporary exhibitions and animal availability need current confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://vanaqua.org/visit/tickets/).

**Contact:** [Official visitor/contact route](https://www.vanaqua.org/explore/exhibits/).

**Evidence:** [Vancouver Aquarium / official publisher](https://www.vanaqua.org/explore/exhibits/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #22: Seattle Aquarium

**Location:** Pier 59, Pier 60 and Ocean Pavilion, Seattle, United States.

Washington waters and kelp habitats are complemented by Ocean Pavilion reef displays and coastal marine-mammal viewing.

**Why go:** The relationship between the local Salish Sea displays and the tropical Ocean Pavilion adds a meaningful habitat comparison to a waterfront day.

**Key attractions:** Washington waters and kelp habitats; Ocean Pavilion reef; Coastal marine mammals.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.seattleaquarium.org/).

**Plan around:** The visit spans several buildings with outdoor walking between them. Aquarium admission is not an admission to every special tour.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.seattleaquarium.org/).

**Contact:** [Official visitor/contact route](https://www.seattleaquarium.org/).

**Evidence:** [Seattle Aquarium / official publisher](https://www.seattleaquarium.org/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #23: New England Aquarium

**Location:** Central Wharf, Boston, Massachusetts, United States.

A central ocean tank, Gulf of Maine environments and penguin viewing bring regional and tropical marine life into one visit.

**Why go:** Regional interpretation and a memorable central tank make this a strong urban introduction before a separate harbour or whale excursion.

**Key attractions:** Giant Ocean Tank; Gulf of Maine habitats; Penguin colony.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.neaq.org/exhibits/).

**Published restriction:** Harbour seals are reported off exhibit during habitat work. Recheck the official ticket page before travelling specifically to see them. [Source](https://www.neaq.org/exhibits/).

**Plan around:** The publisher reports harbour seals temporarily off exhibit for habitat work. Whale-watch tickets are separate.

**Published price reference:** USD 39.95 / adult admission. published reference. Published adult reference; child 3-11 USD 30.95, senior 60+ USD 37.95, under 3 free. Verify selected date. Not a live or all-in quote. [Publisher](https://www.neaq.org/visit/tickets/).

**Tickets/access:** [Official ticket / operator information](https://www.neaq.org/visit/tickets/).

**Contact:** [Official visitor/contact route](https://www.neaq.org/exhibits/). Telephone: +16179735206.

**Evidence:** [New England Aquarium / official publisher](https://www.neaq.org/exhibits/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #24: Kyoto Aquarium

**Location:** Umekoji Park, Kyoto, Japan.

Local rivers and giant-salamander interpretation are joined by jellyfish displays and visible jellyfish-care work.

**Why go:** Local freshwater ecology and a carefully developed jellyfish section make this distinctive among marine-dominated aquariums.

**Key attractions:** Kyoto river and giant-salamander interpretation; Jellyfish Wonder; Visible jellyfish-care work.

**Venue format:** mixed; within park; Umekoji Park.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.kyoto-aquarium.com/about/floor/jellyfish-wonder/).

**Plan around:** Dolphin presentations and other outdoor sections are separate from the indoor galleries. Exhibit species may change.

**Published price reference:** JPY 2600 / adult general admission. published reference. General adult reference. High-school, primary/junior-high and age-three-plus infant categories differ. Annual passport and special evening programmes are separate products. Not a live or all-in quote. [Publisher](https://www.kyoto-aquarium.com/about/price/).

**Tickets/access:** [Official ticket / operator information](https://www.kyoto-aquarium.com/about/ticket/).

**Contact:** [Official visitor/contact route](https://www.kyoto-aquarium.com/about/floor/jellyfish-wonder/). Telephone: +81 75 354 3130.

**Evidence:** [Kyoto Aquarium / official publisher](https://www.kyoto-aquarium.com/about/floor/jellyfish-wonder/); [Kyoto Museums Association](https://kyoto-museums.city.kyoto.lg.jp/en/museum/618/); [Kyoto Aquarium / official publisher](https://www.kyoto-aquarium.com/about/price/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #25: Toba Aquarium

**Location:** Toba, Mie, Japan.

Dugong and sea-otter exhibits complement a broader interpretation of the Ise-Shima marine environment.

**Why go:** Unusual marine-mammal viewing and the local coastal context give the collection a clear reason to merit a dedicated visit.

**Key attractions:** Dugong exhibit; Sea otters; Ise-Shima marine interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://aquarium.co.jp/en/).

**Plan around:** Captive-animal observation is distinct from wild encounters. Individual animals and presentation times are not guaranteed.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://aquarium.co.jp/en/).

**Contact:** [Official visitor/contact route](https://aquarium.co.jp/en/).

**Evidence:** [Toba Aquarium / official publisher](https://aquarium.co.jp/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #26: National Museum of Marine Biology and Aquarium

**Location:** Checheng, Pingtung, Taiwan.

Waters of Taiwan, Coral Kingdom and Waters of the World create three complementary themes in a marine museum visit.

**Why go:** The regional-to-global structure offers a substantial marine-learning visit near southern Taiwan's coastal destinations.

**Key attractions:** Waters of Taiwan; Coral Kingdom; Waters of the World.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.nmmba.gov.tw/en/).

**Plan around:** Overnight experiences and regular admission have different bookings. The retrieved English page is older than current search evidence and needs a dated schedule check.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.nmmba.gov.tw/en/).

**Contact:** [Official visitor/contact route](https://www.nmmba.gov.tw/en/).

**Evidence:** [National Museum of Marine Biology and Aquarium / official publisher](https://www.nmmba.gov.tw/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #27: Port of Nagoya Public Aquarium

**Location:** Garden Pier, Nagoya, Japan.

Marine interpretation and aquarium habitats occupy a port setting that can be considered alongside Garden Pier's maritime attractions.

**Why go:** The aquarium can be combined with separate maritime museums at the port, creating a broader water-focused city itinerary.

**Key attractions:** Aquarium habitat route; Marine interpretation; Garden Pier maritime setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://nagoyaaqua.jp/english/).

**Plan around:** Marine-mammal presentations are part of the venue. Distinguish aquarium-only tickets from four-facility combinations and ignore old sample timetables embedded in the page.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://nagoyaaqua.jp/english/).

**Contact:** [Official visitor/contact route](https://nagoyaaqua.jp/english/).

**Evidence:** [Port of Nagoya Public Aquarium / official publisher](https://nagoyaaqua.jp/english/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #28: AQUATIS

**Location:** Vennes, Lausanne, Switzerland.

A freshwater-led aquarium and vivarium connects continental water environments with Lake Geneva science interpretation.

**Why go:** A freshwater-first narrative fills a gap left by ocean-heavy rankings and connects naturally with lake-focused DipMapper exploration.

**Key attractions:** Freshwater journey across continents; Lake Geneva science interpretation; Aquarium-vivarium displays.

**Venue format:** indoor; mixed use complex; AQUATIS complex, Vennes.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquatis.ch/en/).

**Plan around:** Reptiles form part of this aquarium-vivarium. Hotel, parking and aquarium admission are separate products unless a package states otherwise.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tickets.aquatis.ch).

**Contact:** [Official visitor/contact route](https://www.aquatis.ch/en/).

**Evidence:** [AQUATIS / official publisher](https://www.aquatis.ch/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #29: SEA LIFE Sydney Aquarium

**Location:** Darling Harbour, Sydney, Australia.

Australian aquatic habitats, shark viewing and dugong interpretation create an indoor water-focused visit at Darling Harbour.

**Why go:** A city-centre marine route gives visitors a dry introduction to Australian aquatic environments before outdoor harbour experiences.

**Key attractions:** Australian aquatic habitats; Shark viewing; Dugong exhibit information.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/sydney/).

**Published restriction:** Dugong Island zone closure and relocation reported by the operator. Check current viewing arrangements. [Source](https://www.visitsealife.com/sydney/).

**Plan around:** Dugong Island is reported closed, with the dugong relocated to Day and Night on the Reef. Verify the current animal location rather than copying old gallery text.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/sydney/tickets-passes/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/sydney/).

**Evidence:** [SEA LIFE Sydney Aquarium / official publisher](https://www.visitsealife.com/sydney/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #30: AquaRio

**Location:** Porto Maravilha, Rio de Janeiro, Brazil.

Marine galleries introduce Brazilian and wider ocean environments within Rio's revitalised port district.

**Why go:** The aquarium gives a port-district visit a focused marine activity and a sheltered alternative to a beach-only plan.

**Key attractions:** Marine aquarium galleries; Brazilian and wider marine life; Revitalised port-district setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquariomarinhodorio.com.br/).

**Plan around:** Use the aquarium's own dated ticket categories. Seasonal campaigns and bundled attractions are not permanent inclusions.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://ingressos.aquariomarinhodorio.com.br/).

**Contact:** [Official visitor/contact route](https://www.aquariomarinhodorio.com.br/).

**Evidence:** [AquaRio / official publisher](https://www.aquariomarinhodorio.com.br/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #31: Ripley's Aquarium of Canada

**Location:** Bremner Boulevard, Toronto, Canada.

Canadian aquatic environments lead into marine galleries and kelp-forest displays in a central Toronto aquarium.

**Why go:** A broad indoor aquatic route next to major downtown attractions makes this a practical city-day anchor.

**Key attractions:** Canadian Waters; Kelp forest; Marine viewing galleries.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.ripleys.com/attractions/ripleys-aquarium-of-canada).

**Plan around:** Sensory-friendly sessions are date-specific, not a statement that every visit has reduced sound or lighting.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.ripleys.com/attractions/ripleys-aquarium-of-canada).

**Contact:** [Official visitor/contact route](https://www.ripleys.com/attractions/ripleys-aquarium-of-canada).

**Evidence:** [Ripley's Aquarium of Canada / official publisher](https://www.ripleys.com/attractions/ripleys-aquarium-of-canada). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #32: Aquaria Phuket

**Location:** Central Phuket Floresta, Phuket, Thailand.

Freshwater and marine habitats, including the South China Sea exhibit, occupy the basement of Central Phuket Floresta.

**Why go:** A clear weather-independent option near Phuket Town adds marine discovery when a sea excursion is unsuitable or impractical.

**Key attractions:** South China Sea exhibit; Freshwater and marine habitats; Indoor mall aquarium.

**Venue format:** indoor; inside mall; Central Phuket Floresta, B1.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://aquaria-phuket.com/).

**Plan around:** Do not confuse it with Phuket Aquarium at Cape Panwa. Tourist promotions, height bands and online lead times differ; confirm your category.

**Published price reference:** THB 1251 / international-tourist adult online promotional admission. published reference. Published promotion versus THB 1,390 regular reference. Child and height rules differ; advance-purchase conditions apply. Do not treat as an evergreen guaranteed fare. Not a live or all-in quote. [Publisher](https://aquaria-phuket.com/admission-tickets.php).

**Tickets/access:** [Official ticket / operator information](https://aquaria-phuket.com/admission-tickets.php).

**Contact:** [Official visitor/contact route](https://aquaria-phuket.com/). Telephone: +6676629800.

**Evidence:** [Aquaria Phuket / official publisher](https://aquaria-phuket.com/); [Aquaria Phuket](https://aquaria-phuket.com/location.php). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #33: SEA LIFE Bangkok Ocean World

**Location:** Siam Paragon, Bangkok, Thailand.

An indoor oceanarium beneath Siam Paragon offers a substantial aquatic visit within Bangkok's central shopping district.

**Why go:** This is a substantial indoor water experience in the centre of Bangkok, useful when heat or rain makes a long outdoor itinerary less appealing.

**Key attractions:** Indoor marine exhibits; Urban oceanarium; Siam shopping-district access.

**Venue format:** indoor; inside mall; Siam Paragon.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/bangkok/en/).

**Plan around:** Use the date-specific opening calendar. The operator has advertised early closures on particular dates, so generic mall hours are not sufficient.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/bangkok/en/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/bangkok/en/plan/before-you-visit/opening-hours/).

**Evidence:** [SEA LIFE Bangkok Ocean World / official publisher](https://www.visitsealife.com/bangkok/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #34: Dubai Aquarium & Underwater Zoo

**Location:** Dubai Mall, Dubai, United Arab Emirates.

The aquarium tunnel and Underwater Zoo are distinct parts of a mall attraction whose ticket packages can include further experiences.

**Why go:** A large central tank and separate animal galleries make this more than a passing view from the shopping concourse.

**Key attractions:** Aquarium tunnel; Underwater Zoo; Penguin Cove in selected tickets.

**Venue format:** indoor; inside mall; Dubai Mall.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.thedubaiaquarium.com/tickets/book-tickets/).

**Plan around:** The public-facing tank view and paid tunnel route are different experiences. Silver, Gold and other products include different activities.

**Published price reference:** AED 199 / Silver ticket. published reference. Published Silver reference includes tunnel, Underwater Zoo and Penguin Cove. Resident promotions and boat/animal upgrades are distinct. Not a live or all-in quote. [Publisher](https://www.thedubaiaquarium.com/tickets/book-tickets/).

**Tickets/access:** [Official ticket / operator information](https://www.thedubaiaquarium.com/tickets/book-tickets/).

**Contact:** [Official visitor/contact route](https://www.thedubaiaquarium.com/tickets/book-tickets/).

**Evidence:** [Dubai Aquarium & Underwater Zoo / official publisher](https://www.thedubaiaquarium.com/tickets/book-tickets/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #35: SEA LIFE COEX Aquarium

**Location:** Starfield COEX Mall, Gangnam, Seoul, South Korea.

A marine aquarium route, including Sea at Night displays, sits inside the COEX shopping complex in Seoul.

**Why go:** It provides a substantial aquarium visit without leaving a major Seoul shopping and transport district.

**Key attractions:** Marine aquarium route; Sea at Night displays; Urban mall setting.

**Venue format:** indoor; inside mall; Starfield COEX Mall, B1.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/coex-seoul/en/).

**Plan around:** The current name is SEA LIFE COEX Aquarium. Keep COEX Aquarium as a search alias, not a duplicate attraction. Premium experiences are separate.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://ticketing.visitsealife.com/en/seoul/tickets/sea-life-coex-admission-ticket).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/coex-seoul/en/plan-your-visit/before-you-visit/directions-parking/).

**Evidence:** [SEA LIFE COEX Aquarium / official publisher](https://www.visitsealife.com/coex-seoul/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #36: Aqua Planet Jeju

**Location:** Seopjikoji, Seogwipo, Jeju, South Korea.

The Sea of Jeju display anchors a coastal attraction with aquarium ecology presentations and a separate entertainment programme.

**Why go:** The large marine route and coastal setting make this a substantial island-day attraction rather than a short shopping add-on.

**Key attractions:** Sea of Jeju main tank; Aquarium ecology presentations; Ocean Arena programme.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.aquaplanet.co.kr/jeju/eng/index.do).

**Plan around:** The ticket may include live performances and special exhibitions. The source's age-band years need checkout confirmation; do not infer visitor ages from stale birth-year tables.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aquaplanet.co.kr/jeju/eng/information/use_price.do).

**Contact:** [Official visitor/contact route](https://www.aquaplanet.co.kr/jeju/eng/index.do).

**Evidence:** [Aqua Planet Jeju / official publisher](https://www.aquaplanet.co.kr/jeju/eng/index.do). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #37: AQWA

**Location:** Hillarys Boat Harbour, Perth, Australia.

A Western Australian coastal journey includes a Shipwreck Coast tunnel and seadragon interpretation.

**Why go:** Its focus on one long, varied coastline gives the visit a regional purpose and differentiates it from generic tropical displays.

**Key attractions:** Western Australian coast; Shipwreck Coast tunnel; Leafy seadragons.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aqwa.com.au/exhibits/).

**Plan around:** The tunnel has lift access, while some other areas need staff assistance. Confirm the exact route for your mobility requirements.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aqwa.com.au/buy-tickets/).

**Contact:** [Official visitor/contact route](https://www.aqwa.com.au/contact-us/). Telephone: +61894477500.

**Evidence:** [AQWA / official publisher](https://www.aqwa.com.au/exhibits/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #38: Cairns Aquarium

**Location:** Florence Street, Cairns, Australia.

The route follows tropical water environments from freshwater and mangroves towards reefs and offshore habitats.

**Why go:** The progression from rainforest waters to reef habitats makes a useful preparation for a separate Great Barrier Reef trip.

**Key attractions:** Tropical freshwater habitats; Mangroves and reef systems; Deep-reef and ocean galleries.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.cairnsaquarium.com.au/general-admission/).

**Plan around:** After-hours guided visits are separate products. General admission is not a reef cruise or a turtle-hospital tour unless explicitly included.

**Published price reference:** AUD 61 / adult 15+ general admission. published reference. Published reference; child 3-14 AUD 35, concession AUD 48, under 3 free. Confirm dated terms. Not a live or all-in quote. [Publisher](https://www.cairnsaquarium.com.au/general-admission/).

**Tickets/access:** [Official ticket / operator information](https://www.cairnsaquarium.com.au/general-admission/).

**Contact:** [Official visitor/contact route](https://www.cairnsaquarium.com.au/general-admission/). Telephone: +61740447300. Email: reservations@cairnsaquarium.com.au.

**Evidence:** [Cairns Aquarium / official publisher](https://www.cairnsaquarium.com.au/general-admission/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #39: Alaska SeaLife Center

**Location:** Seward waterfront, Alaska, United States.

Alaskan marine life, seabirds and research interpretation connect aquarium viewing with regional wildlife-response work.

**Why go:** A focused northern marine story gives context to independent wildlife trips without requiring visitors to go out to sea.

**Key attractions:** Alaskan coastal marine life; Seabird and marine-mammal viewing; Research and wildlife-response interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.alaskasealife.org/).

**Plan around:** Wildlife-response information is not a guarantee of seeing a particular rescued animal. Encounters require separate arrangements.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://alaskasealife.sitewrench.com/).

**Contact:** [Official visitor/contact route](https://www.alaskasealife.org/).

**Evidence:** [Alaska SeaLife Center / official publisher](https://www.alaskasealife.org/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #40: Audubon Aquarium

**Location:** Mississippi riverfront, New Orleans, Louisiana, United States.

Bayou and Amazon habitats form part of a New Orleans aquarium visit whose admission also includes the Insectarium.

**Why go:** Louisiana habitats and an included insectarium create a broader natural-history visit than a generic ocean-tank circuit.

**Key attractions:** Down the Bayou; Amazon habitat; Included Audubon Insectarium.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://audubonnatureinstitute.org/aquarium).

**Plan around:** The current aquarium ticket includes the Insectarium, not automatically Audubon Zoo. Animal encounters and VR experiences have separate terms.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://audubonnatureinstitute.org/tickets).

**Contact:** [Official visitor/contact route](https://audubonnatureinstitute.org/aquarium).

**Evidence:** [Audubon Aquarium / official publisher](https://audubonnatureinstitute.org/aquarium); [Audubon Nature Institute](https://audubonnatureinstitute.org/aquarium). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #41: The Florida Aquarium

**Location:** Channel District, Tampa, Florida, United States.

The route connects Florida wetlands with reef, open-water and Moon Bay displays in Tampa.

**Why go:** The progression from wetlands to marine habitats makes the visit especially useful for understanding Florida rather than simply viewing tropical fish.

**Key attractions:** Wetlands of Florida; Coral Reef and Heart of the Sea; Moon Bay.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.flaquarium.org/).

**Plan around:** Dolphin cruises and conservation-campus visits are separate experiences. Check the dated aquarium ticket inclusions.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.flaquarium.org/).

**Contact:** [Official visitor/contact route](https://www.flaquarium.org/).

**Evidence:** [The Florida Aquarium / official publisher](https://www.flaquarium.org/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #42: Texas State Aquarium

**Location:** North Beach, Corpus Christi, Texas, United States.

Gulf and coastal environments are complemented by Caribbean Journey and Tortuga Cay in Corpus Christi.

**Why go:** Regional coastal exhibits and the Caribbean wing give a substantial marine itinerary in a city already associated with the Gulf.

**Key attractions:** Caribbean Journey; Tortuga Cay; Gulf and coastal animal exhibits.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.texasstateaquarium.org/).

**Plan around:** Outdoor areas and splash facilities are not weather-independent. Dolphin presentations and close animal experiences involve captive wildlife.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tickets.texasstateaquarium.org/).

**Contact:** [Official visitor/contact route](https://www.texasstateaquarium.org/).

**Evidence:** [Texas State Aquarium / official publisher](https://www.texasstateaquarium.org/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #43: Birch Aquarium at Scripps

**Location:** La Jolla, San Diego, California, United States.

Marine-science interpretation and a seadragon programme distinguish this aquarium associated with Scripps in La Jolla.

**Why go:** The connection with Scripps marine science gives the aquarium a research-led purpose and a strong regional context.

**Key attractions:** Marine science interpretation; Seadragon programme; Coastal La Jolla setting.

**Venue format:** mixed; science centre; Scripps Institution of Oceanography.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://aquarium.ucsd.edu/).

**Plan around:** Penguin and seahorse behind-the-scenes products require separate booking. Do not treat the ocean-view outdoor areas as fully sheltered.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.birchaquariumprograms.com/).

**Contact:** [Official visitor/contact route](https://aquarium.ucsd.edu/).

**Evidence:** [Birch Aquarium at Scripps / official publisher](https://aquarium.ucsd.edu/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #44: Kelonia marine-turtle observatory

**Location:** Saint-Leu, Reunion, Reunion.

Marine-turtle observation is connected to care, research and museum interpretation at this Reunion observatory.

**Why go:** A specialised turtle centre offers more focused interpretation than a broad aquarium and explains the animals' relationship with the Indian Ocean.

**Key attractions:** Marine-turtle observation; Research and care-centre interpretation; Museum route.

**Venue format:** mixed; museum.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://museesreunion.fr/kelonia/).

**Plan around:** This is a mixed museum, aquarium and care facility, not a promised animal interaction. Individual patients and clinical areas may not be visible.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://museesreunion.fr/kelonia/).

**Contact:** [Official visitor/contact route](https://museesreunion.fr/kelonia/). Telephone: +262262348110. Email: kelonia@museesreunion.re.

**Evidence:** [Kelonia marine-turtle observatory / official publisher](https://museesreunion.fr/kelonia/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #45: The Sea Shell aquarium

**Location:** VinWonders Phu Quoc, Viet Nam.

Large marine galleries and Shark Realm occupy a turtle-shaped aquarium building within VinWonders Phu Quoc.

**Why go:** The distinctive building and extensive aquatic route give a specific marine reason to choose this part of the wider theme park.

**Key attractions:** Turtle-shaped aquarium building; Shark Realm; Large marine viewing galleries.

**Venue format:** mixed; within park; VinWonders Phu Quoc.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://vinwonders.com/en/sea-shell/).

**Plan around:** The aquarium is included in the VinWonders Phu Quoc admission described by the operator. Do not market it as a separately priced aquarium ticket without evidence.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://vinwonders.com/en/sea-shell/).

**Contact:** [Official visitor/contact route](https://vinwonders.com/en/sea-shell/).

**Evidence:** [The Sea Shell aquarium / official publisher](https://vinwonders.com/en/sea-shell/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #46: Aquatics Gallery at Gujarat Science City

**Location:** Science City, Ahmedabad, Gujarat, India.

Freshwater and marine galleries emphasise Indian aquatic biodiversity within the larger Gujarat Science City visit.

**Why go:** The emphasis on Indian aquatic environments gives a large inland aquarium a regional purpose rather than relying on a generic tropical display.

**Key attractions:** Indian aquatic biodiversity; Freshwater and marine zones; Science-city learning context.

**Venue format:** mixed; science centre; Gujarat Science City.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://sciencecity.gujarat.gov.in/attractions/entry-aquatics-gallery-66).

**Plan around:** The Science City entry ticket is required before purchasing paid attraction admission. The 5D theatre and other galleries are separate products.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.sciencecity.gujarat.gov.in/ticketing/ticket/aquatic-gallery-41).

**Contact:** [Official visitor/contact route](https://www.sciencecity.gujarat.gov.in/fees-timing). Email: mail-gcsc@gujarat.gov.in.

**Evidence:** [Aquatics Gallery at Gujarat Science City / official publisher](https://sciencecity.gujarat.gov.in/attractions/entry-aquatics-gallery-66); [Gujarat Science City](https://www.sciencecity.gujarat.gov.in/fees-timing). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #47: Oceanographic Museum of Monaco

**Location:** Monaco-Ville, Monaco.

Aquarium galleries, a shark lagoon and marine museum collections combine living displays with oceanographic history.

**Why go:** The combination of aquarium and oceanographic history rewards visitors interested in both living habitats and the development of marine science.

**Key attractions:** Tropical aquarium; Shark Lagoon; Marine museum collections.

**Venue format:** mixed; museum.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://musee.oceano.org/en/aquariums/).

**Published restriction:** Mediterranean aquarium section under renovation. Confirm the current visitor route before buying for a specific gallery. [Source](https://musee.oceano.org/en/aquariums/).

**Plan around:** The Mediterranean aquarium section is reported closed for renovation. Museum and remaining tropical areas are not equivalent to full aquarium availability.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://musee.oceano.org/en/practical-info/).

**Contact:** [Official visitor/contact route](https://musee.oceano.org/en/aquariums/). Email: resa@oceano.org.

**Evidence:** [Oceanographic Museum of Monaco / official publisher](https://musee.oceano.org/en/aquariums/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #48: Burgers' Ocean

**Location:** Arnhem, Netherlands.

A reef-to-ocean route links Indo-Pacific living coral with larger marine animals inside the wider Burgers' Zoo visit.

**Why go:** The ecosystem-led presentation gives this zoo aquarium a particularly clear underwater story.

**Key attractions:** Indo-Pacific living coral; Reef-to-ocean journey; Shark and ray viewing.

**Venue format:** mixed; within zoo; Burgers' Zoo.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.burgerszoo.com/eco-display/ocean).

**Plan around:** Admission is part of Burgers' Zoo, not a separately priced standalone aquarium visit. The wider day includes outdoor walking.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.burgerszoo.com/).

**Contact:** [Official visitor/contact route](https://www.burgerszoo.com/eco-display/ocean).

**Evidence:** [Burgers' Ocean / official publisher](https://www.burgerszoo.com/eco-display/ocean). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #49: OZEANEUM

**Location:** Stralsund harbour, Germany.

Aquarium galleries and museum interpretation focus on northern seas in a harbour setting at Stralsund.

**Why go:** Northern European waters give this a strong regional identity and a useful contrast to tropical reef aquariums.

**Key attractions:** Northern-seas interpretation; Aquarium galleries; Harbour museum setting.

**Venue format:** indoor; museum.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.deutsches-meeresmuseum.de/museumsstandorte/ozeaneum/ihr-besuch).

**Plan around:** The operator lists a Christmas Eve closure and special year-end hours. Separate German Oceanographic Museum sites are not interchangeable ticket products.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://deutsches-meeresmuseum.ticketfritz.de).

**Contact:** [Official visitor/contact route](https://www.deutsches-meeresmuseum.de/museumsstandorte/ozeaneum/ihr-besuch).

**Evidence:** [OZEANEUM / official publisher](https://www.deutsches-meeresmuseum.de/museumsstandorte/ozeaneum/ihr-besuch). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #50: The Deep

**Location:** Humber waterfront, Hull, United Kingdom.

Large marine displays and ocean interpretation form a waterfront attraction beside the Humber estuary.

**Why go:** The visit is designed around ocean understanding, while the estuary setting links the indoor experience to the surrounding water landscape.

**Key attractions:** Ocean interpretation; Large marine displays; Humber estuary setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.thedeep.co.uk/visit).

**Plan around:** Standard admission is sold as an annual pass; timed reservations still matter. Read the eligibility and return-visit terms rather than assuming transferable entry.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tickets.thedeep.co.uk/tickets).

**Contact:** [Official visitor/contact route](https://www.thedeep.co.uk/visit). Email: info@thedeep.co.uk.

**Evidence:** [The Deep / official publisher](https://www.thedeep.co.uk/visit). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #51: National Marine Aquarium

**Location:** Coxside, Plymouth, United Kingdom.

The route links Plymouth Sound and British marine environments with a Great Barrier Reef zone.

**Why go:** The journey from local waters to distant reefs makes the aquarium an interpretive starting point for coastal exploration around Plymouth.

**Key attractions:** Plymouth Sound; British marine habitats; Great Barrier Reef zone.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.national-aquarium.co.uk/aquarium-zones/).

**Plan around:** Check current exceptions to opening hours and which return-visit or combination benefits belong to the selected ticket.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.national-aquarium.co.uk/book-tickets/).

**Contact:** [Official visitor/contact route](https://www.national-aquarium.co.uk/contact-us/).

**Evidence:** [National Marine Aquarium / official publisher](https://www.national-aquarium.co.uk/aquarium-zones/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #52: Kamo Aquarium

**Location:** Tsuruoka, Yamagata, Japan.

Jellyfish galleries and their interpretation give this coastal aquarium a clear specialist identity.

**Why go:** Its unusually concentrated jellyfish theme gives specialists and repeat aquarium visitors a clear reason to travel beyond the largest city venues.

**Key attractions:** Jellyfish galleries; Jellyfish interpretation; Shonai marine setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://kamo-kurage.jp/english/).

**Plan around:** The coastal location needs separate transport planning. The current Japanese name includes Tohoku Epson Aquarium Kamosui; preserve Kamo as an alias.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://kamo-kurage.jp/english/).

**Contact:** [Official visitor/contact route](https://kamo-kurage.jp/english/). Email: info@kamo-kurage.jp.

**Evidence:** [Kamo Aquarium / official publisher](https://kamo-kurage.jp/english/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #53: Shanghai Ocean Aquarium

**Location:** Lujiazui, Shanghai, China.

A China aquatic zone sits alongside cold-water, polar and deep-ocean displays in a central urban aquarium.

**Why go:** Regional and world-habitat zones give the route more context than a single central tank and complement a Pudong waterfront day.

**Key attractions:** China aquatic zone; Cold-water and polar habitats; Deep-ocean displays.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.sh-aquarium.com/en/).

**Plan around:** Sleepovers and educational classes require separate reservations; a regular admission does not include them.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.sh-aquarium.com/en/).

**Contact:** [Official visitor/contact route](https://www.sh-aquarium.com/en/).

**Evidence:** [Shanghai Ocean Aquarium / official publisher](https://www.sh-aquarium.com/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #54: Poema del Mar

**Location:** Las Palmas de Gran Canaria, Spain.

Jungle and reef environments build towards a large deep-ocean viewing window in Las Palmas.

**Why go:** The progression from freshwater to open ocean supports an aquarium-led excursion rather than a brief bad-weather stop.

**Key attractions:** Deep Ocean viewing window; Jungle habitats; Tropical reef environments.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.poema-del-mar.com/en/).

**Plan around:** The retrieved main page is an older publisher snapshot. Use the official current ticket route for prices and hours, and avoid unverified world-record marketing claims.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.poema-del-mar.com/en/).

**Contact:** [Official visitor/contact route](https://www.poema-del-mar.com/en/).

**Evidence:** [Poema del Mar / official publisher](https://www.poema-del-mar.com/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #55: Afrykarium

**Location:** Wroclaw Zoo, Poland.

An Africa-focused aquatic route links Red Sea, lake, Congo and Mozambique Channel environments within Wroclaw Zoo.

**Why go:** The African aquatic focus makes this a distinctive thematic aquarium, particularly for visitors interested in freshwater as well as marine environments.

**Key attractions:** Red Sea reefs; African lakes and Congo habitats; Mozambique Channel tunnel.

**Venue format:** mixed; within zoo; Wroclaw Zoo.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://zoo.wroclaw.pl/pawilony/afrykarium/).

**Plan around:** There is no separate Afrykarium admission: it is included in the zoo visit. The broader zoo route includes outdoor sections.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://zoo.wroclaw.pl/en/).

**Contact:** [Official visitor/contact route](https://zoo.wroclaw.pl/pawilony/afrykarium/).

**Evidence:** [Afrykarium / official publisher](https://zoo.wroclaw.pl/pawilony/afrykarium/); [Zoo Wroclaw](https://zoo.wroclaw.pl/pawilony/afrykarium/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #56: Sumida Aquarium

**Location:** Tokyo Solamachi, Sumida, Tokyo, Japan.

Penguin, jellyfish and regional aquatic galleries sit within the Tokyo Skytree Town shopping complex.

**Why go:** Distinct small-scale themes and carefully designed viewing make this a strong specialist city aquarium without needing a coastal transfer.

**Key attractions:** Open penguin pool; Jellyfish displays; Ogasawara and Edo-themed galleries.

**Venue format:** indoor; inside mall; Tokyo Solamachi, Tokyo Skytree Town.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.sumida-aquarium.com/about/floor/).

**Plan around:** The aquarium is on floors 5 and 6 of Tokyo Solamachi. Tokyo Skytree observation admission is a different product.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.sumida-aquarium.com/).

**Contact:** [Official visitor/contact route](https://www.sumida-aquarium.com/about/access/). Telephone: +81356191821.

**Evidence:** [Sumida Aquarium / official publisher](https://www.sumida-aquarium.com/about/floor/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #57: Sunshine Aquarium

**Location:** Sunshine City, Ikebukuro, Tokyo, Japan.

Indoor aquatic galleries lead to a rooftop Marine Garden, making weather relevant to part of this Ikebukuro visit.

**Why go:** The rooftop setting and overhead penguin views provide a distinctive urban perspective rather than another conventional tunnel.

**Key attractions:** Rooftop penguin viewing; Outdoor Marine Garden; Indoor aquatic galleries.

**Venue format:** mixed; inside mall complex; Sunshine City, World Import Mart rooftop.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://sunshinecity.jp/en/aquarium/area/).

**Plan around:** The Marine Garden is outdoors, so this is not an entirely weather-proof aquarium. Use the dedicated rooftop access route.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://sunshinecity.jp/en/aquarium/ticket/).

**Contact:** [Official visitor/contact route](https://sunshinecity.jp/en/aquarium/access/).

**Evidence:** [Sunshine Aquarium / official publisher](https://sunshinecity.jp/en/aquarium/area/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #58: The National Aquarium Abu Dhabi

**Location:** Al Qana, Abu Dhabi, United Arab Emirates.

Ten thematic zones provide a dedicated aquarium visit on the Al Qana waterfront.

**Why go:** The substantial themed route provides a dedicated aquatic outing rather than a short mall stop.

**Key attractions:** Ten thematic zones; Aquarium interpretation; Al Qana waterfront setting.

**Venue format:** indoor; waterfront complex; Al Qana.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://thenationalaquarium.ae/faq/).

**Plan around:** Glass-bottom boat access has stairs and specific exclusions that do not apply automatically to the main aquarium. Under-12s require an accompanying paying adult aged at least 16.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tickets.thenationalaquarium.ae/tna_b2c/ticketselection.html).

**Contact:** [Official visitor/contact route](https://thenationalaquarium.ae/faq/).

**Evidence:** [The National Aquarium Abu Dhabi / official publisher](https://thenationalaquarium.ae/faq/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #59: uShaka Sea World Aquarium

**Location:** Durban beachfront, South Africa.

A shipwreck-themed aquarium supplies the marine-life component of Durban's beachfront uShaka attraction.

**Why go:** The themed aquarium adds a substantial indoor marine element to a Durban beach day.

**Key attractions:** Shipwreck-themed aquarium; Marine displays; Beachfront park setting.

**Venue format:** mixed; within park; uShaka Marine World.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://ushakamarine.com/theaquarium/).

**Plan around:** The operator states it does not sell tickets online. Aquarium-only, show upgrades and water-park combinations are different products.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://ushakamarine.com/ratesandtimes/).

**Contact:** [Official visitor/contact route](https://ushakamarine.com/theaquarium/).

**Evidence:** [uShaka Sea World Aquarium / official publisher](https://ushakamarine.com/theaquarium/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #60: SEA LIFE Melbourne Aquarium

**Location:** Yarra riverfront, Melbourne, Australia.

Penguin habitats, jellyfish displays and the Shipwreck Explorer zone give this central-city aquarium several distinct viewing themes.

**Why go:** Distinct marine galleries provide an indoor riverfront outing with several different viewing formats.

**Key attractions:** Penguin habitats; Jellyfish displays; Shipwreck Explorer.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/melbourne/whats-inside/exhibits/).

**Plan around:** Do not advertise the former resident crocodile Pinjarra as a current attraction; the operator reports his death. Online starting fares are date-dependent.

**Published price reference:** AUD 49 / adult online starting fare. from. From-price only, not a guaranteed dated quote; published same-day pricing differs. Not a live or all-in quote. [Publisher](https://www.visitsealife.com/melbourne/tickets-passes/).

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/melbourne/tickets-passes/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/melbourne/plan-your-day/information/contact-us/). Email: info@melbourneaquarium.com.au.

**Evidence:** [SEA LIFE Melbourne Aquarium / official publisher](https://www.visitsealife.com/melbourne/whats-inside/exhibits/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #61: SEA LIFE Kelly Tarlton's Aquarium

**Location:** Tamaki Drive, Auckland, New Zealand.

An underwater tunnel, penguin habitat and turtle-rehabilitation interpretation create a marine visit close to Auckland's waterfront.

**Why go:** Antarctic and coastal themes make this a distinctive Auckland indoor option rather than a small generic tank display.

**Key attractions:** Penguin habitat; Underwater tunnel; Turtle rehabilitation interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.kellytarltons.co.nz/).

**Plan around:** Animal experiences have separate rules and charges. Check the official transport and dated-ticket information.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.kellytarltons.co.nz/).

**Contact:** [Official visitor/contact route](https://www.kellytarltons.co.nz/).

**Evidence:** [SEA LIFE Kelly Tarlton's Aquarium / official publisher](https://www.kellytarltons.co.nz/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #62: Aquarium des Lagons

**Location:** Anse Vata, Noumea, New Caledonia.

A lagoon-focused aquarium introduces the marine life and living coral of New Caledonia from its Anse Vata setting.

**Why go:** A regional lagoon focus gives visitors context for the waters they see around Noumea without requiring a boat trip.

**Key attractions:** New Caledonian lagoon life; Living coral interpretation; Anse Vata setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquarium.nc/laquarium-des-lagons/).

**Plan around:** French-Pacific-franc tariff references and night visits need their own ticket categories. Do not treat a regular visit as a night-event booking.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aquarium.nc/preparer-votre-visite/).

**Contact:** [Official visitor/contact route](https://www.aquarium.nc/laquarium-des-lagons/). Telephone: +687262731.

**Evidence:** [Aquarium des Lagons / official publisher](https://www.aquarium.nc/laquarium-des-lagons/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #63: Aquarium Berlin

**Location:** Zoologischer Garten, Berlin, Germany.

Historic aquarium galleries combine fish, invertebrates and reptile displays beside Berlin's zoo, with current works requiring attention.

**Why go:** The combination of aquatic and small-animal interpretation offers depth within central Berlin, independent of the closed SEA LIFE Berlin attraction.

**Key attractions:** Historic aquarium galleries; Fish and invertebrates; Reptile exhibits.

**Venue format:** indoor; zoo associated; Zoo Berlin.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquarium-berlin.de/en).

**Published restriction:** Construction restrictions published on the official website. Aquarium Berlin is not the former SEA LIFE Berlin. [Source](https://www.aquarium-berlin.de/en).

**Plan around:** Construction restrictions are currently advertised. Verify accessible routes and which floors are available before choosing a ticket.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://shop.aquarium-berlin.de).

**Contact:** [Official visitor/contact route](https://www.aquarium-berlin.de/en).

**Evidence:** [Aquarium Berlin / official publisher](https://www.aquarium-berlin.de/en). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #64: Haus des Meeres

**Location:** Mariahilf, Vienna, Austria.

Multiple aquatic and tropical-animal floors occupy a former flak tower, making the building part of the visit's character.

**Why go:** The vertical reuse of a historic tower creates a distinctive aquarium-and-zoo visit in an inland city.

**Key attractions:** Atlantic walkthrough; Aquatic and tropical animal floors; Former flak-tower setting.

**Venue format:** indoor; mixed aquarium zoo.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.haus-des-meeres.at/en).

**Plan around:** This is not an aquarium-only collection: terrestrial animals and rooftop facilities are part of the wider complex. Verify lift and access arrangements.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.haus-des-meeres.at/en).

**Contact:** [Official visitor/contact route](https://www.haus-des-meeres.at/en).

**Evidence:** [Haus des Meeres / official publisher](https://www.haus-des-meeres.at/en). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #65: L'Aquarium de Barcelona

**Location:** Port Vell, Barcelona, Spain.

A Mediterranean-focused aquarium and oceanarium route sit on Barcelona's Port Vell waterfront.

**Why go:** A Mediterranean emphasis makes this a relevant indoor counterpart to the coast rather than simply a fallback shopping attraction.

**Key attractions:** Mediterranean marine interpretation; Oceanarium route; Port Vell waterfront.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquariumbcn.com/en/).

**Plan around:** Do not assume a combination package includes every extra activity. Use the selected date and official ticket terms.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tickets.aquariumbcn.com).

**Contact:** [Official visitor/contact route](https://www.aquariumbcn.com/en/). Telephone: +34932217474. Email: info@aquariumbcn.com.

**Evidence:** [L'Aquarium de Barcelona / official publisher](https://www.aquariumbcn.com/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #66: Malta National Aquarium

**Location:** Qawra, St Paul's Bay, Malta.

Mediterranean marine themes, a shark tank and jellyfish displays give the island a dedicated aquarium alternative to an open-water outing.

**Why go:** Local marine themes make it a useful sheltered complement to Malta's snorkelling and diving locations.

**Key attractions:** Mediterranean marine themes; Shark tank; Jellyfish displays.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquarium.com.mt/).

**Plan around:** The site also promotes dining and events. Confirm the aquarium admission product and current schedule separately.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aquarium.com.mt/).

**Contact:** [Official visitor/contact route](https://www.aquarium.com.mt/).

**Evidence:** [Malta National Aquarium / official publisher](https://www.aquarium.com.mt/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #67: Enoshima Aquarium

**Location:** Katase Kaigan, Fujisawa, Japan.

Sagami Bay provides the local reference for an aquarium journey that also explores the wider Pacific.

**Why go:** A local-bay focus gives the exhibits geographic relevance and makes the visit a natural part of a Shonan coast day.

**Key attractions:** Sagami Bay interpretation; Pacific marine life; Coastal aquarium setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.enosui.com/en/).

**Plan around:** Published winter opening starts later than the main season; check holiday variations and presentation times.

**Published price reference:** JPY 2800 / adult general admission. published reference. Published tax-inclusive reference. Student and child categories are separate; children under 3 free. Not a live or all-in quote. [Publisher](https://www.enosui.com/en/).

**Tickets/access:** [Official ticket / operator information](https://www.enosui.com/en/).

**Contact:** [Official visitor/contact route](https://www.enosui.com/en/). Telephone: +81466299960.

**Evidence:** [Enoshima Aquarium / official publisher](https://www.enosui.com/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #68: Xpark

**Location:** Qingpu, Taoyuan, Taiwan.

Aquatic habitat galleries and light-led presentation create a designed indoor visit in Taoyuan's Qingpu district.

**Why go:** The immersive presentation offers an urban indoor alternative that can fit a broader Qingpu day.

**Key attractions:** Aquatic habitat galleries; Light-led marine interpretation; Qingpu visitor district.

**Venue format:** indoor; mall adjacent; Taoyuan Qingpu shopping precinct.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.xpark.com.tw/).

**Plan around:** Temporary collaborations have end dates. The official page warns about fake ticket sites; use its own booking link. Mall proximity is not classified as an indoor mall location.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://xpark.fonticket.com).

**Contact:** [Official visitor/contact route](https://www.xpark.com.tw/).

**Evidence:** [Xpark / official publisher](https://www.xpark.com.tw/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #69: SEA LIFE London Aquarium

**Location:** County Hall, South Bank, London, United Kingdom.

A city-centre aquarium route combines a tunnel, coral displays and a jellyfish-focused zone on the South Bank.

**Why go:** A broad marine route offers a sheltered water-themed stop in a highly walkable sightseeing district.

**Key attractions:** Coral Kingdom; Ocean Invaders jellyfish; Aquarium tunnel.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/london/).

**Plan around:** Combined attraction passes and premium experiences are not the same as standard aquarium admission.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/london/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/london/).

**Evidence:** [SEA LIFE London Aquarium / official publisher](https://www.visitsealife.com/london/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #70: SEA LIFE Brighton

**Location:** Brighton seafront, United Kingdom.

Marine viewing takes place inside a historic aquarium, with Day and Night and rainforest-themed sections.

**Why go:** The seafront setting and historic aquarium character distinguish it from many newer mall installations.

**Key attractions:** Day and Night zone; Rainforest Adventure; Marine viewing in a historic aquarium.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/brighton/).

**Plan around:** Glass-bottom boat and other premium experiences have separate tickets; quiet sessions run on selected dates.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/brighton/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/brighton/).

**Evidence:** [SEA LIFE Brighton / official publisher](https://www.visitsealife.com/brighton/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #71: CRETAquarium

**Location:** Gournes, Crete, Greece.

Mediterranean biodiversity is the focus of an aquarium connected to marine-science interpretation on Crete.

**Why go:** A clear Mediterranean research context makes this especially relevant to travellers exploring Crete's surrounding waters.

**Key attractions:** Mediterranean biodiversity; Marine-science interpretation; Aquatic habitat route.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://cretaquarium.gr/?lang=en).

**Plan around:** Winter and summer admission prices differ. The publisher lists behind-the-scenes tours as unavailable; audio and VR are additional products.

**Published price reference:** EUR 12 / winter general admission. published reference. Published winter reference, November-March. Summer April-October EUR 15. Child and concession eligibility must be checked separately. Not a live or all-in quote. [Publisher](https://cretaquarium.gr/opening-hours/).

**Tickets/access:** [Official ticket / operator information](https://cretaquarium.gr/opening-hours/).

**Contact:** [Official visitor/contact route](https://cretaquarium.gr/guided-tours/). Telephone: +302810337888.

**Evidence:** [CRETAquarium / official publisher](https://cretaquarium.gr/?lang=en); [CRETAquarium](https://cretaquarium.gr/?lang=en). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #72: Oceanium at Rotterdam Zoo

**Location:** Diergaarde Blijdorp, Rotterdam, Netherlands.

A large marine aquarium forms part of Rotterdam Zoo, with its aquarium systems adding an interpretation angle.

**Why go:** The scale of the Oceanium and availability of specialist interpretation make it a meaningful aquarium inclusion within a wider zoo day.

**Key attractions:** Large marine aquarium; Aquarium-system interpretation; Zoo-integrated ocean visit.

**Venue format:** mixed; within zoo; Diergaarde Blijdorp.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://diergaardeblijdorp.nl/en/visit/experiences/guided-tours).

**Plan around:** The published EUR 7.50 guided-tour contribution is an add-on, not admission. A valid zoo ticket is also required.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://diergaardeblijdorp.nl/en/visit).

**Contact:** [Official visitor/contact route](https://diergaardeblijdorp.nl/en/visit/experiences/guided-tours).

**Evidence:** [Oceanium at Rotterdam Zoo / official publisher](https://diergaardeblijdorp.nl/en/visit/experiences/guided-tours); [Rotterdam Zoo](https://diergaardeblijdorp.nl/en/visit/experiences/guided-tours). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #73: Galway Atlantaquaria

**Location:** Salthill, Galway, Ireland.

Irish coastal and freshwater habitats give this Salthill aquarium a local-water focus alongside its Ocean Zone.

**Why go:** The emphasis on Irish rivers and seas gives the visit a local purpose and supports understanding of the Atlantic coast outside.

**Key attractions:** Irish coastal species; Freshwater habitats; Ocean Zone.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://nationalaquarium.ie/).

**Plan around:** Treat advertised species as exhibit information, not a guarantee that every animal will be visible during your visit.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://nationalaquarium.ie/).

**Contact:** [Official visitor/contact route](https://nationalaquarium.ie/).

**Evidence:** [Galway Atlantaquaria / official publisher](https://nationalaquarium.ie/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #74: Maxell Aqua Park Shinagawa

**Location:** Shinagawa Prince Hotel, Tokyo, Japan.

Jellyfish displays and light-led galleries combine aquarium viewing with aquatic entertainment at Shinagawa.

**Why go:** A compact indoor format near a transport hub makes this useful for an evening or shorter city visit.

**Key attractions:** Jellyfish Ramble; Light-led aquarium galleries; Aquatic entertainment spaces.

**Venue format:** indoor; hotel complex; Shinagawa Prince Hotel.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aqua-park.jp/en/aqua/guide/).

**Plan around:** The venue includes dolphin performances and amusement elements. It is an entertainment-focused aquarium, not a quiet natural-history museum.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aqua-park.jp/en/aqua/info/).

**Contact:** [Official visitor/contact route](https://www.aqua-park.jp/en/aqua/guide/).

**Evidence:** [Maxell Aqua Park Shinagawa / official publisher](https://www.aqua-park.jp/en/aqua/guide/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #75: SEA LIFE Busan Aquarium

**Location:** Haeundae Beach, Busan, South Korea.

Shark, seahorse and turtle-themed zones offer an aquarium alternative beside Busan's Haeundae waterfront.

**Why go:** A marine visit directly associated with a beach district offers a useful alternative when outdoor conditions or available time do not suit swimming.

**Key attractions:** Shark Zone; Seahorse Kingdom; Turtle Rescue Zone.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/busan/en/).

**Plan around:** Beach proximity does not establish safe swimming conditions. Optional animal experiences require separate checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/busan/en/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/busan/en/).

**Evidence:** [SEA LIFE Busan Aquarium / official publisher](https://www.visitsealife.com/busan/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #76: Aquaria KLCC

**Location:** Kuala Lumpur Convention Centre, Malaysia.

A Living Ocean tunnel and Flooded Forest gallery form an aquatic route beneath Kuala Lumpur Convention Centre.

**Why go:** A varied indoor route within the KLCC district works well as a shorter city visit with marine and freshwater themes.

**Key attractions:** Living Ocean tunnel; Flooded Forest; Aquatic ecosystem galleries.

**Venue format:** indoor; mall adjacent; KLCC convention-centre district.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://aquariaklcc.com/exhibitions/).

**Plan around:** It is beneath the convention centre, not inside Suria KLCC. Publisher ticket pages show differing starting prices, so use checkout rather than one universal fare.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tickets.aquariaklcc.com/).

**Contact:** [Official visitor/contact route](https://aquariaklcc.com/contact-us/). Telephone: +60323331888. Email: sales@aquariaklcc.com.

**Evidence:** [Aquaria KLCC / official publisher](https://aquariaklcc.com/exhibitions/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #77: Jakarta Aquarium & Safari

**Location:** Central Park 2 / Neo Soho, West Jakarta, Indonesia.

Marine and freshwater galleries, penguins and terrestrial-animal displays share an indoor aquarium-and-safari attraction in Neo Soho.

**Why go:** A genuine indoor aquarium-plus-animal route gives this mall visit more substance than a decorative shopping-centre tank.

**Key attractions:** Marine and freshwater galleries; Penguins; Aquatic and terrestrial safari displays.

**Venue format:** indoor; inside mall; Central Park 2 / Neo Soho, LG-LGM.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.jakartaaquariumsafari.com/about-us).

**Plan around:** The venue uses Central Park 2 / former Neo Soho location wording. It includes terrestrial animals and shows; choose the ticket tier deliberately.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.jakartaaquariumsafari.com/ticket-information).

**Contact:** [Official visitor/contact route](https://www.jakartaaquariumsafari.com/getting-here). Telephone: +622127893435. Email: info@jakartaaquariumsafari.com.

**Evidence:** [Jakarta Aquarium & Safari / official publisher](https://www.jakartaaquariumsafari.com/about-us). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #78: Lotte World Aquarium Hanoi

**Location:** Lotte Mall West Lake Hanoi, Viet Nam.

A Vietnamese village-waterways theme develops into a river-to-sea journey inside Lotte Mall West Lake Hanoi.

**Why go:** The local-to-ocean narrative gives this mall aquarium a distinct setting and a useful alternative to another generic retail attraction.

**Key attractions:** Vietnamese village waterways; River-to-sea sequence; Ocean Square.

**Venue format:** indoor; inside mall; Lotte Mall West Lake, B1-B2.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://lottemallwestlakehanoi.vn/en/aquarium).

**Plan around:** Ticket categories use height, not age. Standard admission excludes ancillary services. The plan page describes counter sales; verify online options through the operator.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://lotteworld.vn/en/ticket/).

**Contact:** [Official visitor/contact route](https://lotteworld.vn/en/plan/). Telephone: +842433627799. Email: info@lotteworld.vn.

**Evidence:** [Lotte World Aquarium Hanoi / official publisher](https://lottemallwestlakehanoi.vn/en/aquarium); [Lotte World Aquarium Hanoi](https://lotteworld.vn/en/ticket/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #79: The Lost World Aquarium

**Location:** Atlantis, The Palm, Dubai, United Arab Emirates.

An Atlantis-themed aquarium route presents marine exhibits inside the resort complex, under its newer Lost World name.

**Why go:** A full indoor aquarium route gives day visitors a specific aquatic reason to visit the resort without booking a water-park day.

**Key attractions:** Marine exhibits; Atlantis-themed route; Resort aquarium setting.

**Venue format:** indoor; resort; The Avenues, Atlantis The Palm.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.atlantis.com/dubai/atlantis-the-palm/faq).

**Plan around:** Use the current Lost World name and preserve Lost Chambers as an alias. Hotel-included admission and day-visitor tickets are different eligibility cases.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.atlantis.com/dubai/atlantis-the-palm/faq).

**Contact:** [Official visitor/contact route](https://www.atlantis.com/dubai/atlantis-the-palm/faq).

**Evidence:** [The Lost World Aquarium / official publisher](https://www.atlantis.com/dubai/atlantis-the-palm/faq). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #80: Sharjah Aquarium

**Location:** Al Khan, Sharjah, United Arab Emirates.

Regional marine species give the aquarium a local focus, with the linked Maritime Museum adding a human-water history dimension.

**Why go:** The combination of local marine life and maritime history offers a well-defined, relatively focused alternative to larger entertainment aquariums.

**Key attractions:** Regional marine species; Aquarium interpretation; Joint Maritime Museum visit.

**Venue format:** indoor; museum.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.sharjahmuseums.ae/en-US/Museums/Sharjah-Aquarium).

**Plan around:** Ramadan schedules and specified religious-holiday closures override ordinary hours. A disability concession is not proof of every route's physical accessibility.

**Published price reference:** AED 25 / adult 13+ joint aquarium and maritime museum ticket. published reference. Published joint-ticket reference; child 2-12 AED 15. Concessions and closure dates require the official eligibility rules. Not a live or all-in quote. [Publisher](https://www.sharjahmuseums.ae/en-US/Museums/Sharjah-Aquarium).

**Tickets/access:** [Official ticket / operator information](https://www.sharjahmuseums.ae/en-US/Museums/Sharjah-Aquarium).

**Contact:** [Official visitor/contact route](https://www.sharjahmuseums.ae/en-US/Museums/Sharjah-Aquarium). Telephone: +97165285288. Email: info@sma.gov.ae.

**Evidence:** [Sharjah Aquarium / official publisher](https://www.sharjahmuseums.ae/en-US/Museums/Sharjah-Aquarium). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #81: Aquarium at The Scientific Center

**Location:** Salmiya waterfront, Kuwait, Kuwait.

An aquarium within The Scientific Center combines a water-focused attraction with a broader science-centre setting.

**Why go:** The link to a science centre gives the aquatic visit an educational purpose beyond a stand-alone leisure tank.

**Key attractions:** Aquarium attraction; Science-centre interpretation; Waterfront visitor setting.

**Venue format:** indoor; science centre; The Scientific Center.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.tsck.org.kw/).

**Plan around:** IMAX, Discovery Place and aquarium access are distinct products unless the chosen package explicitly combines them.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.tsck.org.kw/).

**Contact:** [Official visitor/contact route](https://www.tsck.org.kw/).

**Evidence:** [Aquarium at The Scientific Center / official publisher](https://www.tsck.org.kw/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #82: Istanbul Akvaryum

**Location:** Florya, Istanbul, Türkiye.

Geographical aquatic themes lead through marine and terrestrial displays beside the Aqua Florya shopping complex.

**Why go:** The geography-led route and coastal setting support a substantial visit that can be combined with the surrounding waterfront.

**Key attractions:** Geographical aquatic themes; Marine and terrestrial exhibits; Florya coastal setting.

**Venue format:** indoor; mall adjacent; Aqua Florya.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.istanbulakvaryum.com/plan-your-visit/frequently-asked-questions).

**Plan around:** This is not the former SEA LIFE Istanbul. Aqua Florya shopping is adjacent; do not describe the aquarium as a tank inside the mall.

**Published price reference:** TRY 1500 / standard adult online admission. published reference. Published reference, valid one month from purchase under the displayed terms. Premium and Silver packages differ. Not a live or all-in quote. [Publisher](https://www.istanbulakvaryum.com/buyticket).

**Tickets/access:** [Official ticket / operator information](https://www.istanbulakvaryum.com/buyticket).

**Contact:** [Official visitor/contact route](https://www.istanbulakvaryum.com/plan-your-visit/frequently-asked-questions).

**Evidence:** [Istanbul Akvaryum / official publisher](https://www.istanbulakvaryum.com/plan-your-visit/frequently-asked-questions). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #83: Emaar Aquarium & Underwater Zoo

**Location:** Emaar Square Mall, Uskudar, Istanbul, Türkiye.

Aquarium galleries and an Underwater Zoo create an indoor marine-life visit inside Emaar Square Mall.

**Why go:** A substantial indoor aquarium on Istanbul's Asian side offers a practical alternative to crossing the city for the Florya site.

**Key attractions:** Aquarium galleries; Underwater Zoo; Mall-based marine visit.

**Venue format:** indoor; inside mall; Emaar Square Mall.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.emaarakvaryum.com/en/tickets).

**Plan around:** Aquarium, SkyView combination and scuba experiences are separate products. Dollar-labelled fares are not converted or assumed to be TRY.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.emaarakvaryum.com/en/tickets).

**Contact:** [Official visitor/contact route](https://www.emaarakvaryum.com/en/tickets). Telephone: +902165471888.

**Evidence:** [Emaar Aquarium & Underwater Zoo / official publisher](https://www.emaarakvaryum.com/en/tickets). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #84: Antalya Aquarium

**Location:** Konyaalti, Antalya, Türkiye.

Thematic marine displays lead into an underwater tunnel in a coastal-city aquarium setting.

**Why go:** The tunnel-led aquarium is a useful dry marine option close to a major beach district.

**Key attractions:** Thematic marine tanks; Underwater tunnel; Coastal city setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.antalyaaquarium.com/).

**Plan around:** Snow World, Wild Park and cinema products are separate. Published hours vary across pages, so use the dated booking information.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.antalyaaquarium.com/).

**Contact:** [Official visitor/contact route](https://antalyaaquarium.com/En/iletisim.php). Telephone: +902422456565. Email: info@antalyaaquarium.com.

**Evidence:** [Antalya Aquarium / official publisher](https://www.antalyaaquarium.com/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #85: Odysseo Oceanarium

**Location:** Les Salines, Port Louis, Mauritius.

Indian Ocean interpretation and marine galleries offer a water-focused attraction at Port Louis.

**Why go:** The regional ocean focus makes this a useful introduction before separate reef or lagoon outings around Mauritius.

**Key attractions:** Indian Ocean interpretation; Marine galleries; Port Louis waterfront access.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://odysseomauritius.com/plan-your-visit/).

**Plan around:** Resident and non-resident fares differ substantially. Audio guides and special experiences are separate unless explicitly included.

**Published price reference:** MUR 1280 / non-resident adult 18+ admission. published reference. Published non-resident adult reference; resident adult MUR 650. Non-resident child 4-12 MUR 960, under 4 free. Confirm currency and checkout terms. Not a live or all-in quote. [Publisher](https://tickets.odysseomauritius.com/home/).

**Tickets/access:** [Official ticket / operator information](https://tickets.odysseomauritius.com/home/).

**Contact:** [Official visitor/contact route](https://odysseomauritius.com/plan-your-visit/). Telephone: +2306598000. Email: oceanarium@odysseomauritius.com.

**Evidence:** [Odysseo Oceanarium / official publisher](https://odysseomauritius.com/plan-your-visit/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #86: Waikiki Aquarium

**Location:** Waikiki waterfront, Honolulu, Hawaii, United States.

Living Reef and Northwestern Hawaiian Islands displays place Hawaiian marine environments at the centre of a compact aquarium visit.

**Why go:** Its smaller scale and specific Hawaiian focus make it a useful introduction to local reefs rather than a destination chosen for spectacle.

**Key attractions:** Living Reef; Northwestern Hawaiian Islands habitat; Hawaiian marine interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.waikikiaquarium.org/experience/exhibits/).

**Plan around:** The official admission page describes purchase at the front desk. Do not mistake the unrelated .site domain for the operator.

**Published price reference:** USD 12 / general admission reference. published reference. Operator homepage lists USD 12 general admission; discounts differ. Front-desk ticket purchase is stated on the official admission page. Not a live or all-in quote. [Publisher](https://www.waikikiaquarium.org/visit/admission-information/).

**Tickets/access:** [Official ticket / operator information](https://www.waikikiaquarium.org/visit/admission-information/).

**Contact:** [Official visitor/contact route](https://www.waikikiaquarium.org/experience/exhibits/).

**Evidence:** [Waikiki Aquarium / official publisher](https://www.waikikiaquarium.org/experience/exhibits/); [Waikiki Aquarium](https://www.waikikiaquarium.org/); [Waikiki Aquarium](https://www.waikikiaquarium.org/visit/admission-information/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #87: South Carolina Aquarium

**Location:** Charleston waterfront, South Carolina, United States.

Aquatic exhibits and a Sea Turtle Care Center connect the visitor route with coastal conservation interpretation.

**Why go:** The turtle-care interpretation gives this waterfront visit a distinct purpose and a way to learn about regional marine issues.

**Key attractions:** Sea Turtle Care Center; Aquatic exhibits; Coastal conservation interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://scaquarium.org/).

**Plan around:** Temporary exhibitions and encounters change. Do not promise a named turtle or access to clinical work from a general admission ticket.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://scaquarium.org/).

**Contact:** [Official visitor/contact route](https://scaquarium.org/).

**Evidence:** [South Carolina Aquarium / official publisher](https://scaquarium.org/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #88: Oregon Coast Aquarium

**Location:** Newport, Oregon, United States.

Oregon marine environments and reserve interpretation form an aquarium visit with outdoor coastal grounds.

**Why go:** The coastal setting and regional marine story make it a useful complement to, rather than a replacement for, Oregon shore exploration.

**Key attractions:** Oregon coastal marine life; Marine-reserve interpretation; Outdoor coastal grounds.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://aquarium.org/).

**Plan around:** Outdoor grounds are part of the visit. Severe weather and animal-care changes may affect parts of the experience.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tickets.aquarium.org/).

**Contact:** [Official visitor/contact route](https://aquarium.org/).

**Evidence:** [Oregon Coast Aquarium / official publisher](https://aquarium.org/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #89: SEA LIFE Minnesota

**Location:** Mall of America, Bloomington, Minnesota, United States.

An underwater tunnel, sharks, rays, jellyfish and sea turtles create an aquarium visit within Mall of America.

**Why go:** A substantial indoor aquatic stop inside a major shopping centre offers a practical change of pace on a mall day.

**Key attractions:** Underwater tunnel; Shark and ray viewing; Jellyfish and sea turtles.

**Venue format:** indoor; inside mall; Mall of America.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/minnesota/).

**Plan around:** Mall access is not aquarium admission. Do not treat expired themed promotions as permanent exhibits.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/minnesota/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/minnesota/).

**Evidence:** [SEA LIFE Minnesota / official publisher](https://www.visitsealife.com/minnesota/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #90: Tropicarium Budapest

**Location:** Campona shopping centre, Budapest, Hungary.

A shark-viewing tunnel joins marine and tropical-animal exhibits within the Campona shopping centre.

**Why go:** A shark tunnel and tropical route make this a distinct indoor destination on Budapest's southern side rather than a decorative mall tank.

**Key attractions:** Shark-viewing tunnel; Marine aquarium; Tropical animal exhibits.

**Venue format:** indoor; inside mall; Campona.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://tropicarium.hu/en/home/).

**Plan around:** Allow for travel from central Budapest. Holiday hours differ and guided English visits require prior arrangement.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tropicarium.hu/en/tickets-and-prices/).

**Contact:** [Official visitor/contact route](https://tropicarium.hu/en/contact/). Email: info@tropicarium.hu.

**Evidence:** [Tropicarium Budapest / official publisher](https://tropicarium.hu/en/home/); [Tropicarium](https://tropicarium.hu/en/our-story/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #91: Aquario de Sao Paulo

**Location:** Ipiranga, Sao Paulo, Brazil.

Aquatic galleries are part of a broader animal-park route that also includes polar-animal exhibits.

**Why go:** The mix of aquatic and other habitats provides an inland nature outing, with a different scope from a purely marine aquarium.

**Key attractions:** Aquatic galleries; Polar-animal exhibits; Broader animal-park route.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.aquariodesp.com.br/).

**Plan around:** The operator lists exclusions for mermaid experiences, Jurassic Aquarium, parking and food in some offers. Do not flatten a promotion into an all-inclusive price.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aquariodesp.com.br/).

**Contact:** [Official visitor/contact route](https://www.aquariodesp.com.br/). Telephone: +551122735500.

**Evidence:** [Aquario de Sao Paulo / official publisher](https://www.aquariodesp.com.br/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #92: Oceanic Aquarium

**Location:** Barra Sul, Balneario Camboriu, Brazil.

Shark, penguin and freshwater displays sit alongside terrestrial species at Balneario Camboriu.

**Why go:** A coastal-city aquarium with several habitat types offers an alternative when a beach day is not the preferred choice.

**Key attractions:** Shark exhibits; Penguin viewing; Freshwater and terrestrial species.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.oceanicaquarium.com.br/en).

**Plan around:** Displayed prices refer to different products. Fun Passport combinations include other attractions and cannot serve as the aquarium-only fare.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://ingresso.oceanicaquarium.com.br/).

**Contact:** [Official visitor/contact route](https://www.oceanicaquarium.com.br/en).

**Evidence:** [Oceanic Aquarium / official publisher](https://www.oceanicaquarium.com.br/en). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #93: Aquarium at Parque Explora

**Location:** Parque Explora, Medellin, Colombia.

An aquarium inside Parque Explora connects aquatic interpretation with a wider interactive science-museum visit.

**Why go:** A science-centre setting gives the aquatic visit wider learning value and a useful inland alternative to marine-coast attractions.

**Key attractions:** Aquarium inside a science museum; Aquatic interpretation; Broader interactive science visit.

**Venue format:** indoor; science centre; Parque Explora.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.parqueexplora.org/en).

**Plan around:** Choose the correct Parque Explora admission. Planetarium and other experiences have their own ticket conditions.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.parqueexplora.org/en).

**Contact:** [Official visitor/contact route](https://www.parqueexplora.org/en).

**Evidence:** [Aquarium at Parque Explora / official publisher](https://www.parqueexplora.org/en). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #94: Acuario Inbursa

**Location:** Nuevo Polanco, Mexico City, Mexico.

Sharks, rays, penguins and jellyfish are joined by axolotl interpretation in Mexico City.

**Why go:** Marine displays combined with axolotl interpretation provide a reason to include aquatic life in an otherwise city-focused itinerary.

**Key attractions:** Sharks and rays; Penguins and jellyfish; Axolotl interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.acuarioinbursa.com.mx/).

**Plan around:** General admission, Shark Pass and penguin packages differ. A starting price is not a complete quote, and the aquarium is not classified as inside Plaza Carso.

**Published price reference:** MXN 350 / general online starting admission. from. Published from-price only. Shark Pass and penguin products are separate. Date and passenger category require confirmation. Not a live or all-in quote. [Publisher](https://www.acuarioinbursa.com.mx/).

**Tickets/access:** [Official ticket / operator information](https://www.acuarioinbursa.com.mx/).

**Contact:** [Official visitor/contact route](https://www.acuarioinbursa.com.mx/). Telephone: +525561159173.

**Evidence:** [Acuario Inbursa / official publisher](https://www.acuarioinbursa.com.mx/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #95: Hurghada Grand Aquarium

**Location:** Southern Hurghada, Red Sea, Egypt.

Red Sea tanks and an underwater tunnel are combined with rainforest and mini-zoo areas, offering a dry alternative to a reef trip.

**Why go:** A dry introduction to Red Sea marine life gives non-divers a specific aquatic experience without booking a boat.

**Key attractions:** Red Sea marine tanks; Underwater tunnel; Rainforest and mini-zoo areas.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://www.hurghadaaquarium.com/).

**Plan around:** The route includes outdoor zoo areas. Shark dives and other upgrades are separate; the website's conflicting last-admission wording is not copied into a fixed schedule.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://qless.hurghadaaquarium.com/).

**Contact:** [Official visitor/contact route](https://www.hurghadaaquarium.com/).

**Evidence:** [Hurghada Grand Aquarium / official publisher](https://www.hurghadaaquarium.com/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #96: Manila Ocean Park Oceanarium

**Location:** Luneta waterfront, Manila, Philippines.

A seven-section oceanarium route and curved underwater tunnel explore Philippine and Southeast Asian marine life.

**Why go:** The regional marine focus gives a city visitor a clear introduction to the surrounding seas without travelling offshore.

**Key attractions:** Curved underwater tunnel; Philippine and Southeast Asian marine life; Seven-section oceanarium route.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://manilaoceanpark.com/attractions/oceanarium/).

**Plan around:** Tickets often bundle several attractions. Admission uses height rules for children; animal encounters mentioned elsewhere may be unavailable.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://manilaoceanpark.com/buy-tickets/).

**Contact:** [Official visitor/contact route](https://manilaoceanpark.com/attractions/oceanarium/). Telephone: +63272386120. Email: inquiry@manilaoceanpark.com.

**Evidence:** [Manila Ocean Park Oceanarium / official publisher](https://manilaoceanpark.com/attractions/oceanarium/); [Manila Ocean Park](https://manilaoceanpark.com/faq/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #97: Cebu Ocean Park

**Location:** SM Seaside Complex, Cebu City, Philippines.

An aquarium and marine-life attraction offers an indoor visit opposite, rather than inside, SM Seaside.

**Why go:** The park adds a dry marine option to a city often used as a departure point for island trips.

**Key attractions:** Aquarium and marine-life visit; Indoor aquatic viewing; SM Seaside district setting.

**Venue format:** indoor; mall adjacent; SM Seaside Complex.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.cebuoceanpark.com/tickets-and-hours/).

**Plan around:** The operator says opposite SM Seaside, so this is mall-adjacent, not inside the mall. Weekday and weekend fares differ; children under 3 ft have a specific exemption.

**Published price reference:** PHP 750 / online promotional weekday admission. published reference. Published online weekday reference excluding holidays. Weekend/holiday PHP 900. Non-promotional rates differ and discounts do not stack. Not a live or all-in quote. [Publisher](https://www.cebuoceanpark.com/tickets-and-hours/).

**Tickets/access:** [Official ticket / operator information](https://www.cebuoceanpark.com/tickets-and-hours/).

**Contact:** [Official visitor/contact route](https://www.cebuoceanpark.com/tickets-and-hours/).

**Evidence:** [Cebu Ocean Park / official publisher](https://www.cebuoceanpark.com/tickets-and-hours/); [Cebu Ocean Park](https://www.cebuoceanpark.com/tickets-and-hours/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #98: Gdynia Aquarium

**Location:** South Pier, Gdynia, Poland.

Baltic and North Atlantic environments sit alongside coral-reef and Amazon habitats at an aquarium linked to marine-fisheries research.

**Why go:** Northern waters receive meaningful attention here, making the visit distinct from aquariums that concentrate mainly on tropical seas.

**Key attractions:** Baltic and North Atlantic environments; Coral reef and Amazon habitats; Marine-fisheries research context.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://akwarium.gdynia.pl/en/what-will-you-see/).

**Published restriction:** Winter Monday closure: November-January is stated consistently. The English opening page extends it through February while Polish material stops at January; confirm February Mondays. [Source](https://akwarium.gdynia.pl/en/what-will-you-see/).

**Published restriction:** The opened official English and Polish calendars both state Monday closure from November through February. Confirm the applicable year and holiday exceptions with the operator. [Source](https://akwarium.gdynia.pl/godziny-i-dni-otwarcia/).

**Published restriction:** Published fixed holiday closure: 01-01 to 01-01. Current-year confirmation remains necessary. [Source](https://akwarium.gdynia.pl/godziny-i-dni-otwarcia/).

**Published restriction:** Published fixed holiday closure: 11-01 to 11-01. Current-year confirmation remains necessary. [Source](https://akwarium.gdynia.pl/godziny-i-dni-otwarcia/).

**Published restriction:** Published fixed holiday closure: 12-24 to 12-25. Current-year confirmation remains necessary. [Source](https://akwarium.gdynia.pl/godziny-i-dni-otwarcia/).

**Published restriction:** Published fixed holiday closure: 12-31 to 12-31. Current-year confirmation remains necessary. [Source](https://akwarium.gdynia.pl/godziny-i-dni-otwarcia/).

**Plan around:** The final opened English and Polish calendars agree on Monday closure from November through February, plus named holiday closures. An earlier inconsistent search excerpt was superseded. Use the current calendar rather than assuming that indoor means open every day.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://akwarium.gdynia.pl/en/tickets/).

**Contact:** [Official visitor/contact route](https://akwarium.gdynia.pl/en/kontakt/). Telephone: +48572504608. Email: akwarium@mir.gdynia.pl.

**Evidence:** [Gdynia Aquarium / official publisher](https://akwarium.gdynia.pl/en/what-will-you-see/); [Gdynia Aquarium](https://akwarium.gdynia.pl/en/opening/); [Gdynia Aquarium](https://akwarium.gdynia.pl/godziny-i-dni-otwarcia/); [Gdynia Aquarium](https://akwarium.gdynia.pl/en/); [Gdynia Aquarium](https://akwarium.gdynia.pl/en/frequently-asked-questions/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #99: Lotte World Aquarium Seoul

**Location:** Lotte World Mall, Jamsil, Seoul, South Korea.

An urban aquarium inside Lotte World Mall combines marine galleries with penguin and marine-mammal interpretation.

**Why go:** A substantial aquarium beneath Lotte World Mall makes a clear aquatic destination within the Jamsil district rather than a passing retail display.

**Key attractions:** Large urban aquarium route; Marine-mammal and penguin interpretation; Mall-based indoor visit.

**Venue format:** indoor; inside mall; Lotte World Mall.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://english.visitseoul.net/entertainment/LotteWorldAquarium_/37485).

**Plan around:** The aquarium and Seoul Sky combination must be used on the same day under the displayed terms. Do not promise a particular captive whale or a release timetable.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://aquarium.lotteworld.com/price/ticket/price).

**Contact:** [Official visitor/contact route](https://english.visitseoul.net/entertainment/LotteWorldAquarium_/37485).

**Evidence:** [Lotte World Aquarium Seoul / official publisher](https://english.visitseoul.net/entertainment/LotteWorldAquarium_/37485); [Lotte World Aquarium](https://aquarium.lotteworld.com/price/ticket/price). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #100: Bristol Aquarium

**Location:** Harbourside, Bristol, United Kingdom.

Native British waters, Amazon habitats and coral-sea exhibits form an indoor aquarium visit in the city.

**Why go:** The combination of native and tropical environments provides a manageable aquatic stop within a city harbour day.

**Key attractions:** British native waters; Amazon habitats; Coral-sea exhibits.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.bristolaquarium.co.uk/discover/exhibits/).

**Plan around:** Child admission terms changed in 2026. Use the live ticket category, not an older free-child policy. Adult-only events are separate from normal admission.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.bristolaquarium.co.uk/visitor-info/tickets-prices/).

**Contact:** [Official visitor/contact route](https://www.bristolaquarium.co.uk/discover/exhibits/).

**Evidence:** [Bristol Aquarium / official publisher](https://www.bristolaquarium.co.uk/discover/exhibits/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

## Further aquarium discoveries

The original positions 101 to 120 remain. New profiles are additional discoveries without an invented global position.

### Global aquarium #101: Aqua Planet Gwanggyo

**Location:** Gwanggyo, Suwon, South Korea.

Ocean, reef and penguin displays provide a mall-based aquarium visit in Gwanggyo.

**Why go:** A compact urban aquarium can be paired with nearby retail and lake-park time, giving the day both indoor and outdoor options.

**Key attractions:** Into the Ocean gallery; Rainbow Reef; Penguin interpretation.

**Venue format:** indoor; mall adjacent; Galleria Gwanggyo nearby.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.aquaplanet.co.kr/gwanggyo/eng/index.do).

**Plan around:** The operator describes Galleria Department Store as nearby. This listing is mall-adjacent, not verified as inside the department store.

**Published price reference:** KRW 30000 / adult aquarium admission. published reference. Published Korean-site reference; child/senior KRW 27,000. Packages and eligibility differ. Not a live or all-in quote. [Publisher](https://www.aquaplanet.co.kr/gwanggyo/eng/information/use_price.do).

**Tickets/access:** [Official ticket / operator information](https://www.aquaplanet.co.kr/gwanggyo/eng/information/use_price.do).

**Contact:** [Official visitor/contact route](https://www.aquaplanet.co.kr/gwanggyo/eng/index.do).

**Evidence:** [Aqua Planet Gwanggyo / official publisher](https://www.aquaplanet.co.kr/gwanggyo/eng/index.do). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #102: Underwater World Langkawi

**Location:** Pantai Cenang, Langkawi, Malaysia.

Penguin exhibits form part of a broader aquatic visitor route near the island's beach district.

**Why go:** Penguin and aquatic exhibits add an indoor alternative to a largely beach-and-island destination.

**Key attractions:** African penguins; Rockhopper penguins; Aquatic visitor route.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.underwaterworldlangkawi.com/visitor-information.php/index.php).

**Plan around:** Do not confuse aquarium admission with wildlife boat tours. Resident and visitor ticket categories require confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://ticket.underwaterworldlangkawi.com/TicketSelection.aspx).

**Contact:** [Official visitor/contact route](https://www.underwaterworldlangkawi.com/visitor-information.php/index.php).

**Evidence:** [Underwater World Langkawi / official publisher](https://www.underwaterworldlangkawi.com/visitor-information.php/index.php). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #103: Underwater World Pattaya

**Location:** Pattaya, Thailand.

Coral, open-ocean and Giant of Siam freshwater sections connect marine viewing with a Thai freshwater theme.

**Why go:** The marine and freshwater tunnel format gives visitors a varied aquatic route without entering the water.

**Key attractions:** Coral Reef Zone; Open Ocean Zone; Giant of Siam freshwater section.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://underwaterworldpattaya.com/).

**Plan around:** Height-based ticket categories are not age bands. The published wording has boundary ambiguities; confirm with the operator rather than assigning a child by guessed age.

**Published price reference:** THB 550 / published adult-category admission. published reference. Child-category reference THB 320. Height eligibility requires confirmation; no family total is calculated automatically. Not a live or all-in quote. [Publisher](https://underwaterworldpattaya.com/).

**Tickets/access:** [Official ticket / operator information](https://underwaterworldpattaya.com/).

**Contact:** [Official visitor/contact route](https://underwaterworldpattaya.com/).

**Evidence:** [Underwater World Pattaya / official publisher](https://underwaterworldpattaya.com/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #104: Chiang Mai Zoo Aquarium

**Location:** Huay Kaew Road, Chiang Mai, Thailand.

Freshwater and marine tunnels introduce Mekong and ocean environments within the wider Chiang Mai Zoo setting.

**Why go:** The freshwater focus offers a relevant aquatic discovery option in an inland region better known for mountains.

**Key attractions:** Mekong freshwater tunnel; Marine tunnel; Rainforest-water interpretation.

**Venue format:** mixed; within zoo; Chiang Mai Zoo.

**Season, indoor visit format:** All months. The core aquarium galleries offer an all-month discovery option, while this mixed indoor/outdoor site has weather-exposed sections. Month coverage is an editorial visit-format interpretation, not a daily operating guarantee. [Season evidence](https://chiangmaiaquarium.com/en/).

**Plan around:** Zoo and aquarium charges need to be separated. The website contains temporary feeding-show cancellation notices, so do not publish fixed showtimes from old text.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://chiangmaiaquarium.com/en/).

**Contact:** [Official visitor/contact route](https://chiangmaiaquarium.com/en/). Telephone: +6652081775. Email: info.it.aquarium@gmail.com.

**Evidence:** [Chiang Mai Zoo Aquarium / official publisher](https://chiangmaiaquarium.com/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #105: Vinpearl Aquarium Times City

**Location:** Times City, Hanoi, Viet Nam.

Freshwater, saltwater and reptile sections create an aquarium visit within the Times City shopping complex.

**Why go:** A marine visit can be separated from the wider children's entertainment package, making this useful for a focused indoor family stop.

**Key attractions:** Freshwater and saltwater zones; Reptile exhibits; Indoor aquatic route.

**Venue format:** indoor; inside mall; Vincom Mega Mall Times City.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://vinwonders.com/en/vinke-vinpearl-aquarium/).

**Plan around:** Aquarium-only and VinKE combinations differ. Height-band wording differs between publisher materials; confirm the selected ticket's rule.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://booking.vinwonders.com/en-VND/search?adultQuantity=1&code=HNVKA).

**Contact:** [Official visitor/contact route](https://vinwonders.com/en/vinke-vinpearl-aquarium/).

**Evidence:** [Vinpearl Aquarium Times City / official publisher](https://vinwonders.com/en/vinke-vinpearl-aquarium/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #106: Oman Aquarium

**Location:** Mall of Muscat, Al Seeb, Oman.

A two-floor aquarium uses a seafaring narrative to connect its marine exhibits inside the Mall of Muscat.

**Why go:** The Omani navigator narrative gives a mall aquarium a local story and makes it more than a decorative retail installation.

**Key attractions:** Two-floor aquarium; Seafaring narrative; Marine exhibits.

**Venue format:** indoor; inside mall; Mall of Muscat.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://mallofmuscat.com/aquarium/).

**Plan around:** The shopping centre's opening hours and the aquarium's admission rules are not interchangeable. Verify the current ticket product.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.omanaquarium.om/).

**Contact:** [Official visitor/contact route](https://mallofmuscat.com/aquarium/). Telephone: +96893335064. Email: info@omanaquarium.om.

**Evidence:** [Oman Aquarium / official publisher](https://mallofmuscat.com/aquarium/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #107: Bahrain Aquarium

**Location:** Mall of Dilmunia, Galali, Bahrain.

A multi-storey cylindrical aquarium brings marine fish and ray viewing into the Mall of Dilmunia.

**Why go:** The tall cylindrical format creates a distinctive short aquatic stop within a retail day.

**Key attractions:** Multi-storey cylindrical tank; Marine fish and ray viewing; Mall-integrated aquarium.

**Venue format:** indoor; inside mall; Mall of Dilmunia.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://bahrainaquarium.com/).

**Plan around:** Viewing the tank and participating in paid encounters are different products. The source mixes animal and species counts, which are deliberately not reproduced.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://bahrainaquarium.com/).

**Contact:** [Official visitor/contact route](https://bahrainaquarium.com/contact-us/). Telephone: +97313300266. Email: info@bahrainaquarium.com.

**Evidence:** [Bahrain Aquarium / official publisher](https://bahrainaquarium.com/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #108: Aquadream at Morocco Mall

**Location:** Morocco Mall, Casablanca, Morocco.

A cylindrical aquarium and panoramic lift form a compact aquatic experience within Morocco Mall.

**Why go:** The central cylindrical installation is a distinctive short discovery stop for people already visiting the mall.

**Key attractions:** Cylindrical aquarium; Panoramic lift experience; Retail-floor viewing.

**Venue format:** indoor; inside mall; Morocco Mall.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.moroccomall.ma/cinema-divertissement/aquadream).

**Plan around:** This is not a full-scale aquarium museum. Lift access and paid viewing need confirmation; do not repeat the source's inconsistent species-count wording.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.moroccomall.ma/cinema-divertissement/aquadream).

**Contact:** [Official visitor/contact route](https://www.moroccomall.ma/cinema-divertissement/aquadream).

**Evidence:** [Aquadream at Morocco Mall / official publisher](https://www.moroccomall.ma/cinema-divertissement/aquadream). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #109: Discovery Bay mini-aquarium

**Location:** Independence Mall, Wilmington, North Carolina, United States.

A temporary mini-aquarium in Independence Mall presents marine-life displays while the main Fort Fisher aquarium is closed for construction.

**Why go:** An unusual free discovery stop keeps public aquarium learning available while the main Fort Fisher site is closed for construction.

**Key attractions:** Small marine-life displays; Aquarium interpretation; Complimentary mall-based visit.

**Venue format:** indoor; inside mall; Independence Mall.

**Season, indoor visit format:** All months. Temporary indoor mini-aquarium described by the state publisher in July 2026. No permanent all-year operating guarantee; confirm the current temporary programme before visiting. [Season evidence](https://www.dncr.nc.gov/news/press-releases/2026/07/08/nc-aquariums-welcome-visitors-unique-underwater-experience-independence-mall-wilmington).

**Published restriction:** The main NC Aquarium at Fort Fisher is closed for construction. This listing is the separate Independence Mall mini-aquarium. [Source](https://www.dncr.nc.gov/news/press-releases/2026/07/08/nc-aquariums-welcome-visitors-unique-underwater-experience-independence-mall-wilmington).

**Plan around:** This is a temporary mini-aquarium, not the full Fort Fisher attraction. Confirm its current operation and distinguish separately priced events.

**Published price reference:** USD 0 / ordinary Discovery Bay admission. published reference. The state publisher calls the ordinary experience complimentary. Separately ticketed events are not included. Not a live or all-in quote. [Publisher](https://www.dncr.nc.gov/news/press-releases/2026/07/08/nc-aquariums-welcome-visitors-unique-underwater-experience-independence-mall-wilmington).

**Tickets/access:** [Official ticket / operator information](https://www.dncr.nc.gov/news/press-releases/2026/07/08/nc-aquariums-welcome-visitors-unique-underwater-experience-independence-mall-wilmington).

**Contact:** [Official visitor/contact route](https://www.dncr.nc.gov/news/press-releases/2026/07/08/nc-aquariums-welcome-visitors-unique-underwater-experience-independence-mall-wilmington).

**Evidence:** [Discovery Bay mini-aquarium / official publisher](https://www.dncr.nc.gov/news/press-releases/2026/07/08/nc-aquariums-welcome-visitors-unique-underwater-experience-independence-mall-wilmington); [North Carolina Aquariums](https://www.ncaquariums.com/fort-fisher). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #110: SEA LIFE Michigan

**Location:** Great Lakes Crossing Outlets, Auburn Hills, Michigan, United States.

A tunnel and marine galleries bring sharks, rays, sea turtles and jellyfish into the Great Lakes Crossing shopping visit.

**Why go:** The contained indoor route is useful for a shorter marine visit without committing to a full outdoor animal park.

**Key attractions:** Ocean tunnel; Sharks and rays; Sea turtles and jellyfish.

**Venue format:** indoor; inside mall; Great Lakes Crossing Outlets.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/michigan/).

**Plan around:** Aquarium and neighbouring attraction combinations differ. Confirm the specific admission product and time slot.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/michigan/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/michigan/).

**Evidence:** [SEA LIFE Michigan / official publisher](https://www.visitsealife.com/michigan/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #111: SEA LIFE Grapevine

**Location:** Grapevine Mills, Grapevine, Texas, United States.

Ocean Tunnel, Stingray Bay and turtle-rescue interpretation provide distinct viewing themes inside Grapevine Mills.

**Why go:** Its turtle interpretation and indoor route make it a useful aquatic option within a larger family shopping or entertainment day.

**Key attractions:** Ocean Tunnel; Sea Turtle Rescue Center; Stingray Bay and rainforest zone.

**Venue format:** indoor; inside mall; Grapevine Mills.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/grapevine/).

**Plan around:** LEGOLAND and Peppa Pig combinations are not aquarium-only fares. Starting prices are not a quote for every date.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/grapevine/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/grapevine/).

**Evidence:** [SEA LIFE Grapevine / official publisher](https://www.visitsealife.com/grapevine/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #112: SEA LIFE New Jersey

**Location:** American Dream, East Rutherford, New Jersey, United States.

New York-inspired aquatic settings and an ocean tunnel give this American Dream aquarium a metropolitan theme.

**Why go:** The local-city visual theme differentiates this mall aquarium from another standard tunnel attraction.

**Key attractions:** Ocean tunnel; New York-inspired aquatic settings; Sharks and rays.

**Venue format:** indoor; inside mall; American Dream.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/new-jersey/).

**Plan around:** American Dream parking and event-day charges are separate from aquarium admission. Check the selected combination ticket carefully.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/new-jersey/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/new-jersey/).

**Evidence:** [SEA LIFE New Jersey / official publisher](https://www.visitsealife.com/new-jersey/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #113: SEA LIFE Arizona

**Location:** Arizona Mills, Tempe, Arizona, United States.

A 360-degree tunnel, sea turtles and jellyfish provide an indoor aquarium visit inside Arizona Mills.

**Why go:** A fully indoor marine visit is a practical heat-independent option in an inland city, without implying any outdoor weather guarantee.

**Key attractions:** 360-degree ocean tunnel; Sea turtles; Jellyfish exhibits.

**Venue format:** indoor; inside mall; Arizona Mills.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/arizona/).

**Plan around:** LEGO combination tickets cost and include different things. Aquarium availability is separate from mall opening hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/arizona/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/arizona/).

**Evidence:** [SEA LIFE Arizona / official publisher](https://www.visitsealife.com/arizona/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #114: SEA LIFE Charlotte-Concord

**Location:** Concord Mills, Concord, North Carolina, United States.

An ocean tunnel, sea turtles and jellyfish form the aquarium route inside Concord Mills.

**Why go:** A compact, clearly defined aquatic outing adds an indoor alternative within the Concord Mills visitor area.

**Key attractions:** Ocean tunnel; Sea turtles; Jellyfish displays.

**Venue format:** indoor; inside mall; Concord Mills.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/charlotte-concord/).

**Plan around:** Behind-the-scenes activities may be separate. A promotional starting price is not a universal adult ticket.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/charlotte-concord/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/charlotte-concord/).

**Evidence:** [SEA LIFE Charlotte-Concord / official publisher](https://www.visitsealife.com/charlotte-concord/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #115: SEA LIFE Manchester

**Location:** Trafford Palazzo, Manchester, United Kingdom.

Turtle Beach, Shark Shipwreck and Stingray Bay lead into an ocean-tunnel visit beside Manchester's retail attractions.

**Why go:** Several distinct viewing areas make this an accessible-to-discover urban aquarium option within a retail visit.

**Key attractions:** Turtle Beach; Shark Shipwreck; Stingray Bay and Ocean Tunnel.

**Venue format:** indoor; inside mall; Trafford Palazzo.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/manchester/).

**Plan around:** The venue is cashless. LEGO combinations and dedicated animal activities have separate terms; physical accessibility still needs the venue-specific facts.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/manchester/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/manchester/).

**Evidence:** [SEA LIFE Manchester / official publisher](https://www.visitsealife.com/manchester/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #116: SEA LIFE Paris Val d Europe

**Location:** Val d Europe, Serris, France.

Themed aquarium galleries offer an indoor marine visit within Val d'Europe, separate from nearby Disneyland admission.

**Why go:** Its location inside Val d Europe makes it useful as a separate, shorter aquatic outing rather than another theme-park day.

**Key attractions:** Themed aquarium route; Marine-fish galleries; Indoor visit near Disneyland Paris.

**Venue format:** indoor; inside mall; Centre commercial Val d Europe.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/paris/en/).

**Plan around:** This is in Serris, not central Paris. Early-purchase and on-site prices differ; confirm the dated ticket category.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/paris/en/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/paris/en/further-information/contact/). Email: paris@merlinentertainments.biz.

**Evidence:** [SEA LIFE Paris Val d Europe / official publisher](https://www.visitsealife.com/paris/en/); [SEA LIFE Paris](https://www.visitsealife.com/paris/en/further-information/contact/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #117: SEA LIFE Porto

**Location:** Castelo do Queijo waterfront, Porto, Portugal.

Indoor marine galleries provide an aquarium visit at Porto's Atlantic waterfront, rather than a shopping-mall attraction.

**Why go:** A smaller aquarium can be combined with the coastal district without turning the visit into a full resort excursion.

**Key attractions:** Indoor marine galleries; Aquarium viewing route; Atlantic waterfront setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.visitsealife.com/porto/en/).

**Plan around:** Check the operator's exhibit and programme list before travelling for a specific animal. This is not an inside-mall listing.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/porto/en/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/porto/en/).

**Evidence:** [SEA LIFE Porto / official publisher](https://www.visitsealife.com/porto/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #118: Sealand Leon

**Location:** Altacia shopping centre, Leon, Guanajuato, Mexico.

A themed aquarium route provides an indoor marine discovery visit within Altacia, under the Sealand name.

**Why go:** A fully separate aquatic attraction inside an inland shopping centre is a useful discovery beyond coastal travel.

**Key attractions:** Aquarium-based themed route; Marine interpretation; Mall-based discovery visit.

**Venue format:** indoor; inside mall; Altacia.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://altacia.mx/sealand/).

**Plan around:** Preserve Acuario del Bajio as a former-name alias. The mall source confirms the rebrand; current operator tariffs still need confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://altacia.mx/sealand/).

**Contact:** [Official visitor/contact route](https://altacia.mx/sealand/).

**Evidence:** [Sealand Leon / official publisher](https://altacia.mx/sealand/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #119: Acuario Michin Puebla

**Location:** Parque Puebla, Puebla, Mexico.

Aquarium and nature interpretation provide an indoor leisure option within Parque Puebla.

**Why go:** An aquarium within Parque Puebla provides a practical water-life activity in an inland city and an option alongside a retail day.

**Key attractions:** Aquarium route; Aquatic and nature interpretation; Indoor leisure setting.

**Venue format:** indoor; inside mall; Parque Puebla.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.acuariomichin.com/PUE/).

**Plan around:** Puebla tickets are not valid automatically at other Michin branches. Physical games and premium experiences have their own clothing and access rules.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://puebla-es.acuariomichin.com/producto/acceso-total/).

**Contact:** [Official visitor/contact route](https://www.acuariomichin.com/planifica-tu-visita/PUE/horarios-direccion/). Email: info.puebla@acuariomichin.com.

**Evidence:** [Acuario Michin Puebla / official publisher](https://www.acuariomichin.com/PUE/); [Acuario Michin Puebla](https://www.acuariomichin.com/planifica-tu-visita/PUE/horarios-direccion/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Global aquarium #120: Aquarium de La Reunion

**Location:** Port of Saint-Gilles-les-Bains, Reunion, Reunion.

Indian Ocean marine displays and coral-reef education provide a harbour-side aquarium visit at Saint-Gilles.

**Why go:** A local aquarium can add context to a reef or lagoon visit without suggesting visitors enter restricted or unsafe waters.

**Key attractions:** Indian Ocean marine interpretation; Coral-reef education; Saint-Gilles harbour setting.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. Core indoor aquarium viewing is a year-round weather-independent visit format. This is an editorial interpretation of the indoor venue, not confirmation of daily opening, exhibit availability or a live ticket slot. [Season evidence](https://www.reunion.fr/offres/aquarium-de-la-reunion-saint-gilles-les-bains-saint-paul-fr-559652/).

**Plan around:** The source is the official tourism publisher, not a live inventory system. Group visits require advance contact.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.reunion.fr/offres/aquarium-de-la-reunion-saint-gilles-les-bains-saint-paul-fr-559652/).

**Contact:** [Official visitor/contact route](https://www.reunion.fr/offres/aquarium-de-la-reunion-saint-gilles-les-bains-saint-paul-fr-559652/). Email: contact@aquariumdelareunion.com.

**Evidence:** [Aquarium de La Reunion / official publisher](https://www.reunion.fr/offres/aquarium-de-la-reunion-saint-gilles-les-bains-saint-paul-fr-559652/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Mystic Aquarium

**Location:** Mystic, Connecticut, United States.

Mystic Aquarium in Mystic, Connecticut brings together beluga viewing, african penguins and marine conservation interpretation.

**Why go:** Choose this for the contrast between marine-mammal observation and aquarium galleries, rather than a tropical-fish-only visit.

**Key attractions:** Beluga viewing; African penguins; Marine conservation interpretation.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.mysticaquarium.org/).

**Plan around:** Outdoor viewing and separately booked encounters are not covered by an indoor-weather label. Do not reuse the cached August closure notice as a current alert.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.mysticaquarium.org/).

**Contact:** [Official visitor/contact route](https://www.mysticaquarium.org/).

**Evidence:** [Mystic Aquarium / official publisher](https://www.mysticaquarium.org/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: The Maritime Aquarium at Norwalk

**Location:** Norwalk, Connecticut, United States.

The Maritime Aquarium at Norwalk in Norwalk, Connecticut brings together aquarium exhibits, public cruise programme and marine education.

**Why go:** An aquarium visit can become the starting point for a separate on-water learning trip; check the cruise programme before combining them.

**Key attractions:** Aquarium exhibits; Public cruise programme; Marine education.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.maritimeaquarium.org/).

**Plan around:** Cruises and special experiences need their own schedules and ticket checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.maritimeaquarium.org/).

**Contact:** [Official visitor/contact route](https://www.maritimeaquarium.org/).

**Evidence:** [The Maritime Aquarium at Norwalk / official publisher](https://www.maritimeaquarium.org/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Adventure Aquarium

**Location:** Camden waterfront, New Jersey, United States.

Adventure Aquarium in Camden waterfront, New Jersey brings together hippo haven, shark bridge and shark viewing.

**Why go:** The hippo habitat and overhead shark perspective give this aquarium a distinctive route rather than a sequence of similar tanks.

**Key attractions:** Hippo Haven; Shark Bridge; Shark viewing.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.adventureaquarium.com/explore/attractions/).

**Plan around:** The suspension bridge is optional and not a step-free-route assurance. Confirm animal and attraction availability.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.adventureaquarium.com/explore/attractions/).

**Contact:** [Official visitor/contact route](https://www.adventureaquarium.com/explore/attractions/).

**Evidence:** [Adventure Aquarium / official publisher](https://www.adventureaquarium.com/explore/attractions/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Newport Aquarium

**Location:** Newport, Kentucky, United States.

Newport Aquarium in Newport, Kentucky brings together shark bridge, jellies: go with the flow and aquarium galleries.

**Why go:** A choice for visitors who want both immersive shark viewing and a contrasting jellyfish-focused gallery.

**Key attractions:** Shark Bridge; Jellies: Go With The Flow; Aquarium galleries.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.newportaquarium.com/things-to-do/exhibits/).

**Plan around:** Verify the route and any mobility restrictions for the suspended bridge separately from general admission.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.newportaquarium.com/things-to-do/exhibits/).

**Contact:** [Official visitor/contact route](https://www.newportaquarium.com/things-to-do/exhibits/).

**Evidence:** [Newport Aquarium / official publisher](https://www.newportaquarium.com/things-to-do/exhibits/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Loveland Living Planet Aquarium

**Location:** Draper, Utah, United States.

Loveland Living Planet Aquarium in Draper, Utah brings together discover utah, ocean explorer and penguin research station.

**Why go:** Local freshwater interpretation alongside ocean habitats makes this useful for understanding water environments in an inland state.

**Key attractions:** Discover Utah; Ocean Explorer; Penguin Research Station.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://livingplanetaquarium.org/).

**Plan around:** Encounters, theatre and plaza activities may have separate conditions.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://livingplanetaquarium.org/).

**Contact:** [Official visitor/contact route](https://livingplanetaquarium.org/).

**Evidence:** [Loveland Living Planet Aquarium / official publisher](https://livingplanetaquarium.org/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: OdySea Aquarium

**Location:** Scottsdale, Arizona, United States.

OdySea Aquarium in Scottsdale, Arizona brings together penguins, sea turtles and coral displays.

**Why go:** A substantial dry-viewing alternative for a desert itinerary, with contrasting marine habitats rather than a water-sports requirement.

**Key attractions:** Penguins; Sea turtles; Coral displays.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.odyseaaquarium.com/experiences/featured-animals-and-exhibits/).

**Plan around:** SeaTREK is a separate participation product; no medical or age clearance is implied by an aquarium listing.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.odyseaaquarium.com/plan-your-visit/buy-tickets/).

**Contact:** [Official visitor/contact route](https://www.odyseaaquarium.com/experiences/featured-animals-and-exhibits/).

**Evidence:** [OdySea Aquarium / official publisher](https://www.odyseaaquarium.com/experiences/featured-animals-and-exhibits/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Wonders of Wildlife Aquarium Adventure

**Location:** Springfield, Missouri, United States.

Wonders of Wildlife Aquarium Adventure in Springfield, Missouri brings together aquarium adventure, wildlife galleries and conservation exhibits.

**Why go:** Select the aquarium-focused route when a water-themed outing is the priority, and treat the wider museum as an optional extension.

**Key attractions:** Aquarium Adventure; Wildlife galleries; Conservation exhibits.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://wondersofwildlife.org/).

**Plan around:** Check whether the chosen ticket includes both aquarium and wildlife galleries.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://wondersofwildlife.org/).

**Contact:** [Official visitor/contact route](https://wondersofwildlife.org/).

**Evidence:** [Wonders of Wildlife Aquarium Adventure / official publisher](https://wondersofwildlife.org/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Ripley's Aquarium of the Smokies

**Location:** Gatlinburg, Tennessee, United States.

Ripley's Aquarium of the Smokies in Gatlinburg, Tennessee brings together shark lagoon, moving viewing path and penguin displays.

**Why go:** An underwater-viewing outing that provides a different pace from mountain activities without requiring swimming.

**Key attractions:** Shark Lagoon; Moving viewing path; Penguin displays.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.ripleys.com/attractions/ripleys-aquarium-of-the-smokies).

**Plan around:** Do not assume an annual multi-attraction pass and a single aquarium ticket have the same inclusions.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.ripleys.com/attractions/ripleys-aquarium-of-the-smokies).

**Contact:** [Official visitor/contact route](https://www.ripleys.com/attractions/ripleys-aquarium-of-the-smokies).

**Evidence:** [Ripley's Aquarium of the Smokies / official publisher](https://www.ripleys.com/attractions/ripleys-aquarium-of-the-smokies). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Ripley's Aquarium of Myrtle Beach

**Location:** Broadway at the Beach, Myrtle Beach, South Carolina, United States.

Ripley's Aquarium of Myrtle Beach in Broadway at the Beach, Myrtle Beach, South Carolina brings together dangerous reef, moving glidepath and sharks and sawfish.

**Why go:** Use the below-water perspective as an alternative to another beach day, especially for companions who do not enter the sea.

**Key attractions:** Dangerous Reef; Moving glidepath; Sharks and sawfish.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.ripleys.com/attractions/ripleys-aquarium-of-myrtle-beach/exhibits/dangerous-reef).

**Plan around:** Broadway at the Beach is an entertainment complex; this is not automatically an inside-shopping-mall listing.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.ripleys.com/attractions/ripleys-aquarium-of-myrtle-beach).

**Contact:** [Official visitor/contact route](https://www.ripleys.com/attractions/ripleys-aquarium-of-myrtle-beach/exhibits/dangerous-reef).

**Evidence:** [Ripley's Aquarium of Myrtle Beach / official publisher](https://www.ripleys.com/attractions/ripleys-aquarium-of-myrtle-beach/exhibits/dangerous-reef). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: New York Aquarium

**Location:** Coney Island, Brooklyn, New York, United States.

New York Aquarium in Coney Island, Brooklyn, New York brings together ocean wonders: sharks, aquatheater and marine-life interpretation.

**Why go:** The shark-focused gallery makes a water-themed addition to a Coney Island visit without depending on sea conditions.

**Key attractions:** Ocean Wonders: Sharks; Aquatheater; Marine-life interpretation.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://nyaquarium.com/).

**Plan around:** Some experiences are outdoors. The published April-October encounter window is not the aquarium's opening season.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://nyaquarium.com/).

**Contact:** [Official visitor/contact route](https://nyaquarium.com/).

**Evidence:** [New York Aquarium / official publisher](https://nyaquarium.com/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: National SEA LIFE Centre Birmingham

**Location:** Birmingham, United Kingdom.

National SEA LIFE Centre Birmingham in Birmingham brings together 360-degree ocean tunnel, sea-otter interpretation and gentoo penguin area.

**Why go:** The tunnel combines views above and below the visitor, while the mammal exhibits give this city aquarium a different emphasis from a fish-only display.

**Key attractions:** 360-degree ocean tunnel; Sea-otter interpretation; Gentoo penguin area.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/birmingham/).

**Plan around:** The retrieved summer promotion ended on 1 September 2026. Do not reuse its ticket price as a current offer.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/birmingham/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/birmingham/).

**Evidence:** [National SEA LIFE Centre Birmingham / official publisher](https://www.visitsealife.com/birmingham/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Blackpool

**Location:** Blackpool promenade, United Kingdom.

SEA LIFE Blackpool in Blackpool promenade brings together ocean tunnel, rainforest zone and jellyfish and rays.

**Why go:** An indoor marine stop that fits a seaside itinerary when the open coast is not the right choice.

**Key attractions:** Ocean tunnel; Rainforest zone; Jellyfish and rays.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/blackpool/).

**Plan around:** Jurassic or seasonal event branding can change. Shark-snorkelling products require their own eligibility and ticket check.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/blackpool/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/blackpool/).

**Evidence:** [SEA LIFE Blackpool / official publisher](https://www.visitsealife.com/blackpool/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Great Yarmouth

**Location:** Great Yarmouth, United Kingdom.

SEA LIFE Great Yarmouth in Great Yarmouth brings together tropical ocean tunnel, humboldt penguins and jellyfish display.

**Why go:** The penguin, tunnel and jellyfish sequence provides distinct viewing formats instead of repeating one tank style.

**Key attractions:** Tropical ocean tunnel; Humboldt penguins; Jellyfish display.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/great-yarmouth/).

**Plan around:** Published summer discounts and school-holiday events are historical references, not current availability.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/great-yarmouth/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/great-yarmouth/).

**Evidence:** [SEA LIFE Great Yarmouth / official publisher](https://www.visitsealife.com/great-yarmouth/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Hunstanton

**Location:** Hunstanton, Norfolk, United Kingdom.

SEA LIFE Hunstanton in Hunstanton, Norfolk brings together seal hospital, penguin beach and outdoor otter area.

**Why go:** The connection to rescued Norfolk seals adds a local coastal context to a conventional aquarium visit.

**Key attractions:** Seal hospital; Penguin beach; Outdoor otter area.

**Venue format:** mixed; standalone.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/hunstanton/).

**Plan around:** Some animal areas are outdoors. Feedings and close encounters are programme-specific rather than included by default.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/hunstanton/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/hunstanton/).

**Evidence:** [SEA LIFE Hunstanton / official publisher](https://www.visitsealife.com/hunstanton/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Loch Lomond

**Location:** Loch Lomond Shores, Balloch, United Kingdom.

SEA LIFE Loch Lomond in Loch Lomond Shores, Balloch brings together tropical ocean tunnel, rescued-turtle interpretation and otter area.

**Why go:** A dry-viewing alternative for a Loch Lomond day, with different marine environments represented indoors.

**Key attractions:** Tropical ocean tunnel; Rescued-turtle interpretation; Otter area.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/loch-lomond/).

**Plan around:** Aquarium admission and the advertised boat-cruise product are separate choices. Do not infer a cruise timetable from aquarium hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/loch-lomond/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/loch-lomond/).

**Evidence:** [SEA LIFE Loch Lomond / official publisher](https://www.visitsealife.com/loch-lomond/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Scarborough

**Location:** Scarborough, North Yorkshire, United Kingdom.

SEA LIFE Scarborough in Scarborough, North Yorkshire brings together seal hospital, penguin island and otter river.

**Why go:** A useful coastal wildlife learning visit where the rehabilitation story is as relevant as the aquarium tanks.

**Key attractions:** Seal hospital; Penguin Island; Otter River.

**Venue format:** mixed; standalone.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/scarborough/).

**Plan around:** Indoor and outdoor zones need separate weather consideration. Quiet sessions and special feeds require current dates.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/scarborough/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/scarborough/).

**Evidence:** [SEA LIFE Scarborough / official publisher](https://www.visitsealife.com/scarborough/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Weymouth Adventure Park

**Location:** Weymouth, Dorset, United Kingdom.

SEA LIFE Weymouth Adventure Park in Weymouth, Dorset brings together fairy penguins, night-and-day reef display and outdoor splash and play areas.

**Why go:** The mixed marine-and-play format offers a longer family outing than a compact city tank gallery.

**Key attractions:** Fairy penguins; Night-and-day reef display; Outdoor splash and play areas.

**Venue format:** mixed; standalone.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/weymouth/).

**Plan around:** A splash-zone listing does not establish year-round pool operation. Outdoor areas are not a weather-independent fallback.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/weymouth/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/weymouth/).

**Evidence:** [SEA LIFE Weymouth Adventure Park / official publisher](https://www.visitsealife.com/weymouth/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Hannover

**Location:** Hannover, Germany.

SEA LIFE Hannover in Hannover brings together rainforest zone, ocean tunnel and ray lagoon.

**Why go:** Pairs a freshwater rainforest route with marine viewing, making habitat contrasts the main reason to choose it.

**Key attractions:** Rainforest zone; Ocean tunnel; Ray lagoon.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/hannover/en/).

**Plan around:** The operator requests online tickets or reservations and cashless payment. Recheck those requirements for the chosen day.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/hannover/en/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/hannover/en/).

**Evidence:** [SEA LIFE Hannover / official publisher](https://www.visitsealife.com/hannover/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Konstanz

**Location:** Konstanz, Lake Constance, Germany.

SEA LIFE Konstanz in Konstanz, Lake Constance brings together penguins and sharks, aquarium route and lake constance natural-history museum.

**Why go:** The linked natural-history museum connects a broad aquarium visit to the lake outside.

**Key attractions:** Penguins and sharks; Aquarium route; Lake Constance natural-history museum.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/konstanz/en/).

**Plan around:** The source lists museum admission with the aquarium ticket; confirm the current product before comparing bundle prices.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/konstanz/en/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/konstanz/en/).

**Evidence:** [SEA LIFE Konstanz / official publisher](https://www.visitsealife.com/konstanz/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Munich

**Location:** Olympiapark, Munich, Germany.

SEA LIFE Munich in Olympiapark, Munich brings together isar and danube habitat sequence, shark displays and jellyfish and seahorses.

**Why go:** The river-to-sea route gives inland visitors a geographic narrative rather than an unrelated sequence of tanks.

**Key attractions:** Isar and Danube habitat sequence; Shark displays; Jellyfish and seahorses.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/muenchen/en/).

**Plan around:** Shark-themed weeks are dated programmes. Exhibited marine habitats do not create a real Mediterranean location join.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/muenchen/en/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/muenchen/en/).

**Evidence:** [SEA LIFE Munich / official publisher](https://www.visitsealife.com/muenchen/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Oberhausen

**Location:** Oberhausen, Germany.

SEA LIFE Oberhausen in Oberhausen brings together shark nursery, ocean tunnel and rhine and north sea themes.

**Why go:** The nursery provides a distinct life-cycle perspective alongside the familiar large-tank viewing route.

**Key attractions:** Shark nursery; Ocean tunnel; Rhine and North Sea themes.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/oberhausen/en/).

**Plan around:** Online starting fares and ticket-office fares are different products. Combinations with other attractions do not establish that the aquarium is inside a mall.

**Published price reference:** EUR 19 / online starting admission. from. Online starting fares and ticket-office fares are different products. Combinations with other attractions do not establish that the aquarium is inside a mall. Not a live or all-in quote. [Publisher](https://www.visitsealife.com/oberhausen/en/).

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/oberhausen/en/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/oberhausen/en/).

**Evidence:** [SEA LIFE Oberhausen / official publisher](https://www.visitsealife.com/oberhausen/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Timmendorfer Strand

**Location:** Timmendorfer Strand, Baltic coast, Germany.

SEA LIFE Timmendorfer Strand in Timmendorfer Strand, Baltic coast brings together baltic sea interpretation, north sea habitats and tropical ocean tunnel.

**Why go:** Local Baltic conservation context makes it relevant to a beach holiday even when swimming is not the planned activity.

**Key attractions:** Baltic Sea interpretation; North Sea habitats; Tropical ocean tunnel.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/timmendorfer-strand/en/).

**Plan around:** The aquarium-and-Ostsee-Therme combination is a separate ticket, not a second aquarium or automatic spa admission.

**Published price reference:** EUR 16.5 / online starting admission. from. The aquarium-and-Ostsee-Therme combination is a separate ticket, not a second aquarium or automatic spa admission. Not a live or all-in quote. [Publisher](https://www.visitsealife.com/timmendorfer-strand/en/).

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/timmendorfer-strand/en/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/timmendorfer-strand/en/).

**Evidence:** [SEA LIFE Timmendorfer Strand / official publisher](https://www.visitsealife.com/timmendorfer-strand/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Benalmadena

**Location:** Benalmadena, Spain.

SEA LIFE Benalmadena in Benalmadena brings together ray island, otter area and underwater tunnel.

**Why go:** Compact dry viewing adds a different activity to a Costa del Sol coastal itinerary.

**Key attractions:** Ray island; Otter area; Underwater tunnel.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/benalmadena/).

**Plan around:** The advertised bioluminescent exhibit is an aquarium experience, not evidence of a nearby natural glowing bay.

**Published price reference:** EUR 18.5 / online starting admission. from. The advertised bioluminescent exhibit is an aquarium experience, not evidence of a nearby natural glowing bay. Not a live or all-in quote. [Publisher](https://www.visitsealife.com/benalmadena/).

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/benalmadena/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/benalmadena/).

**Evidence:** [SEA LIFE Benalmadena / official publisher](https://www.visitsealife.com/benalmadena/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Blankenberge

**Location:** Blankenberge, Belgium.

SEA LIFE Blankenberge in Blankenberge brings together seal rescue centre, humboldt penguins and otters.

**Why go:** The seal centre links the visit to the Belgian coast and distinguishes it from a purely decorative aquarium.

**Key attractions:** Seal rescue centre; Humboldt penguins; Otters.

**Venue format:** mixed; standalone.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/blankenberge/).

**Plan around:** Animal care claims are publisher statements. Summer events and feeding times require a current programme check.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/blankenberge/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/blankenberge/).

**Evidence:** [SEA LIFE Blankenberge / official publisher](https://www.visitsealife.com/blankenberge/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Helsinki

**Location:** Helsinki, Finland.

SEA LIFE Helsinki in Helsinki brings together underwater tunnel, seahorses and rays and rainforest fish.

**Why go:** A dry indoor option whose habitat variety makes it useful beyond the summer beach season.

**Key attractions:** Underwater tunnel; Seahorses and rays; Rainforest fish.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/helsinki/).

**Plan around:** Touch and feeding sessions follow staff instructions and the current programme; no unrestricted animal contact is implied.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/helsinki/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/helsinki/).

**Evidence:** [SEA LIFE Helsinki / official publisher](https://www.visitsealife.com/helsinki/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Aquarium Carlsbad

**Location:** Carlsbad, California, United States.

SEA LIFE Aquarium Carlsbad in Carlsbad, California brings together ocean tunnel, rockpool learning and aquarist talks.

**Why go:** A child-oriented introduction to marine life with a separate aquarium-only ticket route, avoiding the need to plan a full theme-park day.

**Key attractions:** Ocean tunnel; Rockpool learning; Aquarist talks.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.legoland.com/california/things-to-do/sea-life-aquarium/).

**Plan around:** The operator restricts strollers on most days. Aquarium-only admission and park-hopper products are not interchangeable.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.legoland.com/california/things-to-do/sea-life-aquarium/).

**Contact:** [Official visitor/contact route](https://www.legoland.com/california/things-to-do/sea-life-aquarium/).

**Evidence:** [SEA LIFE Aquarium Carlsbad / official publisher](https://www.legoland.com/california/things-to-do/sea-life-aquarium/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Florida

**Location:** Winter Haven, Florida, United States.

SEA LIFE Florida in Winter Haven, Florida brings together florida wetlands gallery, stingray bay and ocean tunnel.

**Why go:** Combines a freshwater Florida theme with ocean viewing within a larger park visit.

**Key attractions:** Florida wetlands gallery; Stingray bay; Ocean tunnel.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.legoland.com/florida/things-to-do/sea-life-florida/).

**Plan around:** The source says standalone aquarium tickets are unavailable and admission is tied to eligible LEGOLAND tickets. Do not invent a separate aquarium fare.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.legoland.com/florida/things-to-do/sea-life-florida/).

**Contact:** [Official visitor/contact route](https://www.legoland.com/florida/things-to-do/sea-life-florida/).

**Evidence:** [SEA LIFE Florida / official publisher](https://www.legoland.com/florida/things-to-do/sea-life-florida/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Orlando

**Location:** ICON Park, Orlando, Florida, United States.

SEA LIFE Orlando in ICON Park, Orlando, Florida brings together 360-degree ocean tunnel, jelly wall and rockpool interpretation.

**Why go:** The wraparound tunnel is the key attraction for visitors seeking a compact indoor marine experience rather than an outdoor park.

**Key attractions:** 360-degree ocean tunnel; Jelly wall; Rockpool interpretation.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/orlando/).

**Plan around:** The listed behind-the-scenes supplement is not the full admission price. Resident and combination products have separate eligibility.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/orlando/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/orlando/).

**Evidence:** [SEA LIFE Orlando / official publisher](https://www.visitsealife.com/orlando/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Sunshine Coast

**Location:** Mooloolaba, Queensland, Australia.

SEA LIFE Sunshine Coast in Mooloolaba, Queensland brings together long ocean tunnel, little blue penguins and seahorse kingdom.

**Why go:** The penguin and seahorse exhibits complement the large-tank route and give a Sunshine Coast trip a dry-viewing alternative.

**Key attractions:** Long ocean tunnel; Little blue penguins; Seahorse Kingdom.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/sunshine-coast/).

**Plan around:** Exhibit listings are not promises that a particular animal or optional encounter will be available.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/sunshine-coast/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/sunshine-coast/).

**Evidence:** [SEA LIFE Sunshine Coast / official publisher](https://www.visitsealife.com/sunshine-coast/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Kansas City

**Location:** Crown Center, Kansas City, Missouri, United States.

SEA LIFE Kansas City in Crown Center, Kansas City, Missouri brings together ocean tunnel, sea turtle rescue center and stingray bay.

**Why go:** The turtle-rescue interpretation adds substance to a compact indoor aquarium stop in a wider city itinerary.

**Key attractions:** Ocean tunnel; Sea Turtle Rescue Center; Stingray Bay.

**Venue format:** indoor; inside mall; Crown Center.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/kansas-city/).

**Plan around:** Single aquarium admission, virtual-reality upgrades and LEGOLAND Discovery Center bundles are different products. Cached summer prices are not current quotes.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/kansas-city/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/kansas-city/).

**Evidence:** [SEA LIFE Kansas City / official publisher](https://www.visitsealife.com/kansas-city/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE San Antonio

**Location:** Shops at Rivercenter, San Antonio, Texas, United States.

SEA LIFE San Antonio in Shops at Rivercenter, San Antonio, Texas brings together underwater tunnel, aquarium galleries and scheduled talks.

**Why go:** Use it as a dry-viewing addition to a downtown visit, rather than treating a mall aquarium as a full marine excursion.

**Key attractions:** Underwater tunnel; Aquarium galleries; Scheduled talks.

**Venue format:** indoor; inside mall; Shops at Rivercenter.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/san-antonio/).

**Plan around:** The published starting fare and multi-attraction combo are distinct. Confirm date, currency and current exhibit availability.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/san-antonio/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/san-antonio/).

**Evidence:** [SEA LIFE San Antonio / official publisher](https://www.visitsealife.com/san-antonio/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Shanghai Changfeng Ocean World

**Location:** Changfeng, Shanghai, China.

Shanghai Changfeng Ocean World in Changfeng, Shanghai brings together ray starry night, african penguins and coral-reef displays.

**Why go:** A separate Shanghai aquarium choice with ray and penguin zones; it is not the Shanghai Ocean Aquarium already in the catalogue.

**Key attractions:** Ray Starry Night; African penguins; Coral-reef displays.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/shanghai-changfeng-ocean-world/).

**Plan around:** Operator identity and gallery information are sourced. Current admission, seasonal hours and an exact entrance need confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/shanghai-changfeng-ocean-world/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/shanghai-changfeng-ocean-world/).

**Evidence:** [Shanghai Changfeng Ocean World / official publisher](https://www.visitsealife.com/shanghai-changfeng-ocean-world/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Shenyang

**Location:** Third floor, Shenyang K11 Shopping Art Center, China.

SEA LIFE Shenyang in Third floor, Shenyang K11 Shopping Art Center brings together ocean tunnel, coral reefs and sunken treasure zone.

**Why go:** The explicit mall-floor location makes this a practical aquarium stop within a shopping and art-complex visit.

**Key attractions:** Ocean tunnel; Coral reefs; Sunken Treasure zone.

**Venue format:** indoor; inside mall; Shenyang K11 Shopping Art Center.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/sea-life-shenyang/).

**Plan around:** Follow the operator route to third-floor units 3043-3044. Mall opening does not guarantee aquarium admission.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/sea-life-shenyang/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/sea-life-shenyang/).

**Evidence:** [SEA LIFE Shenyang / official publisher](https://www.visitsealife.com/sea-life-shenyang/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Malaysia

**Location:** LEGOLAND Malaysia Resort, Iskandar Puteri, Malaysia.

SEA LIFE Malaysia in LEGOLAND Malaysia Resort, Iskandar Puteri brings together ocean tunnel, rockpool interpretation and multiple aquatic habitat zones.

**Why go:** A water-themed visit without rides or swimming, useful when a group wants a different pace within the resort.

**Key attractions:** Ocean Tunnel; Rockpool interpretation; Multiple aquatic habitat zones.

**Venue format:** indoor; within resort; LEGOLAND Malaysia Resort.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.legoland.com.my/explore/sea-life-aquarium/).

**Plan around:** Aquarium, water-park and theme-park admission are separate products unless the chosen ticket expressly bundles them. Ignore cached navigation closure labels as live notices.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.legoland.com.my/explore/sea-life-aquarium/).

**Contact:** [Official visitor/contact route](https://www.legoland.com.my/explore/sea-life-aquarium/).

**Evidence:** [SEA LIFE Malaysia / official publisher](https://www.legoland.com.my/explore/sea-life-aquarium/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Nagoya

**Location:** LEGOLAND Japan Resort, Nagoya, Japan.

SEA LIFE Nagoya in LEGOLAND Japan Resort, Nagoya brings together child-focused aquatic galleries, themed discovery areas and optional behind-the-scenes programme.

**Why go:** Its child-led learning format complements a family resort visit and is distinct from the Port of Nagoya Public Aquarium.

**Key attractions:** Child-focused aquatic galleries; Themed discovery areas; Optional behind-the-scenes programme.

**Venue format:** indoor; within resort; LEGOLAND Japan Resort.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.legoland.jp/resort-guide/sealife-nagoya/).

**Plan around:** A temporary shark programme is not a permanent attraction or all-year event. Confirm admission independently of the theme park.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.legoland.jp/resort-guide/sealife-nagoya/).

**Contact:** [Official visitor/contact route](https://www.legoland.jp/resort-guide/sealife-nagoya/).

**Evidence:** [SEA LIFE Nagoya / official publisher](https://www.legoland.jp/resort-guide/sealife-nagoya/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: SEA LIFE Scheveningen

**Location:** Scheveningen, The Hague, Netherlands.

SEA LIFE Scheveningen in Scheveningen, The Hague brings together dutch-coast interpretation, ocean tunnel and jellyfish displays.

**Why go:** The local-coast-to-ocean theme gives an indoor counterpart to a North Sea seaside visit.

**Key attractions:** Dutch-coast interpretation; Ocean tunnel; Jellyfish displays.

**Venue format:** indoor; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.visitsealife.com/scheveningen/).

**Plan around:** Online admission includes a selected time slot. The page has an undated July reopening message; confirm current operation instead of converting that into a live alert.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitsealife.com/scheveningen/).

**Contact:** [Official visitor/contact route](https://www.visitsealife.com/scheveningen/).

**Evidence:** [SEA LIFE Scheveningen / official publisher](https://www.visitsealife.com/scheveningen/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Atlantis by SEA LIFE at LEGOLAND Billund

**Location:** Imagination Zone, LEGOLAND Billund, Denmark.

Atlantis by SEA LIFE at LEGOLAND Billund in Imagination Zone, LEGOLAND Billund brings together underwater tunnel, lego shipwreck theming and shark and ray viewing.

**Why go:** An aquarium sequence inside a theme-park day rather than a separate full-scale aquarium destination.

**Key attractions:** Underwater tunnel; LEGO shipwreck theming; Shark and ray viewing.

**Venue format:** indoor; within park; LEGOLAND Billund.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.legoland.dk/udforsk/parken/forlystelser/atlantis-by-sea-life/).

**Plan around:** The retrieved page is over a year old. The indoor format does not override the parent park operating calendar; no standalone aquarium ticket is established.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.legoland.dk/udforsk/parken/forlystelser/atlantis-by-sea-life/).

**Contact:** [Official visitor/contact route](https://www.legoland.dk/udforsk/parken/forlystelser/atlantis-by-sea-life/).

**Evidence:** [Atlantis by SEA LIFE at LEGOLAND Billund / official publisher](https://www.legoland.dk/udforsk/parken/forlystelser/atlantis-by-sea-life/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Aqua World Ibaraki Oarai Aquarium

**Location:** Oarai, Ibaraki, Japan.

Aqua World Ibaraki Oarai Aquarium in Oarai, Ibaraki brings together ibaraki sea-life tank, jellyfish 365 and marine specimens.

**Why go:** The local continental-shelf and coastal interpretation gives context to the displays rather than treating every tank as a generic ocean.

**Key attractions:** Ibaraki sea-life tank; Jellyfish 365; Marine specimens.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://en.aquaworld-oarai.com/floor/zone/).

**Plan around:** Night Aqua World requires a separate special ticket. Food-court works are not a closure of the whole aquarium.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://en.aquaworld-oarai.com/guide/admission/).

**Contact:** [Official visitor/contact route](https://en.aquaworld-oarai.com/floor/zone/).

**Evidence:** [Aqua World Ibaraki Oarai Aquarium / official publisher](https://en.aquaworld-oarai.com/floor/zone/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Kujukushima Aquarium Umi Kirara

**Location:** Kujukushima Pearl Sea Resort, Sasebo, Nagasaki, Japan.

Kujukushima Aquarium Umi Kirara in Kujukushima Pearl Sea Resort, Sasebo, Nagasaki brings together kujukushima bay tank, jellyfish interpretation and outdoor marine viewing.

**Why go:** The nearby bay is the subject of the aquarium, making it a useful introduction before a separately arranged islands cruise.

**Key attractions:** Kujukushima bay tank; Jellyfish interpretation; Outdoor marine viewing.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.pearlsea.jp/en/educational_trip/school_trip_umikirara/).

**Plan around:** This is a mixed indoor/outdoor visit. The aquarium ticket is not a cruise ticket or an encounter authorisation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.umikirara.jp/en/).

**Contact:** [Official visitor/contact route](https://www.pearlsea.jp/en/educational_trip/school_trip_umikirara/).

**Evidence:** [Kujukushima Aquarium Umi Kirara / official publisher](https://www.pearlsea.jp/en/educational_trip/school_trip_umikirara/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Shikoku Aquarium

**Location:** Utazurinkai Park, Utazu, Kagawa, Japan.

Shikoku Aquarium in Utazurinkai Park, Utazu, Kagawa brings together seto inland sea and pacific habitats, shikoku freshwater interpretation and waterscape-led galleries.

**Why go:** The island's connected rivers and surrounding seas form a coherent regional theme rather than a collection ranked only by tank size.

**Key attractions:** Seto Inland Sea and Pacific habitats; Shikoku freshwater interpretation; Waterscape-led galleries.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.shikoku-aquarium.jp/en/).

**Plan around:** Mixed indoor/outdoor sections and special programmes need their own operating checks. Reduced fares use precise age categories.

**Published price reference:** JPY 2600 / individual adult aged 16+. published reference. Group fares are separate; ages 7-15 and 3-6 have distinct rates. Confirm the visit date. Not a live or all-in quote. [Publisher](https://www.shikoku-aquarium.jp/en/).

**Tickets/access:** [Official ticket / operator information](https://www.shikoku-aquarium.jp/en/).

**Contact:** [Official visitor/contact route](https://www.shikoku-aquarium.jp/en/). Telephone: +81 877 49 4590.

**Evidence:** [Shikoku Aquarium / official publisher](https://www.shikoku-aquarium.jp/en/); [Shikoku Aquarium / official publisher](https://shikoku-tourism.com/en/see-and-do/13753). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Marine World Uminonakamichi

**Location:** Uminonakamichi, Fukuoka, Japan.

Marine World Uminonakamichi in Uminonakamichi, Fukuoka brings together panoramic marine tank, kyushu marine interpretation and shark specimen displays.

**Why go:** A regional marine-learning stop on the Uminonakamichi peninsula, distinct from an open-water wildlife trip.

**Key attractions:** Panoramic marine tank; Kyushu marine interpretation; Shark specimen displays.

**Venue format:** mixed; standalone.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.crossroadfukuoka.jp/en/experience/12373).

**Plan around:** Live shows, outdoor areas and the wider seaside park have separate schedules and access conditions. Do not treat an aquarium listing as a welfare certification.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://marine-world.jp/).

**Contact:** [Official visitor/contact route](https://www.crossroadfukuoka.jp/en/experience/12373).

**Evidence:** [Marine World Uminonakamichi / official publisher](https://www.crossroadfukuoka.jp/en/experience/12373). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

## Aquariums inside shopping malls

This list excludes mall-adjacent and convention-centre venues. Read the full card above using the global aquarium number.

| Global aquarium position | Aquarium | Mall | Location |
| ---: | --- | --- | --- |
| 32 | Aquaria Phuket | Central Phuket Floresta, B1 | Central Phuket Floresta, Phuket |
| 33 | SEA LIFE Bangkok Ocean World | Siam Paragon | Siam Paragon, Bangkok |
| 34 | Dubai Aquarium & Underwater Zoo | Dubai Mall | Dubai Mall, Dubai |
| 35 | SEA LIFE COEX Aquarium | Starfield COEX Mall, B1 | Starfield COEX Mall, Gangnam, Seoul |
| 56 | Sumida Aquarium | Tokyo Solamachi, Tokyo Skytree Town | Tokyo Solamachi, Sumida, Tokyo |
| 77 | Jakarta Aquarium & Safari | Central Park 2 / Neo Soho, LG-LGM | Central Park 2 / Neo Soho, West Jakarta |
| 78 | Lotte World Aquarium Hanoi | Lotte Mall West Lake, B1-B2 | Lotte Mall West Lake Hanoi |
| 83 | Emaar Aquarium & Underwater Zoo | Emaar Square Mall | Emaar Square Mall, Uskudar, Istanbul |
| 89 | SEA LIFE Minnesota | Mall of America | Mall of America, Bloomington, Minnesota |
| 90 | Tropicarium Budapest | Campona | Campona shopping centre, Budapest |
| 99 | Lotte World Aquarium Seoul | Lotte World Mall | Lotte World Mall, Jamsil, Seoul |
| 105 | Vinpearl Aquarium Times City | Vincom Mega Mall Times City | Times City, Hanoi |
| 106 | Oman Aquarium | Mall of Muscat | Mall of Muscat, Al Seeb |
| 107 | Bahrain Aquarium | Mall of Dilmunia | Mall of Dilmunia, Galali |
| 108 | Aquadream at Morocco Mall | Morocco Mall | Morocco Mall, Casablanca |
| 109 | Discovery Bay mini-aquarium | Independence Mall | Independence Mall, Wilmington, North Carolina |
| 110 | SEA LIFE Michigan | Great Lakes Crossing Outlets | Great Lakes Crossing Outlets, Auburn Hills, Michigan |
| 111 | SEA LIFE Grapevine | Grapevine Mills | Grapevine Mills, Grapevine, Texas |
| 112 | SEA LIFE New Jersey | American Dream | American Dream, East Rutherford, New Jersey |
| 113 | SEA LIFE Arizona | Arizona Mills | Arizona Mills, Tempe, Arizona |
| 114 | SEA LIFE Charlotte-Concord | Concord Mills | Concord Mills, Concord, North Carolina |
| 115 | SEA LIFE Manchester | Trafford Palazzo | Trafford Palazzo, Manchester |
| 116 | SEA LIFE Paris Val d Europe | Centre commercial Val d Europe | Val d Europe, Serris |
| 118 | Sealand Leon | Altacia | Altacia shopping centre, Leon, Guanajuato |
| 119 | Acuario Michin Puebla | Parque Puebla | Parque Puebla, Puebla |
| Discovery | SEA LIFE Kansas City | Crown Center | Crown Center, Kansas City, Missouri |
| Discovery | SEA LIFE San Antonio | Shops at Rivercenter | Shops at Rivercenter, San Antonio, Texas |
| Discovery | SEA LIFE Shenyang | Shenyang K11 Shopping Art Center | Third floor, Shenyang K11 Shopping Art Center |

## Top 200 water experiences

This preserved selection spans multiple activity families. Coarse editorial scores tie; the list position does not imply a measured quality gap. Aquariums have a separate list, rather than displacing swimming and outdoor experiences.

### Water rank #1: Whitehaven Beach and Hill Inlet area

**Location:** Whitsunday Island, Australia.

An island beach and tidal coastal landscape, visited by boat as part of a Whitsunday outing.

**Why go:** Island beach, tidal landscape and limited development give this a distinctive setting. Transport, tides and basic facilities are the practical trade-offs.

**Key attractions:** Whitehaven Beach; Hill Inlet tidal landscape; Protected island setting.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Protected island beach; regional drier-season context. Boat access, tides and current conditions need checking. [Season evidence](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://parks.qld.gov.au/parks/whitsunday-islands/attractions/whitehaven-beach-day-use-area).

**Contact:** [Official visitor/contact route](https://parks.qld.gov.au/parks/whitsunday-islands/attractions/whitehaven-beach-day-use-area).

**Evidence:** [Queensland Parks](https://parks.qld.gov.au/parks/whitsunday-islands/attractions/whitehaven-beach-day-use-area); [Tourism Australia](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Milford Sound scenic cruise

**Location:** Milford Sound, New Zealand.

A boat journey through Milford Sound brings the fjord landscape into view without committing to a kayaking activity.

**Why go:** Choose the cruise for a fjord-scale landscape seen from the water without the demands of a kayak trip. It is a distinct option from a coach transfer or a full-day package.

**Key attractions:** Fjord-scale scenery; Water-level viewpoint; Marine wildlife, when encountered.

**Season, operator program:** Not established. No complete dated annual calendar extracted. [Season evidence](https://www.realnz.com/en/experiences/day-cruises/).

**Season, New Zealand fur seal:** All months. Resident fur seals are described through the year. Boat operation, road access and individual sailings remain separate checks. [Season evidence](https://www.realnz.com/en/experiences/day-cruises/milford-sound-classic-cruise/).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Published price reference:** NZD 179 / person_trip. from. Cruise only, not coach transport from Queenstown. Not a live or all-in quote. [Publisher](https://www.realnz.com/en/experiences/day-cruises/).

**Tickets/access:** [Official ticket / operator information](https://www.realnz.com/en/experiences/day-cruises/).

**Contact:** [Official visitor/contact route](https://www.realnz.com/en/experiences/day-cruises/).

**Evidence:** [RealNZ](https://www.realnz.com/en/experiences/day-cruises/); [RealNZ](https://www.realnz.com/en/experiences/day-cruises/milford-sound-classic-cruise/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Naeroyfjord scenic crossing

**Location:** Flam and Gudvangen, Norway.

A scenic crossing connects the Naeroyfjord and Aurlandsfjord landscape with Gudvangen.

**Why go:** The journey itself is the attraction: a fjord crossing can connect places while supplying the scenic experience. It earns a place independently of any packaged rail or bus circuit.

**Key attractions:** Naeroyfjord; Aurlandsfjord; Scenic one-way water journey.

**Season, operator program:** All months. Advertised throughout the year; winter routing can change. [Season evidence](https://www.norwaysbest.com/en/flam/things-to-do/fjord-cruise-naeroyfjord).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.norwaysbest.com/en/flam/things-to-do/fjord-cruise-naeroyfjord).

**Contact:** [Official visitor/contact route](https://www.norwaysbest.com/en/flam/things-to-do/fjord-cruise-naeroyfjord).

**Evidence:** [Norways Best](https://www.norwaysbest.com/en/flam/things-to-do/fjord-cruise-naeroyfjord). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Galapagos seasonal diving

**Location:** Galapagos Islands, Ecuador.

An expedition-style dive destination where underwater wildlife opportunities and water conditions vary through the year.

**Why go:** A specialist underwater wildlife proposition with strong seasonal contrasts. Currents, qualification and the actual itinerary remain separate from the scenic score.

**Key attractions:** Underwater wildlife; Seasonal whale-shark opportunity; Island dive itinerary.

**Season, typical conditions:** Dec, Jan, Feb, Mar, Apr, May. Warmer period with generally milder currents; conditions remain site-dependent. [Season evidence](https://blog.padi.com/best-liveaboards-galapagos/).

**Season, whale_shark:** Jun, Jul, Aug, Sep, Oct, Nov. Cooler-season whale-shark encounters highlighted by PADI. [Season evidence](https://blog.padi.com/best-liveaboards-galapagos/).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Contact:** [Official visitor/contact route](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [PADI](https://blog.padi.com/best-liveaboards-galapagos/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Raja Ampat seasonal reef diving

**Location:** Raja Ampat, Indonesia.

A dispersed island archipelago offers a reef-led diving journey across different sites and habitats.

**Why go:** A reef-led island destination with multiple habitats and sites. Compare the exact dive region and route rather than treating an entire archipelago as one departure.

**Key attractions:** Island reefs; Multiple dive habitats; Archipelago scenery.

**Season, typical conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr. PADI identifies October-April as the favoured regional window. [Season evidence](https://www.padi.com/diving-in/raja-ampat/).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Contact:** [Official visitor/contact route](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [PADI](https://www.padi.com/diving-in/raja-ampat/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Similan Islands diving and snorkelling

**Location:** Similan Islands, Phang Nga, Thailand.

Offshore islands and marine-park reefs create a seasonal diving and snorkelling destination in the Andaman Sea.

**Why go:** The marine-park setting and offshore island reefs make this a destination-led dive choice. Its defined access season gives the calendar practical importance.

**Key attractions:** Offshore island reefs; Marine-park setting; Seasonal access window.

**Season, typical conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr. Regional Andaman seasonal guidance; October is only partially open under the park calendar. [Season evidence](https://www.padi.com/diving-in/thailand/).

**Season, legal window:** Oct, Nov, Dec, Jan, Feb, Mar, Apr, May. Park authority gives 15 October to 15 May, subject to later notices. Published date window: {"start": "10-15", "end": "05-15"}. [Season evidence](https://news.dnp.go.th/news/48044).

**Published restriction:** Seasonal park closure from 16 May to 14 October; later park notices can change access. [Source](https://news.dnp.go.th/news/48044).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://news.dnp.go.th/news/50049).

**Contact:** [Official visitor/contact route](https://news.dnp.go.th/news/50049).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [PADI](https://www.padi.com/diving-in/thailand/); [Thailand Department of National Parks](https://news.dnp.go.th/news/50049); [Thailand Department of National Parks](https://news.dnp.go.th/news/48044). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Tubbataha liveaboard diving

**Location:** Tubbataha Reefs, Palawan, Philippines.

Remote reefs make this a liveaboard-led expedition rather than an easy shore-based dive excursion.

**Why go:** An offshore reef expedition with a tightly bounded visiting season. Its attractiveness does not reduce the required diving competence, travel commitment or permit checks.

**Key attractions:** Offshore reef expedition; Remote marine setting; Defined visiting season.

**Season, typical conditions:** Mar, Apr, May, Jun. Park describes access from mid-March to mid-June; exact annual dates need confirmation. [Season evidence](https://tubbatahareefs.org/f/tubbataha-reefs-southeast-asia%E2%80%99s-best-dive-destination-for-2025?blogcategory=Mama+Ranger+Diaries&page_id=162).

**Published restriction:** Entry permit and authorised vessel required. Verify current permitted season and conservation charge. [Source](https://tubbatahareefs.org/permits-and-fees).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Published price reference:** PHP 5000 / permit_person. published reference. Do not display as the price of a dive trip; under-13 exemption is published. Not a live or all-in quote. [Publisher](https://tubbatahareefs.org/permits-and-fees).

**Tickets/access:** [Published fee or access information](https://tubbatahareefs.org/permits-and-fees).

**Contact:** [Official visitor/contact route](https://tubbatahareefs.org/permits-and-fees).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [Tubbataha Management Office](https://tubbatahareefs.org/f/tubbataha-reefs-southeast-asia%E2%80%99s-best-dive-destination-for-2025?blogcategory=Mama+Ranger+Diaries&page_id=162); [Tubbataha Management Office](https://tubbatahareefs.org/permits-and-fees). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Milford Sound guided kayaking

**Location:** Milford Sound / Piopiotahi, New Zealand.

Guided kayaking offers a paddle-level view of Milford Sound, distinct from the scenic-cruise experience.

**Why go:** The fjord setting and water-level viewpoint drive this assessment. The operator highlights calmer winter conditions, which a simple warm-weather ranking would miss.

**Key attractions:** Fjord landscape; Water-level paddling; Operator-defined route options.

**Season, operator conditions:** Apr, May, Jun, Jul, Aug, Sep, Oct. Operator describes calmer winter kayaking, despite colder air. [Season evidence](https://www.roscosmilfordkayaks.com/faqs/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.roscosmilfordkayaks.com/faqs/).

**Contact:** [Official visitor/contact route](https://www.roscosmilfordkayaks.com/faqs/).

**Evidence:** [Tourism New Zealand](https://www.newzealand.com/nz/feature/top-experiences-in-fiordland/); [Roscos Milford Kayaks](https://www.roscosmilfordkayaks.com/faqs/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Great Astrolabe Reef snorkel discovery

**Location:** Kadavu, Fiji.

A named Fijian reef region provides a destination-led snorkelling option beyond a generic resort beach.

**Why go:** A named reef region offers a more specific Fiji discovery than an undifferentiated resort snorkel. Choose the exact departure and reef itinerary rather than the country label.

**Key attractions:** Great Astrolabe Reef; Reef-region exploration; Local boat-based outings.

**Season, underwater visibility:** Jun, Jul, Aug. Tourism publisher highlights these months for reef visibility. [Season evidence](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Contact:** [Official visitor/contact route](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Evidence:** [Tourism Fiji](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide); [Tourism Fiji](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Hanifaru Bay manta feeding season

**Location:** Hanifaru Bay, Baa Atoll, Maldives.

Seasonal manta feeding brings a specific wildlife focus to snorkelling at Hanifaru Bay.

**Why go:** The attraction is the seasonal feeding aggregation, not a generic Maldives beach. Snorkelling access and conservation controls matter more than a high all-time score.

**Key attractions:** Reef manta feeding aggregation; Seasonal wildlife observation; Regulated snorkelling area.

**Season, reef_manta:** May, Jun, Jul, Aug, Sep, Oct, Nov, Dec. Southwest-monsoon feeding period; aggregation is not guaranteed on any day. [Season evidence](https://www.mantatrust.org/the-cyclone-exclusive-content/2022/01/27/learning-about-zooplankton).

**Season, biological event:** May, Jun, Jul, Aug, Sep, Oct, Nov, Dec. Plankton feeding aggregation; tide and conditions matter. This is not a breeding claim. [Season evidence](https://www.mantatrust.org/the-cyclone-exclusive-content/2022/01/27/learning-about-zooplankton).

**Published restriction:** Scuba diving is prohibited inside Hanifaru Bay. [Source](https://www.cms.int/publication/elasmobranch-tourism-factsheets-maldives).

**Published restriction:** Obtain current authorised visit, guide and permit details; visitor controls apply. [Source](https://www.maldivesmantaconservation.org/protected-areas).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.maldivesmantaconservation.org/protected-areas).

**Contact:** [Official visitor/contact route](https://www.maldivesmantaconservation.org/protected-areas).

**Evidence:** [Maldives Manta Conservation Programme](https://www.maldivesmantaconservation.org/protected-areas); [Convention on Migratory Species](https://www.cms.int/publication/elasmobranch-tourism-factsheets-maldives); [Manta Trust](https://www.mantatrust.org/the-cyclone-exclusive-content/2022/01/27/learning-about-zooplankton). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Komodo boat-and-reef discovery

**Location:** Labuan Bajo / Komodo, Indonesia.

Boat-based reef visits combine Komodo island scenery with underwater exploration at selected stops.

**Why go:** Choose this for reef discovery woven into an island boat itinerary. The attraction is the combination of protected-island scenery and underwater stops, not a guaranteed species list.

**Key attractions:** Island scenery; Reef snorkelling; Multi-stop boat format.

**Season, regional conditions:** Apr, May, Jun, Jul, Aug, Sep, Oct, Nov. North/central Komodo dry-season context, not a whole-park rule for every reef. [Season evidence](https://www.padi.com/diving-in/komodo/).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.indonesia.travel/gb/en/destination/bali-nusa-tenggara/east-nusa-tenggara/snorkeling-komodo-island).

**Contact:** [Official visitor/contact route](https://www.indonesia.travel/gb/en/destination/bali-nusa-tenggara/east-nusa-tenggara/snorkeling-komodo-island).

**Evidence:** [Indonesia Ministry of Tourism](https://www.indonesia.travel/gb/en/destination/bali-nusa-tenggara/east-nusa-tenggara/snorkeling-komodo-island); [PADI](https://www.padi.com/diving-in/komodo/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Ningaloo whale-shark snorkel season

**Location:** Exmouth and Ningaloo, Australia.

Licensed snorkelling programmes offer a seasonal opportunity to observe whale sharks around Ningaloo.

**Why go:** A seasonal opportunity to observe whale sharks provides a clear wildlife reason for this snorkelling trip. The animals are fish, and the encounter belongs in a licensed snorkel programme rather than a generic whale cruise.

**Key attractions:** Whale-shark observation; Reef-region setting; Season-specific wildlife programme.

**Season, whale_shark:** Mar, Apr, May, Jun, Jul, Aug. DBCA regional whale-shark window; other sources use a narrower peak. [Season evidence](https://exploreparks.dbca.wa.gov.au/park/ningaloo-marine-park).

**Season, humpback_whale:** Jun, Jul, Aug, Sep, Oct, Nov. Humpback-whale presence window does not authorise swimming with whales. [Season evidence](https://exploreparks.dbca.wa.gov.au/park/ningaloo-marine-park).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://exploreparks.dbca.wa.gov.au/park/ningaloo-marine-park).

**Contact:** [Official visitor/contact route](https://exploreparks.dbca.wa.gov.au/park/ningaloo-marine-park).

**Evidence:** [Department of Biodiversity Conservation and Attractions WA](https://exploreparks.dbca.wa.gov.au/park/ningaloo-marine-park); [Ningaloo Discovery](https://www.ningaloodiscovery.com.au/ningaloo-whale-shark-swims/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Silfra year-round snorkelling

**Location:** Thingvellir, Iceland.

Cold freshwater and a geological setting give Silfra a different character from a tropical reef snorkel.

**Why go:** Freshwater geology and clear-water immersion make this distinct from tropical reef snorkelling. Exposure protection, medical requirements and operator eligibility need confirmation.

**Key attractions:** Freshwater geology; Clear-water immersion; Cold-water snorkelling format.

**Season, operator program:** All months. Operator advertises all-year snorkelling. [Season evidence](https://magmadive.is/dive-trips/snorkeling-day-trips/silfra-snorkeling-day-trip/).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://magmadive.is/dive-trips/snorkeling-day-trips/silfra-snorkeling-day-trip/).

**Contact:** [Official visitor/contact route](https://magmadive.is/dive-trips/snorkeling-day-trips/silfra-snorkeling-day-trip/).

**Evidence:** [Magmadive](https://magmadive.is/dive-trips/snorkeling-day-trips/silfra-snorkeling-day-trip/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Wakatobi island-reef discovery

**Location:** Wakatobi, Indonesia.

An island-reef destination supports a snorkelling-focused stay with several possible local bases.

**Why go:** A dispersed island-reef setting rewards travellers who want a reef-focused stay rather than a short excursion attached to a city visit.

**Key attractions:** Island reefs; Multiple island bases; Reef-focused stay.

**Season, operator pattern:** All months. Publisher describes year-round reef activities. [Season evidence](https://www.wakatobi.com/scuba-diving/seasons/).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.wakatobi.com/scuba-diving/seasons/).

**Contact:** [Official visitor/contact route](https://www.wakatobi.com/scuba-diving/seasons/).

**Evidence:** [Indonesia Ministry of Tourism](https://www.indonesia.travel/id/en/destination/sulawesi/zuidoost-sulawesi/snorkeling-wakatobi); [Wakatobi](https://www.wakatobi.com/scuba-diving/seasons/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #1: Kaikoura sperm-whale boat tour

**Location:** Kaikoura, New Zealand.

Boat-based whale observation focuses on the resident sperm whales associated with Kaikoura.

**Why go:** A resident sperm-whale focus makes the encounter distinctive without relying on one short migration window. The sea trip remains dependent on weather and operator suitability.

**Key attractions:** Sperm whales; Offshore boat observation; Resident-wildlife focus.

**Season, sperm_whale:** All months. Resident sperm whales can be encountered throughout the year. [Season evidence](https://whalewatch.co.nz/your-experience/our-tours/whale-watch-tour/).

**Season, operator program:** All months. The operator offers year-round tours, subject to conditions. [Season evidence](https://whalewatch.co.nz/your-experience/our-tours/whale-watch-tour/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** NZD 185 / adult_trip. published reference. Check current booking terms; no live availability supplied. Not a live or all-in quote. [Publisher](https://whalewatch.co.nz/our-tours/faqs/?lang=1).

**Tickets/access:** [Official ticket / operator information](https://whalewatch.co.nz/our-tours/faqs/?lang=1).

**Contact:** [Official visitor/contact route](https://whalewatch.co.nz/our-tours/faqs/?lang=1).

**Evidence:** [Whale Watch Kaikoura](https://whalewatch.co.nz/your-experience/our-tours/whale-watch-tour/); [Whale Watch Kaikoura](https://whalewatch.co.nz/our-tours/faqs/?lang=1). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Hayman Island underwater-art outing

**Location:** Whitsundays / Hayman Island, Australia.

An island snorkelling outing adds underwater artworks to the usual reasons for looking beneath the surface.

**Why go:** Underwater artworks add a different reason to look beneath the surface. This combines an island-water outing with art, rather than duplicating a conventional reef tour.

**Key attractions:** Underwater artworks; Island-water setting; Snorkelling discovery.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Broad Great Barrier Reef dry-season context; reef sectors and operations differ. [Season evidence](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Contact:** [Official visitor/contact route](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Evidence:** [Tourism and Events Queensland](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland); [Tourism Australia](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Balos lagoon and beach viewpoint

**Location:** Western Crete, Greece.

A lagoon, beach and coastal viewpoint offer several ways to experience the Balos landscape without requiring a swim.

**Why go:** Choose this for the lagoon-and-coast landscape and the option of appreciating it from a viewpoint. The scenery matters independently of whether swimming is appropriate that day.

**Key attractions:** Lagoon landscape; Beach setting; Coastal viewpoint.

**Season, regional conditions:** Apr, May, Jun, Jul, Aug, Sep, Oct. Lagoon and coastal viewpoint; broad April-October visiting window is not a swimming assurance. [Season evidence](https://www.discovergreece.com/experiences/prepare-be-mesmerised-cretes-balos-beach).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitgreece.gr/en/experiences/beaches/beloved-beaches/elafonisi-and-balos).

**Contact:** [Official visitor/contact route](https://www.visitgreece.gr/en/experiences/beaches/beloved-beaches/elafonisi-and-balos).

**Evidence:** [Greek National Tourism Organisation](https://www.visitgreece.gr/en/experiences/beaches/beloved-beaches/elafonisi-and-balos); [Discover Greece](https://www.discovergreece.com/experiences/prepare-be-mesmerised-cretes-balos-beach). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Calo des Moro beach

**Location:** Mallorca, Spain.

Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate.

**Why go:** A named Balearic beach gives the shortlist a specific coastal destination instead of a generic Mallorca entry. Its appeal needs to be weighed against limited access and summer pressure.

**Key attractions:** Beaches.

**Season, editorial season mapping:** Jun, Jul, Aug. Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate. [Season evidence](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Contact:** [Official visitor/contact route](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Evidence:** [Spain Tourism](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Ehukai Beach shore visit

**Location:** North Shore, Oahu, United States.

Summer can have calmer conditions. Winter brings powerful surf; a shore visit and swimming are different activities.

**Why go:** The shoreline changes its role through the year: beach discovery in one season and powerful-surf observation in another. The ranking values the setting, not permission to enter the water.

**Key attractions:** Beaches.

**Season, editorial season mapping:** Jun, Jul, Aug. Summer can have calmer conditions. Winter brings powerful surf; a shore visit and swimming are different activities. [Season evidence](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/).

**Contact:** [Official visitor/contact route](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/).

**Evidence:** [Hawaii Ocean Safety](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/); [Hawaii Tourism Authority](https://www.gohawaii.com/islands/oahu/things-to-do/beaches). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Elafonisi coastal beach landscape

**Location:** Western Crete, Greece.

Protected coastal scenery; May-October visits, with quieter shoulder periods.

**Why go:** The protected coastal landscape is the reason to go. Shoulder-period planning can serve visitors seeking the setting without treating a famous beach as a guaranteed quiet swim.

**Key attractions:** Beaches.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Protected coastal scenery; May-October visits, with quieter shoulder periods. [Season evidence](https://www.discovergreece.com/experiences/dreamscape-cretes-elafonisi-beach).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitgreece.gr/en/experiences/beaches/beloved-beaches/elafonisi-and-balos).

**Contact:** [Official visitor/contact route](https://www.visitgreece.gr/en/experiences/beaches/beloved-beaches/elafonisi-and-balos).

**Evidence:** [Greek National Tourism Organisation](https://www.visitgreece.gr/en/experiences/beaches/beloved-beaches/elafonisi-and-balos); [Discover Greece](https://www.discovergreece.com/experiences/dreamscape-cretes-elafonisi-beach). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: La Pelosa protected beach

**Location:** Stintino, Sardinia, Italy.

Protected coastal landscape with summer visitor pressure. This is an editorial summer mapping, not permit availability.

**Why go:** A protected Sardinian coastal landscape merits a place as a scenic shore destination. The useful planning question is access and visitor pressure, not a generic summer temperature.

**Key attractions:** Beaches.

**Season, editorial season mapping:** Jun, Jul, Aug. Protected coastal landscape with summer visitor pressure. This is an editorial summer mapping, not permit availability. [Season evidence](https://www.sardegnaturismo.it/it/esplora/la-pelosa).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.sardegnaturismo.it/it/esplora/la-pelosa).

**Contact:** [Official visitor/contact route](https://www.sardegnaturismo.it/it/esplora/la-pelosa).

**Evidence:** [Sardegna Turismo](https://www.sardegnaturismo.it/it/esplora/la-pelosa). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Cala Macarella beach

**Location:** Menorca, Spain.

Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate.

**Why go:** This specific Menorca beach gives an island visit a named coastal focus. Compare access and seasonal crowding before treating a beautiful shore as an effortless family outing.

**Key attractions:** Beaches.

**Season, editorial season mapping:** Jun, Jul, Aug. Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate. [Season evidence](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Contact:** [Official visitor/contact route](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Evidence:** [Spain Tourism](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Matira Beach

**Location:** Bora Bora, French Polynesia.

Drier-season lagoon-side beach discovery, with local water conditions checked separately.

**Why go:** A lagoon-side beach offers a different experience from an offshore excursion: visitors can build the day around the shore and its setting rather than a boat departure.

**Key attractions:** Beaches.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Drier-season lagoon-side beach discovery, with local water conditions checked separately. [Season evidence](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Contact:** [Official visitor/contact route](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Evidence:** [Tahiti Tourisme](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Ses Illetes beach

**Location:** Formentera, Spain.

Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate.

**Why go:** The named Formentera beach belongs in an island-coast shortlist rather than a broad Spain list. Its usefulness comes from pairing the setting with access and seasonal visitor context.

**Key attractions:** Beaches.

**Season, editorial season mapping:** Jun, Jul, Aug. Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate. [Season evidence](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Contact:** [Official visitor/contact route](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Evidence:** [Spain Tourism](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Sunset Beach shore visit

**Location:** North Shore, Oahu, United States.

Summer can have calmer conditions. Winter brings powerful surf; a shore visit and swimming are different activities.

**Why go:** A shore-viewing destination with a strong seasonal surf contrast. It is valuable for people interested in the coast even when swimming is not appropriate.

**Key attractions:** Beaches.

**Season, editorial season mapping:** Jun, Jul, Aug. Summer can have calmer conditions. Winter brings powerful surf; a shore visit and swimming are different activities. [Season evidence](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/).

**Contact:** [Official visitor/contact route](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/).

**Evidence:** [Hawaii Ocean Safety](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/); [Hawaii Tourism Authority](https://www.gohawaii.com/islands/oahu/things-to-do/beaches). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Waimea Bay shore visit

**Location:** North Shore, Oahu, United States.

Summer can have calmer conditions. Winter brings powerful surf; a shore visit and swimming are different activities.

**Why go:** Summer beach viewing and winter surf watching are different propositions at the same place. A high scenic score never authorises swimming.

**Key attractions:** Beaches.

**Season, editorial season mapping:** Jun, Jul, Aug. Summer can have calmer conditions. Winter brings powerful surf; a shore visit and swimming are different activities. [Season evidence](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/).

**Contact:** [Official visitor/contact route](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/).

**Evidence:** [Hawaii Ocean Safety](https://oceansafety.hawaii.gov/hawaiis-surf-seasons/); [Hawaii Tourism Authority](https://www.gohawaii.com/islands/oahu/things-to-do/beaches). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Vieques Mosquito Bay night paddle

**Location:** Vieques / Mosquito Bay, Puerto Rico.

A night paddle or boat outing reveals the natural light phenomenon of a protected bioluminescent bay.

**Why go:** The natural light phenomenon is the attraction. Monthly seasonality is relatively weak; moonlight and current conditions matter more for an actual evening.

**Key attractions:** Bioluminescence; Night-water outing; Protected bay setting.

**Season, natural phenomenon:** All months. Bioluminescent outings possible year-round; moonlight and water conditions matter. [Season evidence](https://www.discoverpuertorico.com/bio-bays).

**Published restriction:** The tourism authority identifies swimming prohibitions in Mosquito Bay and Laguna Grande. This applies to swimming, not a blanket prohibition on guided observation. [Source](https://www.discoverpuertorico.com/article/guide-to-exploring-puerto-ricos-bioluminescent-bays).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.discoverpuertorico.com/article/guide-to-exploring-puerto-ricos-bioluminescent-bays).

**Contact:** [Official visitor/contact route](https://www.discoverpuertorico.com/article/guide-to-exploring-puerto-ricos-bioluminescent-bays).

**Evidence:** [Discover Puerto Rico](https://www.discoverpuertorico.com/article/guide-to-exploring-puerto-ricos-bioluminescent-bays); [Discover Puerto Rico](https://www.discoverpuertorico.com/bio-bays). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Aitutaki Vaka lagoon and lunch cruise

**Location:** Aitutaki Lagoon, Cook Islands.

A lagoon-and-lunch cruise combines water scenery with a longer, meal-based outing.

**Why go:** Choose this when a lagoon outing and an included meal are the desired experience. It offers a different day structure from a short glass-bottom cruise.

**Key attractions:** Aitutaki lagoon; Boat-based sightseeing; Lunch programme.

**Season, regional conditions:** Apr, May, Sep, Oct. April, May, September and October are highlighted for a warm/dry balance. Trade-wind months are not automatically the calmest lagoon days. [Season evidence](https://cookislands.travel/islands/weather-seasons).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://cookislands.travel/supplier/vaka-cruise).

**Contact:** [Official visitor/contact route](https://cookislands.travel/supplier/vaka-cruise).

**Evidence:** [Cook Islands Tourism](https://cookislands.travel/supplier/vaka-cruise); [Cook Islands Tourism](https://cookislands.travel/islands/weather-seasons). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Curieuse island-and-reef day

**Location:** Praslin / Curieuse, Seychelles.

Combine a managed island visit with a reef stop. Check whether land admission and snorkel equipment are included.

**Why go:** An island landing plus a reef stop gives the day two distinct interests. It suits comparison with a pure snorkel trip rather than being treated as the same product.

**Key attractions:** Island boat outings.

**Season, regional conditions:** Mar, Apr, May, Sep, Oct, Nov. Regional calmer water-sports window; exposure differs by coast. [Season evidence](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Contact:** [Official visitor/contact route](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Evidence:** [Tourism Seychelles](https://seychelles.com/blog-details/1986/highlights/why-you-should-visit-curieuse-island); [Air Seychelles](https://fly.airseychelles.com/en/explore-seychelles/water-sports). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Ilulissat Icefjord boat discovery

**Location:** Ilulissat, Greenland.

An ice-landscape boat outing, not an implied invitation to approach or climb icebergs.

**Why go:** Icefjord scenery makes the boat journey itself the discovery. The experience does not require, or imply permission for, approaching or climbing an iceberg.

**Key attractions:** Scenic cruises.

**Season, editorial season mapping:** Jun, Jul, Aug. Summer is the published broad context. June-August is an editorial core-summer mapping; local ice and operations vary. [Season evidence](https://visitgreenland.com/activities/boat-tours/).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitgreenland.com/activities/icebergs/).

**Contact:** [Official visitor/contact route](https://visitgreenland.com/activities/icebergs/).

**Evidence:** [Visit Greenland](https://visitgreenland.com/activities/icebergs/); [Visit Greenland](https://visitgreenland.com/activities/boat-tours/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Patagonia Marble Caves by launch

**Location:** Puerto Rio Tranquilo, Chile.

A stay-on-board alternative to the kayak approach, still subject to lake conditions.

**Why go:** View the lake formations while remaining aboard a launch. It preserves the geological attraction for visitors who do not want the separate challenge of kayaking.

**Key attractions:** Scenic cruises.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar. November-March generally brings longer days and more stable conditions. Water levels can prevent entering formations; spring/autumn access differs from summer. [Season evidence](https://chile.travel/en/blog/marble-chapels-how-to-visit-them-and-their-surprising-connection-to-ancient-greece/).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://chile.travel/atractivos/lago-general-carrera-y-capillas-de-marmol/).

**Contact:** [Official visitor/contact route](https://chile.travel/atractivos/lago-general-carrera-y-capillas-de-marmol/).

**Evidence:** [SERNATUR / Chile Travel](https://chile.travel/atractivos/lago-general-carrera-y-capillas-de-marmol/); [Chile Travel](https://chile.travel/en/blog/marble-chapels-how-to-visit-them-and-their-surprising-connection-to-ancient-greece/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Palau Rock Islands guided boat outing

**Location:** Rock Islands, Palau.

Combine island scenery and snorkel stops; lake access requires a walk and separate rule checks.

**Why go:** Combine island scenery and selected reef stops in one guided outing. Separate lake permits and walking access make the exact itinerary more important than a simple boat-tour label.

**Key attractions:** Snorkel boat excursions.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. November-April is the drier and generally calmer regional window. This does not confirm Jellyfish Lake access or its changing jellyfish population. [Season evidence](https://www.padi.com/diving-in/palau/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.samstours.com/rock-island-tours).

**Contact:** [Official visitor/contact route](https://www.samstours.com/rock-island-tours).

**Evidence:** [Sams Tours](https://www.samstours.com/rock-island-tours); [PADI](https://www.padi.com/diving-in/palau/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Staffa and Fingals Cave from the water

**Location:** Staffa / Inner Hebrides, United Kingdom.

Basalt cliffs and a sea cave viewed on a boat outing. The weather may change the route or prevent a landing.

**Why go:** Basalt cliffs and a sea cave provide a geological reason for this boat trip. A worthwhile water view can remain distinct from a landing, which weather may prevent.

**Key attractions:** Scenic cruises.

**Season, regional operator reference:** Apr, May, Jun, Jul, Aug, Sep, Oct. Typical tour season April-October. Puffins mostly April to early August. A landing-maintenance notice has no reliably established year and must be checked for the planned trip. [Season evidence](https://staffatours.com/faq/).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitscotland.com/info/tours/fingals-cave-seafari-02155cfa).

**Contact:** [Official visitor/contact route](https://www.visitscotland.com/info/tours/fingals-cave-seafari-02155cfa).

**Evidence:** [VisitScotland / listed provider](https://www.visitscotland.com/info/tours/fingals-cave-seafari-02155cfa); [Staffa Tours](https://staffatours.com/faq/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Soomaa fifth-season flooded-forest canoeing

**Location:** Soomaa National Park, Estonia.

A naturally triggered flood window creates an outing that cannot be scheduled from a fixed annual opening date.

**Why go:** Floodwater transforms the forest into a temporary canoe landscape. This is a genuinely event-led discovery: the attraction depends on a natural water-level trigger rather than an annual opening date.

**Key attractions:** Kayaking.

**Season, typical conditions:** Mar, Apr. Operator describes March-April depending on weather; flood occurrence is not guaranteed. [Season evidence](https://360.ee/en/matkad/kayak-tours/fifth-season-in-soomaa/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Published price reference:** EUR 39 / participant_group_trip. published reference. 39 EUR plus VAT per participant; minimum group12. VAT amount and group eligibility must be resolved before a total. Not a live or all-in quote. [Publisher](https://360.ee/en/matkad/kayak-tours/fifth-season-in-soomaa/).

**Tickets/access:** [Official ticket / operator information](https://360.ee/en/matkad/kayak-tours/fifth-season-in-soomaa/).

**Contact:** [Official visitor/contact route](https://360.ee/en/matkad/kayak-tours/fifth-season-in-soomaa/). Telephone: +37256668172.

**Evidence:** [360 KRAADI](https://360.ee/en/matkad/kayak-tours/fifth-season-in-soomaa/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Patagonia Marble Caves by kayak

**Location:** Puerto Rio Tranquilo, Chile.

Compare a paddle visit with a launch outing around the same lake formations.

**Why go:** Paddling offers a water-level encounter with the same formations visited by launches. Choose it for the active format, with lake exposure and the guided route checked separately.

**Key attractions:** Kayaking.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar. November-March generally brings longer days and more stable conditions. Water levels can prevent entering formations; spring/autumn access differs from summer. [Season evidence](https://chile.travel/en/blog/marble-chapels-how-to-visit-them-and-their-surprising-connection-to-ancient-greece/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://chile.travel/atractivos/lago-general-carrera-y-capillas-de-marmol/).

**Contact:** [Official visitor/contact route](https://chile.travel/atractivos/lago-general-carrera-y-capillas-de-marmol/).

**Evidence:** [SERNATUR / Chile Travel](https://chile.travel/atractivos/lago-general-carrera-y-capillas-de-marmol/); [Chile Travel](https://chile.travel/en/blog/marble-chapels-how-to-visit-them-and-their-surprising-connection-to-ancient-greece/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Phang Nga Hong by Starlight sea-canoe trip

**Location:** Phang Nga Bay, Phuket departure, Thailand.

A guided boat-and-canoe excursion through tidal caves and lagoons. The tide-dependent route and evening light experience require operator confirmation, not a static promise that every cave or natural effect will be available.

**Why go:** Tidal caves, enclosed lagoons and an evening programme create a more varied day than a simple point-to-point boat ride. Tide-dependent routing is central to the experience.

**Key attractions:** Phang Nga Bay; Kayaking.

**Season, operator program:** Not established. Exact operating calendar was not established; contact operator for the selected date. [Season evidence](https://johngray-seacanoe.com/).

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Published price reference:** THB 3950 / package_unspecified. from. Confirm age category, transfer, park fees and selected itinerary. Starting amount is published; exact passenger category and package unit require confirmation. Not a live or all-in quote. [Publisher](https://johngray-seacanoe.com/).

**Tickets/access:** [Official ticket / operator information](https://johngray-seacanoe.com/).

**Contact:** [Official visitor/contact route](https://johngray-seacanoe.com/). Telephone: +66631243404.

**Evidence:** [John Gray Sea Canoe](https://johngray-seacanoe.com/); [John Gray Sea Canoe](https://johngray-seacanoe.com/); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: South Greenland guided fjord kayaking

**Location:** South Greenland, Greenland.

A specialist cold-water paddle experience with operator-selected routes.

**Why go:** Cold-water fjord scenery gives the paddle a strong sense of place. This is a specialist guided outing rather than a substitute for an easy beach rental.

**Key attractions:** Kayaking.

**Season, editorial season mapping:** Jun, Jul, Aug. Summer is the published broad context. June-August is an editorial core-summer mapping; local ice and operations vary. [Season evidence](https://visitgreenland.com/activities/boat-tours/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitgreenland.com/activities/icebergs/).

**Contact:** [Official visitor/contact route](https://visitgreenland.com/activities/icebergs/).

**Evidence:** [Visit Greenland](https://visitgreenland.com/activities/icebergs/); [Visit Greenland](https://visitgreenland.com/activities/boat-tours/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Ile Cocos marine snorkelling

**Location:** La Digue / Ile Cocos, Seychelles.

A marine-park snorkelling stop. Do not turn occasional recorded wildlife into a promised species encounter.

**Why go:** A marine-park reef stop offers a specific island-water discovery. Its appeal comes from the protected setting rather than promises of particular animals.

**Key attractions:** Snorkelling.

**Season, regional conditions:** Mar, Apr, May, Sep, Oct, Nov. Regional calmer water-sports window; exposure differs by coast. [Season evidence](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Contact:** [Official visitor/contact route](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Evidence:** [Tourism Seychelles](https://www.seychelles.com/listingdetails/62c7ddc58955d80bdec4702f); [Air Seychelles](https://fly.airseychelles.com/en/explore-seychelles/water-sports). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Palau Jellyfish Lake snorkelling

**Location:** Rock Islands, Palau.

A marine-lake snorkel that needs its own permit and activity rules.

**Why go:** A marine lake is a fundamentally different snorkel environment from an open reef. Its distinct access and conservation rules are part of what makes the choice meaningful.

**Key attractions:** Snorkelling.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. November-April is the drier and generally calmer regional window. This does not confirm Jellyfish Lake access or its changing jellyfish population. [Season evidence](https://www.padi.com/diving-in/palau/).

**Published restriction:** Publisher specifies snorkelling only at Jellyfish Lake. Do not offer scuba here. [Source](https://palau.co/discover-palau/natural-wonders/jellyfish-lake/).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://palau.co/discover-palau/natural-wonders/jellyfish-lake/).

**Contact:** [Official visitor/contact route](https://palau.co/discover-palau/natural-wonders/jellyfish-lake/).

**Evidence:** [Palau Visitors Authority](https://palau.co/discover-palau/natural-wonders/jellyfish-lake/); [PADI](https://www.padi.com/diving-in/palau/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Lady Elliot Island manta and reef snorkelling

**Location:** Lady Elliot Island, Australia.

Reef and lagoon snorkelling with manta habitat. Confirm transfer and accommodation arrangements before choosing a date.

**Why go:** Combine a reef-island visit with lagoon and manta-habitat exploration. Transfer and stay arrangements matter because the island is the destination, not merely a nearby boat stop.

**Key attractions:** manta ray; Snorkelling.

**Season, manta_ray:** May, Jun, Jul, Aug. Tourism authority identifies May-August as the stronger manta period, not a sighting guarantee. [Season evidence](https://www.queensland.com/us/en/things-to-do/traveller/first-time-visitor/first-timers-guide-great-barrier-reef).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Contact:** [Official visitor/contact route](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Evidence:** [Tourism and Events Queensland](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Moorea lagoon reef discovery

**Location:** Moorea, French Polynesia.

A lagoon outing remains a distinct choice from offshore whale viewing.

**Why go:** Lagoon reef exploration offers an alternative to offshore whale trips. This lets a group choose an underwater habitat experience without implying in-water whale contact.

**Key attractions:** Snorkelling.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Drier Society Islands climate context; wind and lagoon conditions vary. [Season evidence](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tahititourisme.nz/activities/diving/moorea/).

**Contact:** [Official visitor/contact route](https://www.tahititourisme.nz/activities/diving/moorea/).

**Evidence:** [Tahiti Tourisme](https://www.tahititourisme.nz/activities/diving/moorea/); [Tahiti Tourisme](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Ribbon Reefs wildlife snorkelling

**Location:** Port Douglas / Ribbon Reefs, Australia.

Reef excursions with a seasonal dwarf-minke interest. An encounter requires an appropriate operator and permissions.

**Why go:** A reef itinerary with a seasonal dwarf-minke interest adds a wildlife dimension beyond ordinary snorkelling. The actual operator permissions and route define the opportunity.

**Key attractions:** dwarf minke whale; Snorkelling.

**Season, dwarf_minke_whale:** Jun, Jul. Tourism authority identifies June-July as the dwarf-minke period. [Season evidence](https://www.queensland.com/us/en/things-to-do/traveller/first-time-visitor/first-timers-guide-great-barrier-reef).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Contact:** [Official visitor/contact route](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Evidence:** [Tourism and Events Queensland](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Sainte Anne marine-park reef outing

**Location:** Mahe / Sainte Anne Marine Park, Seychelles.

A boat-access reef outing with a useful shoulder-season planning signal. Park access and the boat fare are separate checks.

**Why go:** A managed marine-park outing combines a boat approach with reef exploration. Shoulder-season context can help plan it without treating a park permit as a tour ticket.

**Key attractions:** Snorkelling.

**Season, typical conditions:** Apr, May, Oct, Nov. Tourism Seychelles highlights April-May and October-November for calmer snorkelling conditions. [Season evidence](https://www.seychelles.com/blog-details/10052/highlights/visit-seychelles-marine-sanctuaries-untouched-unforgettable-protected).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.seychelles.com/blog-details/10052/highlights/visit-seychelles-marine-sanctuaries-untouched-unforgettable-protected).

**Contact:** [Official visitor/contact route](https://www.seychelles.com/blog-details/10052/highlights/visit-seychelles-marine-sanctuaries-untouched-unforgettable-protected).

**Evidence:** [Tourism Seychelles](https://www.seychelles.com/blog-details/10052/highlights/visit-seychelles-marine-sanctuaries-untouched-unforgettable-protected). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Somosomo Strait reef discovery

**Location:** Taveuni, Fiji.

An individual reef region identified by Tourism Fiji; check local currents and trip suitability.

**Why go:** The Somosomo Strait setting gives the choice a specific reef geography rather than a generic Fiji label. Compare the actual boat route and current-sensitive sites.

**Key attractions:** Snorkelling.

**Season, underwater visibility:** Jun, Jul, Aug. Tourism publisher highlights these months for reef visibility. [Season evidence](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Contact:** [Official visitor/contact route](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Evidence:** [Tourism Fiji](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide); [Tourism Fiji](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Vatu-i-Ra conservation-reef discovery

**Location:** Vatu-i-Ra Passage, Fiji.

An individual reef region identified by Tourism Fiji; check local currents and trip suitability.

**Why go:** The conservation-reef context distinguishes this from a resort-front swim. It is a named reef discovery whose access and trip structure deserve their own check.

**Key attractions:** Snorkelling.

**Season, underwater visibility:** Jun, Jul, Aug. Tourism publisher highlights these months for reef visibility. [Season evidence](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Contact:** [Official visitor/contact route](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Evidence:** [Tourism Fiji](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide); [Tourism Fiji](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Hermanus whale watching

**Location:** Hermanus, South Africa.

A boat trip into Walker Bay with species-specific calendars. The main southern-right-whale period differs from the shorter humpback window and the possible year-round presence of Brydes whales.

**Why go:** Walker Bay offers several whale themes with different calendars. The species-specific distinction is the reason to choose a dated outing rather than a generic year-round whale promise.

**Key attractions:** southern right whale; humpback whale; brydes whale; Whale watching.

**Season, southern_right_whale:** Jun, Jul, Aug, Sep, Oct, Nov, Dec. Southern right whales use the bay for mating, calving and nursing; December is a shoulder period. [Season evidence](https://www.southernrightcharters.co.za/whale-watching/).

**Season, humpback_whale:** Jun, Jul, Aug, Sep. Humpback presence has a shorter published window. [Season evidence](https://www.southernrightcharters.co.za/whale-watching/).

**Season, brydes_whale:** All months. Resident Brydes whales may be encountered; this does not imply year-round tour operation. [Season evidence](https://www.southernrightcharters.co.za/whale-watching/).

**Season, operator program:** Jun, Jul, Aug, Sep, Oct, Nov. Core advertised programme ends in November; ask about December departures. [Season evidence](https://www.southernrightcharters.co.za/whale-watching/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** ZAR 1580 / adult_trip. published reference. Do not roll the 2026 amount into 2027 automatically. Not a live or all-in quote. [Publisher](https://www.southernrightcharters.co.za/whale-watching/).

**Tickets/access:** [Official ticket / operator information](https://www.southernrightcharters.co.za/whale-watching/).

**Contact:** [Official visitor/contact route](https://www.southernrightcharters.co.za/whale-watching/). Telephone: +27823530550.

**Evidence:** [Southern Right Charters](https://www.southernrightcharters.co.za/whale-watching/); [Southern Right Charters](https://www.southernrightcharters.co.za/contact/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Hervey Bay whale watching

**Location:** Hervey Bay, Queensland, Australia.

A half-day wildlife cruise with separate adult, child and family pricing. The reviewed programme is explicitly the 2026 season, so a subsequent year needs fresh operator dates and fares.

**Why go:** The seasonal whale programme gives this bay a clear wildlife-led reason to visit. Its defined seasonal operation helps compare it with resident-species destinations.

**Key attractions:** Whale watching.

**Season, operator program:** Jul, Aug, Sep, Oct. Published 2026 whale programme runs July to October. [Season evidence](https://www.spiritofherveybay.com/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** AUD 155 / adult_trip. published reference. Historical reference after season end; request 2027 fare. Not a live or all-in quote. [Publisher](https://www.spiritofherveybay.com/).

**Tickets/access:** [Official ticket / operator information](https://www.spiritofherveybay.com/).

**Contact:** [Official visitor/contact route](https://www.spiritofherveybay.com/).

**Evidence:** [Spirit of Hervey Bay](https://www.spiritofherveybay.com/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Juneau seasonal whale watching

**Location:** Juneau, Alaska, United States.

A shore-excursion style whale tour with a published meeting address separate from the company office. Harbour transfers and return-to-ship time need a dated confirmation.

**Why go:** A seasonal whale trip can be paired with a Juneau visit or cruise call. The useful distinction is an organised wildlife outing with an explicit return-time requirement.

**Key attractions:** Whale watching.

**Season, species presence:** May, Jun, Jul, Aug, Sep. Operator describes May-September as the main whale season. [Season evidence](https://www.juneauwhalewatch.com/f-a-q/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.juneauwhalewatch.com/contact-us/).

**Contact:** [Official visitor/contact route](https://www.juneauwhalewatch.com/contact-us/). Telephone: +19076216502.

**Evidence:** [Juneau Whale Watch](https://www.juneauwhalewatch.com/f-a-q/); [Juneau Whale Watch](https://www.juneauwhalewatch.com/contact-us/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Maalaea humpback whale watching

**Location:** Maui, Hawaii, United States.

A seasonal humpback-whale boat experience from Maui. Keep whale encounters separate from snorkelling permissions and show the operator price link when no defensible current amount is available.

**Why go:** The humpback season supplies a strong, specific reason for a Maui boat trip. Whale observation remains separate from any reef-swimming or snorkelling product.

**Key attractions:** humpback whale; Whale watching.

**Season, humpback_whale:** Nov, Dec, Jan, Feb, Mar, Apr. Operator describes November to April as Maui whale season. [Season evidence](https://pacwhale.com/faq/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://pacwhale.com/ecotour/whalewatch-maalaea/).

**Contact:** [Official visitor/contact route](https://pacwhale.com/ecotour/whalewatch-maalaea/).

**Evidence:** [PacWhale Eco-Adventures](https://pacwhale.com/faq/); [PacWhale Eco-Adventures](https://pacwhale.com/ecotour/whalewatch-maalaea/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Lajes do Pico whale and dolphin tour

**Location:** Pico, Azores, Portugal.

An Azores wildlife departure from Pico rather than Sao Miguel. The source says high season only without exact months, so the calendar remains unknown until dates are confirmed.

**Why go:** A departure from Pico lets travellers build an Azores wildlife day around that island instead of automatically routing through Sao Miguel.

**Key attractions:** Whale watching.

**Season, operator program:** Not established. High season only is published; exact months not established. [Season evidence](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-cetaceos-nas-lajes-do-pico-acores/).

**Season, regional operator reference:** Apr, May, Jun, Jul, Aug, Sep, Oct. A named Pico operator runs April-October. Confirm the operator in this record separately. [Season evidence](https://whalewatchingazores.com/en/faqs/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** EUR 70 / adult_trip. published reference.  Not a live or all-in quote. [Publisher](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-cetaceos-nas-lajes-do-pico-acores/).

**Tickets/access:** [Official ticket / operator information](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-cetaceos-nas-lajes-do-pico-acores/).

**Contact:** [Official visitor/contact route](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-cetaceos-nas-lajes-do-pico-acores/).

**Evidence:** [Futurismo](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-cetaceos-nas-lajes-do-pico-acores/); [Futurismo](https://whalewatchingazores.com/en/faqs/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Ponta Delgada whale and dolphin tour

**Location:** Sao Miguel, Azores, Portugal.

A year-round Azores wildlife trip with the booking surcharge separated from the headline fare. Species presence must be sourced separately rather than treating every whale named in marketing copy as equally likely.

**Why go:** A year-round departure base offers flexibility for an Azores visit, while species calendars still determine the particular wildlife interest.

**Key attractions:** Whale watching.

**Season, operator program:** All months. Tour is described as available throughout the year. [Season evidence](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-baleias-em-ponta-delgada-sao-miguel-azores/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** EUR 70 / adult_trip. published reference. Listed online components total EUR 74.20; final booking total may vary. Not a live or all-in quote. [Publisher](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-baleias-em-ponta-delgada-sao-miguel-azores/).

**Tickets/access:** [Official ticket / operator information](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-baleias-em-ponta-delgada-sao-miguel-azores/).

**Contact:** [Official visitor/contact route](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-baleias-em-ponta-delgada-sao-miguel-azores/).

**Evidence:** [Futurismo](https://www.futurismo.pt/pt/visitas-guiadas/observacao-de-baleias-em-ponta-delgada-sao-miguel-azores/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Puerto Piramides southern-right-whale tour

**Location:** Puerto Piramides, Peninsula Valdes, Argentina.

A southern-right-whale excursion with clearly differentiated low- and high-season prices. The municipal operator directory is a useful verification route, rather than relying on a booking aggregator.

**Why go:** The southern-right-whale focus gives this excursion a clearly defined wildlife identity. Seasonal tariffs and the municipal operator directory make the practical comparison unusually specific.

**Key attractions:** southern right whale; Whale watching.

**Season, operator program:** Jun, Jul, Aug, Sep, Oct, Nov, Dec. Published 2026 tour window is 15 June to 15 December. Published date window: {"start": "06-15", "end": "12-15"}. [Season evidence](https://www.southernspirit.com.ar/en/servicio/traditional-whale-watching/).

**Season, southern_right_whale:** Jun, Jul, Aug, Sep, Oct, Nov, Dec. Southern right whales visit the reproduction and nursery area. [Season evidence](https://www.puertopiramides.gov.ar/avistaje/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** ARS 150000 / adult_trip. published reference. Taxes included; separate destination access fees must be confirmed. Not a live or all-in quote. [Publisher](https://www.southernspirit.com.ar/en/servicio/traditional-whale-watching/).

**Published price reference:** ARS 195000 / adult_trip. published reference. Taxes included; separate destination access fees must be confirmed. Not a live or all-in quote. [Publisher](https://www.southernspirit.com.ar/en/servicio/traditional-whale-watching/).

**Tickets/access:** [Official ticket / operator information](https://www.southernspirit.com.ar/en/servicio/traditional-whale-watching/).

**Contact:** [Official visitor/contact route](https://www.southernspirit.com.ar/en/servicio/traditional-whale-watching/).

**Evidence:** [Southern Spirit](https://www.southernspirit.com.ar/en/servicio/traditional-whale-watching/); [Municipality of Puerto Piramides](https://www.puertopiramides.gov.ar/avistaje/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: San Ignacio Lagoon gray-whale trips

**Location:** San Ignacio Lagoon, Baja California Sur, Mexico.

A lagoon-based whale programme with an explicitly published 2027 window.

**Why go:** The lagoon setting and gray-whale focus provide a specific wildlife reason to travel, rather than a generic offshore sightseeing trip.

**Key attractions:** Gray whales; Lagoon setting; Seasonal boat programme.

**Season, operator program:** Jan, Feb, Mar. Published 2027 programme: 20 January to 31 March. Published date window: {"start": "01-20", "end": "03-31"}. [Season evidence](https://www.kuyima.com/).

**Season, gray_whale:** Jan, Feb, Mar. The operator describes gray-whale encounters for its lagoon season. [Season evidence](https://www.kuyima.com/).

**Plan around:** A lagoon-based whale programme with an explicitly published 2027 window. Future travel dates belong in a dated programme, not an endlessly recurring calendar copied from an old season. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.kuyima.com/).

**Contact:** [Official visitor/contact route](https://www.kuyima.com/).

**Evidence:** [Kuyima](https://www.kuyima.com/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #16: Tonga seasonal humpback watching

**Location:** Tonga, Tonga.

A boat-viewing stream focused on seasonal humpbacks.

**Why go:** Seasonal humpbacks make Tonga a wildlife-led destination. The boat-viewing experience has value independently of any separately regulated swimming product.

**Key attractions:** Humpback whales; Seasonal boat observation; Island-water setting.

**Season, humpback_whale:** Jul, Aug, Sep, Oct. Tourism authority gives July-October arrival period. [Season evidence](https://www.tongatourism.travel/see-and-do/whale-watching).

**Season, humpback_whale:** Jul, Aug, Sep, Oct. Breeding and calf-rearing period; avoid promoting close approaches to mothers and calves. [Season evidence](https://www.tongatourism.travel/see-and-do/whale-watching).

**Plan around:** A boat-viewing stream focused on seasonal humpbacks. A whale-watching listing does not grant permission to swim with animals; any in-water product needs a separately checked licence and protocol. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://jonestravel.com.to/tours/seasonal-whale-watching/).

**Contact:** [Official visitor/contact route](https://jonestravel.com.to/tours/seasonal-whale-watching/).

**Evidence:** [Tonga Tourism Authority](https://www.tongatourism.travel/see-and-do/whale-watching); [Jones Travel and Tours](https://jonestravel.com.to/tours/seasonal-whale-watching/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Addu Atoll manta diving

**Location:** Addu Atoll, Maldives.

A southern Maldives counterexample to a single national season.

**Why go:** A southern-atoll manta experience adds geographical variety to a Maldives dive plan instead of repeating a central-atoll seasonal formula.

**Key attractions:** Manta-focused diving; Southern atoll; Distinct regional season.

**Season, reef_manta:** All months. PADI describes manta opportunities under both monsoons. [Season evidence](https://www.padi.com/diving-in/addu-atoll-seenu-atoll/).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** A southern Maldives counterexample to a single national season. Keep the manta experience separate from wreck-diving depth and qualification requirements. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Contact:** [Official visitor/contact route](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [PADI](https://www.padi.com/diving-in/addu-atoll-seenu-atoll/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Aliwal Shoal specialist dive

**Location:** Umkomaas / Aliwal Shoal, South Africa.

A specialist offshore dive setting.

**Why go:** An offshore specialist dive provides a different experience from a sheltered reef outing. Choose it for the site and underwater environment, not a guaranteed animal encounter.

**Key attractions:** Offshore dive setting; Specialist diving; Site-specific underwater interest.

**Season, species presence:** Jun, Jul, Aug, Sep, Oct, Nov. Seasonal shark-diving context at Aliwal; not a sighting guarantee. [Season evidence](https://www.padi.com/diving-in/kwazulu-natal/).

**Plan around:** A specialist offshore dive setting. Ask about experience requirements, currents and whether the product uses bait before comparing it with reef dives. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.southafrica.net/gl/en/travel/article/embrace-the-outdoors-hibiscus-coast-kwazulu-natal).

**Contact:** [Official visitor/contact route](https://www.southafrica.net/gl/en/travel/article/embrace-the-outdoors-hibiscus-coast-kwazulu-natal).

**Evidence:** [South African Tourism](https://www.southafrica.net/gl/en/travel/article/embrace-the-outdoors-hibiscus-coast-kwazulu-natal); [PADI](https://www.padi.com/diving-in/kwazulu-natal/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Gozo Blue Hole diving

**Location:** Dwejra, Gozo, Malta.

A shore-diving discovery with site-specific access and training requirements.

**Why go:** A named shore-diving site gives a Gozo visit a precise underwater focus without requiring a generic island-wide dive package.

**Key attractions:** Blue Hole; Shore-diving format; Gozo coastal setting.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. May-October is the warmer Gozo diving context, with July-August busier. Wind determines which shore sites are usable; the Blue Hole is not guaranteed accessible. [Season evidence](https://www.padi.com/diving-in/gozo/).

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitmalta.com/en/experience-diving/).

**Contact:** [Official visitor/contact route](https://www.visitmalta.com/en/experience-diving/).

**Evidence:** [Malta Tourism Authority](https://www.visitmalta.com/en/experience-diving/); [PADI](https://www.padi.com/diving-in/gozo/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Iriomote guided two-dive day

**Location:** Iriomote / Uehara, Japan.

A sourced two-dive product with separately priced rental equipment and lunch.

**Why go:** A defined two-dive day makes the actual underwater programme easier to compare than an unspecified island excursion.

**Key attractions:** Two-dive day; Iriomote underwater setting; Operator-defined itinerary.

**Season, operator program:** Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov. National-park activity listing covers March-November. [Season evidence](https://www.japan.travel/national-parks/parks/iriomote-ishigaki/see-and-do/diving-around-iriomotejima-island/).

**Plan around:** A sourced two-dive product with separately priced rental equipment and lunch. Do not compare its base price with an all-inclusive excursion. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Published price reference:** JPY 15400 / person_two_dive_day. published reference. Two dives. Rental set JPY 5500, lunch JPY 680; special expeditions extra. Confirm applicable components. Not a live or all-in quote. [Publisher](https://www.japan.travel/national-parks/parks/iriomote-ishigaki/see-and-do/diving-around-iriomotejima-island/).

**Tickets/access:** [Published fee or access information](https://www.japan.travel/national-parks/parks/iriomote-ishigaki/see-and-do/diving-around-iriomotejima-island/).

**Contact:** [Official visitor/contact route](https://www.japan.travel/national-parks/parks/iriomote-ishigaki/see-and-do/diving-around-iriomotejima-island/). Telephone: +81980856146.

**Evidence:** [JNTO / Ministry of the Environment](https://www.japan.travel/national-parks/parks/iriomote-ishigaki/see-and-do/diving-around-iriomotejima-island/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Ishigaki reef and manta dive planning

**Location:** Ishigaki, Japan.

A seasonal dive destination.

**Why go:** Reef diving and a narrower manta window provide two distinct reasons to choose a travel date for Ishigaki.

**Key attractions:** Reef dives; Seasonal manta opportunity; Island dive base.

**Season, typical conditions:** Mar, Apr, May, Jun, Jul, Aug, Sep, Oct. JNTO identifies March-October as the main diving window. [Season evidence](https://www.japan.travel/en/spot/572/).

**Plan around:** A seasonal dive destination. The broad diving window and the narrower manta period must remain separate. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.japan.travel/en/spot/572/).

**Contact:** [Official visitor/contact route](https://www.japan.travel/en/spot/572/).

**Evidence:** [Japan National Tourism Organization](https://www.japan.travel/en/spot/572/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: North Male Atoll diving seasons

**Location:** North Male Atoll, Maldives.

A visibility-focused atoll guide.

**Why go:** A visibility-led atoll guide suits travellers prioritising underwater viewing conditions rather than assuming every Maldives wildlife site peaks together.

**Key attractions:** Atoll dive sites; Visibility-focused planning; Regional seasonal context.

**Season, typical conditions:** Dec, Jan, Feb, Mar, Apr. Northeast-monsoon period favoured for conditions and visibility. [Season evidence](https://www.padi.com/diving-in/north-male-atoll-kaafu-atoll/).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** A visibility-focused atoll guide. Do not apply this dry-season preference to every manta site in the Maldives; site exposure and feeding conditions can favour a different monsoon. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Contact:** [Official visitor/contact route](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [PADI](https://www.padi.com/diving-in/north-male-atoll-kaafu-atoll/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Nusa Penida manta and sunfish diving

**Location:** Nusa Penida, Bali, Indonesia.

Two different wildlife calendars belong on the same location card: mantas can be encountered throughout the year, while ocean sunfish have a narrower period.

**Why go:** Mantas and ocean sunfish give the destination two wildlife themes with different calendars, which is more useful than one generic best month.

**Key attractions:** Manta rays; Seasonal ocean sunfish; Island dive sites.

**Season, reef_manta:** All months. Manta rays described year-round. [Season evidence](https://www.padi.com/diving-in/indonesia/nusa-penida/).

**Season, ocean_sunfish:** Jul, Aug, Sep, Oct. Ocean sunfish mainly July-October. [Season evidence](https://www.padi.com/diving-in/indonesia/nusa-penida/).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** Two different wildlife calendars belong on the same location card: mantas can be encountered throughout the year, while ocean sunfish have a narrower period. A month filter cannot replace local current and dive-site assessment. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Contact:** [Official visitor/contact route](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [PADI](https://www.padi.com/diving-in/indonesia/nusa-penida/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Phuket Shark Point and wreck dive day

**Location:** Phuket, Chalong, Thailand.

A three-dive operator itinerary rather than a public swimming location.

**Why go:** The three-dive itinerary combines site variety within one operator day, making it a different choice from a single-site introduction.

**Key attractions:** Shark Point itinerary; Wreck-dive component; Three-dive format.

**Season, typical conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr. Regional Andaman guidance, not a binding operating season. [Season evidence](https://www.padi.com/diving-in/thailand/).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** A three-dive operator itinerary rather than a public swimming location. Preserve the exact diver/non-diver distinction and ask whether a non-diver ticket actually includes guided snorkelling. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Published price reference:** THB 4700 / diver_day. published reference. Equipment, park charges, transfers and site suitability require item-level confirmation. Not a live or all-in quote. [Publisher](https://sea-bees.de/phuket-tauchtagestouren/).

**Published price reference:** THB 2600 / person_trip. published reference. Do not relabel a non-diver ticket as a guided snorkelling tour. Not a live or all-in quote. [Publisher](https://sea-bees.de/phuket-tauchtagestouren/).

**Tickets/access:** [Official ticket / operator information](https://sea-bees.de/phuket-tauchtagestouren/).

**Contact:** [Official visitor/contact route](https://sea-bees.de/phuket-tauchtagestouren/).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [Sea Bees Diving](https://sea-bees.de/phuket-tauchtagestouren/); [PADI](https://www.padi.com/diving-in/thailand/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Richelieu Rock specialist dive

**Location:** Mu Ko Surin / Richelieu Rock, Thailand.

A distinct offshore dive rather than a beach snorkel.

**Why go:** A distinct offshore site gives experienced divers a specific objective beyond choosing Thailand as a broad diving destination.

**Key attractions:** Richelieu Rock; Offshore diving; Marine-park context.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** A distinct offshore dive rather than a beach snorkel. Confirm current park access, certification requirements and sea conditions. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tourismthailand.org/Articles/mu-koh-surin-the-tropical-paradise-in-andaman).

**Contact:** [Official visitor/contact route](https://www.tourismthailand.org/Articles/mu-koh-surin-the-tropical-paradise-in-andaman).

**Evidence:** [Tourism Authority of Thailand](https://www.tourismthailand.org/Articles/mu-koh-surin-the-tropical-paradise-in-andaman); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Sharm el-Sheikh diving and reef trips

**Location:** Sharm el-Sheikh, Egypt.

Sharm el-Sheikh diving and reef trips combines reef diving, boat-based sites.

**Why go:** A reef-focused holiday base can support several underwater formats, from certified diving to separately organised surface trips.

**Key attractions:** Reef diving; Boat-based sites; Separate snorkelling formats.

**Season, typical conditions:** Not established. A destination source is present, but no month-level recommendation is asserted without reviewed evidence. [Season evidence](https://www.padi.com/diving-in/sharm-el-sheikh/).

**Season, regional conditions:** All months. Year-round regional Red Sea diving context; the snorkel excursion schedule remains unconfirmed. [Season evidence](https://www.padi.com/diving-in/egypt/).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Contact:** [Official visitor/contact route](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [PADI](https://www.padi.com/diving-in/sharm-el-sheikh/); [PADI](https://www.padi.com/diving-in/egypt/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Sipadan permit-led dive planning

**Location:** Semporna / Sipadan, Malaysia.

An offshore dive destination where seasonal appeal and actual permission need separate checks.

**Why go:** The offshore setting makes Sipadan a destination-led dive choice. Actual permission is part of the trip decision rather than a minor booking detail.

**Key attractions:** Offshore dive setting; Island marine environment; Permit-led visit.

**Season, typical conditions:** Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov. Tourism Malaysia highlights February-November for diving. [Season evidence](https://www.malaysia.travel/explore/sipadan-island).

**Plan around:** An offshore dive destination where seasonal appeal and actual permission need separate checks. Do not infer permit inventory from a calendar. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.malaysia.travel/explore/sipadan-island).

**Contact:** [Official visitor/contact route](https://www.malaysia.travel/explore/sipadan-island).

**Evidence:** [Tourism Malaysia](https://www.malaysia.travel/explore/sipadan-island). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Kadavu supported sea-kayak expedition

**Location:** Kadavu, Fiji.

Multi-day island paddling with support arrangements and optional reef exploration.

**Why go:** A supported multi-day paddle lets the islands become the journey, with optional reef exploration adding a second water experience.

**Key attractions:** Multi-day paddling; Island coastline; Optional reef exploration.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Drier regional climate, not a launch or route guarantee. [Season evidence](https://www.fiji.travel/things-to-know/weather-and-climate-in-fiji/climate-in-fiji).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fiji.travel/things-to-do/thrilling/adventures-for-the-eco-concious-travller).

**Contact:** [Official visitor/contact route](https://www.fiji.travel/things-to-do/thrilling/adventures-for-the-eco-concious-travller).

**Evidence:** [Tourism Fiji](https://www.fiji.travel/things-to-do/thrilling/adventures-for-the-eco-concious-travller); [Tourism Fiji](https://www.fiji.travel/things-to-know/weather-and-climate-in-fiji/climate-in-fiji). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Yasawa island-hopping kayak journey

**Location:** Yasawa Islands, Fiji.

Island paddling with a separate typical manta-viewing window.

**Why go:** Island-to-island paddling supplies the main journey, while a separate manta window can add a wildlife reason to choose the timing.

**Key attractions:** Island hopping; Sea kayaking; Separate manta-season interest.

**Season, manta ray:** May, Jun, Jul, Aug, Sep, Oct. Tourism Fiji describes manta encounters May-October; neither a sighting guarantee nor the full expedition calendar. [Season evidence](https://www.fiji.travel/things-to-do/thrilling/adventures-for-the-eco-concious-travller).

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Drier regional climate, not a launch or route guarantee. [Season evidence](https://www.fiji.travel/things-to-know/weather-and-climate-in-fiji/climate-in-fiji).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fiji.travel/things-to-do/thrilling/adventures-for-the-eco-concious-travller).

**Contact:** [Official visitor/contact route](https://www.fiji.travel/things-to-do/thrilling/adventures-for-the-eco-concious-travller).

**Evidence:** [Tourism Fiji](https://www.fiji.travel/things-to-do/thrilling/adventures-for-the-eco-concious-travller); [Tourism Fiji](https://www.fiji.travel/things-to-know/weather-and-climate-in-fiji/climate-in-fiji). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Futaleufu whitewater discovery

**Location:** Futaleufu, Chile.

A distinct Chilean whitewater destination; route grade and operating conditions need specialist confirmation.

**Why go:** The river itself is the destination for a specialist whitewater trip, rather than an incidental activity attached to a city break.

**Key attractions:** Whitewater river; Chilean setting; Operator-selected rafting routes.

**Season, regional conditions:** Dec, Jan, Feb, Mar. December-March is the highlighted rafting period inside a broader October-April season. River level and qualified operator assessment remain decisive. [Season evidence](https://chile.travel/en/blog/turquoise-waters-this-is-the-best-river-in-south-america-for-rafting/).

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://chile.travel/en/activities/adventure-and-sports/river-experiences/).

**Contact:** [Official visitor/contact route](https://chile.travel/en/activities/adventure-and-sports/river-experiences/).

**Evidence:** [SERNATUR / Chile Travel](https://chile.travel/en/activities/adventure-and-sports/river-experiences/); [Chile Travel](https://chile.travel/en/blog/turquoise-waters-this-is-the-best-river-in-south-america-for-rafting/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Soca guided rafting

**Location:** Soca Valley, Slovenia.

A guided whitewater outing; suitable river levels and swimming ability matter more than a generic summer label.

**Why go:** A guided river outing adds an active water experience to the Soca landscape without treating every flow level as equivalent.

**Key attractions:** Soca River; Guided rafting; Whitewater setting.

**Season, access window:** Mar, Apr, May, Jun, Jul, Aug, Sep, Oct. Published boating window March 15-October 31, subject to permits and current rules. Seasonal access is not a weather clearance. Published date window: {"start": "03-15", "end": "10-31"}. [Season evidence](https://www.soca-valley.com/en/in-search-of-adventure/nature/2020120910545268/the-soca-river/).

**Published restriction:** Outside the published annual boating window. Confirm the current permit rules with the competent authority. [Source](https://www.soca-valley.com/en/in-search-of-adventure/nature/2020120910545268/the-soca-river/).

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.soca-valley.com/en/in-search-of-adventure/activities/2020120110560946/rafting/).

**Contact:** [Official visitor/contact route](https://www.soca-valley.com/en/in-search-of-adventure/activities/2020120110560946/rafting/).

**Evidence:** [Soca Valley Tourism](https://www.soca-valley.com/en/in-search-of-adventure/activities/2020120110560946/rafting/); [Soca Valley tourism](https://www.soca-valley.com/en/in-search-of-adventure/nature/2020120910545268/the-soca-river/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Nosy Be whale-shark safari

**Location:** Nosy Be / Nosy Komba, Madagascar.

A full-day wildlife outing with a Nosy Sakatia stop described by the operator.

**Why go:** A full-day marine safari combines wildlife searching with an island stop, offering more structure than a brief coastal cruise.

**Key attractions:** Whale-shark programme; Nosy Sakatia stop; Full-day boat format.

**Season, whale_shark:** Sep, Oct, Nov, Dec. Marine-park publisher describes whale-shark presence around Nosy Be September-December. [Season evidence](https://www.tanikely.com/en/national-marine-park/).

**Plan around:** A full-day wildlife outing with a Nosy Sakatia stop described by the operator. Verify which whale or whale-shark programme runs on your date. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Published price reference:** EUR 80 / adult_trip. published reference. Adult excursion reference; child under 12 listed separately at EUR 50. Not a live or all-in quote. [Publisher](https://www.floralykomba.com/en/blog/whale-season-nosy-be/).

**Tickets/access:** [Official ticket / operator information](https://www.floralykomba.com/en/blog/whale-season-nosy-be/).

**Contact:** [Official visitor/contact route](https://www.floralykomba.com/en/blog/whale-season-nosy-be/).

**Evidence:** [Floraly Komba](https://www.floralykomba.com/en/blog/whale-season-nosy-be/); [Nosy Tanikely National Marine Park](https://www.tanikely.com/en/national-marine-park/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Bunaken reef snorkelling

**Location:** Manado / Bunaken, Indonesia.

A marine-park reef discovery.

**Why go:** A marine-park reef visit provides a surface-viewing alternative to deeper diving, allowing the same region to serve different underwater interests.

**Key attractions:** Marine-park reefs; Surface snorkelling; Separate deeper dive sites.

**Season, regional conditions:** Apr, May, Jun, Jul, Aug, Sep, Oct. Drier Bunaken-region window; conditions can vary by reef. [Season evidence](https://www.padi.com/diving-in/north-sulawesi/).

**Plan around:** A marine-park reef discovery. Separate a shallow guided snorkel from the park's deeper dive sites. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.indonesia.travel/au/en/destination/sulawesi/north-sulawesi/snorkeling-bunaken-national-park).

**Contact:** [Official visitor/contact route](https://www.indonesia.travel/au/en/destination/sulawesi/north-sulawesi/snorkeling-bunaken-national-park).

**Evidence:** [Indonesia Ministry of Tourism](https://www.indonesia.travel/au/en/destination/sulawesi/north-sulawesi/snorkeling-bunaken-national-park); [PADI](https://www.padi.com/diving-in/north-sulawesi/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Cano Island snorkelling boat trip

**Location:** Cano Island and Uvita, Costa Rica.

A surface-snorkelling excursion distinct from a scuba-diving booking.

**Why go:** An island excursion lets surface snorkellers choose a reef-focused boat day without paying for or assuming a scuba product.

**Key attractions:** Island reefs; Surface snorkelling; Boat excursion.

**Season, operator program:** Not established. No reliable month-level operating schedule was extracted. [Season evidence](https://www.bahiaaventuras.com/tours/cano-island/).

**Season, regional conditions:** Dec, Jan, Feb, Mar, Apr. Pacific dry-season context; not the Caribbean coast or a river-flow assessment. [Season evidence](https://www.visitcostarica.com/planning-your-trip/climate).

**Plan around:** A surface-snorkelling excursion distinct from a scuba-diving booking. Store marine-park permissions, transfer details and sea conditions independently from wildlife possibilities. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.bahiaaventuras.com/tours/cano-island/).

**Contact:** [Official visitor/contact route](https://www.bahiaaventuras.com/tours/cano-island/).

**Evidence:** [Bahia Aventuras](https://www.bahiaaventuras.com/tours/cano-island/); [Bahia Aventuras](https://www.bahiaaventuras.com/contact/); [Costa Rica Tourism Institute](https://www.visitcostarica.com/planning-your-trip/climate). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Mafia Island whale-shark discovery

**Location:** Mafia Island, Tanzania, United Republic of.

A wildlife-led trip with an operator-described October-March peak.

**Why go:** A distinct whale-shark peak gives this trip a clear wildlife purpose and a useful seasonal planning question.

**Key attractions:** Whale sharks; Island-water setting; Seasonal wildlife programme.

**Season, whale_shark:** Oct, Nov, Dec, Jan, Feb, Mar. Operator describes October-March as peak period; year-round presence is not year-round easy observation. [Season evidence](https://staywithsimba.com/).

**Plan around:** A wildlife-led trip with an operator-described October-March peak. The season is not a numerical sighting probability. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://staywithsimba.com/).

**Contact:** [Official visitor/contact route](https://staywithsimba.com/).

**Evidence:** [Stay with Simba](https://staywithsimba.com/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #55: Surin Islands reef snorkelling

**Location:** Phang Nga / Mu Ko Surin, Thailand.

An offshore national-park snorkel option north of Phuket.

**Why go:** Offshore national-park reefs provide a different snorkelling proposition from beach-adjacent stops around Phuket.

**Key attractions:** Offshore reefs; National-park islands; Seasonal boat access.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** An offshore national-park snorkel option north of Phuket. Obtain the current annual opening notice and transport plan before fixing dates. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tourismthailand.org/Articles/mu-koh-surin-the-tropical-paradise-in-andaman).

**Contact:** [Official visitor/contact route](https://www.tourismthailand.org/Articles/mu-koh-surin-the-tropical-paradise-in-andaman).

**Evidence:** [Tourism Authority of Thailand](https://www.tourismthailand.org/Articles/mu-koh-surin-the-tropical-paradise-in-andaman); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #75: Panagsama sardine snorkelling

**Location:** Moalboal / Panagsama Beach, Philippines.

A shore-access fish-school discovery, distinct from South Africa's moving sardine run.

**Why go:** The shore-access sardine school supplies a strong underwater attraction without requiring a remote expedition.

**Key attractions:** Sardine school; Shore-access snorkelling; Panagsama coastal setting.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr, May. November-May is the drier Cebu diving context. This does not establish a boat departure or guarantee a sardine encounter. [Season evidence](https://www.padi.com/diving-in/cebu/).

**Plan around:** A shore-access fish-school discovery, distinct from South Africa's moving sardine run. Do not import the African seasonal calendar. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://philippines.travel/destinations/moalboal/index).

**Contact:** [Official visitor/contact route](https://philippines.travel/destinations/moalboal/index).

**Evidence:** [Philippines Department of Tourism](https://philippines.travel/destinations/moalboal/index); [PADI](https://www.padi.com/diving-in/cebu/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #75: KwaZulu-Natal sardine-run discovery

**Location:** KwaZulu-Natal coast, South Africa.

A moving wildlife phenomenon, not a fixed guaranteed attraction.

**Why go:** A moving marine phenomenon rewards event-led planning and offers different viewing formats rather than one fixed attraction.

**Key attractions:** Sardine movement; Associated marine wildlife; Shore or specialist boat observation.

**Season, sardine_aggregation:** May, Jun, Jul. The tourism authority describes a May-July seasonal window; exact shoals and locations vary. [Season evidence](https://www.southafrica.net/za/en/travel/category/what-you-need-to-know/best-times-to-visit-south-africa).

**Plan around:** A moving wildlife phenomenon, not a fixed guaranteed attraction. Compare shore observation with specialist boat products. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.southafrica.net/za/en/travel/category/what-you-need-to-know/best-times-to-visit-south-africa).

**Contact:** [Official visitor/contact route](https://www.southafrica.net/za/en/travel/category/what-you-need-to-know/best-times-to-visit-south-africa).

**Evidence:** [South African Tourism](https://www.southafrica.net/za/en/travel/category/what-you-need-to-know/best-times-to-visit-south-africa). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Calo des Mort beach

**Location:** Formentera, Spain.

Named in the national summer beach guide.

**Why go:** A named Formentera shore gives an island visit a specific beach objective rather than a generic Mediterranean recommendation.

**Key attractions:** Calo des Mort; Formentera coast; Shore visit.

**Season, editorial season mapping:** Jun, Jul, Aug. Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate. [Season evidence](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Plan around:** Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Contact:** [Official visitor/contact route](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Evidence:** [Spain Tourism](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Camps Bay beach

**Location:** Cape Town, South Africa.

Southern summer beach visit framed by the Atlantic and mountain backdrop.

**Why go:** The combination of Atlantic shoreline and mountain backdrop gives a beach visit value even when entering cold water is not the plan.

**Key attractions:** Atlantic shore; Mountain backdrop; Southern-summer beach visit.

**Season, editorial season mapping:** Dec, Jan, Feb. Southern summer beach visit framed by the Atlantic and mountain backdrop. Water can be cold; conditions are separate. [Season evidence](https://www.capetown.travel/the-ultimate-cape-town-beach-guide-for-every-type-of-traveller/).

**Plan around:** Southern summer beach visit framed by the Atlantic and mountain backdrop. Water can be cold; conditions are separate. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.capetown.travel/the-ultimate-cape-town-beach-guide-for-every-type-of-traveller/).

**Contact:** [Official visitor/contact route](https://www.capetown.travel/the-ultimate-cape-town-beach-guide-for-every-type-of-traveller/).

**Evidence:** [Cape Town Tourism](https://www.capetown.travel/the-ultimate-cape-town-beach-guide-for-every-type-of-traveller/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Cavalleria beach

**Location:** Menorca, Spain.

Named in the national summer beach guide.

**Why go:** A specific Menorca coastal destination adds variety to an island beach shortlist without borrowing another cove's access assumptions.

**Key attractions:** Cavalleria beach; Menorca coastline; Seasonal shore visit.

**Season, editorial season mapping:** Jun, Jul, Aug. Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate. [Season evidence](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Plan around:** Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Contact:** [Official visitor/contact route](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Evidence:** [Spain Tourism](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Clifton Fourth Beach

**Location:** Cape Town, South Africa.

Atlantic cove beach in southern summer; crowding, cold water and access steps need checking.

**Why go:** A cove setting offers a distinct Cape Town beach experience, with the shore itself remaining attractive when swimming conditions are unsuitable.

**Key attractions:** Atlantic cove; Coastal scenery; Beach viewing.

**Season, editorial season mapping:** Dec, Jan, Feb. Atlantic cove beach in southern summer; crowding, cold water and access steps need checking. [Season evidence](https://www.capetown.travel/the-ultimate-cape-town-beach-guide-for-every-type-of-traveller/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.capetown.gov.za/see-all-city-facilities/our-recreational-facilities/beaches/clifton-4th-beach/).

**Contact:** [Official visitor/contact route](https://www.capetown.gov.za/see-all-city-facilities/our-recreational-facilities/beaches/clifton-4th-beach/).

**Evidence:** [City of Cape Town](https://www.capetown.gov.za/see-all-city-facilities/our-recreational-facilities/beaches/clifton-4th-beach/); [Cape Town Tourism](https://www.capetown.travel/the-ultimate-cape-town-beach-guide-for-every-type-of-traveller/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Playa Conchal

**Location:** Guanacaste, Costa Rica.

Pacific dry-season beach discovery; current sea state and access remain local checks.

**Why go:** A Pacific-coast beach supplies a straightforward shore-based alternative to an excursion, with a separate dry-season planning window.

**Key attractions:** Playa Conchal; Pacific coast; Dry-season shore outing.

**Season, regional conditions:** Dec, Jan, Feb, Mar, Apr. Pacific dry-season beach discovery; current sea state and access remain local checks. [Season evidence](https://www.visitcostarica.com/planning-your-trip/climate).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitcostarica.com/planning-your-trip/climate).

**Contact:** [Official visitor/contact route](https://www.visitcostarica.com/planning-your-trip/climate).

**Evidence:** [Costa Rica Tourism Institute](https://www.visitcostarica.com/planning-your-trip/climate). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Es Trenc beach

**Location:** Mallorca, Spain.

Named in the national summer beach guide.

**Why go:** A named Mallorca beach gives visitors a coastal alternative to a boat itinerary or a generic island-wide search.

**Key attractions:** Es Trenc beach; Mallorca coast; Summer shore visit.

**Season, editorial season mapping:** Jun, Jul, Aug. Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate. [Season evidence](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Plan around:** Named in the national summer beach guide. June-August maps the broad season; crowding, access and sea conditions are separate. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Contact:** [Official visitor/contact route](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/).

**Evidence:** [Spain Tourism](https://www.spain.info/en/top/spend-a-summer-holiday-on-the-best-beaches-in-balearic-islands/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Jamaica Beach, Sirmione

**Location:** Southern Lake Garda, Italy.

Summer lake-shore visit at Sirmione.

**Why go:** A lakeside setting at Sirmione makes this a freshwater-coast discovery rather than another sea-beach recommendation.

**Key attractions:** Lake Garda shore; Sirmione setting; Stone shoreline.

**Season, editorial season mapping:** Jun, Jul, Aug. Summer lake-shore visit at Sirmione. Stone surfaces and lake levels need checking. [Season evidence](https://visitlagodigarda.it/en/lake-garda-beaches/).

**Plan around:** Summer lake-shore visit at Sirmione. Stone surfaces and lake levels need checking. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitlagodigarda.it/en/lake-garda-beaches/).

**Contact:** [Official visitor/contact route](https://visitlagodigarda.it/en/lake-garda-beaches/).

**Evidence:** [Visit Lago di Garda](https://visitlagodigarda.it/en/lake-garda-beaches/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Palombaggia beach

**Location:** Porto-Vecchio, Corsica, France.

June/September quieter; named lifeguarded sectors run July-August only.

**Why go:** The beach offers both quieter shoulder-period discovery and a distinct supervised-sector calendar during peak summer.

**Key attractions:** Corsican beach; Coastal setting; Season-specific supervised sectors.

**Season, regional conditions:** Jun, Jul, Aug, Sep. June/September quieter; named lifeguarded sectors run July-August only. [Season evidence](https://www.portovecchio-tourisme.corsica/en/faq-plages-porto-vecchio/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.portovecchio-tourisme.corsica/en/faq-plages-porto-vecchio/).

**Contact:** [Official visitor/contact route](https://www.portovecchio-tourisme.corsica/en/faq-plages-porto-vecchio/).

**Evidence:** [Porto-Vecchio tourism office](https://www.portovecchio-tourisme.corsica/en/faq-plages-porto-vecchio/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Santa Giulia beach

**Location:** Porto-Vecchio, Corsica, France.

June/September quieter; named lifeguarded sectors run July-August only.

**Why go:** A named Corsican beach can serve different visit styles across the season, from shoulder-period scenery to peak-summer facilities.

**Key attractions:** Santa Giulia beach; Coastal landscape; Seasonal facility context.

**Season, regional conditions:** Jun, Jul, Aug, Sep. June/September quieter; named lifeguarded sectors run July-August only. [Season evidence](https://www.portovecchio-tourisme.corsica/en/faq-plages-porto-vecchio/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.portovecchio-tourisme.corsica/en/faq-plages-porto-vecchio/).

**Contact:** [Official visitor/contact route](https://www.portovecchio-tourisme.corsica/en/faq-plages-porto-vecchio/).

**Evidence:** [Porto-Vecchio tourism office](https://www.portovecchio-tourisme.corsica/en/faq-plages-porto-vecchio/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Temae Beach

**Location:** Moorea, French Polynesia.

Drier-season Moorea beach discovery; lagoon exposure and current access vary.

**Why go:** A Moorea shoreline visit provides lagoon-side scenery without committing the whole day to an offshore excursion.

**Key attractions:** Temae Beach; Moorea coast; Lagoon setting.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Drier-season Moorea beach discovery; lagoon exposure and current access vary. [Season evidence](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Contact:** [Official visitor/contact route](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Evidence:** [Tahiti Tourisme](https://www.tahititourisme.uk/preparing-you-trip/when-to-visit-the-islands-of-tahiti/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Lunga seabird boat trip

**Location:** Tiree / Treshnish Isles, United Kingdom.

A boat trip to a seabird island.

**Why go:** A boat journey to a seabird island creates a marine-wildlife outing for people whose main interest is above the water.

**Key attractions:** Seabird island; Boat approach; Nesting-season interest.

**Season, regional operator reference:** Apr, May, Jun, Jul, Aug, Sep, Oct. Typical tour season April-October. Puffins mostly April to early August. A landing-maintenance notice has no reliably established year and must be checked for the planned trip. [Season evidence](https://staffatours.com/faq/).

**Season, Puffin:** Apr, May, Jun, Jul. Puffin window extends into early August in the source. Full months April-July are shown conservatively; check the August boundary. [Season evidence](https://staffatours.com/faq/).

**Plan around:** A boat trip to a seabird island. Landing access and nesting-season controls require confirmation. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitscotland.com/info/tours/lunga-treshnish-isles-9a37aa0b).

**Contact:** [Official visitor/contact route](https://www.visitscotland.com/info/tours/lunga-treshnish-isles-9a37aa0b).

**Evidence:** [VisitScotland / listed provider](https://www.visitscotland.com/info/tours/lunga-treshnish-isles-9a37aa0b); [Staffa Tours](https://staffatours.com/faq/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Ri Ri Blue Hole outrigger approach

**Location:** Espiritu Santo, Vanuatu.

A locally paddled canoe approach turns a swimming destination into a water journey.

**Why go:** The canoe approach turns a freshwater swimming destination into a journey, offering a distinct alternative to simply arriving by road.

**Key attractions:** Outrigger canoe; Blue-hole approach; Freshwater destination.

**Season, regional conditions:** Apr, May, Jun, Jul, Aug, Sep. April-September is the cooler seasonal context. December-April is wetter with cyclone exposure; river levels and access need separate checks. [Season evidence](https://www.vanuatu.travel/en/things-to-know/travel-tips/weather).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.vanuatu.travel/en/component/content/article/124-riri-blue-hole).

**Contact:** [Official visitor/contact route](https://www.vanuatu.travel/en/component/content/article/124-riri-blue-hole).

**Evidence:** [Vanuatu Tourism Office](https://www.vanuatu.travel/en/component/content/article/124-riri-blue-hole); [Vanuatu Tourism Office](https://www.vanuatu.travel/en/things-to-know/travel-tips/weather). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Lake Brienz rail-and-boat day

**Location:** Lake Brienz, Switzerland.

Combine the lake boat with the rail network; check that the chosen seasonal connection exists.

**Why go:** The lake voyage can connect with rail travel, letting the transport itself provide the scenic water experience.

**Key attractions:** Lake Brienz; Boat journey; Rail connection possibilities.

**Season, dated programme:** Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec. The published 2026 boat season is April 3 to December 6. This does not mean every route or vessel runs daily. Published date window: {"start": "2026-04-03", "end": "2026-12-06"}. [Season evidence](https://www.bls.ch/de/freizeit-und-ferien/ausfluege/schifffahrt-brienzersee).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.myswitzerland.com/en-us/experiences/bernese-oberland-cruises/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/bernese-oberland-cruises/).

**Evidence:** [Switzerland Tourism](https://www.myswitzerland.com/en-us/experiences/bernese-oberland-cruises/); [BLS](https://www.bls.ch/de/freizeit-und-ferien/ausfluege/schifffahrt-brienzersee). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Lake Como Como-Colico boat corridor

**Location:** Como and upper Lake Como, Italy.

Lake Como Como-Colico boat corridor combines lake como corridor, como-colico route.

**Why go:** The longer lake corridor offers a journey through the water landscape rather than a brief local crossing.

**Key attractions:** Lake Como corridor; Como-Colico route; Ordinary and fast-service choices.

**Season, dated programme:** Nov, Dec, Jan, Feb, Mar. The current search excerpt identifies a November 2, 2026 to March 14, 2027 timetable for the Como-Colico corridor and central-lake ferries. The opened page returned an older summer cache. Retain the evidence conflict and confirm the current timetable directly. Published date window: {"start": "2026-11-02", "end": "2027-03-14"}. [Season evidence](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/).

**Contact:** [Official visitor/contact route](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/).

**Evidence:** [Navigazione Laghi](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/); [Navigazione Laghi](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Lake Geneva heritage and Chillon cruise

**Location:** Lausanne and eastern Lake Geneva, Switzerland.

A seasonal sightseeing and dining product with a clearly expired summer programme in the reviewed source.

**Why go:** A heritage-and-water outing combines lake scenery with the Chillon theme, with dining available only through the specified product.

**Key attractions:** Lake Geneva; Chillon theme; Seasonal sightseeing programme.

**Season, operator program:** Jun, Jul, Aug, Sep. Reviewed summer programme ran 1 June-21 September 2026. Published date window: {"start": "06-01", "end": "09-21"}. [Season evidence](https://www.cgn.ch/en/lunch-on-the-lake-patrimoine-tour.html).

**Plan around:** A seasonal sightseeing and dining product with a clearly expired summer programme in the reviewed source. Preserve it as a planning idea while requiring a new dated offer before displaying bookable departures. Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.cgn.ch/en/lunch-on-the-lake-patrimoine-tour.html).

**Contact:** [Official visitor/contact route](https://www.cgn.ch/en/lunch-on-the-lake-patrimoine-tour.html).

**Evidence:** [CGN](https://www.cgn.ch/en/lunch-on-the-lake-patrimoine-tour.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Lake Thun rail-and-boat day

**Location:** Lake Thun, Switzerland.

Combine the lake boat with the rail network; check that the chosen seasonal connection exists.

**Why go:** A lake boat can become the scenic section of a rail-based day rather than an isolated sightseeing add-on.

**Key attractions:** Lake Thun; Boat journey; Rail connection possibilities.

**Season, operator pattern:** All months. Lake Thun has a year-round boat offer. [Season evidence](https://www.bls.ch/en/freizeit-und-ferien/ausfluege/schifffahrt-thunersee-brienzersee).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.bls.ch/en/freizeit-und-ferien/ausfluege/schifffahrt-thunersee-brienzersee).

**Contact:** [Official visitor/contact route](https://www.bls.ch/en/freizeit-und-ferien/ausfluege/schifffahrt-thunersee-brienzersee).

**Evidence:** [Switzerland Tourism](https://www.myswitzerland.com/en-us/experiences/bernese-oberland-cruises/); [BLS](https://www.bls.ch/en/freizeit-und-ferien/ausfluege/schifffahrt-thunersee-brienzersee). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Pescador Island reef and wall outing

**Location:** Moalboal / Pescador Island, Philippines.

A boat excursion to reef and wall habitats.

**Why go:** Reef and wall environments give the island outing specific underwater interest, with different experiences for divers and surface visitors.

**Key attractions:** Pescador Island; Reef environment; Underwater walls.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr, May. November-May is the drier Cebu diving context. This does not establish a boat departure or guarantee a sardine encounter. [Season evidence](https://www.padi.com/diving-in/cebu/).

**Plan around:** A boat excursion to reef and wall habitats. Confirm whether the selected product is a dive or snorkel trip. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://philippines.travel/destinations/moalboal/index).

**Contact:** [Official visitor/contact route](https://philippines.travel/destinations/moalboal/index).

**Evidence:** [Philippines Department of Tourism](https://philippines.travel/destinations/moalboal/index); [PADI](https://www.padi.com/diving-in/cebu/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Lake Como central-lake ferries

**Location:** Bellagio, Varenna, Menaggio and Cadenabbia, Italy.

Lake Como central-lake ferries combines central lake como, public crossings.

**Why go:** A useful ferry crossing can also be the sightseeing experience, allowing visitors to connect lake places without choosing a packaged cruise.

**Key attractions:** Central Lake Como; Public crossings; Lakeside destinations.

**Season, dated programme:** Nov, Dec, Jan, Feb, Mar. The current search excerpt identifies a November 2, 2026 to March 14, 2027 timetable for the Como-Colico corridor and central-lake ferries. The opened page returned an older summer cache. Retain the evidence conflict and confirm the current timetable directly. Published date window: {"start": "2026-11-02", "end": "2027-03-14"}. [Season evidence](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/).

**Contact:** [Official visitor/contact route](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/).

**Evidence:** [Navigazione Laghi](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/); [Navigazione Laghi](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-como/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Gothenburg southern-archipelago paddling

**Location:** Gothenburg southern archipelago, Sweden.

A distinct Swedish paddling area with local routes and operator choices to confirm.

**Why go:** Archipelago paddling adds an island-water perspective to a Gothenburg visit rather than another city-centre activity.

**Key attractions:** Southern archipelago; Island paddling; Local route options.

**Season, regional conditions:** Jun, Jul, Aug, Sep. June-September is the broad summer kayaking context. The High Coast and southern archipelagos have different exposures; this is not a local launch or weather approval. [Season evidence](https://traveltrade.visitsweden.com/why-sweden/practical-information/seasons-climate-and-weather/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/).

**Contact:** [Official visitor/contact route](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/).

**Evidence:** [Visit Sweden](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/); [Visit Sweden](https://traveltrade.visitsweden.com/why-sweden/practical-information/seasons-climate-and-weather/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Grebbestad culinary paddling

**Location:** Grebbestad, Sweden.

A distinct Swedish paddling area with local routes and operator choices to confirm.

**Why go:** The culinary-paddling format gives the outing a food-and-water purpose beyond a standard equipment rental.

**Key attractions:** Coastal paddling; Culinary theme; Guided outing format.

**Season, regional conditions:** Jun, Jul, Aug, Sep. June-September is the broad summer kayaking context. The High Coast and southern archipelagos have different exposures; this is not a local launch or weather approval. [Season evidence](https://traveltrade.visitsweden.com/why-sweden/practical-information/seasons-climate-and-weather/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/).

**Contact:** [Official visitor/contact route](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/).

**Evidence:** [Visit Sweden](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/); [Visit Sweden](https://traveltrade.visitsweden.com/why-sweden/practical-information/seasons-climate-and-weather/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Ha Long Bay cruise-and-kayak discovery

**Location:** Ha Long Bay, Viet Nam.

Ha Long Bay cruise-and-kayak discovery combines bay scenery, water-level paddling.

**Why go:** Kayaking supplies a closer water-level component within a bay cruise, provided the actual itinerary allocates meaningful paddling time.

**Key attractions:** Bay scenery; Water-level paddling; Cruise-and-kayak format.

**Season, regional conditions:** Apr, May, Jun, Sep, Oct, Nov. April-June and September-November are highlighted for Ha Long. Storms can cancel cruises, including within a preferred month. [Season evidence](https://vietnam.travel/things-to-do/weather-and-climate-vietnam/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://vietnam.travel/things-to-do/what-to-do-in-ha-long-bay/).

**Contact:** [Official visitor/contact route](https://vietnam.travel/things-to-do/what-to-do-in-ha-long-bay/).

**Evidence:** [Vietnam National Authority of Tourism](https://vietnam.travel/things-to-do/what-to-do-in-ha-long-bay/); [Vietnam Tourism](https://vietnam.travel/things-to-do/weather-and-climate-vietnam/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: High Coast sea-kayak discovery

**Location:** Hoga Kusten, Sweden.

A distinct Swedish paddling area with local routes and operator choices to confirm.

**Why go:** A distinct Swedish coastal region adds a landscape-led paddling choice without treating all archipelagos as interchangeable.

**Key attractions:** High Coast setting; Sea kayaking; Local coastal routes.

**Season, regional conditions:** Jun, Jul, Aug, Sep. June-September is the broad summer kayaking context. The High Coast and southern archipelagos have different exposures; this is not a local launch or weather approval. [Season evidence](https://traveltrade.visitsweden.com/why-sweden/practical-information/seasons-climate-and-weather/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/).

**Contact:** [Official visitor/contact route](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/).

**Evidence:** [Visit Sweden](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/); [Visit Sweden](https://traveltrade.visitsweden.com/why-sweden/practical-information/seasons-climate-and-weather/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: La Digue clear-kayak coast outing

**Location:** La Digue, Seychelles.

A transparent-kayak perspective on the granite coastline.

**Why go:** The transparent kayak changes how visitors experience the granite coastline, adding a viewing element to the paddle itself.

**Key attractions:** Granite coastline; Clear-kayak format; Coastal paddling.

**Season, regional conditions:** Mar, Apr, May, Sep, Oct, Nov. Regional calmer water-sports window; exposure differs by coast. [Season evidence](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Plan around:** A transparent-kayak perspective on the granite coastline. Ask about tides, launch location and weather cancellation. Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Contact:** [Official visitor/contact route](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Evidence:** [Tourism Seychelles](https://seychelles.com/blog-details/1915/highlights/day-excursions-mahe-praslin-and-la-digue); [Air Seychelles](https://fly.airseychelles.com/en/explore-seychelles/water-sports). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Stockholm archipelago kayak discovery

**Location:** Stockholm archipelago, Sweden.

A distinct Swedish paddling area with local routes and operator choices to confirm.

**Why go:** An archipelago paddle offers a water-based contrast to central Stockholm and can focus on the exact islands within reach.

**Key attractions:** Stockholm archipelago; Island waterways; Sea-kayak discovery.

**Season, regional conditions:** Jun, Jul, Aug, Sep. June-September is the broad summer kayaking context. The High Coast and southern archipelagos have different exposures; this is not a local launch or weather approval. [Season evidence](https://traveltrade.visitsweden.com/why-sweden/practical-information/seasons-climate-and-weather/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/).

**Contact:** [Official visitor/contact route](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/).

**Evidence:** [Visit Sweden](https://visitsweden.com/what-to-do/nature-outdoors/canoeing-and-kayaking/canoeing-kayaking/); [Visit Sweden](https://traveltrade.visitsweden.com/why-sweden/practical-information/seasons-climate-and-weather/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Coin de Mire boat snorkelling

**Location:** North Mauritius / Coin de Mire, Mauritius.

A boat-and-reef experience around a protected islet.

**Why go:** A protected-islet setting combines coastal scenery with reef viewing while preserving the distinction between a boat visit and a landing.

**Key attractions:** Coin de Mire; Reef snorkelling; Protected-islet waters.

**Season, regional conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr. October-April is a northern Mauritius underwater visiting reference. This regional window is not the exact Coin de Mire operator programme. [Season evidence](https://www.padi.com/diving-in/republic-of-mauritius/trou-aux-biches-grand-baie/).

**Published restriction:** Tourism authority states that visitors cannot step onto the protected islet. [Source](https://mauritiusnow.com/blog/things-to-do/coin-de-mire/).

**Plan around:** A boat-and-reef experience around a protected islet. A water excursion does not grant permission to land. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://mauritiusnow.com/blog/things-to-do/coin-de-mire/).

**Contact:** [Official visitor/contact route](https://mauritiusnow.com/blog/things-to-do/coin-de-mire/).

**Evidence:** [Mauritius Tourism Promotion Authority](https://mauritiusnow.com/blog/things-to-do/coin-de-mire/); [PADI](https://www.padi.com/diving-in/republic-of-mauritius/trou-aux-biches-grand-baie/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Daymaniyat Islands snorkel boat trip

**Location:** Muscat and Daymaniyat Islands, Oman.

Daymaniyat Islands snorkel boat trip combines daymaniyat islands, marine reserve.

**Why go:** The reserve setting gives a boat snorkel a clear destination, with the permit forming part of an honest comparison of trip costs.

**Key attractions:** Daymaniyat Islands; Marine reserve; Boat snorkelling.

**Season, regional conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr, May. Broad Oman underwater conditions window; permit and landing rules remain separate. [Season evidence](https://www.padi.com/diving-in/oman/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Published price reference:** OMR 30 / adult_trip. published reference. Adult trip 30 OMR plus 3 OMR government environmental permit. Other terms need confirmation. Not a live or all-in quote. [Publisher](https://www.daymaniat-shells.com/services/snorkelling).

**Published price reference:** OMR 45 / adult_trip. published reference. Full-day product, not the same ticket as the half-day trip. Adult45 OMR plus3 OMR permit. Not a live or all-in quote. [Publisher](https://www.daymaniat-shells.com/services/full-day-trip).

**Tickets/access:** [Official ticket / operator information](https://www.daymaniat-shells.com/services/snorkelling); [Official ticket / operator information](https://www.daymaniat-shells.com/services/full-day-trip).

**Contact:** [Official visitor/contact route](https://www.daymaniat-shells.com/services/snorkelling).

**Evidence:** [Daymaniat Shells](https://www.daymaniat-shells.com/services/snorkelling); [Daymaniat Shells](https://www.daymaniat-shells.com/services/full-day-trip); [PADI](https://www.padi.com/diving-in/oman/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Garden Key snorkelling day

**Location:** Dry Tortugas / Garden Key, United States.

Remote island snorkelling paired with a ferry or seaplane journey.

**Why go:** Remote-island snorkelling adds an underwater component to a journey that is already distinctive for its ferry or seaplane approach.

**Key attractions:** Garden Key; Island snorkelling; Remote-access journey.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct, Nov. Mid-May-November summer context can bring calmer seas but wetter weather. Published date window: {"start": "05-15", "end": "11-14"}. [Season evidence](https://www.nps.gov/drto/learn/nature/weather.htm).

**Plan around:** Remote island snorkelling paired with a ferry or seaplane journey. Transport availability and sea state determine the practical day. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.nps.gov/drto/learn/nature/weather.htm).

**Contact:** [Official visitor/contact route](https://www.nps.gov/drto/learn/nature/weather.htm).

**Evidence:** [US National Park Service](https://www.nps.gov/drto/planyourvisit/swimming-snorkeling-and-diving.htm); [US National Park Service](https://www.nps.gov/drto/learn/nature/weather.htm). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Fitzroy Island shore snorkelling

**Location:** Cairns / Fitzroy Island, Australia.

A ferry-based island day with shore snorkelling.

**Why go:** A ferry-based island day combines a defined transport route with the flexibility of shore snorkelling.

**Key attractions:** Fitzroy Island; Shore snorkelling; Ferry-based outing.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Broad Great Barrier Reef dry-season context; reef sectors and operations differ. [Season evidence](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html).

**Plan around:** A ferry-based island day with shore snorkelling. Confirm the final return departure before entering the water. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Contact:** [Official visitor/contact route](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Evidence:** [Tourism and Events Queensland](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland); [Tourism Australia](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Heron Island reef snorkelling

**Location:** Gladstone / Heron Island, Australia.

Island-based snorkelling with a shallow lagoon and turtle habitat.

**Why go:** A shallow lagoon and turtle habitat give an island stay a direct reef-viewing focus beyond a conventional beach holiday.

**Key attractions:** Island lagoon; Reef snorkelling; Turtle habitat.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Broad Great Barrier Reef dry-season context; reef sectors and operations differ. [Season evidence](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html).

**Plan around:** Island-based snorkelling with a shallow lagoon and turtle habitat. Plan the island transfer separately. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Contact:** [Official visitor/contact route](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Evidence:** [Tourism and Events Queensland](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland); [Tourism Australia](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Jabang soft-coral boat stop

**Location:** Ko Lipe / Jabang channel, Thailand.

Soft-coral viewing in a channel where the authority highlights strong current.

**Why go:** Soft corals provide a specific underwater attraction, making the site more than an interchangeable stop on an island tour.

**Key attractions:** Soft corals; Channel setting; Boat-based viewing.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** Soft-coral viewing in a channel where the authority highlights strong current. Local conditions, not the attractive reef label, determine access. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://thai.tourismthailand.org/Articles/%E0%B8%A3%E0%B9%88%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B8%88%E0%B8%B2%E0%B8%9A%E0%B8%B1%E0%B8%87-%E0%B8%88-%E0%B8%AA%E0%B8%95%E0%B8%B9%E0%B8%A5).

**Contact:** [Official visitor/contact route](https://thai.tourismthailand.org/Articles/%E0%B8%A3%E0%B9%88%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B8%88%E0%B8%B2%E0%B8%9A%E0%B8%B1%E0%B8%87-%E0%B8%88-%E0%B8%AA%E0%B8%95%E0%B8%B9%E0%B8%A5).

**Evidence:** [Tourism Authority of Thailand](https://thai.tourismthailand.org/Articles/%E0%B8%A3%E0%B9%88%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B8%88%E0%B8%B2%E0%B8%9A%E0%B8%B1%E0%B8%87-%E0%B8%88-%E0%B8%AA%E0%B8%95%E0%B8%B9%E0%B8%A5); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Kisite-Mpunguti reef excursion

**Location:** Kisite-Mpunguti, Kenya.

Explore a distinct Kenyan marine protected area with its own departure and access arrangements.

**Why go:** A named Kenyan marine protected area gives the excursion a clearer purpose than a generic coastal boat ride.

**Key attractions:** Kisite-Mpunguti; Protected marine waters; Reef excursion.

**Season, regional conditions:** Oct, Nov, Dec, Jan, Feb, Mar. October-March is a broad coastal underwater conditions reference. Individual marine parks, surface conditions and boats need separate checking. [Season evidence](https://travel.padi.com/s/dive-resorts/kenya/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://kws.go.ke/park/kisite-mpunguti-marine-national-park-reserve/).

**Contact:** [Official visitor/contact route](https://kws.go.ke/park/kisite-mpunguti-marine-national-park-reserve/).

**Evidence:** [Kenya Wildlife Service](https://kws.go.ke/park/kisite-mpunguti-marine-national-park-reserve/); [PADI Travel](https://travel.padi.com/s/dive-resorts/kenya/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Lady Musgrave lagoon excursion

**Location:** Bundaberg / Lady Musgrave Island, Australia.

A coral-cay lagoon outing.

**Why go:** A coral-cay lagoon provides both a distinctive setting and a focused reef excursion, with transport and activities compared separately.

**Key attractions:** Coral cay; Lagoon; Boat-based reef outing.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Broad Great Barrier Reef dry-season context; reef sectors and operations differ. [Season evidence](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html).

**Plan around:** A coral-cay lagoon outing. Boat transport, equipment and guided activities may be separate fare components. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Contact:** [Official visitor/contact route](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Evidence:** [Tourism and Events Queensland](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland); [Tourism Australia](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Perhentian guided reef discovery

**Location:** Perhentian Islands, Malaysia.

An identified Terengganu island-water destination.

**Why go:** An island-specific reef discovery helps visitors choose a Terengganu base rather than treating the whole coast as one snorkelling destination.

**Key attractions:** Perhentian Islands; Reef viewing; Island excursion.

**Season, regional conditions:** Mar, Apr, May, Jun, Jul, Aug, Sep, Oct. March-October is the published east-coast diving window for Perhentian and Tenggol. Monsoon affects transport and operations; individual schedules require checking. [Season evidence](https://www.sekawantravel.com/east-coast-diving-season/).

**Plan around:** An identified Terengganu island-water destination. Confirm the specific transfer, operating season and reef activity rather than borrowing another island's schedule. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Contact:** [Official visitor/contact route](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Evidence:** [Tourism Malaysia](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/); [Sekawan Travel](https://www.sekawantravel.com/east-coast-diving-season/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Phi Phi reef and island boat excursion

**Location:** Phuket to Phi Phi, Thailand.

A boat excursion combining reef snorkelling and island sightseeing.

**Why go:** Combining reef stops with island sightseeing gives a mixed-interest group more than a beach-only or dive-only day.

**Key attractions:** Reef snorkelling; Island sightseeing; Boat excursion.

**Season, operator program:** Not established. Sunrise, seasonal sunset and private products have different calendars. [Season evidence](https://simbaseatrips.com/tours/phi-phi-island-tour/).

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** A boat excursion combining reef snorkelling and island sightseeing. Display the boat departure separately from hotel pickup, and never infer permission to swim at every named sightseeing stop. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://simbaseatrips.com/join-in-tours/).

**Contact:** [Official visitor/contact route](https://simbaseatrips.com/join-in-tours/).

**Evidence:** [Simba Sea Trips](https://simbaseatrips.com/join-in-tours/); [Simba Sea Trips](https://simbaseatrips.com/tours/phi-phi-island-tour/); [Tourism Authority of Thailand](https://www.tatnews.org/2026/10/the-andaman-opens-its-doors-again/); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Redang reef-and-island discovery

**Location:** Redang, Malaysia.

An identified Terengganu island-water destination.

**Why go:** A reef-and-island visit gives Redang its own place in the shortlist rather than borrowing the schedule and character of neighbouring islands.

**Key attractions:** Redang Island; Reef discovery; Island-water setting.

**Season, regional conditions:** Mar, Apr, May, Jun, Jul, Aug, Sep, Oct. Main island-visit window; many resorts suspend in monsoon. [Season evidence](https://www.malaysia.travel/index.php/explore/redang-island).

**Plan around:** An identified Terengganu island-water destination. Confirm the specific transfer, operating season and reef activity rather than borrowing another island's schedule. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Contact:** [Official visitor/contact route](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Evidence:** [Tourism Malaysia](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/); [Tourism Malaysia](https://www.malaysia.travel/index.php/explore/redang-island). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Tioman ferry-and-reef outing

**Location:** Mersing / Tioman, Malaysia.

A reef holiday with a ferry dependency.

**Why go:** The ferry approach and reef setting form a complete island outing, with transport availability part of the attraction's practical character.

**Key attractions:** Tioman Island; Reef snorkelling; Ferry approach.

**Season, regional conditions:** Mar, Apr, May, Jun, Jul, Aug, Sep, Oct. Main island-visit window; monsoon can affect access. [Season evidence](https://www.malaysia.travel/explore/tioman-island).

**Plan around:** A reef holiday with a ferry dependency. The authority flags a late-October to early-February monsoon; check actual sailings and operators. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.malaysia.travel/explore/tioman-island).

**Contact:** [Official visitor/contact route](https://www.malaysia.travel/explore/tioman-island).

**Evidence:** [Tourism Malaysia](https://www.malaysia.travel/explore/tioman-island); [Tourism Malaysia](https://www.malaysia.travel/explore/tioman-island). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Watamu marine-reserve snorkelling

**Location:** Watamu, Kenya.

Explore a distinct Kenyan marine protected area with its own departure and access arrangements.

**Why go:** A distinct marine-reserve setting adds a specific reef experience to a Kenyan coast stay.

**Key attractions:** Watamu reserve; Reef snorkelling; Protected marine setting.

**Season, regional conditions:** Oct, Nov, Dec, Jan, Feb, Mar. October-March is a broad coastal underwater conditions reference. Individual marine parks, surface conditions and boats need separate checking. [Season evidence](https://travel.padi.com/s/dive-resorts/kenya/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://kws.go.ke/park/watamu-marine-national-park-reserve/).

**Contact:** [Official visitor/contact route](https://kws.go.ke/park/watamu-marine-national-park-reserve/).

**Evidence:** [Kenya Wildlife Service](https://kws.go.ke/park/watamu-marine-national-park-reserve/); [PADI Travel](https://travel.padi.com/s/dive-resorts/kenya/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Wilson Island reef stay

**Location:** Wilson Island, Gladstone, Australia.

A reef-fringed island stay with beach snorkelling.

**Why go:** A reef-fringed island stay offers snorkelling as part of the base itself, rather than a separate daily excursion from a mainland hotel.

**Key attractions:** Reef-fringed island; Beach snorkelling; Island-stay format.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Broad Great Barrier Reef dry-season context; reef sectors and operations differ. [Season evidence](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html).

**Plan around:** A reef-fringed island stay with beach snorkelling. Treat accommodation-dependent access separately from public day access. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Contact:** [Official visitor/contact route](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Evidence:** [Tourism and Events Queensland](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland); [Tourism Australia](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Espiritu Santo freshwater blue-hole discovery

**Location:** Espiritu Santo, Vanuatu.

Freshwater swimming extends a marine holiday without treating every blue hole as an identical attraction.

**Why go:** Freshwater blue holes add a different water environment to a marine holiday, giving visitors a reason to explore beyond the coast.

**Key attractions:** Freshwater swimming; Blue-hole settings; Inland water discovery.

**Season, regional conditions:** Apr, May, Jun, Jul, Aug, Sep. April-September is the cooler seasonal context. December-April is wetter with cyclone exposure; river levels and access need separate checks. [Season evidence](https://www.vanuatu.travel/en/things-to-know/travel-tips/weather).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.vanuatu.travel/en/things-to-do/blue-holes).

**Contact:** [Official visitor/contact route](https://www.vanuatu.travel/en/things-to-do/blue-holes).

**Evidence:** [Vanuatu Tourism Office](https://www.vanuatu.travel/en/things-to-do/blue-holes); [Vanuatu Tourism Office](https://www.vanuatu.travel/en/things-to-know/travel-tips/weather). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Andenes whale safari

**Location:** Andenes, Norway.

Northern Norway whale tours with a year-round programme and a busier late-spring to early-autumn period.

**Why go:** A northern coastal whale programme offers a different setting from tropical migrations and supports planning beyond a single summer window.

**Key attractions:** Northern Norway waters; Whale safari; Season-dependent vessel options.

**Season, operator program:** All months. Operator offers tours throughout the year. [Season evidence](https://whalesafari.no/trips-andenes).

**Season, typical conditions:** May, Jun, Jul, Aug, Sep. Main operating season is late May to mid-September; this is not a species probability estimate. [Season evidence](https://whalesafari.no/trips-andenes).

**Plan around:** Northern Norway whale tours with a year-round programme and a busier late-spring to early-autumn period. Vessel type and exact departure point need confirmation for the chosen departure. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** NOK 1690 / person_trip. from. Age category and current extras need confirmation. Not a live or all-in quote. [Publisher](https://whalesafari.no/when-to-see-whales).

**Tickets/access:** [Official ticket / operator information](https://whalesafari.no/when-to-see-whales).

**Contact:** [Official visitor/contact route](https://whalesafari.no/when-to-see-whales).

**Evidence:** [Whalesafari / Whale2Sea](https://whalesafari.no/when-to-see-whales); [Whalesafari / Whale2Sea](https://whalesafari.no/trips-andenes). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Greenland fjord whale-watching discovery

**Location:** Greenland fjords, Greenland.

A wildlife-focused boat outing needs locality and operator season detail, not a single Arctic calendar.

**Why go:** A fjord setting adds landscape value to a wildlife boat trip, even though the exact local programme still determines what is possible.

**Key attractions:** Fjord scenery; Whale observation; Local boat programme.

**Season, editorial season mapping:** Jun, Jul, Aug. Summer is the published broad context. June-August is an editorial core-summer mapping; local ice and operations vary. [Season evidence](https://visitgreenland.com/activities/boat-tours/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitgreenland.com/activities/whale-watching/).

**Contact:** [Official visitor/contact route](https://visitgreenland.com/activities/whale-watching/).

**Evidence:** [Visit Greenland](https://visitgreenland.com/activities/whale-watching/); [Visit Greenland](https://visitgreenland.com/activities/boat-tours/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Husavik original whale watching

**Location:** Husavik, Iceland.

A seasonal harbour-based wildlife trip.

**Why go:** A harbour-based wildlife outing gives visitors a focused marine experience with a defined seasonal programme.

**Key attractions:** Whale watching; Husavik harbour departure; Seasonal boat outing.

**Season, operator program:** Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov. Operator advertises daily departures 1 March to 30 November. Published date window: {"start": "03-01", "end": "11-30"}. [Season evidence](https://www.northsailing.is/tour/husavik-original-whale-watching/).

**Plan around:** A seasonal harbour-based wildlife trip. A departure programme is evidence of when trips are offered, not a guarantee of a particular whale species. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** ISK 12990 / adult_trip. from. VAT included; exact departure fare still requires confirmation. Not a live or all-in quote. [Publisher](https://www.northsailing.is/tour/husavik-original-whale-watching/).

**Tickets/access:** [Official ticket / operator information](https://www.northsailing.is/tour/husavik-original-whale-watching/).

**Contact:** [Official visitor/contact route](https://www.northsailing.is/tour/husavik-original-whale-watching/). Telephone: +3544647272.

**Evidence:** [North Sailing](https://www.northsailing.is/tour/husavik-original-whale-watching/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Niue shore-based humpback watching

**Location:** Niue west coast, Niue.

Watch from land as a distinct alternative to an offshore or in-water trip.

**Why go:** Land-based humpback observation gives people a wildlife option without requiring an offshore boat or an in-water activity.

**Key attractions:** Humpback whales; Shore observation; Island coastal viewpoints.

**Season, humpback whale:** Jul, Aug, Sep, Oct. Watch from land as a distinct alternative to an offshore or in-water trip. [Season evidence](https://www.niueisland.com/see-and-do/whale-experiences).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.niueisland.com/see-and-do/whale-experiences).

**Contact:** [Official visitor/contact route](https://www.niueisland.com/see-and-do/whale-experiences).

**Evidence:** [Niue Tourism](https://www.niueisland.com/see-and-do/whale-experiences). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Tadoussac whale-watching boat tour

**Location:** Tadoussac, Quebec, Canada.

A Saint Lawrence boat programme with an explicitly dated season.

**Why go:** The Saint Lawrence setting makes the wildlife journey a distinctive regional outing rather than a generic ocean cruise.

**Key attractions:** Saint Lawrence waters; Whale observation; Dated boat programme.

**Season, operator program:** May, Jun, Jul, Aug, Sep, Oct, Nov. Published 2026 programme ended on 1 November. Published date window: {"start": "05-09", "end": "11-01"}. [Season evidence](https://www.croisieresaml.com/en/our-cruises/tadoussac/whale-watching-boat-tour).

**Plan around:** A Saint Lawrence boat programme with an explicitly dated season. Retain the 2026 price as historical reference, not as a ticket available today. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** CAD 134.99 / adult_trip. published reference. Taxes additional. Expired-season reference; obtain the next programme. Not a live or all-in quote. [Publisher](https://www.croisieresaml.com/nos-croisieres/tadoussac/croisiere-aux-baleines-en-bateau).

**Tickets/access:** [Official ticket / operator information](https://www.croisieresaml.com/nos-croisieres/tadoussac/croisiere-aux-baleines-en-bateau).

**Contact:** [Official visitor/contact route](https://www.croisieresaml.com/nos-croisieres/tadoussac/croisiere-aux-baleines-en-bateau).

**Evidence:** [Croisieres AML](https://www.croisieresaml.com/en/our-cruises/tadoussac/whale-watching-boat-tour); [Croisieres AML](https://www.croisieresaml.com/nos-croisieres/tadoussac/croisiere-aux-baleines-en-bateau). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Victoria whale watching by vessel type

**Location:** Victoria, British Columbia, Canada.

The season depends on the vessel.

**Why go:** Different vessel formats let visitors match the outing to their preferred exposure and season, rather than treating every whale tour as identical.

**Key attractions:** Whale observation; Zodiac format; Covered-catamaran option.

**Season, operator program:** All months. Zodiac tours continue through winter; the covered-catamaran timetable differs. [Season evidence](https://princeofwhales.com/victoria-winter-whale-watching/).

**Plan around:** The season depends on the vessel. Winter Zodiac trips and warmer-season covered catamarans must remain distinct offers, so a winter visitor is not shown a closed catamaran as available. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** CAD 229 / adult_trip. published reference. Seasonal pricing; taxes and fees extra; do not apply to winter Zodiac tours. Not a live or all-in quote. [Publisher](https://princeofwhales.com/now-playing/).

**Tickets/access:** [Official ticket / operator information](https://princeofwhales.com/now-playing/).

**Contact:** [Official visitor/contact route](https://princeofwhales.com/now-playing/).

**Evidence:** [Prince of Whales](https://princeofwhales.com/victoria-winter-whale-watching/); [Prince of Whales](https://princeofwhales.com/now-playing/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #77: Tobermory Whalewatch Explorer

**Location:** Tobermory / Isle of Mull, United Kingdom.

Boat-based whale and marine-wildlife discovery with a published April-October programme.

**Why go:** A marine-wildlife boat trip adds a seasonal water-based perspective to the Tobermory coast.

**Key attractions:** Whale and marine wildlife; Boat observation; Seasonal coastal programme.

**Season, operator program:** Apr, May, Jun, Jul, Aug, Sep, Oct. The provider describes an April-October programme. [Season evidence](https://www.visitscotland.com/info/tours/whalewatch-explorer-5cc11c7b).

**Plan around:** Boat-based whale and marine-wildlife discovery with a published April-October programme. Species and sightings vary. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitscotland.com/info/tours/whalewatch-explorer-5cc11c7b).

**Contact:** [Official visitor/contact route](https://www.visitscotland.com/info/tours/whalewatch-explorer-5cc11c7b).

**Evidence:** [VisitScotland / Sea Life Mull](https://www.visitscotland.com/info/tours/whalewatch-explorer-5cc11c7b). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: La Parguera bioluminescent boat outing

**Location:** Lajas / La Parguera, Puerto Rico.

A boat-based alternative to the island's kayak-focused bays.

**Why go:** A boat-based bioluminescence outing offers a different way to experience a night-water phenomenon from a kayak-only trip.

**Key attractions:** Bioluminescence; Night boat outing; Bay setting.

**Season, natural phenomenon:** All months. Bioluminescent outings possible year-round; moonlight and water conditions matter. [Season evidence](https://www.discoverpuertorico.com/bio-bays).

**Plan around:** A boat-based alternative to the island's kayak-focused bays. Confirm current permitted activities with the local provider. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.discoverpuertorico.com/article/guide-to-exploring-puerto-ricos-bioluminescent-bays).

**Contact:** [Official visitor/contact route](https://www.discoverpuertorico.com/article/guide-to-exploring-puerto-ricos-bioluminescent-bays).

**Evidence:** [Discover Puerto Rico](https://www.discoverpuertorico.com/article/guide-to-exploring-puerto-ricos-bioluminescent-bays); [Discover Puerto Rico](https://www.discoverpuertorico.com/bio-bays). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Florida Space Coast night kayaking

**Location:** Florida Space Coast, United States.

A night paddle focused on light-producing organisms.

**Why go:** The light-producing organisms give a familiar coastal waterway a distinct after-dark purpose, separate from a daytime paddle.

**Key attractions:** Bioluminescent organisms; Night kayaking; Coastal waterway.

**Season, natural phenomenon:** Jun, Jul, Aug, Sep, Oct. Published bioluminescence season; no nightly visibility promise. [Season evidence](https://www.visitspacecoast.com/bioluminescence/?app_page=1).

**Plan around:** A night paddle focused on light-producing organisms. Ask which phenomenon is currently observable rather than assuming every night glows. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://traveltrade.visittheusa.com/destinations/florida/space-coast/).

**Contact:** [Official visitor/contact route](https://traveltrade.visittheusa.com/destinations/florida/space-coast/).

**Evidence:** [Brand USA](https://traveltrade.visittheusa.com/destinations/florida/space-coast/); [Florida Space Coast tourism](https://www.visitspacecoast.com/bioluminescence/?app_page=1). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Ko Muk Emerald Cave water excursion

**Location:** Trang / Ko Muk, Thailand.

A guided water passage into a coastal cave and lagoon.

**Why go:** The passage into a coastal cave and lagoon supplies a specific journey and destination within one guided water excursion.

**Key attractions:** Coastal cave; Lagoon; Guided water passage.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Published restriction:** Tourism authority describes closure of the Ko Muk visitor area from 1 June to 30 September. Recheck the park annual notice. [Source](https://thai.tourismthailand.org/Attraction/%E0%B8%96%E0%B9%89%E0%B8%B3%E0%B8%A1%E0%B8%A3%E0%B8%81%E0%B8%95).

**Plan around:** A guided water passage into a coastal cave and lagoon. This is not an independent cave-diving route or an all-year attraction. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://thai.tourismthailand.org/Attraction/%E0%B8%96%E0%B9%89%E0%B8%B3%E0%B8%A1%E0%B8%A3%E0%B8%81%E0%B8%95).

**Contact:** [Official visitor/contact route](https://thai.tourismthailand.org/Attraction/%E0%B8%96%E0%B9%89%E0%B8%B3%E0%B8%A1%E0%B8%A3%E0%B8%81%E0%B8%95).

**Evidence:** [Tourism Authority of Thailand](https://thai.tourismthailand.org/Attraction/%E0%B8%96%E0%B9%89%E0%B8%B3%E0%B8%A1%E0%B8%A3%E0%B8%81%E0%B8%95); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Te Anau glowworm cave boat visit

**Location:** Te Anau, New Zealand.

A lake-and-cave boat experience centred on glowworms.

**Why go:** A lake approach and cave boat visit combine two water settings around a glowworm-focused experience.

**Key attractions:** Lake journey; Cave boat; Glowworms.

**Season, natural phenomenon:** All months. Te Anau glowworms are active year-round. Natural presence does not establish access or a particular tour departure. [Season evidence](https://www.realnz.com/en/blog/what-to-do-in-te-anau/).

**Plan around:** A lake-and-cave boat experience centred on glowworms. Confirm the trip duration and access requirements. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.newzealand.com/nz/feature/top-experiences-in-fiordland/).

**Contact:** [Official visitor/contact route](https://www.newzealand.com/nz/feature/top-experiences-in-fiordland/).

**Evidence:** [Tourism New Zealand](https://www.newzealand.com/nz/feature/top-experiences-in-fiordland/); [RealNZ](https://www.realnz.com/en/blog/what-to-do-in-te-anau/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Fajardo bioluminescent-bay kayak

**Location:** Laguna Grande, Fajardo, Puerto Rico.

A night-paddle experience where darkness helps observation but cannot guarantee a bright biological display.

**Why go:** A paddle after dark makes the natural light phenomenon the central attraction rather than a bonus on a daytime bay visit.

**Key attractions:** Night paddling; Bioluminescent bay; Darkness-led viewing.

**Season, biological event:** Not established. Brightness is variable; no defensible month-level peak extracted. [Season evidence](https://pureadventurepr.com/frequently-asked-questions/).

**Season, natural phenomenon:** All months. Bioluminescent outings possible year-round; moonlight and water conditions matter. [Season evidence](https://www.discoverpuertorico.com/bio-bays).

**Published restriction:** The tourism authority identifies swimming prohibitions in Mosquito Bay and Laguna Grande. This applies to swimming, not a blanket prohibition on guided observation. [Source](https://www.discoverpuertorico.com/article/guide-to-exploring-puerto-ricos-bioluminescent-bays).

**Plan around:** A night-paddle experience where darkness helps observation but cannot guarantee a bright biological display. Do not calculate a wildlife probability from moon phase alone. Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://pureadventurepr.com/frequently-asked-questions/).

**Contact:** [Official visitor/contact route](https://pureadventurepr.com/frequently-asked-questions/).

**Evidence:** [Pure Adventure](https://pureadventurepr.com/frequently-asked-questions/); [Pure Adventure](https://pureadventurepr.com/bio-bay-kayak-tour/); [Discover Puerto Rico](https://www.discoverpuertorico.com/bio-bays). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Lake Karapiro twilight glowworm kayak

**Location:** Lake Karapiro, New Zealand.

A dusk paddle with a freshwater glowworm focus.

**Why go:** Freshwater glowworms give the twilight paddle a different biological theme from sea-water bioluminescent bays.

**Key attractions:** Freshwater paddling; Glowworms; Twilight outing.

**Season, regional conditions:** Dec, Jan, Feb. New Zealand summer comfort context; local operations can extend year-round. [Season evidence](https://www.newzealand.com/nz/kayaking/).

**Plan around:** A dusk paddle with a freshwater glowworm focus. The experience depends on darkness, not a sea-water bioluminescence season. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.newzealand.com/au/plan/business/lake-district-adventures-ltd/).

**Contact:** [Official visitor/contact route](https://www.newzealand.com/au/plan/business/lake-district-adventures-ltd/).

**Evidence:** [Tourism New Zealand / Lake District Adventures](https://www.newzealand.com/au/plan/business/lake-district-adventures-ltd/); [Tourism New Zealand](https://www.newzealand.com/nz/kayaking/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Lake McLaren canyon kayak discovery

**Location:** Tauranga / Lake McLaren, New Zealand.

A freshwater canyon outing.

**Why go:** The canyon provides a scenic daytime paddle, with night glowworm products available as a distinct choice rather than an assumed inclusion.

**Key attractions:** Freshwater canyon; Daytime scenery; Separate night experience.

**Season, regional conditions:** Dec, Jan, Feb. New Zealand summer comfort context; local operations can extend year-round. [Season evidence](https://www.newzealand.com/nz/kayaking/).

**Plan around:** A freshwater canyon outing. Distinguish a scenic daytime paddle from a separately booked night glowworm experience. Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.newzealand.com/ca/plan/business/kayak-tours/).

**Contact:** [Official visitor/contact route](https://www.newzealand.com/ca/plan/business/kayak-tours/).

**Evidence:** [Tourism New Zealand / Waimarino](https://www.newzealand.com/ca/plan/business/kayak-tours/); [Tourism New Zealand](https://www.newzealand.com/nz/kayaking/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Agincourt Reef pontoon and underwater viewing

**Location:** Port Douglas / Agincourt Reef, Australia.

A reef platform with snorkelling and dry underwater-viewing options. Check what the chosen fare actually includes.

**Why go:** Combines reef scenery with dry underwater viewing options. Accessibility differs by ship, platform and viewing activity, so an overall wheelchair badge would mislead.

**Key attractions:** Dry reef viewing.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Broad Great Barrier Reef dry-season context; reef sectors and operations differ. [Season evidence](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Contact:** [Official visitor/contact route](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Evidence:** [Tourism and Events Queensland](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland); [Tourism Australia](https://www.australia.com/en/places/cairns-and-surrounds/guide-to-the-great-barrier-reef.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Blue Spring manatee viewing

**Location:** Orange City / Blue Spring, United States.

A land-based wildlife option that does not require swimming with animals.

**Why go:** A land-based manatee visit suits people who want wildlife observation without entering the animals' water habitat.

**Key attractions:** Manatees; Shore viewing; Spring environment.

**Season, species presence:** Nov, Dec, Jan, Feb, Mar. Winter refuge viewing from shore; in-water access restrictions are separate. Published date window: {"start": "11-15", "end": "03-31"}. [Season evidence](https://www.floridastateparks.org/parks-and-trails/blue-spring-state-park/experiences-amenities).

**Plan around:** A land-based wildlife option that does not require swimming with animals. Viewing depends on conditions and current site access. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.floridastateparks.org/parks-and-trails/blue-spring-state-park/experiences-amenities).

**Contact:** [Official visitor/contact route](https://www.floridastateparks.org/parks-and-trails/blue-spring-state-park/experiences-amenities).

**Evidence:** [VISIT FLORIDA](https://www.visitflorida.com/things-to-do/outdoors-and-adventure/wildlife/manatees/); [Florida State Parks](https://www.floridastateparks.org/parks-and-trails/blue-spring-state-park/experiences-amenities). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Fort Myers Manatee Park observation

**Location:** Fort Myers, United States.

A land-based wildlife option that does not require swimming with animals.

**Why go:** A dedicated land-viewing option adds marine-mammal interest to a Fort Myers day without a boat booking.

**Key attractions:** Manatee observation; Land-based access; Wildlife-viewing setting.

**Season, editorial season mapping:** Dec, Jan, Feb. Publisher identifies winter refuges. December-February is an editorial core-winter mapping, not exact opening dates. [Season evidence](https://myfwc.com/education/wildlife/manatee/where-to-see/).

**Plan around:** A land-based wildlife option that does not require swimming with animals. Viewing depends on conditions and current site access. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://myfwc.com/education/wildlife/manatee/where-to-see/).

**Contact:** [Official visitor/contact route](https://myfwc.com/education/wildlife/manatee/where-to-see/).

**Evidence:** [VISIT FLORIDA](https://www.visitflorida.com/things-to-do/outdoors-and-adventure/wildlife/manatees/); [Florida Fish and Wildlife Conservation Commission](https://myfwc.com/education/wildlife/manatee/where-to-see/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Apollo Beach manatee viewing

**Location:** Apollo Beach, United States.

A land-based wildlife option that does not require swimming with animals.

**Why go:** A shore-viewing destination offers a wildlife-focused stop for visitors who prefer not to swim or paddle around animals.

**Key attractions:** Manatees; Shore observation; Apollo Beach setting.

**Season, editorial season mapping:** Dec, Jan, Feb. Publisher identifies winter refuges. December-February is an editorial core-winter mapping, not exact opening dates. [Season evidence](https://myfwc.com/education/wildlife/manatee/where-to-see/).

**Plan around:** A land-based wildlife option that does not require swimming with animals. Viewing depends on conditions and current site access. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://myfwc.com/education/wildlife/manatee/where-to-see/).

**Contact:** [Official visitor/contact route](https://myfwc.com/education/wildlife/manatee/where-to-see/).

**Evidence:** [VISIT FLORIDA](https://www.visitflorida.com/things-to-do/outdoors-and-adventure/wildlife/manatees/); [Florida Fish and Wildlife Conservation Commission](https://myfwc.com/education/wildlife/manatee/where-to-see/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Dirk Hartog Island turtle observation

**Location:** Dirk Hartog Island, Australia.

Nesting and hatchling activity are different experiences.

**Why go:** Managed turtle observation gives the island visit a seasonal wildlife theme, with nesting and hatching treated as different experiences.

**Key attractions:** Marine turtles; Island habitat; Seasonal observation.

**Season, marine_turtle:** Dec, Jan, Feb. Nesting and hatchling activity are different experiences. Use a managed observation option without disturbing animals. [Season evidence](https://www.australiascoralcoast.com/plan/natures-calendar).

**Plan around:** Nesting and hatchling activity are different experiences. Use a managed observation option without disturbing animals. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.australiascoralcoast.com/plan/natures-calendar).

**Contact:** [Official visitor/contact route](https://www.australiascoralcoast.com/plan/natures-calendar).

**Evidence:** [Australia's Coral Coast](https://www.australiascoralcoast.com/plan/natures-calendar). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #123: Crystal River manatees and Three Sisters access

**Location:** Crystal River, Florida, United States.

The strongest manatee-viewing period overlaps with restrictions on entering particular springs.

**Why go:** The manatee focus supports several distinct visit formats, including shore observation, rather than making swimming the only worthwhile choice.

**Key attractions:** Manatee habitat; Three Sisters area; Multiple observation formats.

**Season, west_indian_manatee:** Nov, Dec, Jan, Feb, Mar. Refuge manatee season 15 November-31 March. Published date window: {"start": "11-15", "end": "03-31"}. [Season evidence](https://www.fws.gov/refuge/crystal-river/visit-us).

**Published restriction:** No scuba inside Three Sisters Springs during the protected winter period. This does not close all of Crystal River. [Source](https://www.fws.gov/refuge/crystal-river/visit-us/activities/scuba-diving).

**Published restriction:** Paddlecraft cannot enter Three Sisters Springs in the protected winter period. [Source](https://www.fws.gov/refuge/crystal-river/visit-us/activities/boating---non-motorized).

**Published restriction:** Marked sanctuaries and temporary closures remain out of bounds. Check the current refuge map before entering the water. [Source](https://www.fws.gov/refuge/crystal-river/visit-us).

**Plan around:** The strongest manatee-viewing period overlaps with restrictions on entering particular springs. Shore viewing, snorkelling, paddling and scuba require different access answers. No permission to enter a marked sanctuary is implied. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fws.gov/refuge/crystal-river/visit-us).

**Contact:** [Official visitor/contact route](https://www.fws.gov/refuge/crystal-river/visit-us).

**Evidence:** [US Fish and Wildlife Service](https://www.fws.gov/refuge/crystal-river/visit-us); [US Fish and Wildlife Service](https://www.fws.gov/refuge/crystal-river/visit-us/activities/boating---non-motorized); [US Fish and Wildlife Service](https://www.fws.gov/refuge/crystal-river/visit-us/activities/scuba-diving). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Domwe Island freshwater diving

**Location:** Domwe Island, Malawi.

Freshwater island diving with local equipment, access and health checks required.

**Why go:** A freshwater island dive broadens the underwater shortlist beyond tropical seas and adds a different habitat to a Malawi trip.

**Key attractions:** Freshwater diving; Domwe Island; Island-water setting.

**Season, regional conditions:** All months. Lake Malawi diving is described year-round. September-December adds a cichlid breeding observation opportunity, without guaranteeing an encounter. [Season evidence](https://www.padi.com/diving-in/malawi/).

**Season, Cichlids:** Sep, Oct, Nov, Dec. Published cichlid courtship and mouth-brooding observation window. Do not approach or disturb breeding fish. [Season evidence](https://www.padi.com/diving-in/malawi/).

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.malawitourism.com/experiences/lake/scuba-diving/).

**Contact:** [Official visitor/contact route](https://www.malawitourism.com/experiences/lake/scuba-diving/).

**Evidence:** [Malawi Tourism](https://www.malawitourism.com/experiences/lake/scuba-diving/); [PADI](https://www.padi.com/diving-in/malawi/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Great Barrier Reef coral-spawning planning

**Location:** Great Barrier Reef, Cairns region, Australia.

A biological-event planning guide, not a scheduled spawning show.

**Why go:** A biological-event focus offers experienced visitors a reason to investigate the reef calendar beyond a standard daytime tour.

**Key attractions:** Coral spawning; Reef biology; Event-led dive planning.

**Season, reef_building_corals:** Oct, Nov, Dec. Spawning follows selected full moons and varies by reef and temperature; no exact night is promised. [Season evidence](https://www.aims.gov.au/research-topics/featured-projects/reef-spawning-research-aims).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** A biological-event planning guide, not a scheduled spawning show. Use the month range to research suitable operators, then confirm reef-specific observations and night-diving eligibility. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Contact:** [Official visitor/contact route](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [Australian Institute of Marine Science](https://www.aims.gov.au/research-topics/featured-projects/reef-spawning-research-aims). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Kadmat island diving discovery

**Location:** Kadmat, Lakshadweep, India.

An Indian Ocean island dive base requiring visitor access and operator checks.

**Why go:** An Indian Ocean island base gives divers a specific regional alternative to better-known mainland holiday centres.

**Key attractions:** Kadmat Island; Island diving; Indian Ocean setting.

**Season, regional conditions:** Sep, Oct, Nov, Dec, Jan, Feb, Mar, Apr, May. September-May is the published island water-sports visiting window. Permits, vessel access and actual dive operations need separate checks. [Season evidence](https://lakshadweep.gov.in/tourism/).

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://lakshadweep.gov.in/tourism/adventures/).

**Contact:** [Official visitor/contact route](https://lakshadweep.gov.in/tourism/adventures/).

**Evidence:** [Government of Lakshadweep](https://lakshadweep.gov.in/tourism/adventures/); [Lakshadweep Administration](https://lakshadweep.gov.in/tourism/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Koh Tao reef and dive-school discovery

**Location:** Koh Tao, Thailand.

A Gulf of Thailand alternative to Andaman diving.

**Why go:** A Gulf of Thailand dive base offers a regional and seasonal alternative to the Andaman coast, with reef and training interests kept distinct.

**Key attractions:** Island reefs; Dive-school base; Gulf of Thailand season.

**Season, regional conditions:** All months. Koh Tao diving is described through the year. Gulf conditions differ from Phuket; storms and local site choices remain separate. [Season evidence](https://www.padi.com/diving-in/koh-tao/).

**Plan around:** A Gulf of Thailand alternative to Andaman diving. Do not copy Phuket seasonal rules onto this island. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://thai.tourismthailand.org/Destinations/Provinces/%E0%B9%80%E0%B8%81%E0%B8%B2%E0%B8%B0%E0%B9%80%E0%B8%95%E0%B9%88%E0%B8%B2/361).

**Contact:** [Official visitor/contact route](https://thai.tourismthailand.org/Destinations/Provinces/%E0%B9%80%E0%B8%81%E0%B8%B2%E0%B8%B0%E0%B9%80%E0%B8%95%E0%B9%88%E0%B8%B2/361).

**Evidence:** [Tourism Authority of Thailand](https://thai.tourismthailand.org/Destinations/Provinces/%E0%B9%80%E0%B8%81%E0%B8%B2%E0%B8%B0%E0%B9%80%E0%B8%95%E0%B9%88%E0%B8%B2/361); [PADI](https://www.padi.com/diving-in/koh-tao/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Manado Tua dive discovery

**Location:** Manado Tua, Indonesia.

A distinct island within the Bunaken-Manado Tua marine park.

**Why go:** A distinct island within the marine park lets a diving itinerary focus on particular sites rather than one broad Bunaken label.

**Key attractions:** Manado Tua; Marine-park diving; Island dive sites.

**Season, regional conditions:** Apr, May, Jun, Jul, Aug, Sep, Oct. Drier Bunaken-region window; conditions can vary by reef. [Season evidence](https://www.padi.com/diving-in/north-sulawesi/).

**Plan around:** A distinct island within the Bunaken-Manado Tua marine park. Confirm which dive sites match your qualification. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.indonesia.travel/de/en/destination/sulawesi/north-sulawesi/manado-tua-island).

**Contact:** [Official visitor/contact route](https://www.indonesia.travel/de/en/destination/sulawesi/north-sulawesi/manado-tua-island).

**Evidence:** [Indonesia Ministry of Tourism](https://www.indonesia.travel/de/en/destination/sulawesi/north-sulawesi/manado-tua-island); [PADI](https://www.padi.com/diving-in/north-sulawesi/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Mumbo Island freshwater diving

**Location:** Mumbo Island, Malawi.

Freshwater island diving with local equipment, access and health checks required.

**Why go:** Freshwater island diving adds underwater variety to a trip where the main comparison is usually between marine reefs.

**Key attractions:** Mumbo Island; Freshwater habitats; Island dive base.

**Season, regional conditions:** All months. Lake Malawi diving is described year-round. September-December adds a cichlid breeding observation opportunity, without guaranteeing an encounter. [Season evidence](https://www.padi.com/diving-in/malawi/).

**Season, Cichlids:** Sep, Oct, Nov, Dec. Published cichlid courtship and mouth-brooding observation window. Do not approach or disturb breeding fish. [Season evidence](https://www.padi.com/diving-in/malawi/).

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.malawitourism.com/experiences/lake/scuba-diving/).

**Contact:** [Official visitor/contact route](https://www.malawitourism.com/experiences/lake/scuba-diving/).

**Evidence:** [Malawi Tourism](https://www.malawitourism.com/experiences/lake/scuba-diving/); [PADI](https://www.padi.com/diving-in/malawi/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Racha Noi and Racha Yai dive excursion

**Location:** Phuket and Racha Islands, Thailand.

An operator-run day trip combining the Racha islands.

**Why go:** A two-island operator itinerary offers site variety within a day trip, distinct from the Shark Point and wreck route.

**Key attractions:** Racha Noi; Racha Yai; Multi-site dive day.

**Season, typical conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr. Andaman conditions pattern, separate from the weekly boat schedule. [Season evidence](https://www.padi.com/diving-in/thailand/).

**Published restriction:** Before adding flights or high-altitude travel after scuba, consult the operator, dive computer guidance and appropriate diving-medical advice. This planner does not clear a person to dive or fly. [Source](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/).

**Plan around:** An operator-run day trip combining the Racha islands. Store the advertised weekly itinerary as reference information; do not generate future departures until the operator confirms a dated programme. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://sea-bees.com/shop/phuket-scuba-day-trips/racha-noi/).

**Contact:** [Official visitor/contact route](https://sea-bees.com/shop/phuket-scuba-day-trips/racha-noi/).

**Evidence:** [Divers Alert Network](https://dan.org/health-medicine/health-resources/diseases-conditions/flying-after-diving/); [Sea Bees Diving](https://sea-bees.com/shop/phuket-scuba-day-trips/racha-noi/); [PADI](https://www.padi.com/diving-in/thailand/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Tenggol dive-island discovery

**Location:** Pulau Tenggol, Malaysia.

An identified Terengganu island-water destination.

**Why go:** A named Terengganu dive island helps visitors choose a specific base and transfer plan rather than an undifferentiated coast-wide package.

**Key attractions:** Tenggol Island; Island diving; Terengganu waters.

**Season, regional conditions:** Mar, Apr, May, Jun, Jul, Aug, Sep, Oct. March-October is the published east-coast diving window for Perhentian and Tenggol. Monsoon affects transport and operations; individual schedules require checking. [Season evidence](https://www.sekawantravel.com/east-coast-diving-season/).

**Plan around:** An identified Terengganu island-water destination. Confirm the specific transfer, operating season and reef activity rather than borrowing another island's schedule. Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Contact:** [Official visitor/contact route](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Evidence:** [Tourism Malaysia](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/); [Sekawan Travel](https://www.sekawantravel.com/east-coast-diving-season/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Nam Ha protected-area river journey

**Location:** Luang Namtha, Lao People's Democratic Republic.

A river-based protected-area visit complements a trek without replacing local guide requirements.

**Why go:** A protected-area river journey gives visitors a water-level alternative to trekking while retaining the value of local guidance.

**Key attractions:** Protected-area river; Guided paddling; Alternative to trekking.

**Season, regional conditions:** Nov, Dec, Jan, Feb. November-February is the broad cooler visiting context. This is not a river-flow, pollution or operator calendar assessment. [Season evidence](https://www.tourismlaos.org/2025/12/31/laos-ranks-among-worlds-most-budget-friendly-destinations-for-2026/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tourismlaos.org/northern-provinces/luang-namtha-province/).

**Contact:** [Official visitor/contact route](https://www.tourismlaos.org/northern-provinces/luang-namtha-province/).

**Evidence:** [Laos Tourism](https://www.tourismlaos.org/northern-provinces/luang-namtha-province/); [Tourism Laos](https://www.tourismlaos.org/2025/12/31/laos-ranks-among-worlds-most-budget-friendly-destinations-for-2026/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Mendoza River rafting

**Location:** Mendoza, Argentina.

A river outing adds a water-based choice to the region.

**Why go:** A river outing introduces an active water experience to a region that visitors may otherwise explore primarily on land.

**Key attractions:** Mendoza River; Rafting; River landscape.

**Season, flow pattern:** Apr, May, Jun, Jul, Aug, Sep. April-September generally has lower flow; summer brings more intense rapids. Lower flow is not a blanket novice or family approval. [Season evidence](https://www.argentina.travel/en/activities/rafting-in-the-mendoza-river).

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://argentina.travel/en/activities/rafting-in-the-mendoza-river).

**Contact:** [Official visitor/contact route](https://argentina.travel/en/activities/rafting-in-the-mendoza-river).

**Evidence:** [Argentina INPROTUR](https://argentina.travel/en/activities/rafting-in-the-mendoza-river); [Argentina Tourism](https://www.argentina.travel/en/activities/rafting-in-the-mendoza-river). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Nakhon Nayok rainy-season rafting

**Location:** Nakhon Nayok River, Thailand.

A rainy-season water activity shows why one country-wide dry-season score is unsuitable.

**Why go:** A rain-season activity provides a useful counterexample to the idea that every water outing is best in the dry months.

**Key attractions:** River rafting; Rain-season pattern; Local water adventure.

**Season, typical conditions:** Jun, Jul, Aug, Sep, Oct. Tourism authority describes June-October rafting; this is not a real-time river clearance. [Season evidence](https://www.tourismthailand.org/Attraction/rafting-in-nakhon-nayok-river).

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tourismthailand.org/Attraction/rafting-in-nakhon-nayok-river).

**Contact:** [Official visitor/contact route](https://www.tourismthailand.org/Attraction/rafting-in-nakhon-nayok-river).

**Evidence:** [Tourism Authority of Thailand](https://www.tourismthailand.org/Attraction/rafting-in-nakhon-nayok-river). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Ngonye Falls region rafting

**Location:** Sioma, Zambia.

A lesser-known Zambezi water adventure with a different seasonal window from generic dry-season safari travel.

**Why go:** A lesser-known Zambezi rafting setting gives experienced travellers a specific alternative to the most familiar regional water itineraries.

**Key attractions:** Ngonye Falls region; Zambezi waters; Rafting discovery.

**Season, typical conditions:** Feb, Mar, Apr, May. Publisher identifies February-May after the rains for rafting; daily water levels control actual operation. [Season evidence](https://www.zambiatourism.com/destinations/waterfalls/ngonye-falls/).

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.zambiatourism.com/destinations/waterfalls/ngonye-falls/).

**Contact:** [Official visitor/contact route](https://www.zambiatourism.com/destinations/waterfalls/ngonye-falls/).

**Evidence:** [Zambia Tourism](https://www.zambiatourism.com/destinations/waterfalls/ngonye-falls/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #136: Kalbarri surfing season discovery

**Location:** Kalbarri, Australia.

The regional surfing calendar runs March-October.

**Why go:** A regional surfing window gives the coast a sport-specific seasonal role, rather than being judged only as a swimming beach.

**Key attractions:** Surfing; Coastal breaks; March-October reference window.

**Season, typical conditions:** Mar, Apr, May, Jun, Jul, Aug, Sep, Oct. The regional surfing calendar runs March-October. Break selection and competence need local advice. [Season evidence](https://www.australiascoralcoast.com/plan/natures-calendar).

**Plan around:** The regional surfing calendar runs March-October. Break selection and competence need local advice. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.australiascoralcoast.com/plan/natures-calendar).

**Contact:** [Official visitor/contact route](https://www.australiascoralcoast.com/plan/natures-calendar).

**Evidence:** [Australia's Coral Coast](https://www.australiascoralcoast.com/plan/natures-calendar). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Anglesea riverbank beach

**Location:** Great Ocean Road, Victoria, Australia.

Seasonal access equipment is typically installed early December to mid-April.

**Why go:** The riverbank setting and documented seasonal access equipment give visitors practical details beyond a scenic beach label.

**Key attractions:** Riverbank beach; Seasonal access equipment; Shore outing.

**Season, regional conditions:** Dec, Jan, Feb. December-February is the regional summer scenic-visit context. This guidance concerns the coastal region, not beach patrols, water quality or a swimming clearance. [Season evidence](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html).

**Plan around:** Seasonal access equipment is typically installed early December to mid-April. Book assistance; this is not a water-safety clearance. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Contact:** [Official visitor/contact route](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Evidence:** [Great Ocean Road Coast and Parks Authority](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches); [Tourism Australia](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Apollo Bay beach

**Location:** Great Ocean Road, Victoria, Australia.

Seasonal access equipment is typically installed early December to mid-April.

**Why go:** A named beach with documented seasonal access equipment provides a more actionable choice for visitors planning assistance.

**Key attractions:** Apollo Bay shore; Seasonal access equipment; Beach visit.

**Season, regional conditions:** Dec, Jan, Feb. December-February is the regional summer scenic-visit context. This guidance concerns the coastal region, not beach patrols, water quality or a swimming clearance. [Season evidence](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html).

**Plan around:** Seasonal access equipment is typically installed early December to mid-April. Book assistance; this is not a water-safety clearance. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Contact:** [Official visitor/contact route](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Evidence:** [Great Ocean Road Coast and Parks Authority](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches); [Tourism Australia](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Fishermans Beach Torquay

**Location:** Great Ocean Road, Victoria, Australia.

Seasonal access equipment is typically installed early December to mid-April. Book assistance; this is not a water-safety clearance.

**Why go:** The shore-access programme creates a useful beach-visit option. The authority does not recommend entering the water here, so it is excluded from water-entry suggestions.

**Key attractions:** Beaches.

**Season, regional conditions:** Dec, Jan, Feb. December-February is the regional summer scenic-visit context. This guidance concerns the coastal region, not beach patrols, water quality or a swimming clearance. [Season evidence](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html).

**Published restriction:** Authority says this beach is not patrolled and does not recommend water entry. Retain as a shore-access discovery, not a swimming suggestion. [Source](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Contact:** [Official visitor/contact route](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Evidence:** [Great Ocean Road Coast and Parks Authority](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches); [Tourism Australia](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Lorne beach

**Location:** Great Ocean Road, Victoria, Australia.

Seasonal access equipment is typically installed early December to mid-April.

**Why go:** Seasonal access-equipment information makes this a practical Great Ocean Road beach option to investigate, rather than a generic accessibility claim.

**Key attractions:** Lorne beach; Seasonal access equipment; Coastal visit.

**Season, regional conditions:** Dec, Jan, Feb. December-February is the regional summer scenic-visit context. This guidance concerns the coastal region, not beach patrols, water quality or a swimming clearance. [Season evidence](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html).

**Plan around:** Seasonal access equipment is typically installed early December to mid-April. Book assistance; this is not a water-safety clearance. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Contact:** [Official visitor/contact route](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Evidence:** [Great Ocean Road Coast and Parks Authority](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches); [Tourism Australia](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Point Roadknight beach

**Location:** Great Ocean Road, Victoria, Australia.

Seasonal access equipment is typically installed early December to mid-April.

**Why go:** A specific beach and equipment calendar let visitors plan the assistance question before committing to the day.

**Key attractions:** Point Roadknight; Seasonal access equipment; Shore discovery.

**Season, regional conditions:** Dec, Jan, Feb. December-February is the regional summer scenic-visit context. This guidance concerns the coastal region, not beach patrols, water quality or a swimming clearance. [Season evidence](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html).

**Plan around:** Seasonal access equipment is typically installed early December to mid-April. Book assistance; this is not a water-safety clearance. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Contact:** [Official visitor/contact route](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Evidence:** [Great Ocean Road Coast and Parks Authority](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches); [Tourism Australia](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Port Campbell beach

**Location:** Great Ocean Road, Victoria, Australia.

Seasonal access equipment is typically installed early December to mid-April.

**Why go:** The beach adds a water-focused stop to the coastal journey, with documented seasonal equipment rather than assumed year-round assistance.

**Key attractions:** Port Campbell shore; Seasonal access equipment; Beach outing.

**Season, regional conditions:** Dec, Jan, Feb. December-February is the regional summer scenic-visit context. This guidance concerns the coastal region, not beach patrols, water quality or a swimming clearance. [Season evidence](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html).

**Plan around:** Seasonal access equipment is typically installed early December to mid-April. Book assistance; this is not a water-safety clearance. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Contact:** [Official visitor/contact route](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches).

**Evidence:** [Great Ocean Road Coast and Parks Authority](https://www.greatoceanroadauthority.vic.gov.au/Stay-and-Explore/Accessible-Beaches); [Tourism Australia](https://www.australia.com/en-gb/places/melbourne-and-surrounds/guide-to-the-great-ocean-road.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Tamarindo beach

**Location:** Guanacaste, Costa Rica.

Pacific beach and surf setting.

**Why go:** The combination of beach and surf interests allows different members of a group to value the same coastal setting in different ways.

**Key attractions:** Pacific beach; Surf setting; Shore visit.

**Season, regional conditions:** Dec, Jan, Feb, Mar, Apr. Pacific beach and surf setting. A dry-season weather preference is not a beginner-surf or swimming guarantee. [Season evidence](https://www.visitcostarica.com/planning-your-trip/climate).

**Plan around:** Pacific beach and surf setting. A dry-season weather preference is not a beginner-surf or swimming guarantee. Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitcostarica.com/planning-your-trip/climate).

**Contact:** [Official visitor/contact route](https://www.visitcostarica.com/planning-your-trip/climate).

**Evidence:** [Costa Rica Tourism Institute](https://www.visitcostarica.com/planning-your-trip/climate). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Reykjavik puffin boat trip

**Location:** Reykjavik, Iceland.

A water-based birdwatching trip, kept inside marine wildlife rather than expanding DipMapper into a general bird directory.

**Why go:** A puffin-focused boat trip offers a shorter thematic marine-wildlife choice distinct from a general whale excursion.

**Key attractions:** Puffins; Boat-based birdwatching; Seasonal island waters.

**Season, operator program:** Apr, May, Jun, Jul, Aug. Classic puffin trips are advertised from 20 April to 20 August. Published date window: {"start": "04-20", "end": "08-20"}. [Season evidence](https://elding.is/reykjavik-schedule-prices).

**Plan around:** A water-based birdwatching trip, kept inside marine wildlife rather than expanding DipMapper into a general bird directory. The published season has partial April and August coverage. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Published price reference:** ISK 8300 / adult_trip. published reference. One-hour advertised duration; transfer separate. Not a live or all-in quote. [Publisher](https://elding.is/reykjavik-schedule-prices).

**Tickets/access:** [Official ticket / operator information](https://elding.is/reykjavik-schedule-prices).

**Contact:** [Official visitor/contact route](https://elding.is/reykjavik-schedule-prices).

**Evidence:** [Elding Adventure at Sea](https://elding.is/reykjavik-schedule-prices). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Aitutaki glass-bottom lagoon cruise

**Location:** Aitutaki Lagoon, Cook Islands.

A mixed-group reef outing lets people snorkel or remain on the glass-bottom boat.

**Why go:** The glass-bottom format lets a mixed group share the reef setting even when some people do not want to snorkel.

**Key attractions:** Lagoon scenery; Glass-bottom viewing; Optional snorkelling format.

**Season, regional conditions:** Apr, May, Sep, Oct. April, May, September and October are highlighted for a warm/dry balance. Trade-wind months are not automatically the calmest lagoon days. [Season evidence](https://cookislands.travel/islands/weather-seasons).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://cookislands.travel/supplier/rus-lagoon-cruise-glass-bottom-boat).

**Contact:** [Official visitor/contact route](https://cookislands.travel/supplier/rus-lagoon-cruise-glass-bottom-boat).

**Evidence:** [Cook Islands Tourism](https://cookislands.travel/supplier/rus-lagoon-cruise-glass-bottom-boat); [Cook Islands Tourism](https://cookislands.travel/islands/weather-seasons). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Fathom Five island and wreck-viewing boats

**Location:** Tobermory / Flowerpot Island, Canada.

An alternative for visitors who prefer to stay dry.

**Why go:** Island and wreck-viewing boats give non-divers a reason to explore an underwater-interest destination while remaining dry.

**Key attractions:** Island scenery; Wreck-viewing option; Dry boat experience.

**Season, operator pattern:** May, Jun, Jul, Aug, Sep, Oct. Typical boat-access period, weather permitting. Published date window: {"start": "05-15", "end": "10-15"}. [Season evidence](https://parks.canada.ca/amnc-nmca/on/fathomfive/activ/flowerpot.).

**Plan around:** An alternative for visitors who prefer to stay dry. Check whether a fare includes island landing, underwater viewing or only a cruise. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://parks.canada.ca/amnc-nmca/on/fathomfive/activ/flowerpot.).

**Contact:** [Official visitor/contact route](https://parks.canada.ca/amnc-nmca/on/fathomfive/activ/flowerpot.).

**Evidence:** [Parks Canada](https://parks.canada.ca/amnc-nmca/on/fathomfive/activ/operat); [Parks Canada](https://parks.canada.ca/amnc-nmca/on/fathomfive/activ/flowerpot.). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Isla Tortuga boat outing

**Location:** Gulf of Nicoya, Costa Rica.

An island boat day, with the exact landing and snorkel inclusions dependent on the provider.

**Why go:** An island boat day combines travel over water with a destination stop, with the exact inclusions chosen through the operator.

**Key attractions:** Isla Tortuga; Boat journey; Island outing.

**Season, regional conditions:** Dec, Jan, Feb, Mar, Apr. Pacific dry-season context; not the Caribbean coast or a river-flow assessment. [Season evidence](https://www.visitcostarica.com/planning-your-trip/climate).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitcostarica.com/things-to-do/adventure).

**Contact:** [Official visitor/contact route](https://www.visitcostarica.com/things-to-do/adventure).

**Evidence:** [Costa Rican Tourism Board](https://www.visitcostarica.com/things-to-do/adventure); [Costa Rica Tourism Institute](https://www.visitcostarica.com/planning-your-trip/climate). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Kavaratti lagoon and reef experiences

**Location:** Kavaratti, Lakshadweep, India.

A lagoon-based water-sports discovery separate from an advanced offshore dive.

**Why go:** Lagoon-based water activities provide a more varied island-water choice than an advanced offshore dive alone.

**Key attractions:** Kavaratti lagoon; Reef environment; Water-sports discovery.

**Season, regional conditions:** Sep, Oct, Nov, Dec, Jan, Feb, Mar, Apr, May. September-May is the published island water-sports visiting window. Permits, vessel access and actual dive operations need separate checks. [Season evidence](https://lakshadweep.gov.in/tourism/).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://lakshadweep.gov.in/tourism/adventures/).

**Contact:** [Official visitor/contact route](https://lakshadweep.gov.in/tourism/adventures/).

**Evidence:** [Government of Lakshadweep](https://lakshadweep.gov.in/tourism/adventures/); [Lakshadweep Administration](https://lakshadweep.gov.in/tourism/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Narvik Arctic Sauna

**Location:** Narvik Harbour, Norway.

A floating sauna in the harbour.

**Why go:** A floating harbour sauna creates a water-focused visit even when an exposed boat outing is not the preferred plan.

**Key attractions:** Floating sauna; Harbour setting; Managed plunge option.

**Season, operator pattern:** All months. The named Narvik harbour sauna is described as open year-round. A generic wheelchair-accessible label needs route and transfer details before personal fit can be established. [Season evidence](https://www.visitnorway.com/listings/arctic-sauna/274988/).

**Plan around:** A floating sauna in the harbour. Keep managed plunge access separate from general harbour swimming. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitnorway.com/listings/arctic-sauna/274988/).

**Contact:** [Official visitor/contact route](https://www.visitnorway.com/listings/arctic-sauna/274988/).

**Evidence:** [Visit Norway / listed provider](https://www.visitnorway.com/listings/arctic-sauna/274988/); [Visit Norway / Visit Narvik](https://www.visitnorway.com/listings/arctic-sauna/274988/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Dampen fjord sauna

**Location:** Fjaerland, Norway.

A fjord sauna with shared and whole-sauna booking formats.

**Why go:** The fjord setting is part of the attraction, while shared and private formats let visitors choose the social character of the visit.

**Key attractions:** Fjord sauna; Shared sessions; Whole-sauna format.

**Season, editorial season mapping:** Dec, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug. The named floating sauna lists winter, spring and summer. Months December-August are a labelled season-to-month interpretation, not guaranteed daily opening. [Season evidence](https://www.visitnorway.com/listings/dampen-sauna-fjaerland/245675/).

**Plan around:** A fjord sauna with shared and whole-sauna booking formats. Those prices cannot be compared as one person-rate. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitnorway.com/listings/dampen-sauna-fjaerland/245675/).

**Contact:** [Official visitor/contact route](https://www.visitnorway.com/listings/dampen-sauna-fjaerland/245675/).

**Evidence:** [Visit Norway / listed provider](https://www.visitnorway.com/listings/dampen-sauna-fjaerland/245675/); [Visit Norway / Visit Sognefjord](https://www.visitnorway.com/listings/dampen-sauna-fjaerland/245675/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Kaukajarvi public sauna and lake swim

**Location:** Tampere, Finland.

A year-round lake-swimming and sauna location, not a claim that cold-water immersion suits every visitor.

**Why go:** A public sauna beside a lake combines two water traditions in one location, with bathing choices left to the visitor's circumstances.

**Key attractions:** Public sauna; Lake setting; Year-round programme reference.

**Season, operator program:** All months. A year-round lake-swimming and sauna location, not a claim that cold-water immersion suits every visitor. [Season evidence](https://www.visitfinland.com/en/product/2a3d1d09-0ad4-495f-8163-566d3e15b2bc/kaukajarvi-public-sauna/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitfinland.com/en/product/2a3d1d09-0ad4-495f-8163-566d3e15b2bc/kaukajarvi-public-sauna/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/2a3d1d09-0ad4-495f-8163-566d3e15b2bc/kaukajarvi-public-sauna/).

**Evidence:** [Visit Finland / listed provider](https://www.visitfinland.com/en/product/2a3d1d09-0ad4-495f-8163-566d3e15b2bc/kaukajarvi-public-sauna/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Kinn Damp coastal sauna

**Location:** Floro, Norway.

A floating coastal sauna with year-round fjord-dip access described in the listing.

**Why go:** A floating coastal sauna adds a distinct water-level setting to a visit, without requiring a long excursion.

**Key attractions:** Floating sauna; Coastal setting; Managed fjord-dip context.

**Season, operator program:** All months. A floating coastal sauna with year-round fjord-dip access described in the listing. [Season evidence](https://www.visitnorway.com/listings/kinn-damp-8211-a-coastal-sauna-experience-in-floro/279832/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitnorway.com/listings/kinn-damp-8211-a-coastal-sauna-experience-in-floro/279832/).

**Contact:** [Official visitor/contact route](https://www.visitnorway.com/listings/kinn-damp-8211-a-coastal-sauna-experience-in-floro/279832/).

**Evidence:** [Visit Norway / listed provider](https://www.visitnorway.com/listings/kinn-damp-8211-a-coastal-sauna-experience-in-floro/279832/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Lidasanden floating lake sauna

**Location:** Oppstrynsvatnet, Norway.

A wood-fired floating sauna with lake swimming.

**Why go:** A wood-fired sauna on a lake gives the setting a central role, rather than treating the sauna as an indoor facility anywhere.

**Key attractions:** Wood-fired sauna; Floating lake setting; Lake-swim context.

**Season, operator pattern:** All months. The listed floating sauna offers year-round private bookings. Water entry and assistance remain separate questions. [Season evidence](https://www.visitnorway.com/listings/sauna-lidasanden/280254/).

**Plan around:** A wood-fired floating sauna with lake swimming. Confirm booking, access and water conditions. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitnorway.com/listings/floating-sauna-on-oppstrynsvatnet-lidasanden/280254/).

**Contact:** [Official visitor/contact route](https://www.visitnorway.com/listings/floating-sauna-on-oppstrynsvatnet-lidasanden/280254/).

**Evidence:** [Visit Norway / listed provider](https://www.visitnorway.com/listings/floating-sauna-on-oppstrynsvatnet-lidasanden/280254/); [Visit Norway / Nordfjord](https://www.visitnorway.com/listings/sauna-lidasanden/280254/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Ukonlinna winter-swim sauna

**Location:** Imatra / Lake Saimaa, Finland.

The published winter-swimming period runs October-April.

**Why go:** A published winter-swimming programme provides a clearly seasonal reason to explore the sauna-and-water combination.

**Key attractions:** Sauna; Winter-swimming programme; October-April reference.

**Season, operator program:** Oct, Nov, Dec, Jan, Feb, Mar, Apr. The published winter-swimming period runs October-April. [Season evidence](https://www.visitfinland.com/en/product/02539900-2592-47a1-ac82-b52c5ed90dcd/ukonlinna-sauna-village/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitfinland.com/en/product/02539900-2592-47a1-ac82-b52c5ed90dcd/ukonlinna-sauna-village/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/02539900-2592-47a1-ac82-b52c5ed90dcd/ukonlinna-sauna-village/).

**Evidence:** [Visit Finland / listed provider](https://www.visitfinland.com/en/product/02539900-2592-47a1-ac82-b52c5ed90dcd/ukonlinna-sauna-village/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Sainte Anne semi-submarine viewing

**Location:** Mahe / Sainte Anne Marine Park, Seychelles.

A dry-viewing alternative for a mixed group where not everyone wants to snorkel.

**Why go:** Below-surface viewing from a boat lets non-snorkellers share an underwater-interest outing with a mixed group.

**Key attractions:** Semi-submarine viewing; Marine setting; Dry underwater observation.

**Season, regional conditions:** Mar, Apr, May, Sep, Oct, Nov. Regional calmer water-sports window; exposure differs by coast. [Season evidence](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Plan around:** A dry-viewing alternative for a mixed group where not everyone wants to snorkel. Accessibility still needs operator confirmation. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Contact:** [Official visitor/contact route](https://fly.airseychelles.com/en/explore-seychelles/water-sports).

**Evidence:** [Tourism Seychelles / Semi-Sub Seychelles](https://seychelles.com/blog-details/1850/highlights/semi-submarine-experience); [Air Seychelles](https://fly.airseychelles.com/en/explore-seychelles/water-sports). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Beqa Lagoon reef snorkelling

**Location:** Pacific Harbour and Beqa Lagoon, Fiji.

A boat-access reef alternative to a resort beach swim.

**Why go:** A boat-access lagoon reef provides an underwater outing distinct from simply swimming beside a resort beach.

**Key attractions:** Beqa Lagoon; Reef snorkelling; Boat access.

**Season, underwater visibility:** Jun, Jul, Aug. Tourism publisher highlights these months for reef visibility. [Season evidence](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fiji.travel/places-to-go/pacific-harbour/locations/adventures-in-pacific-harbour).

**Contact:** [Official visitor/contact route](https://www.fiji.travel/places-to-go/pacific-harbour/locations/adventures-in-pacific-harbour).

**Evidence:** [Tourism Fiji](https://www.fiji.travel/places-to-go/pacific-harbour/locations/adventures-in-pacific-harbour); [Tourism Fiji](https://www.fiji.travel/things-to-do/snorkelling/the-ultimate-fiji-snorkelling-guide). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Coral Bay manta discovery

**Location:** Coral Bay, Australia.

Mantas are described as present throughout the year.

**Why go:** A resident-manta reference gives the destination a wildlife theme beyond the shorter whale-shark season nearby.

**Key attractions:** Manta rays; Coral Bay setting; Boat-based wildlife discovery.

**Season, manta_ray:** All months. Mantas are described as present throughout the year. Visibility, encounters and departures still vary. [Season evidence](https://www.australiascoralcoast.com/plan/natures-calendar).

**Plan around:** Mantas are described as present throughout the year. Visibility, encounters and departures still vary. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.australiascoralcoast.com/plan/natures-calendar).

**Contact:** [Official visitor/contact route](https://www.australiascoralcoast.com/plan/natures-calendar).

**Evidence:** [Australia's Coral Coast](https://www.australiascoralcoast.com/plan/natures-calendar). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Hol Chan reef and seagrass snorkelling

**Location:** Hol Chan Marine Reserve, Belize.

A reef-and-seagrass outing with marine-reserve access requirements.

**Why go:** Reef and seagrass environments offer two habitat themes within one marine-reserve outing.

**Key attractions:** Reef habitat; Seagrass habitat; Marine-reserve snorkelling.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr, May. Drier Belize regional context, not a reef permit, trip schedule or wildlife guarantee. [Season evidence](https://www.islandexpeditions.com/book-your-trip/frequently-asked-questions/).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://fisheries.gov.bz/hcmr/).

**Contact:** [Official visitor/contact route](https://fisheries.gov.bz/hcmr/).

**Evidence:** [Belize Fisheries Department](https://fisheries.gov.bz/hcmr/); [Island Expeditions](https://www.islandexpeditions.com/book-your-trip/frequently-asked-questions/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Mombasa Marine Park boat-and-reef outing

**Location:** Mombasa, Kenya.

Explore a distinct Kenyan marine protected area with its own departure and access arrangements.

**Why go:** A defined marine-park excursion adds a specific water experience to a Mombasa stay rather than a generic coastal cruise.

**Key attractions:** Mombasa Marine Park; Reef viewing; Boat outing.

**Season, regional conditions:** Oct, Nov, Dec, Jan, Feb, Mar. October-March is a broad coastal underwater conditions reference. Individual marine parks, surface conditions and boats need separate checking. [Season evidence](https://travel.padi.com/s/dive-resorts/kenya/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://kws.go.ke/park/mombasa-marine-national-park-reserve/).

**Contact:** [Official visitor/contact route](https://kws.go.ke/park/mombasa-marine-national-park-reserve/).

**Evidence:** [Kenya Wildlife Service](https://kws.go.ke/park/mombasa-marine-national-park-reserve/); [PADI Travel](https://travel.padi.com/s/dive-resorts/kenya/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Palolo Deep shore snorkelling

**Location:** Apia, Samoa.

A city-accessible marine-reserve snorkel where tide timing is central.

**Why go:** A marine reserve close to the city offers a shore-based underwater visit without the logistics of an offshore island trip.

**Key attractions:** Palolo Deep; Shore snorkelling; Tide-dependent marine reserve.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Drier Samoan seasonal context; currents and local access need checking. [Season evidence](https://www.samoa.travel/samoa-travel-advice/climate-weather/).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.samoa.travel/plan-book/activities/palolo-deep-marine-reserve/).

**Contact:** [Official visitor/contact route](https://www.samoa.travel/plan-book/activities/palolo-deep-marine-reserve/).

**Evidence:** [Samoa Tourism Authority](https://www.samoa.travel/plan-book/activities/palolo-deep-marine-reserve/); [Samoa Tourism Authority](https://www.samoa.travel/samoa-travel-advice/climate-weather/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Shaheed Dweep reef discovery

**Location:** Shaheed Dweep / Neil Island, India.

A snorkelling and dive base with its historical name preserved for search consistency.

**Why go:** A named island base supplies a specific snorkelling-and-diving option, with the former place name retained to help travellers find the same destination.

**Key attractions:** Shaheed Dweep; Reef discovery; Island water base.

**Season, regional conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr, May. October-May is the published beach/water-visit context. Current closures, currents and operator requirements remain separate. [Season evidence](https://tourism.andamannicobar.gov.in/experience_details.php?data=_qQxZPPpNZ98QHcAD-XpCpO2Rk7UZWUM8qqcE-td9OFlGx4IGJQc-CaD).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://southandaman.nic.in/tourism/).

**Contact:** [Official visitor/contact route](https://southandaman.nic.in/tourism/).

**Evidence:** [South Andaman district administration](https://southandaman.nic.in/tourism/); [Andaman and Nicobar Tourism](https://tourism.andamannicobar.gov.in/experience_details.php?data=_qQxZPPpNZ98QHcAD-XpCpO2Rk7UZWUM8qqcE-td9OFlGx4IGJQc-CaD). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Sharm el-Sheikh dedicated snorkel boat trip

**Location:** Sharm el-Sheikh, Egypt.

A dedicated snorkelling booking rather than a non-diver seat on a scuba boat.

**Why go:** A dedicated surface-snorkelling product gives non-divers a clear alternative to taking a spare seat on a scuba itinerary.

**Key attractions:** Reef snorkelling; Dedicated boat product; Surface-viewing format.

**Season, operator program:** Not established. Exact annual schedule not established. [Season evidence](https://www.cameldive.com/prices/).

**Season, regional conditions:** All months. Year-round regional Red Sea diving context; the snorkel excursion schedule remains unconfirmed. [Season evidence](https://www.padi.com/diving-in/egypt/).

**Plan around:** A dedicated snorkelling booking rather than a non-diver seat on a scuba boat. Confirm the actual reef itinerary, equipment, park fee and transfer before comparing the price. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.cameldive.com/prices/).

**Contact:** [Official visitor/contact route](https://www.cameldive.com/prices/).

**Evidence:** [Camel Dive Club](https://www.cameldive.com/prices/); [PADI](https://www.padi.com/diving-in/egypt/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: AQUA DOME thermal-water outing

**Location:** Laengenfeld, Austria.

A water-based option in the Tyrolean Imst and Oetztal region; facility schedules and conditions need date-specific confirmation.

**Why go:** A thermal venue supplies a different water day within the Tyrolean mountain region, independent of a lake-swimming season.

**Key attractions:** Thermal-water venue; Tyrolean setting; Multiple facility areas.

**Season, operator pattern:** All months. Year-round thermal offer; maintenance is separate. [Season evidence](https://www.aqua-dome.at/en/thermal-spa/).

**Published restriction:** Children's indoor pool and slide listed for maintenance 9-13 November 2026. Other thermal areas are not declared closed by this notice. [Source](https://www.aqua-dome.at/de/revisionen/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.aqua-dome.at/en/thermal-spa/).

**Contact:** [Official visitor/contact route](https://www.aqua-dome.at/en/thermal-spa/).

**Evidence:** [Imst tourism](https://www.imst.at/en/experience-water.html); [AQUA DOME](https://www.aqua-dome.at/en/thermal-spa/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Forest Lagoon

**Location:** Akureyri, Iceland.

Geothermal pools with a cold tub and sauna.

**Why go:** Geothermal pools, a cold tub and sauna create a venue-based alternative to an exposed offshore outing.

**Key attractions:** Geothermal pools; Cold tub; Sauna.

**Season, operator pattern:** All months. Earth Lagoon Myvatn and Forest Lagoon are described as year-round experiences. Operating exceptions and access facilities are product-specific. [Season evidence](https://www.northiceland.is/en/experiences/winter-magic-in-north-iceland).

**Plan around:** Geothermal pools with a cold tub and sauna. A bathing alternative to exposed offshore excursions. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visiticeland.com/things-to-do/forest-lagoon/).

**Contact:** [Official visitor/contact route](https://www.visiticeland.com/things-to-do/forest-lagoon/).

**Evidence:** [Visit Iceland](https://www.visiticeland.com/things-to-do/forest-lagoon/); [Visit North Iceland](https://www.northiceland.is/en/experiences/winter-magic-in-north-iceland). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Laugaras Lagoon

**Location:** Laugaras, Iceland.

A river-view geothermal bathing venue.

**Why go:** The river-view setting gives geothermal bathing a landscape component rather than making temperature the only attraction.

**Key attractions:** Geothermal bathing; River views; Venue-based water visit.

**Season, operator pattern:** All months. Year-round lagoon offer; check current hours. [Season evidence](https://www.laugaraslagoon.is/faq).

**Plan around:** A river-view geothermal bathing venue. Confirm the current ticket category rather than assuming every facility is included. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.laugaraslagoon.is/faq).

**Contact:** [Official visitor/contact route](https://www.laugaraslagoon.is/faq).

**Evidence:** [Visit Iceland](https://www.visiticeland.com/things-to-do/laugaras-lagoon/); [Laugaras Lagoon](https://www.laugaraslagoon.is/faq). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Earth Lagoon Myvatn

**Location:** Myvatn, Iceland.

Geothermal bathing in northern Iceland.

**Why go:** Northern Iceland's geothermal setting makes this a distinct bathing stop within a regional journey, not simply another urban pool.

**Key attractions:** Geothermal bathing; Northern Iceland setting; Regional water stop.

**Season, operator pattern:** All months. Earth Lagoon Myvatn and Forest Lagoon are described as year-round experiences. Operating exceptions and access facilities are product-specific. [Season evidence](https://www.northiceland.is/en/experiences/winter-magic-in-north-iceland).

**Plan around:** Geothermal bathing in northern Iceland. Retain the former Myvatn Nature Baths name as a search alias. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/).

**Contact:** [Official visitor/contact route](https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/).

**Evidence:** [Visit Iceland](https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/); [Visit North Iceland](https://www.northiceland.is/en/experiences/winter-magic-in-north-iceland). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Secret Lagoon geothermal pool

**Location:** Fludir, Iceland.

A geothermal bathing stop near the Golden Circle.

**Why go:** A geothermal pool near the Golden Circle offers a compact water-focused addition to a wider land itinerary.

**Key attractions:** Geothermal pool; Golden Circle area; Bathing stop.

**Season, operator pattern:** All months. Published winter and summer schedules span the year. The page also contains an undated-year May renovation notice; exact planned-day opening requires confirmation. [Season evidence](https://secretlagoon.is/).

**Plan around:** A geothermal bathing stop near the Golden Circle. Check current admission and bathing-session rules. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/).

**Contact:** [Official visitor/contact route](https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/).

**Evidence:** [Visit Iceland](https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/); [Secret Lagoon](https://secretlagoon.is/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Mirissa whale watching

**Location:** Mirissa, Sri Lanka.

A south-coast whale-watching programme with blue whales among the possible encounters.

**Why go:** Blue whales among the possible encounters give this south-coast programme a specific wildlife interest beyond general boat sightseeing.

**Key attractions:** Possible blue whales; South-coast setting; Boat-based observation.

**Season, operator program:** Not established. Operator says almost year-round; exact excluded dates are not published in the reviewed evidence. [Season evidence](https://rajaandthewhales.com/).

**Season, species presence:** Nov, Dec, Jan, Feb, Mar, Apr. South-coast whale-watching window; sea state and sightings still vary. [Season evidence](https://srilanka.travel/attraction?attraction_id=6).

**Plan around:** A south-coast whale-watching programme with blue whales among the possible encounters. Almost year-round operation is not a twelve-month guarantee; weather cancellations and exact sailing dates remain operator decisions. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** LKR 20000 / adult_trip. published reference. Check included fees and current schedule. Not a live or all-in quote. [Publisher](https://rajaandthewhales.com/book-a-tour/).

**Tickets/access:** [Official ticket / operator information](https://rajaandthewhales.com/book-a-tour/).

**Contact:** [Official visitor/contact route](https://rajaandthewhales.com/book-a-tour/). Telephone: +94776953452.

**Evidence:** [Raja and the Whales](https://rajaandthewhales.com/); [Raja and the Whales](https://rajaandthewhales.com/book-a-tour/); [Sri Lanka Tourism](https://srilanka.travel/attraction?attraction_id=6). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Monterey Bay whale watching

**Location:** Monterey Bay, California, United States.

A year-round operator with different species emphases across the calendar. Keep three-hour, four-hour and upper-deck fares separate; do not compare an upgraded fare with another operators base trip.

**Why go:** A year-round operator with changing species emphasis gives return visitors a different reason to go in different months. Trip length and deck category remain separate choices.

**Key attractions:** gray whale; humpback whale; Whale watching.

**Season, gray_whale:** Jan, Feb, Mar. Operator highlights gray whales in winter and early spring. [Season evidence](https://www.montereybaywhalewatch.com/whale-watching/whale-watch-tour/).

**Season, humpback_whale:** Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec. Operator highlights humpback and blue whales in this wider period; species-specific peaks are not established here. [Season evidence](https://www.montereybaywhalewatch.com/whale-watching/whale-watch-tour/).

**Season, operator program:** All months. Daily tour page covers winter and warmer-season programmes. [Season evidence](https://www.montereybaywhalewatch.com/whale-watching/whale-watch-tour/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** USD 76.32 / adult_trip. published reference. Current page supersedes older trips.htm base prices; avoid adding a fee twice. Not a live or all-in quote. [Publisher](https://www.montereybaywhalewatch.com/whale-watching/whale-watch-tour/).

**Published price reference:** USD 84.8 / adult_trip. published reference.  Not a live or all-in quote. [Publisher](https://www.montereybaywhalewatch.com/whale-watching/whale-watch-tour/).

**Tickets/access:** [Official ticket / operator information](https://www.montereybaywhalewatch.com/whale-watching/whale-watch-tour/).

**Contact:** [Official visitor/contact route](https://www.montereybaywhalewatch.com/whale-watching/whale-watch-tour/).

**Evidence:** [Monterey Bay Whale Watch](https://www.montereybaywhalewatch.com/whale-watching/whale-watch-tour/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Okinawa whales and separate reef snorkelling

**Location:** Kerama Islands, Okinawa, Japan.

A combined day can include boat-based whale observation and reef snorkelling without allowing people to swim with whales.

**Why go:** Whale observation and a separate reef snorkel let a day include two water experiences without implying permission to swim with whales.

**Key attractions:** Boat whale watching; Separate reef snorkelling; Combined-day format.

**Season, humpback_whale:** Jan, Feb, Mar. Regional January-March humpback period. [Season evidence](https://www.japan.travel/en/sports/diving/travel/whale-watching-in-okinawa/).

**Season, operator program:** Jan, Feb, Mar. Specific next-season programme 22 January-22 March 2027. Published date window: {"start": "01-22", "end": "03-22"}. [Season evidence](https://aquamarine.okinawa/en/whalewatching/whalewatching-snorkeling).

**Plan around:** A combined day can include boat-based whale observation and reef snorkelling without allowing people to swim with whales. The two locations and activity permissions remain separate. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://aquamarine.okinawa/en/whalewatching/whalewatching-snorkeling).

**Contact:** [Official visitor/contact route](https://aquamarine.okinawa/en/whalewatching/whalewatching-snorkeling).

**Evidence:** [Japan National Tourism Organization](https://www.japan.travel/en/sports/diving/travel/whale-watching-in-okinawa/); [Okinawa Aquamarine](https://aquamarine.okinawa/en/whalewatching/whalewatching-snorkeling). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Reykjavik classic whale watching

**Location:** Reykjavik, Iceland.

A harbour-based wildlife boat trip with different departure patterns through the year.

**Why go:** A harbour-based wildlife trip adds an offshore perspective to a city stay and can be considered independently of a long regional road journey.

**Key attractions:** Whale observation; Reykjavik harbour; Seasonal boat departures.

**Season, operator program:** All months. Published classic-tour schedule covers all twelve months. [Season evidence](https://elding.is/reykjavik-schedule-prices).

**Plan around:** A harbour-based wildlife boat trip with different departure patterns through the year. Use the operator booking calendar for the selected day rather than treating a seasonal timetable as confirmed availability. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Published price reference:** ISK 14500 / adult_trip. published reference. Hotel transfer is separately priced; 2.5 to 3.5 hour advertised duration. Not a live or all-in quote. [Publisher](https://elding.is/reykjavik-schedule-prices).

**Tickets/access:** [Official ticket / operator information](https://elding.is/reykjavik-schedule-prices).

**Contact:** [Official visitor/contact route](https://elding.is/reykjavik-schedule-prices). Telephone: +3545195000.

**Evidence:** [Elding Adventure at Sea](https://elding.is/reykjavik-schedule-prices). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Samana Bay humpback whale tour

**Location:** Samana Bay, Dominican Republic.

A boat-based visit to a humpback calving and mating area.

**Why go:** A humpback breeding-area visit supplies a clear seasonal wildlife purpose, rather than a year-round generic coastal tour.

**Key attractions:** Humpback whales; Calving and mating area; Bay boat outing.

**Season, operator program:** Jan, Feb, Mar. Published annual programme runs 15 January to 31 March. Published date window: {"start": "01-15", "end": "03-31"}. [Season evidence](https://whalesamana.com/).

**Season, humpback_whale:** Jan, Feb, Mar. Operator describes humpbacks using Samana Bay as calving and mating grounds. [Season evidence](https://whalesamana.com/).

**Plan around:** A boat-based visit to a humpback calving and mating area. The programme has different daily frequencies across the season; the currency on the observed price requires confirmation before comparison. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://whalesamana.com/).

**Contact:** [Official visitor/contact route](https://whalesamana.com/). Telephone: +18095382494.

**Evidence:** [Whale Samana](https://whalesamana.com/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Santa Catarina shore-based whale watching

**Location:** Imbituba, Garopaba and Praia do Rosa, Brazil.

Shore-based observation offers an alternative to boat trips along the southern-right-whale coast.

**Why go:** Shore-based southern-right-whale observation allows a wildlife visit without the cost and exposure of an offshore trip.

**Key attractions:** Southern right whales; Shore observation; Seasonal coastal habitat.

**Season, southern_right_whale:** Jul, Aug, Sep, Oct. Tourism authority describes July to October, with September peak and calving/nursing behaviour. [Season evidence](https://feel.visitbrasil.com/en/whale-safari).

**Plan around:** Shore-based observation offers an alternative to boat trips along the southern-right-whale coast. Keep viewing locations on public access paths and do not convert nursery information into close-approach instructions. No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://feel.visitbrasil.com/en/whale-safari).

**Contact:** [Official visitor/contact route](https://feel.visitbrasil.com/en/whale-safari).

**Evidence:** [Embratur / Visit Brasil](https://feel.visitbrasil.com/en/whale-safari). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Tahiti seasonal humpback boat watching

**Location:** Tahiti, French Polynesia.

Tahiti seasonal humpback boat watching combines humpback whales, seasonal boat viewing.

**Why go:** Seasonal humpbacks add a wildlife reason to time a Tahiti visit beyond beach weather alone.

**Key attractions:** Humpback whales; Seasonal boat viewing; Island-water setting.

**Season, humpback whale:** Aug, Sep, Oct, Nov. Track the seasonal wildlife window separately from authorised tour dates and in-water rules. [Season evidence](https://www.tahititourisme.nz/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tahititourisme.nz/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Contact:** [Official visitor/contact route](https://www.tahititourisme.nz/preparing-you-trip/when-to-visit-the-islands-of-tahiti/).

**Evidence:** [Tahiti Tourisme](https://www.tahititourisme.nz/preparing-you-trip/when-to-visit-the-islands-of-tahiti/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Taiwan east-coast cetacean watching

**Location:** Taiwan east coast, Taiwan.

A seasonal coastal boat discovery covering cetaceans, not a guaranteed large-whale encounter.

**Why go:** An east-coast cetacean outing broadens the wildlife shortlist beyond destinations marketed mainly for large whales.

**Key attractions:** Cetaceans; East-coast waters; Seasonal boat observation.

**Season, cetaceans:** Apr, May, Jun, Jul, Aug, Sep, Oct. A seasonal coastal boat discovery covering cetaceans, not a guaranteed large-whale encounter. [Season evidence](https://www.oca.gov.tw/en/home.jsp?id=108&parentpath=0%2C6%2C105).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.oca.gov.tw/en/home.jsp?id=108&parentpath=0%2C6%2C105).

**Contact:** [Official visitor/contact route](https://www.oca.gov.tw/en/home.jsp?id=108&parentpath=0%2C6%2C105).

**Evidence:** [Taiwan Ocean Conservation Administration](https://www.oca.gov.tw/en/home.jsp?id=108&parentpath=0%2C6%2C105). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Southwest Tenerife whale watching

**Location:** Tenerife, Spain.

A resident-cetacean destination rather than a single migration window. Show pilot whales and bottlenose dolphins as separate species, and distinguish wildlife presence from any particular boat timetable.

**Why go:** Resident pilot whales and dolphins distinguish this destination from migration-only outings. The attraction is flexible wildlife observation, not a promise of every species on every sailing.

**Key attractions:** short finned pilot whale; bottlenose dolphin; Whale watching.

**Season, short_finned_pilot_whale:** All months. Resident short-finned pilot whales are described year-round. [Season evidence](https://whalewatchtenerife.org/tenerife-whale-watching-season/).

**Season, bottlenose_dolphin:** All months. Resident bottlenose dolphins are described year-round. [Season evidence](https://whalewatchtenerife.org/tenerife-whale-watching-season/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://whalewatchtenerife.org/tenerife-whale-watching-season/).

**Contact:** [Official visitor/contact route](https://whalewatchtenerife.org/tenerife-whale-watching-season/).

**Evidence:** [Whale Watch Tenerife](https://whalewatchtenerife.org/tenerife-whale-watching-season/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Uvita whale and dolphin boat tour

**Location:** Uvita, Marino Ballena, Costa Rica.

Two separated annual whale windows are stored instead of one continuous season. Trips outside those windows can still offer other coastal wildlife, without being promoted as equivalent whale opportunities.

**Why go:** Two annual whale windows create distinct opportunities rather than one continuous season. The wider coastal-wildlife outing remains a different proposition between those windows.

**Key attractions:** humpback whale; Whale watching.

**Season, humpback_whale:** Jul, Aug, Sep, Oct. Southern migration window described as mid-July to October. Published date window: {"start": "07-15", "end": "10-31"}. [Season evidence](https://www.bahiaaventuras.com/frequently-asked-question/).

**Season, humpback_whale:** Dec, Jan, Feb, Mar. Separate December-March whale window. Published date window: {"start": "12-01", "end": "03-31"}. [Season evidence](https://www.bahiaaventuras.com/frequently-asked-question/).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.bahiaaventuras.com/contact/).

**Contact:** [Official visitor/contact route](https://www.bahiaaventuras.com/contact/). Telephone: +50688466576.

**Evidence:** [Bahia Aventuras](https://www.bahiaaventuras.com/contact/); [Bahia Aventuras](https://www.bahiaaventuras.com/tours/whale-dolphin-combo-tour/); [Bahia Aventuras](https://www.bahiaaventuras.com/frequently-asked-question/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Abrolhos Islands marine-wildlife boat outing

**Location:** Houtman Abrolhos Islands, Australia.

Island waters support sea lions and dolphins.

**Why go:** The island-water setting combines coastal scenery with the possibility of sea lions and dolphins, rather than focusing only on whales.

**Key attractions:** Island scenery; Sea lions; Dolphins.

**Season, sea_lion:** All months. Island waters support sea lions and dolphins. Choose a trip by its actual route and wildlife protocol. [Season evidence](https://www.australiascoralcoast.com/plan/natures-calendar).

**Plan around:** Island waters support sea lions and dolphins. Choose a trip by its actual route and wildlife protocol. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.australiascoralcoast.com/plan/natures-calendar).

**Contact:** [Official visitor/contact route](https://www.australiascoralcoast.com/plan/natures-calendar).

**Evidence:** [Australia's Coral Coast](https://www.australiascoralcoast.com/plan/natures-calendar). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Jurien Bay sea-lion outing

**Location:** Jurien Bay, Australia.

Sea-lion habitat offers a different wildlife theme from whale trips.

**Why go:** Sea lions provide a distinct marine-mammal theme and a reason to choose this outing instead of a conventional whale tour.

**Key attractions:** Sea lions; Coastal habitat; Operator-led wildlife outing.

**Season, sea_lion:** All months. Sea-lion habitat offers a different wildlife theme from whale trips. Confirm the operator interaction rules. [Season evidence](https://www.australiascoralcoast.com/plan/natures-calendar).

**Plan around:** Sea-lion habitat offers a different wildlife theme from whale trips. Confirm the operator interaction rules. Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.australiascoralcoast.com/plan/natures-calendar).

**Contact:** [Official visitor/contact route](https://www.australiascoralcoast.com/plan/natures-calendar).

**Evidence:** [Australia's Coral Coast](https://www.australiascoralcoast.com/plan/natures-calendar). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Qatar offshore whale-shark watching

**Location:** Qatar offshore waters, Qatar.

A specialist wildlife voyage; the existence of a seasonal aggregation does not establish a departure.

**Why go:** A seasonal offshore aggregation offers a specialist wildlife objective that is distinct from an ordinary coastal cruise.

**Key attractions:** Whale sharks; Offshore waters; Seasonal aggregation.

**Season, Whale shark:** Apr, May, Jun, Jul, Aug, Sep. Whale sharks congregate offshore April-September. Protected-area access and actual tour availability are separate; no in-water encounter is implied. [Season evidence](https://visitqatar.com/intl-en/about-qatar/wildlife/whale-sharks).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.discoverqatar.qa/whale-sharks-of-qatar/faqs/).

**Contact:** [Official visitor/contact route](https://www.discoverqatar.qa/whale-sharks-of-qatar/faqs/).

**Evidence:** [Discover Qatar](https://www.discoverqatar.qa/whale-sharks-of-qatar/faqs/); [Visit Qatar](https://visitqatar.com/intl-en/about-qatar/wildlife/whale-sharks). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Shark Bay dugong boat discovery

**Location:** Shark Bay, Australia.

A boat-based way to look for dugongs without promising an in-water encounter.

**Why go:** Dugong searching from a boat gives visitors a different marine-mammal theme without requiring an in-water encounter.

**Key attractions:** Dugongs; Shark Bay waters; Boat observation.

**Season, dugong:** All months. A boat-based way to look for dugongs without promising an in-water encounter. [Season evidence](https://www.australiascoralcoast.com/plan/natures-calendar).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.australiascoralcoast.com/plan/natures-calendar).

**Contact:** [Official visitor/contact route](https://www.australiascoralcoast.com/plan/natures-calendar).

**Evidence:** [Australia's Coral Coast](https://www.australiascoralcoast.com/plan/natures-calendar). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Shark Ray Alley snorkel discovery

**Location:** Hol Chan Zone D, Belize.

Nurse-shark and ray viewing at a managed tourism site; animal-attraction practices need explicit disclosure.

**Why go:** Nurse sharks and rays give this snorkel a clear wildlife focus, with animal-attraction practices part of the comparison.

**Key attractions:** Nurse sharks; Rays; Managed snorkelling site.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr, May. Drier Belize regional context, not a reef permit, trip schedule or wildlife guarantee. [Season evidence](https://www.islandexpeditions.com/book-your-trip/frequently-asked-questions/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://fisheries.gov.bz/hcmr/).

**Contact:** [Official visitor/contact route](https://fisheries.gov.bz/hcmr/).

**Evidence:** [Belize Fisheries Department](https://fisheries.gov.bz/hcmr/); [Island Expeditions](https://www.islandexpeditions.com/book-your-trip/frequently-asked-questions/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #149: Geraldton windsurfing season discovery

**Location:** Geraldton, Australia.

The regional calendar highlights an October-April windsurfing period.

**Why go:** A windsurfing-specific seasonal window makes the coast relevant to a sporting visit rather than a generic fair-weather beach search.

**Key attractions:** Windsurfing; Regional wind season; Coastal sport setting.

**Season, typical conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr. The regional calendar highlights an October-April windsurfing period. A seasonal pattern is not a wind forecast. [Season evidence](https://www.australiascoralcoast.com/plan/natures-calendar).

**Plan around:** The regional calendar highlights an October-April windsurfing period. A seasonal pattern is not a wind forecast. Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.australiascoralcoast.com/plan/natures-calendar).

**Contact:** [Official visitor/contact route](https://www.australiascoralcoast.com/plan/natures-calendar).

**Evidence:** [Australia's Coral Coast](https://www.australiascoralcoast.com/plan/natures-calendar). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #196: Alpamare indoor and outdoor water park

**Location:** Pfaeffikon SZ, Switzerland.

Indoor and outdoor water attractions provide a pool-based alternative to seasonal Lake Zurich swimming.

**Why go:** Indoor and outdoor water attractions provide an alternative to seasonal lake swimming. It earns a place for a different type of water day, not as a proxy for good outdoor weather.

**Key attractions:** Indoor water attractions; Outdoor sections; Water-park format.

**Season, facility indoor:** All months. Operator advertises 365-day opening; attractions and holiday hours vary. [Season evidence](https://alpamare.ch/en/openinghours/).

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Published price reference:** CHF 46 / adult_visit. held. English publisher snapshot may lag checkout. Reconfirm before displaying as a current offer. Excluded from current-price comparison until the conflicting tariff evidence is resolved. Not a live or all-in quote. [Publisher](https://alpamare.ch/en/prices/).

**Tickets/access:** [Official ticket / operator information](https://alpamare.ch/en/prices/).

**Contact:** [Official visitor/contact route](https://alpamare.ch/en/prices/). Telephone: +41554151515.

**Evidence:** [Alpamare](https://alpamare.ch/en/openinghours/); [Alpamare](https://alpamare.ch/en/prices/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #196: Andamanda Phuket water park

**Location:** Kathu, Phuket, Thailand.

An outdoor water park gives Phuket visitors a pool-and-slide alternative to beach and boat days.

**Why go:** An outdoor water-park day offers a different format from Phuket beaches and boat trips, with admission categories that can be matched to visitor height rather than guessed from age.

**Key attractions:** Water-park attractions; Outdoor water day; Height-specific ticket categories.

**Season, operator program:** Not established. Daily hours are published, but a year-round annual operating claim was not independently established. [Season evidence](https://www.andamandaphuket.com/plan/get-ready).

**Season, operator pattern:** All months. The operator describes the park as open every day throughout the year. Separate zones, maintenance, height rules and weather closures still need checking. [Season evidence](https://www.andamandaphuket.com/booking).

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Published price reference:** THB 1800 / person_visit. published reference. Height-based category. Transfers, towels, lockers and other extras depend on package. Not a live or all-in quote. [Publisher](https://www.andamandaphuket.com/plan/get-ready).

**Published price reference:** THB 1200 / person_visit. published reference. Do not convert height band into an invented age band. Not a live or all-in quote. [Publisher](https://www.andamandaphuket.com/plan/get-ready).

**Tickets/access:** [Official ticket / operator information](https://www.andamandaphuket.com/plan/get-ready).

**Contact:** [Official visitor/contact route](https://www.andamandaphuket.com/plan/get-ready). Telephone: +6676646777.

**Evidence:** [Andamanda Phuket](https://www.andamandaphuket.com/plan/get-ready); [Andamanda Phuket](https://www.andamandaphuket.com/booking). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #196: Therme Erding pools, waves and slides

**Location:** Erding, Bavaria, Germany.

Pools, waves and slides provide a venue-based water outing with several possible durations and admission areas.

**Why go:** Pools, waves and slides support a full water-focused venue visit with several possible ticket durations. Compare the exact included areas rather than assuming every thermal or adult-only zone is part of the base fare.

**Key attractions:** Pools; Waves; Slides.

**Season, operator pattern:** All months. The indoor Galaxy offer includes a year-round slide. Outdoor attractions have separate seasons, and individual facilities can close. [Season evidence](https://www.therme-erding.de/en/therme-sauna/therme/galaxy/).

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Published price reference:** EUR 25 / person_two_hours. published reference. Base two-hour Therme reference including wave pool and Galaxy; surcharge-day and extension costs excluded. Not a live or all-in quote. [Publisher](https://www.therme-erding.de/en/info/prices-opening-hours-revisions/).

**Tickets/access:** [Official ticket / operator information](https://www.therme-erding.de/en/info/prices-opening-hours-revisions/).

**Contact:** [Official visitor/contact route](https://www.therme-erding.de/en/info/prices-opening-hours-revisions/).

**Evidence:** [Therme Erding](https://www.therme-erding.de/en/info/prices-opening-hours-revisions/); [Therme Erding](https://www.therme-erding.de/en/therme-sauna/therme/galaxy/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #196: Rulantica water world

**Location:** Rust, Baden-Wurttemberg, Germany.

Indoor and outdoor pool and slide areas form a dedicated water-world visit.

**Why go:** A dedicated water world supplies a pool-and-slide alternative when open-water swimming is not the desired activity. Indoor and outdoor areas need separate availability checks.

**Key attractions:** Pools; Slides; Indoor and outdoor areas.

**Season, operator program:** All months. The operator describes an all-year water-world programme, not guaranteed access to every attraction. [Season evidence](https://www.europapark.de/en/rulantica/info/plan-your-visit/rulantica-opening-hours).

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.europapark.de/en/rulantica/info/plan-your-visit/rulantica-opening-hours).

**Contact:** [Official visitor/contact route](https://www.europapark.de/en/rulantica/info/plan-your-visit/rulantica-opening-hours).

**Evidence:** [Europa-Park / Rulantica](https://www.europapark.de/en/rulantica/info/plan-your-visit/rulantica-opening-hours). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Water rank #196: Siam Park waterpark

**Location:** Costa Adeje, Tenerife, Spain.

A Tenerife water park offers an alternative to beach swimming and wildlife cruises.

**Why go:** An all-year water-park programme makes this a distinct Tenerife option alongside beaches and whale cruises. Individual ride eligibility remains a separate decision.

**Key attractions:** Water-park attractions; All-year programme reference; Attraction-specific ride choices.

**Season, operator program:** All months. Operator lists a 365-day annual programme; this does not guarantee every ride or a particular date. [Season evidence](https://siampark.net/plan-your-visit/opening-hours/).

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://siampark.net/plan-your-visit/opening-hours/).

**Contact:** [Official visitor/contact route](https://siampark.net/plan-your-visit/opening-hours/).

**Evidence:** [Siam Park](https://siampark.net/plan-your-visit/opening-hours/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

## Further water discoveries and explicit research gaps

These catalogue records have complete-format cards but are not included in the Top 200. An unknown season is not presented as a positive seasonal recommendation.

### Additional discovery: Ratsada guided jet-ski excursions

**Location:** Ratsada, Phuket, Thailand.

A provider listing for a guided watercraft experience. Keep per-jet-ski prices, rider limits, damage liability, insurance and operating-zone permissions visible before any booking link. This is not a verified Patong beach concession.

**Why go:** A provider listing for a guided watercraft experience. Keep per-jet-ski prices, rider limits, damage liability, insurance and operating-zone permissions visible before any booking link. This is not a verified Patong beach concession.

**Key attractions:** Jet-ski outings.

**Season, operator program:** Not established. Operating dates and weather policy require provider confirmation. [Season evidence](https://www.ratsadaphuketseasport.com/).

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** Operator verification and access controls are unresolved, so this is held from highlights.

**Published price reference:** THB 9000 / watercraft_trip. held. Not comparable until package duration, capacity, deposit and insurance terms are confirmed. Not a live or all-in quote. [Publisher](https://www.ratsadaphuketseasport.com/).

**Tickets/access:** [Official ticket / operator information](https://www.ratsadaphuketseasport.com/).

**Contact:** [Official visitor/contact route](https://www.ratsadaphuketseasport.com/).

**Evidence:** [Ratsada Phuket Sea Sport](https://www.ratsadaphuketseasport.com/); [Ratsada Phuket Sea Sport](https://www.ratsadaphuketseasport.com/); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Horgen-Meilen Lake Zurich ferry

**Location:** Lake Zurich, Switzerland.

A short cross-lake transport experience with pedestrian and vehicle products. Keep direction, ticket class and selected travel date explicit; the accessible English summer table has already expired.

**Why go:** A useful public crossing becomes a short Lake Zurich outing without needing a packaged cruise. It ranks as a crossing experience, not as a substitute for a full lake itinerary.

**Key attractions:** Horgen; Meilen; Ferry crossings.

**Season, operator program:** All months. Summer and winter programmes are evidenced; exact date-specific departures still need a current timetable. [Season evidence](https://www.faehre.ch/de/aktuelles/anpassungen-auf-den-winterfahrplan-2026).

**Published restriction:** The retrieved summer timetable ended 24 October 2026; use the current winter notice or journey planner. [Source](https://www.faehre.ch/en/timetables).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.faehre.ch/en/timetables).

**Contact:** [Official visitor/contact route](https://www.faehre.ch/en/timetables). Telephone: +41447273737.

**Evidence:** [Lake Zurich Ferry Horgen-Meilen](https://www.faehre.ch/en/timetables); [Lake Zurich Ferry Horgen-Meilen](https://www.faehre.ch/de/aktuelles/anpassungen-auf-den-winterfahrplan-2026). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lake Zurich scheduled and sightseeing cruises

**Location:** Zurich, Lake Zurich, Switzerland.

A network of round trips and scheduled services, not one interchangeable ticket. Show route, embarkation pier, transport fare and optional catering separately; give service notices priority over a general timetable.

**Why go:** A year-round public boat network offers several lengths of outing. The precise ship, route and accessibility need more detail than a general lake-cruise description.

**Key attractions:** Scenic cruises.

**Season, operator program:** Not established. Route-specific seasonal schedules are published by ZSG; do not apply one calendar to the whole fleet. [Season evidence](https://www.zsg.ch/en/timetables/).

**Season, operator pattern:** All months. Year-round fleet programme; individual routes and vessels vary. [Season evidence](https://www.zsg.ch/en/about-us/).

**Published restriction:** A published reduced-service notice affects Zurich Burkliplatz-Thalwil through 30 November 2026; recheck before planning. [Source](https://www.zsg.ch/en/traffic-conditions/).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.zsg.ch/en/timetables/).

**Contact:** [Official visitor/contact route](https://www.zsg.ch/en/timetables/).

**Evidence:** [Zurichsee-Schifffahrtsgesellschaft](https://www.zsg.ch/en/timetables/); [Zurichsee-Schifffahrtsgesellschaft](https://www.zsg.ch/en/traffic-conditions/); [Zurichsee Schifffahrtsgesellschaft](https://www.zsg.ch/en/about-us/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lausanne-Evian Lake Geneva crossing

**Location:** Lake Geneva / Lac Leman, Switzerland, France.

A cross-border passenger crossing that can be an outing as well as transport. Retain departure direction, return plan, border-document checks and current service disruptions; do not invent a sailing from a seasonal summary.

**Why go:** A cross-border passenger crossing that can be an outing as well as transport. Retain departure direction, return plan, border-document checks and current service disruptions; do not invent a sailing from a seasonal summary.

**Key attractions:** Lausanne-Ouchy; Evian-les-Bains; Ferry crossings.

**Season, operator program:** Not established. Use dated route N1 timetable for the travel day. [Season evidence](https://www.cgn.ch/en/horaires-billets).

**Season, operator pattern:** All months. The Lausanne-Evian route operates throughout the year. Timetable, weather cancellations and cross-border travel documents remain separate checks. [Season evidence](https://www.evad.fr/navettes-lacustres-cgn/).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.cgn.ch/en/horaires-billets).

**Contact:** [Official visitor/contact route](https://www.cgn.ch/en/horaires-billets).

**Evidence:** [CGN](https://www.cgn.ch/en/horaires-billets); [CGN](https://www.cgn.ch/en/cgn-mobilite); [EVA D public transport](https://www.evad.fr/navettes-lacustres-cgn/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Friedrichshafen-Romanshorn Lake Constance ferry

**Location:** Bodensee / Lake Constance, Germany, Switzerland.

A cross-border lake crossing with different pedestrian, bicycle and vehicle products. Treat the ferry and seasonal sightseeing boats as different services even when they share the same lake.

**Why go:** A cross-border lake crossing with different pedestrian, bicycle and vehicle products. Treat the ferry and seasonal sightseeing boats as different services even when they share the same lake.

**Key attractions:** Friedrichshafen; Romanshorn; Ferry crossings.

**Season, operator program:** Not established. Read the date-specific ferry timetable; no frequency inferred. [Season evidence](https://www.bsb.de/de/fahrplan).

**Season, operator pattern:** All months. Year-round cross-lake ferry programme. [Season evidence](https://www.bodensee.eu/en/where-to-travel/regions/german-lake-constance/excursion-destinations/lake-constance-ferry-friedrichshafen%E2%80%94romanshorn_poi681).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.bsb.de/de/fahrplan/bodensee-faehre).

**Contact:** [Official visitor/contact route](https://www.bsb.de/de/fahrplan/bodensee-faehre).

**Evidence:** [Bodensee-Schiffsbetriebe](https://www.bsb.de/de/fahrplan/bodensee-faehre); [Bodensee-Schiffsbetriebe](https://www.bsb.de/de/fahrplan); [Bodensee tourism](https://www.bodensee.eu/en/where-to-travel/regions/german-lake-constance/excursion-destinations/lake-constance-ferry-friedrichshafen%E2%80%94romanshorn_poi681). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lindau and Bregenz Bay sightseeing cruise

**Location:** Eastern Lake Constance, Germany, Austria.

A sightseeing circuit distinct from the transport ferry. Departure dates and exact ticket prices need their own operator offer rather than a fleet-wide starting price.

**Why go:** A sightseeing circuit distinct from the transport ferry. Departure dates and exact ticket prices need their own operator offer rather than a fleet-wide starting price.

**Key attractions:** Bregenz Bay; Scenic cruises.

**Season, operator program:** Not established. Exact seasonal programme not extracted. [Season evidence](https://www.bsb.de/de/bodensee-erlebnisse/rundfahrten/lindau/bregenzer-bucht).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.bsb.de/de/bodensee-erlebnisse/rundfahrten/lindau/bregenzer-bucht).

**Contact:** [Official visitor/contact route](https://www.bsb.de/de/bodensee-erlebnisse/rundfahrten/lindau/bregenzer-bucht).

**Evidence:** [Bodensee-Schiffsbetriebe](https://www.bsb.de/de/bodensee-erlebnisse/rundfahrten/lindau/bregenzer-bucht). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Uvita low-tide sea kayaking

**Location:** Uvita beach, Costa Rica.

A tide-dependent paddle with departure timing supplied by the operator. A monthly calendar cannot generate its daily start time.

**Why go:** A tide-dependent paddle with departure timing supplied by the operator. A monthly calendar cannot generate its daily start time.

**Key attractions:** Kayaking.

**Season, tidal constraint:** Not established. Departure depends on low tide; no daily prediction is supplied. [Season evidence](https://www.bahiaaventuras.com/tours/sea-kayaking-uvita-beach/).

**Season, regional conditions:** Dec, Jan, Feb, Mar, Apr. Pacific dry-season context; not the Caribbean coast or a river-flow assessment. [Season evidence](https://www.visitcostarica.com/planning-your-trip/climate).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.bahiaaventuras.com/tours/sea-kayaking-uvita-beach/).

**Contact:** [Official visitor/contact route](https://www.bahiaaventuras.com/tours/sea-kayaking-uvita-beach/).

**Evidence:** [Bahia Aventuras](https://www.bahiaaventuras.com/tours/sea-kayaking-uvita-beach/); [Bahia Aventuras](https://www.bahiaaventuras.com/contact/); [Costa Rica Tourism Institute](https://www.visitcostarica.com/planning-your-trip/climate). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Gansbaai shark-cage experience

**Location:** Gansbaai, South Africa.

A caged shark encounter requiring an explicit ethical-practice and participation review. Present species actually described by the operator rather than promising great whites. Operator publication is not independent safety certification.

**Why go:** A caged shark encounter requiring an explicit ethical-practice and participation review. Present species actually described by the operator rather than promising great whites. Operator publication is not independent safety certification.

**Key attractions:** Shark experiences.

**Season, operator program:** Not established. No complete dated operating calendar extracted. [Season evidence](https://sharkwatchsa.com/rates-and-info/).

**Published restriction:** Confirm cage participation requirements, current species expectations and baiting/chumming practice before promotion. [Source](https://sharkwatchsa.com/rates-and-info/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Published price reference:** ZAR 3655 / adult_trip. published reference. Known listed base plus conservation fee: ZAR 3805. Optional transport separate; local resident tariff differs. Not a live or all-in quote. [Publisher](https://sharkwatchsa.com/rates-and-info/).

**Tickets/access:** [Official ticket / operator information](https://sharkwatchsa.com/rates-and-info/).

**Contact:** [Official visitor/contact route](https://sharkwatchsa.com/rates-and-info/). Telephone: +27823803405.

**Evidence:** [Marine Dynamics](https://sharkwatchsa.com/rates-and-info/); [Marine Dynamics](https://sharkwatchsa.com/shark-cage-diving/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Staten Island harbour crossing

**Location:** New York City, United States.

A public harbour crossing that can also be a low-cost sightseeing experience. Free passage is explicitly supported by the transport authority; free does not mean reserved capacity or a guaranteed departure.

**Why go:** A public harbour crossing that can also be a low-cost sightseeing experience. Free passage is explicitly supported by the transport authority; free does not mean reserved capacity or a guaranteed departure.

**Key attractions:** Lower Manhattan; Staten Island; Ferry crossings.

**Season, operator program:** All months. Authority describes daily service throughout the year. [Season evidence](https://www.nyc.gov/html/dot/html/ferrybus/staten-island-ferry.shtml).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Published price reference:** USD 0 / person_one_way. free. No passenger fare; check service alerts. Not a live or all-in quote. [Publisher](https://www.nyc.gov/html/dot/html/ferrybus/staten-island-ferry.shtml).

**Tickets/access:** [Published fee or access information](https://www.nyc.gov/html/dot/html/ferrybus/staten-island-ferry.shtml).

**Contact:** [Official visitor/contact route](https://www.nyc.gov/html/dot/html/ferrybus/staten-island-ferry.shtml).

**Evidence:** [NYC Department of Transportation](https://www.nyc.gov/html/dot/html/ferrybus/staten-island-ferry.shtml). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Star Ferry Central to Tsim Sha Tsui

**Location:** Victoria Harbour, Hong Kong, Hong Kong.

A short harbour crossing with different deck and day-type fares. The announced future tariff change is retained so the old fare cannot silently continue into 2027.

**Why go:** A short harbour crossing with different deck and day-type fares. The announced future tariff change is retained so the old fare cannot silently continue into 2027.

**Key attractions:** Central; Tsim Sha Tsui; Ferry crossings.

**Season, operator program:** All months. Published weekday/weekend service pattern, subject to alerts and weather. [Season evidence](https://www.starferry.com.hk/en/service).

**Published restriction:** A new fare schedule takes effect on 25 January 2027; do not reuse older prices for later dates. [Source](https://www.news.gov.hk/eng/2026/10/20261021/20261021_170401_191.html).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Published price reference:** HKD 4 / person_one_way. published reference. Weekend/holiday lower deck HKD 5.60; other deck fares differ. Not a live or all-in quote. [Publisher](https://www.starferry.com.hk/en/service).

**Tickets/access:** [Official ticket / operator information](https://www.starferry.com.hk/en/service).

**Contact:** [Official visitor/contact route](https://www.starferry.com.hk/en/service).

**Evidence:** [Star Ferry](https://www.starferry.com.hk/en/service); [Hong Kong Government](https://www.news.gov.hk/eng/2026/10/20261021/20261021_170401_191.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Sydney F1 Manly ferry

**Location:** Sydney Harbour, Australia.

A public-transport harbour journey, distinct from the separately operated fast ferry. Show the exact service brand before comparing fares or duration.

**Why go:** A public-transport harbour journey, distinct from the separately operated fast ferry. Show the exact service brand before comparing fares or duration.

**Key attractions:** Circular Quay; Manly; Ferry crossings.

**Season, operator program:** Not established. Route verified; dated timetable not downloaded in this handoff. [Season evidence](https://transportnsw.info/routes/details/sydney-ferries-network/f1/090f1).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://transportnsw.info/routes/details/sydney-ferries-network/f1/090f1).

**Contact:** [Official visitor/contact route](https://transportnsw.info/routes/details/sydney-ferries-network/f1/090f1).

**Evidence:** [Transport for NSW](https://transportnsw.info/routes/details/sydney-ferries-network/f1/090f1). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Istanbul municipal Bosphorus tour

**Location:** Istanbul, Bosphorus, Türkiye.

Compare long and short sightseeing programmes separately from commuter ferries. Local and foreign-passenger tariffs differ and must remain visible.

**Why go:** Compare long and short sightseeing programmes separately from commuter ferries. Local and foreign-passenger tariffs differ and must remain visible.

**Key attractions:** Bosphorus; Scenic cruises.

**Season, operator program:** Not established. The fare page does not establish an exact annual departure calendar. [Season evidence](https://sehirhatlari.istanbul/en/price-list/bosphorus-tours-78).

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Published price reference:** TRY 640 / adult_trip. published reference. Local passenger reference TRY 320; child categories differ. Not a live or all-in quote. [Publisher](https://sehirhatlari.istanbul/en/price-list/bosphorus-tours-78).

**Published price reference:** TRY 340 / adult_trip. published reference. Local passenger reference TRY 170. Not a live or all-in quote. [Publisher](https://sehirhatlari.istanbul/en/price-list/bosphorus-tours-78).

**Tickets/access:** [Official ticket / operator information](https://sehirhatlari.istanbul/en/price-list/bosphorus-tours-78).

**Contact:** [Official visitor/contact route](https://sehirhatlari.istanbul/en/price-list/bosphorus-tours-78).

**Evidence:** [Sehir Hatlari](https://sehirhatlari.istanbul/en/price-list/bosphorus-tours-78). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Miyajimaguchi to Miyajima crossing

**Location:** Miyajima, Hiroshima, Japan.

A short island crossing where the outbound visitor tax differs from the return fare. Do not mislabel the ferry fare alone as the complete island-entry cost.

**Why go:** A short island crossing where the outbound visitor tax differs from the return fare. Do not mislabel the ferry fare alone as the complete island-entry cost.

**Key attractions:** Miyajima; Ferry crossings.

**Season, operator program:** Not established. Fare source verified; a dated timetable still needs operator confirmation. [Season evidence](https://miyajima-matsudai.co.jp/en/price.html).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Published price reference:** JPY 200 / person_one_way. published reference. Listed outbound components JPY 300. Exemptions and return journey differ. Not a live or all-in quote. [Publisher](https://miyajima-matsudai.co.jp/en/price.html).

**Tickets/access:** [Official ticket / operator information](https://miyajima-matsudai.co.jp/en/price.html).

**Contact:** [Official visitor/contact route](https://miyajima-matsudai.co.jp/en/price.html).

**Evidence:** [Miyajima Matsudai Kisen](https://miyajima-matsudai.co.jp/en/price.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Tropical Islands indoor water resort

**Location:** Krausnick, Germany.

A weather-independent indoor option with separate access rules for day and overnight guests. Generic hidden calendar messages must not be interpreted as a dated closure.

**Why go:** A weather-independent indoor option with separate access rules for day and overnight guests. Generic hidden calendar messages must not be interpreted as a dated closure.

**Key attractions:** Water parks.

**Season, facility indoor:** All months. Year-round resort offer; individual attraction and guest-category hours differ. [Season evidence](https://www.tropical-islands.de/en/preise-oeffnungszeiten/oeffnungszeiten).

**Season, operator pattern:** All months. Year-round indoor resort; day and overnight hours differ. [Season evidence](https://www.tropical-islands.de/en/preise-oeffnungszeiten/oeffnungszeiten).

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.tropical-islands.de/en/preise-oeffnungszeiten/oeffnungszeiten).

**Contact:** [Official visitor/contact route](https://www.tropical-islands.de/en/preise-oeffnungszeiten/oeffnungszeiten).

**Evidence:** [Tropical Islands](https://www.tropical-islands.de/en/preise-oeffnungszeiten/oeffnungszeiten); [Tropical Islands](https://www.tropical-islands.de/en/preise-oeffnungszeiten/oeffnungszeiten). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Waterbom Bali water park

**Location:** Kuta, Bali, Indonesia.

An outdoor water-park option with resident and non-resident ticket rules. A headline ticket does not automatically include lockers, towels or food.

**Why go:** An outdoor water-park option with resident and non-resident ticket rules. A headline ticket does not automatically include lockers, towels or food.

**Key attractions:** Water parks.

**Season, operator program:** Not established. Check the selected day with the operator; no annual opening assertion added. [Season evidence](https://www.waterbom-bali.com/ticket).

**Season, operator pattern:** All months. The operator describes year-round operation. Individual ride closures, height requirements and booking availability remain separate. [Season evidence](https://www.waterbom-bali.com/frequently-asked-questions).

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.waterbom-bali.com/ticket).

**Contact:** [Official visitor/contact route](https://www.waterbom-bali.com/ticket).

**Evidence:** [Waterbom Bali](https://www.waterbom-bali.com/ticket); [Waterbom Bali](https://www.waterbom-bali.com/frequently-asked-questions). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Wild Wild Wet Singapore

**Location:** Pasir Ris, Singapore, Singapore.

A park with date-specific access and event closures. A tropical location is not evidence of being open every day.

**Why go:** A park with date-specific access and event closures. A tropical location is not evidence of being open every day.

**Key attractions:** Water parks.

**Season, operator program:** Not established. Use official date calendar; event closures and changing hours matter. [Season evidence](https://www.wildwildwet.com/visitor-information/guest-services).

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.wildwildwet.com/visitor-information/guest-services).

**Contact:** [Official visitor/contact route](https://www.wildwildwet.com/visitor-information/guest-services).

**Evidence:** [Wild Wild Wet](https://www.wildwildwet.com/visitor-information/guest-services); [Wild Wild Wet](https://www.wildwildwet.com/tickets-memberships/day-pass). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Chanaral de Aceituno marine wildlife

**Location:** Chanaral de Aceituno, Chile.

A coastal wildlife destination with whale and marine-bird interest. Keep operator, season, price and boat authorisation gaps explicit rather than importing an old season price.

**Why go:** A coastal wildlife destination with whale and marine-bird interest. Keep operator, season, price and boat authorisation gaps explicit rather than importing an old season price.

**Key attractions:** Whale watching.

**Season, species presence:** Not established. A destination is supported; month-specific timing remains unverified here. [Season evidence](https://wwhandbook.iwc.int/en/country-profiles/chile).

**Plan around:** No sighting guarantee; distinguish species season from boat operation and wildlife conduct.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://wwhandbook.iwc.int/en/country-profiles/chile).

**Contact:** [Official visitor/contact route](https://wwhandbook.iwc.int/en/country-profiles/chile).

**Evidence:** [International Whaling Commission](https://wwhandbook.iwc.int/en/country-profiles/chile). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Moreton Island wreck snorkelling

**Location:** Moreton Island, Brisbane, Australia.

Artificial wreck habitat reached from Moreton Island. Currents and boat movements need local assessment.

**Why go:** Artificial wreck habitat reached from Moreton Island. Currents and boat movements need local assessment.

**Key attractions:** Snorkelling.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Contact:** [Official visitor/contact route](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland).

**Evidence:** [Tourism and Events Queensland](https://www.queensland.com/au/en/things-to-do/adventure/diving-and-snorkelling/best-snorkelling-sites-queensland). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lake Rotoiti guided kayak outing

**Location:** Rotorua / Lake Rotoiti, New Zealand.

A lake-based kayak experience rather than an offshore excursion. Ask which hot-pool or cave visits the booked product includes.

**Why go:** A lake-based kayak experience rather than an offshore excursion. Ask which hot-pool or cave visits the booked product includes.

**Key attractions:** Kayaking.

**Season, regional conditions:** Dec, Jan, Feb. New Zealand summer comfort context; local operations can extend year-round. [Season evidence](https://www.newzealand.com/nz/kayaking/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.newzealand.com/uk/plan/business/scenic-lake-rotoiti-kayak-tour/).

**Contact:** [Official visitor/contact route](https://www.newzealand.com/uk/plan/business/scenic-lake-rotoiti-kayak-tour/).

**Evidence:** [Tourism New Zealand / Waimarino](https://www.newzealand.com/uk/plan/business/scenic-lake-rotoiti-kayak-tour/); [Tourism New Zealand](https://www.newzealand.com/nz/kayaking/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Buck Island underwater trail

**Location:** St Croix / Buck Island, US Virgin Islands.

An underwater interpretive trail makes the snorkel itself educational. Confirm authorised transport and park conditions.

**Why go:** An underwater interpretive trail makes the snorkel itself educational. Confirm authorised transport and park conditions.

**Key attractions:** Underwater snorkel trails.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.nps.gov/places/buck-island-underwater-trail.htm).

**Contact:** [Official visitor/contact route](https://www.nps.gov/places/buck-island-underwater-trail.htm).

**Evidence:** [US National Park Service](https://www.nps.gov/places/buck-island-underwater-trail.htm). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Trunk Bay underwater interpretation trail

**Location:** St John / Trunk Bay, US Virgin Islands.

A beach-based underwater trail. Check wave conditions and any facility fees before planning a swim.

**Why go:** A beach-based underwater trail. Check wave conditions and any facility fees before planning a swim.

**Key attractions:** Underwater snorkel trails.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.nps.gov/places/trunk-bay.htm).

**Contact:** [Official visitor/contact route](https://www.nps.gov/places/trunk-bay.htm).

**Evidence:** [US National Park Service](https://www.nps.gov/places/trunk-bay.htm). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Biscayne Maritime Heritage Trail

**Location:** Biscayne National Park, United States.

An underwater heritage route, not a single interchangeable dive. Some wrecks suit snorkelling; others require scuba skills and boat access.

**Why go:** An underwater heritage route, not a single interchangeable dive. Some wrecks suit snorkelling; others require scuba skills and boat access.

**Key attractions:** Wreck diving.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.nps.gov/bisc/learn/historyculture/maritime-heritage-trail.htm).

**Contact:** [Official visitor/contact route](https://www.nps.gov/bisc/learn/historyculture/maritime-heritage-trail.htm).

**Evidence:** [US National Park Service](https://www.nps.gov/bisc/learn/historyculture/maritime-heritage-trail.htm). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Fathom Five freshwater wreck exploration

**Location:** Tobermory / Fathom Five, Canada.

Cold-water wreck exploration in a protected Great Lakes setting. Distinguish snorkelling areas from scuba routes and permit requirements.

**Why go:** Cold-water wreck exploration in a protected Great Lakes setting. Distinguish snorkelling areas from scuba routes and permit requirements.

**Key attractions:** Wreck diving.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://parks.canada.ca/amnc-nmca/on/fathomfive/activ/plong-dive).

**Contact:** [Official visitor/contact route](https://parks.canada.ca/amnc-nmca/on/fathomfive/activ/plong-dive).

**Evidence:** [Parks Canada](https://parks.canada.ca/amnc-nmca/on/fathomfive/activ/plong-dive). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Saguenay-St Lawrence cold-water diving

**Location:** Saguenay-St Lawrence Marine Park, Canada.

A cold-water marine-life discovery rather than a tropical reef substitute. Confirm qualifications, equipment and permitted launch sites.

**Why go:** A cold-water marine-life discovery rather than a tropical reef substitute. Confirm qualifications, equipment and permitted launch sites.

**Key attractions:** Scuba diving.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://parks.canada.ca/amnc-nmca/qc/saguenay/activ/plongee-diving).

**Contact:** [Official visitor/contact route](https://parks.canada.ca/amnc-nmca/qc/saguenay/activ/plongee-diving).

**Evidence:** [Parks Canada](https://parks.canada.ca/amnc-nmca/qc/saguenay/activ/plongee-diving). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Wakulla Springs riverboat wildlife outing

**Location:** Wakulla Springs, United States.

A freshwater wildlife cruise with a separate designated swimming option. Do not treat the whole river as a swimming area.

**Why go:** A freshwater wildlife cruise with a separate designated swimming option. Do not treat the whole river as a swimming area.

**Key attractions:** Wildlife boats.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitflorida.com/places-to-go/north-central/wakulla-springs/).

**Contact:** [Official visitor/contact route](https://www.visitflorida.com/places-to-go/north-central/wakulla-springs/).

**Evidence:** [VISIT FLORIDA](https://www.visitflorida.com/places-to-go/north-central/wakulla-springs/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Gudlaug coastal baths

**Location:** Akranes, Iceland.

Hot pools beside Langisandur Beach. Distinguish the managed baths from independent sea swimming.

**Why go:** Hot pools beside Langisandur Beach. Distinguish the managed baths from independent sea swimming.

**Key attractions:** Thermal baths.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/).

**Contact:** [Official visitor/contact route](https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/).

**Evidence:** [Visit Iceland](https://www.visiticeland.com/things-to-do/recreation/geothermal-baths/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Nautholsvik geothermal beach

**Location:** Reykjavik, Iceland.

A coastal lagoon blending sea and geothermal water. Temperature and staffed access are separate facts.

**Why go:** A coastal lagoon blending sea and geothermal water. Temperature and staffed access are separate facts.

**Key attractions:** Thermal baths.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visiticeland.com/things-to-do/nautholsvik-geothermal-beach/).

**Contact:** [Official visitor/contact route](https://www.visiticeland.com/things-to-do/nautholsvik-geothermal-beach/).

**Evidence:** [Visit Iceland](https://www.visiticeland.com/things-to-do/nautholsvik-geothermal-beach/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Akureyri geothermal swimming pools

**Location:** Akureyri, Iceland.

A municipal-style pool experience with heated pools and slides. Useful for a practical swim rather than only spa tourism.

**Why go:** A municipal-style pool experience with heated pools and slides. Useful for a practical swim rather than only spa tourism.

**Key attractions:** Pools.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visiticeland.com/things-to-do/akureyri-swimming-pool/).

**Contact:** [Official visitor/contact route](https://www.visiticeland.com/things-to-do/akureyri-swimming-pool/).

**Evidence:** [Visit Iceland](https://www.visiticeland.com/things-to-do/akureyri-swimming-pool/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Niihama lakeside sauna

**Location:** Tampere, Finland.

A public lakeside sauna with winter swimming described by the operator.

**Why go:** A public lakeside sauna with winter swimming described by the operator.

**Key attractions:** Sauna and swimming.

**Season, operator pattern:** All months. Public and private sauna with year-round availability. Public sessions are limited weekdays; lake entry is not a personal cold-water clearance. [Season evidence](https://www.visitfinland.com/en/product/613f17f6-38c8-4fa7-8e25-04a282dde91e/niihaman-ulkoilumajas-sauna/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown. Additional 13 November source review: Public and private sessions differ. Published public times are Tuesdays and Thursdays; confirm the current schedule. A lit path does not establish step-free water access.

**Published price reference:** EUR 8 / per-person public sauna session. published reference. Public and private sessions differ. Published public times are Tuesdays and Thursdays; confirm the current schedule. A lit path does not establish step-free water access. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/613f17f6-38c8-4fa7-8e25-04a282dde91e/niihaman-ulkoilumajas-sauna/).

**Tickets/access:** [Official visitor / access information](https://www.visitfinland.com/en/product/613f17f6-38c8-4fa7-8e25-04a282dde91e/niihaman-ulkoilumajas-sauna/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/613f17f6-38c8-4fa7-8e25-04a282dde91e/niihaman-ulkoilumajas-sauna/).

**Evidence:** [Visit Finland / listed provider](https://www.visitfinland.com/en/product/613f17f6-38c8-4fa7-8e25-04a282dde91e/niihaman-ulkoilumajas-sauna/); [Visit Finland / Niihaman Ulkoilumaja](https://www.visitfinland.com/en/product/613f17f6-38c8-4fa7-8e25-04a282dde91e/niihaman-ulkoilumajas-sauna/); [Niihaman Ulkoilumaja sauna / official publisher](https://www.visitfinland.com/en/product/613f17f6-38c8-4fa7-8e25-04a282dde91e/niihaman-ulkoilumajas-sauna/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Aulanko lakeside sauna

**Location:** Hameenlinna, Finland.

A lake sauna with an ice-swimming option described for winter. Confirm supervised access.

**Why go:** A lake sauna with an ice-swimming option described for winter. Confirm supervised access.

**Key attractions:** Sauna and swimming.

**Season, operator pattern:** All months. The named Aulanko lakeside sauna is listed as a year-round experience. Booking and lake conditions need checking. [Season evidence](https://www.visitfinland.com/en/product/5300ffe5-7258-4e13-a1f8-83e74b2b7ba7/lakeside-sauna-at-aulanko-hameenlinna/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitfinland.com/en/product/5300ffe5-7258-4e13-a1f8-83e74b2b7ba7/lakeside-sauna-at-aulanko-hameenlinna/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/5300ffe5-7258-4e13-a1f8-83e74b2b7ba7/lakeside-sauna-at-aulanko-hameenlinna/).

**Evidence:** [Visit Finland / listed provider](https://www.visitfinland.com/en/product/5300ffe5-7258-4e13-a1f8-83e74b2b7ba7/lakeside-sauna-at-aulanko-hameenlinna/); [Visit Finland](https://www.visitfinland.com/en/product/5300ffe5-7258-4e13-a1f8-83e74b2b7ba7/lakeside-sauna-at-aulanko-hameenlinna/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Nosturi sauna and lake dip

**Location:** Lahti, Finland.

A lakeside sauna whose public hours vary by season. Do not carry winter hours into summer.

**Why go:** A lakeside sauna whose public hours vary by season. Do not carry winter hours into summer.

**Key attractions:** Sauna and swimming.

**Season, operator pattern:** All months. Sauna is described as a year-round experience, with reduced public-session hours in summer. Winter swimming is optional, not personal clearance. [Season evidence](https://www.visitfinland.com/en/product/a2b61ff4-fe2e-489d-8812-5d3fd2062bdb/nosturis-sauna-lahti/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitfinland.com/en/product/a2b61ff4-fe2e-489d-8812-5d3fd2062bdb/nosturis-sauna-lahti/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/a2b61ff4-fe2e-489d-8812-5d3fd2062bdb/nosturis-sauna-lahti/).

**Evidence:** [Visit Finland / listed provider](https://www.visitfinland.com/en/product/a2b61ff4-fe2e-489d-8812-5d3fd2062bdb/nosturis-sauna-lahti/); [Visit Finland / Lahden Nosturi](https://www.visitfinland.com/en/product/a2b61ff4-fe2e-489d-8812-5d3fd2062bdb/nosturis-sauna-lahti/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Son Spa sauna rafts

**Location:** Son, Norway.

Floating sauna rafts offer a water-based outing near Oslo. Check whether a booking is private or shared.

**Why go:** Floating sauna rafts offer a water-based outing near Oslo. Check whether a booking is private or shared.

**Key attractions:** Sauna and swimming.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitnorway.com/listings/son-spa-sauna-rafts/217304/).

**Contact:** [Official visitor/contact route](https://www.visitnorway.com/listings/son-spa-sauna-rafts/217304/).

**Evidence:** [Visit Norway / listed provider](https://www.visitnorway.com/listings/son-spa-sauna-rafts/217304/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Elgol to Loch Coruisk boat outing

**Location:** Elgol / Isle of Skye, United Kingdom.

A mountain-and-wildlife boat trip. Keep optional walking time and the return boat in the same plan.

**Why go:** A mountain-and-wildlife boat trip. Keep optional walking time and the return boat in the same plan.

**Key attractions:** Scenic cruises.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitscotland.com/info/tours/misty-isle-boat-trips-3d7bab4f).

**Contact:** [Official visitor/contact route](https://www.visitscotland.com/info/tours/misty-isle-boat-trips-3d7bab4f).

**Evidence:** [VisitScotland / listed provider](https://www.visitscotland.com/info/tours/misty-isle-boat-trips-3d7bab4f). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Blue Bay snorkel and glass-bottom discovery

**Location:** Blue Bay, Mauritius.

Compare a reef-viewing boat with in-water snorkelling in the same marine park. This supports groups with different activity preferences.

**Why go:** Compare a reef-viewing boat with in-water snorkelling in the same marine park. This supports groups with different activity preferences.

**Key attractions:** Dry reef viewing.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://mauritiusnow.com/blog/things-to-do/blue-bay-marine-park/).

**Contact:** [Official visitor/contact route](https://mauritiusnow.com/blog/things-to-do/blue-bay-marine-park/).

**Evidence:** [Mauritius Tourism Promotion Authority](https://mauritiusnow.com/blog/things-to-do/blue-bay-marine-park/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Ile aux Benitiers lagoon boat day

**Location:** La Gaulette / Ile aux Benitiers, Mauritius.

A lagoon boat outing to an offshore island. Separate the embarkation town from the island destination.

**Why go:** A lagoon boat outing to an offshore island. Separate the embarkation town from the island destination.

**Key attractions:** Island boat outings.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://mauritiusnow.com/blog/things-to-do/ile-aux-benitiers/).

**Contact:** [Official visitor/contact route](https://mauritiusnow.com/blog/things-to-do/ile-aux-benitiers/).

**Evidence:** [Mauritius Tourism Promotion Authority](https://mauritiusnow.com/blog/things-to-do/ile-aux-benitiers/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Grand River South East waterfall paddle

**Location:** Grand River South East, Mauritius.

A river-based alternative to offshore boat trips. Water level and route suitability remain local operational checks.

**Why go:** A river-based alternative to offshore boat trips. Water level and route suitability remain local operational checks.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://mauritiusnow.com/blog/things-to-do/kayaking/).

**Contact:** [Official visitor/contact route](https://mauritiusnow.com/blog/things-to-do/kayaking/).

**Evidence:** [Mauritius Tourism Promotion Authority](https://mauritiusnow.com/blog/things-to-do/kayaking/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Plettenberg Bay dolphin and coastal wildlife

**Location:** Plettenberg Bay, South Africa.

A choice between shore observation and a boat outing. Neither requires a claim that animals will approach the visitor.

**Why go:** A choice between shore observation and a boat outing. Neither requires a claim that animals will approach the visitor.

**Key attractions:** Wildlife boats.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.southafrica.net/gl/en/travel/article/dolphin-tours-in-south-africa-thousands-of-kilometres-of-coastline-offering-the-best-dolphin-spotting-opportunities).

**Contact:** [Official visitor/contact route](https://www.southafrica.net/gl/en/travel/article/dolphin-tours-in-south-africa-thousands-of-kilometres-of-coastline-offering-the-best-dolphin-spotting-opportunities).

**Evidence:** [South African Tourism](https://www.southafrica.net/gl/en/travel/article/dolphin-tours-in-south-africa-thousands-of-kilometres-of-coastline-offering-the-best-dolphin-spotting-opportunities). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Protea Banks specialist dive

**Location:** Shelly Beach / Protea Banks, South Africa.

A specialist offshore dive setting. Ask about experience requirements, currents and whether the product uses bait before comparing it with reef dives.

**Why go:** A specialist offshore dive setting. Ask about experience requirements, currents and whether the product uses bait before comparing it with reef dives.

**Key attractions:** Scuba diving.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.southafrica.net/gl/en/travel/article/embrace-the-outdoors-hibiscus-coast-kwazulu-natal).

**Contact:** [Official visitor/contact route](https://www.southafrica.net/gl/en/travel/article/embrace-the-outdoors-hibiscus-coast-kwazulu-natal).

**Evidence:** [South African Tourism](https://www.southafrica.net/gl/en/travel/article/embrace-the-outdoors-hibiscus-coast-kwazulu-natal). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Tofo ocean safari

**Location:** Praia do Tofo, Mozambique.

A dedicated snorkelling wildlife search, distinct from a dive course. Encounters are uncertain and entry into the water depends on the outing.

**Why go:** A dedicated snorkelling wildlife search, distinct from a dive course. Encounters are uncertain and entry into the water depends on the outing.

**Key attractions:** Wildlife boats.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Published price reference:** USD 55 / adult_trip. published reference. Ocean Safari published reference. Confirm extras and current fare. Not a live or all-in quote. [Publisher](https://www.tofoscuba.com/prices).

**Tickets/access:** [Official ticket / operator information](https://www.tofoscuba.com/prices).

**Contact:** [Official visitor/contact route](https://www.tofoscuba.com/prices). Telephone: +258843733074.

**Evidence:** [Tofo Scuba](https://www.tofoscuba.com/prices); [Tofo Scuba](https://www.tofoscuba.com/faqs). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Nosy Tanikely marine-park snorkelling

**Location:** Nosy Be / Nosy Tanikely, Madagascar.

A protected-island reef outing. Do not confuse a park snorkel with a separate offshore whale-shark search.

**Why go:** A protected-island reef outing. Do not confuse a park snorkel with a separate offshore whale-shark search.

**Key attractions:** Snorkelling.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tanikely.com/en/national-marine-park/).

**Contact:** [Official visitor/contact route](https://www.tanikely.com/en/national-marine-park/).

**Evidence:** [Nosy Tanikely National Marine Park](https://www.tanikely.com/en/national-marine-park/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Pelican Point seal kayak outing

**Location:** Walvis Bay / Pelican Point, Namibia.

A combined boat, kayak and land-transfer outing. Keep the operator office, kayak launch and return transport distinct.

**Why go:** A combined boat, kayak and land-transfer outing. Keep the operator office, kayak launch and return transport distinct.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.mola-namibia.com/kayaking-experience/).

**Contact:** [Official visitor/contact route](https://www.mola-namibia.com/kayaking-experience/). Telephone: +264811272522.

**Evidence:** [Mola Mola Safaris](https://www.mola-namibia.com/kayaking-experience/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Tha Pom tidal creek and canoe discovery

**Location:** Krabi / Khao Khram, Thailand.

A creek whose water character changes with the tide. Check designated swimming areas rather than treating every clear section as open.

**Why go:** A creek whose water character changes with the tide. Check designated swimming areas rather than treating every clear section as open.

**Key attractions:** Kayaking.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Published price reference:** THB 100 / foreign_adult_admission. published reference. Foreign adult admission only; boat rental not included. Source retains older health copy, so recheck tariff. Not a live or all-in quote. [Publisher](https://thai.tourismthailand.org/Attraction/%E0%B8%97%E0%B9%88%E0%B8%B2%E0%B8%9B%E0%B8%AD%E0%B8%A1-%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%AA%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3).

**Tickets/access:** [Published fee or access information](https://thai.tourismthailand.org/Attraction/%E0%B8%97%E0%B9%88%E0%B8%B2%E0%B8%9B%E0%B8%AD%E0%B8%A1-%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%AA%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3).

**Contact:** [Official visitor/contact route](https://thai.tourismthailand.org/Attraction/%E0%B8%97%E0%B9%88%E0%B8%B2%E0%B8%9B%E0%B8%AD%E0%B8%A1-%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%AA%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3). Telephone: +6675694198.

**Evidence:** [Tourism Authority of Thailand](https://thai.tourismthailand.org/Attraction/%E0%B8%97%E0%B9%88%E0%B8%B2%E0%B8%9B%E0%B8%AD%E0%B8%A1-%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%AA%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Khlong Root freshwater kayak outing

**Location:** Krabi / Nong Thale, Thailand.

A freshwater paddle with village rental access. Useful as a different experience from offshore island boats, not an automatic storm-day substitute.

**Why go:** A freshwater paddle with village rental access. Useful as a different experience from offshore island boats, not an automatic storm-day substitute.

**Key attractions:** Kayaking.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://thai.tourismthailand.org/Attraction/%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B9%83%E0%B8%AA%E0%B9%81%E0%B8%A5%E0%B8%B0%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%AB%E0%B8%A3%E0%B8%B9%E0%B8%94).

**Contact:** [Official visitor/contact route](https://thai.tourismthailand.org/Attraction/%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B9%83%E0%B8%AA%E0%B9%81%E0%B8%A5%E0%B8%B0%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%AB%E0%B8%A3%E0%B8%B9%E0%B8%94).

**Evidence:** [Tourism Authority of Thailand](https://thai.tourismthailand.org/Attraction/%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B9%83%E0%B8%AA%E0%B9%81%E0%B8%A5%E0%B8%B0%E0%B8%84%E0%B8%A5%E0%B8%AD%E0%B8%87%E0%B8%AB%E0%B8%A3%E0%B8%B9%E0%B8%94); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Krabi Emerald Pool bathing visit

**Location:** Khlong Thom / Krabi, Thailand.

A freshwater bathing stop distinct from Trang's Emerald Cave. Keep the names separate in search and maps.

**Why go:** A freshwater bathing stop distinct from Trang's Emerald Cave. Keep the names separate in search and maps.

**Key attractions:** Swimming.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. West-coast drier beach season. Freshwater flow, cave access and each operator require separate checks. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tourismthailand.org/Attraction/sa-morakot-emerald-pool).

**Contact:** [Official visitor/contact route](https://www.tourismthailand.org/Attraction/sa-morakot-emerald-pool).

**Evidence:** [Tourism Authority of Thailand](https://www.tourismthailand.org/Attraction/sa-morakot-emerald-pool); [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lang Tengah snorkel-stay discovery

**Location:** Lang Tengah, Malaysia.

An identified Terengganu island-water destination. Confirm the specific transfer, operating season and reef activity rather than borrowing another island's schedule.

**Why go:** An identified Terengganu island-water destination. Confirm the specific transfer, operating season and reef activity rather than borrowing another island's schedule.

**Key attractions:** Snorkelling.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Contact:** [Official visitor/contact route](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Evidence:** [Tourism Malaysia](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Kapas island snorkelling

**Location:** Pulau Kapas, Malaysia.

An identified Terengganu island-water destination. Confirm the specific transfer, operating season and reef activity rather than borrowing another island's schedule.

**Why go:** An identified Terengganu island-water destination. Confirm the specific transfer, operating season and reef activity rather than borrowing another island's schedule.

**Key attractions:** Snorkelling.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Contact:** [Official visitor/contact route](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/).

**Evidence:** [Tourism Malaysia](https://ebrochures.malaysia.travel/en/islands-and-beaches/islands-of-terengganu/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Shiraho blue-coral viewing

**Location:** Ishigaki / Shiraho, Japan.

Compare guided snorkelling with high-tide glass-bottom viewing. A tide-dependent trip needs more than a month filter.

**Why go:** Compare guided snorkelling with high-tide glass-bottom viewing. A tide-dependent trip needs more than a month filter.

**Key attractions:** Dry reef viewing.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.japan.travel/en/spot/567/).

**Contact:** [Official visitor/contact route](https://www.japan.travel/en/spot/567/).

**Evidence:** [Japan National Tourism Organization](https://www.japan.travel/en/spot/567/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Minamijima guided island-water visit

**Location:** Ogasawara / Chichijima, Japan.

A protected island outing requiring a guide. Visitor limits and access rules matter more than a generic popularity ranking.

**Why go:** A protected island outing requiring a guide. Visitor limits and access rules matter more than a generic popularity ranking.

**Key attractions:** Island boat outings.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.japan.travel/en/sports/diving/travel/minamijima-ogasawara/).

**Contact:** [Official visitor/contact route](https://www.japan.travel/en/sports/diving/travel/minamijima-ogasawara/).

**Evidence:** [Japan National Tourism Organization](https://www.japan.travel/en/sports/diving/travel/minamijima-ogasawara/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Yonaguni underwater formations

**Location:** Yonaguni, Japan.

A specialist underwater-geology interest. Do not present disputed origins as established archaeology or imply beginner suitability.

**Why go:** A specialist underwater-geology interest. Do not present disputed origins as established archaeology or imply beginner suitability.

**Key attractions:** Scuba diving.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.japan.travel/en/spot/564/).

**Contact:** [Official visitor/contact route](https://www.japan.travel/en/spot/564/).

**Evidence:** [Japan National Tourism Organization](https://www.japan.travel/en/spot/564/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Seogwipo submarine reef viewing

**Location:** Jeju / Seogwipo, South Korea.

Underwater viewing without scuba participation. Confirm boarding steps, age rules and weather cancellation directly.

**Why go:** Underwater viewing without scuba participation. Confirm boarding steps, age rules and weather cancellation directly.

**Key attractions:** Submarine outings.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://english.visitkorea.or.kr/svc/whereToGo/locIntrdn/rgnContentsView.do?vcontsId=90740).

**Contact:** [Official visitor/contact route](https://english.visitkorea.or.kr/svc/whereToGo/locIntrdn/rgnContentsView.do?vcontsId=90740).

**Evidence:** [Korea Tourism Organization](https://english.visitkorea.or.kr/svc/whereToGo/locIntrdn/rgnContentsView.do?vcontsId=90740). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Soesokkak estuary paddle discovery

**Location:** Jeju / Soesokkak, South Korea.

A volcanic-estuary outing by kayak or traditional tewoo craft. Check which form is operating and book the correct product.

**Why go:** A volcanic-estuary outing by kayak or traditional tewoo craft. Check which form is operating and book the correct product.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://english.visitkorea.or.kr/svc/whereToGo/locIntrdn/rgnContentsView.do?vcontsId=94895).

**Contact:** [Official visitor/contact route](https://english.visitkorea.or.kr/svc/whereToGo/locIntrdn/rgnContentsView.do?vcontsId=94895).

**Evidence:** [Korea Tourism Organization](https://english.visitkorea.or.kr/svc/whereToGo/locIntrdn/rgnContentsView.do?vcontsId=94895). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lake Lucerne Sunday brunch cruise

**Location:** Lucerne, Switzerland.

A lake outing built around brunch rather than a point-to-point transfer.

**Why go:** A lake outing built around brunch rather than a point-to-point transfer.

**Key attractions:** Food and lake cruises.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Published price reference:** CHF 96 / adult_trip. published reference. Adult package reference; no GA or Half Fare reduction. Children have separate fare and catering components. Not a live or all-in quote. [Publisher](https://webshop.lakelucerne.ch/en/stories/brunch-cruise).

**Published price reference:** CHF 99 / adult_trip. published reference. Published future tariff, not a live quote or confirmation that the selected Sunday sails. Not a live or all-in quote. [Publisher](https://webshop.lakelucerne.ch/en/stories/brunch-cruise).

**Tickets/access:** [Official ticket / operator information](https://webshop.lakelucerne.ch/en/stories/brunch-cruise).

**Contact:** [Official visitor/contact route](https://webshop.lakelucerne.ch/en/stories/brunch-cruise).

**Evidence:** [Lake Lucerne Navigation Company](https://webshop.lakelucerne.ch/en/stories/brunch-cruise). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Maderno-Torri Lake Garda crossing

**Location:** Maderno and Torri del Benaco, Italy.

A cross-lake ferry is both transport and a short water experience.

**Why go:** A direct cross-lake perspective between Maderno and Torri. Seasonal timetables, holidays and vessel accessibility govern the actual plan.

**Key attractions:** Ferry crossings.

**Season, dated programme:** Nov, Dec, Jan, Feb, Mar. Winter crossing programme through 25 March 2027; consult timetable. [Season evidence](https://www.comune.rivadelgarda.tn.it/Novita/Notizie/L-orario-invernale-di-Navigarda).

**Published restriction:** The published winter crossing excludes Christmas Day 2026. [Source](https://www.comune.rivadelgarda.tn.it/Novita/Notizie/L-orario-invernale-di-Navigarda).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-garda/).

**Contact:** [Official visitor/contact route](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-garda/).

**Evidence:** [Navigazione Laghi](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-garda/); [Comune di Riva del Garda](https://www.comune.rivadelgarda.tn.it/Novita/Notizie/L-orario-invernale-di-Navigarda). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lake Garda scheduled sightseeing boats

**Location:** Desenzano, Peschiera and Riva del Garda, Italy.

Build a lake day around scheduled boats rather than assuming a private excursion is necessary.

**Why go:** Build a lake day around scheduled boats rather than assuming a private excursion is necessary.

**Key attractions:** Scenic cruises.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-garda/).

**Contact:** [Official visitor/contact route](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-garda/).

**Evidence:** [Navigazione Laghi](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-garda/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Intra-Laveno Lake Maggiore ferry

**Location:** Intra and Laveno, Italy.

Use a short practical crossing to see the lake from the water.

**Why go:** Use a short practical crossing to see the lake from the water.

**Key attractions:** Ferry crossings.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-maggiore/).

**Contact:** [Official visitor/contact route](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-maggiore/).

**Evidence:** [Navigazione Laghi](https://www.navigazionelaghi.it/en/tickets-and-timetables-lake-maggiore/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Swiss Three-Lakes waterway cruise

**Location:** Neuchatel, Murten and Biel, Switzerland.

A lake-and-channel journey offers a different outing from a single-lake circuit.

**Why go:** A lake-and-channel journey offers a different outing from a single-lake circuit.

**Key attractions:** Scenic cruises.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.myswitzerland.com/en-us/experiences/lake-neuchatel-cruises/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/lake-neuchatel-cruises/).

**Evidence:** [Switzerland Tourism](https://www.myswitzerland.com/en-us/experiences/lake-neuchatel-cruises/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Greifensee small-lake cruises

**Location:** Greifensee, Switzerland.

A smaller-lake alternative near Zurich includes both historic and modern vessels.

**Why go:** A smaller-lake alternative near Zurich includes both historic and modern vessels.

**Key attractions:** Scenic cruises.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.myswitzerland.com/en-ch/experiences/lake-greifen-cruises/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-ch/experiences/lake-greifen-cruises/).

**Evidence:** [Switzerland Tourism](https://www.myswitzerland.com/en-ch/experiences/lake-greifen-cruises/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lucerne-Buergenstock catamaran

**Location:** Lucerne and Kehrsiten-Buergenstock, Switzerland.

A short catamaran crossing can stand alone or connect with a hillside excursion.

**Why go:** A short catamaran crossing can stand alone or connect with a hillside excursion.

**Key attractions:** Ferry crossings.

**Season, operator pattern:** All months. The named catamaran provides the crossing throughout the year. Published journey reference is about 30 minutes each way; actual sailings remain timetable-dependent. [Season evidence](https://www.lakelucerne.ch/en/information/our-fleet/motor-vessel-buergenstock/).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.lakelucerne.ch/en/information/our-fleet/motor-vessel-buergenstock/).

**Contact:** [Official visitor/contact route](https://www.lakelucerne.ch/en/information/our-fleet/motor-vessel-buergenstock/).

**Evidence:** [Lake Lucerne Navigation Company](https://www.lakelucerne.ch/en/information/our-fleet/motor-vessel-buergenstock/); [Lake Lucerne Navigation Company](https://www.lakelucerne.ch/en/information/our-fleet/motor-vessel-buergenstock/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Attersee underwater heritage interpretation

**Location:** Attersee, Austria.

Freshwater diving can include an underwater interpretation trail, not only marine wildlife.

**Why go:** Freshwater diving can include an underwater interpretation trail, not only marine wildlife.

**Key attractions:** Scuba diving.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://b2b.austria.info/en-gb/media/story-ideas/adventures-rivers-lakes-austria/).

**Contact:** [Official visitor/contact route](https://b2b.austria.info/en-gb/media/story-ideas/adventures-rivers-lakes-austria/).

**Evidence:** [Austrian National Tourist Office](https://b2b.austria.info/en-gb/media/story-ideas/adventures-rivers-lakes-austria/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: AREA 47 water activity park

**Location:** Oetztal, Austria.

A water-based option in the Tyrolean Imst and Oetztal region; facility schedules and conditions need date-specific confirmation.

**Why go:** A water-based option in the Tyrolean Imst and Oetztal region; facility schedules and conditions need date-specific confirmation.

**Key attractions:** Water parks.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.imst.at/en/experience-water.html).

**Contact:** [Official visitor/contact route](https://www.imst.at/en/experience-water.html).

**Evidence:** [Imst tourism](https://www.imst.at/en/experience-water.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Piburger See mountain-lake swim

**Location:** Oetz, Austria.

A water-based option in the Tyrolean Imst and Oetztal region; facility schedules and conditions need date-specific confirmation.

**Why go:** A water-based option in the Tyrolean Imst and Oetztal region; facility schedules and conditions need date-specific confirmation.

**Key attractions:** Swimming.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.imst.at/en/experience-water.html).

**Contact:** [Official visitor/contact route](https://www.imst.at/en/experience-water.html).

**Evidence:** [Imst tourism](https://www.imst.at/en/experience-water.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Pont du Gard canoe viewpoint

**Location:** Gardon, France.

See a familiar heritage landscape from the river; confirm the authorised reach and current water conditions.

**Why go:** See a familiar heritage landscape from the river; confirm the authorised reach and current water conditions.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.france.fr/en/article/france-along-the-water/).

**Contact:** [Official visitor/contact route](https://www.france.fr/en/article/france-along-the-water/).

**Evidence:** [Atout France](https://www.france.fr/en/article/france-along-the-water/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Dordogne castle-view canoe journey

**Location:** Dordogne, France.

See a familiar heritage landscape from the river; confirm the authorised reach and current water conditions.

**Why go:** See a familiar heritage landscape from the river; confirm the authorised reach and current water conditions.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.france.fr/en/article/france-along-the-water/).

**Contact:** [Official visitor/contact route](https://www.france.fr/en/article/france-along-the-water/).

**Evidence:** [Atout France](https://www.france.fr/en/article/france-along-the-water/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Chenonceau from the water

**Location:** Cher, France.

See a familiar heritage landscape from the river; confirm the authorised reach and current water conditions.

**Why go:** See a familiar heritage landscape from the river; confirm the authorised reach and current water conditions.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.france.fr/en/article/france-along-the-water/).

**Contact:** [Official visitor/contact route](https://www.france.fr/en/article/france-along-the-water/).

**Evidence:** [Atout France](https://www.france.fr/en/article/france-along-the-water/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Alsace flat-bottomed river outing

**Location:** Ill, Alsace, France.

See a familiar heritage landscape from the river; confirm the authorised reach and current water conditions.

**Why go:** See a familiar heritage landscape from the river; confirm the authorised reach and current water conditions.

**Key attractions:** Scenic cruises.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.france.fr/en/article/france-along-the-water/).

**Contact:** [Official visitor/contact route](https://www.france.fr/en/article/france-along-the-water/).

**Evidence:** [Atout France](https://www.france.fr/en/article/france-along-the-water/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Canal du Midi paddle outing

**Location:** Canal du Midi, France.

A canal outing combines paddling with waterway heritage.

**Why go:** A canal outing combines paddling with waterway heritage.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.canal-du-midi.com/en/frequently-asked-questions/).

**Contact:** [Official visitor/contact route](https://www.canal-du-midi.com/en/frequently-asked-questions/).

**Evidence:** [Canal du Midi official destination](https://www.canal-du-midi.com/en/frequently-asked-questions/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Fourques-sur-Garonne small-boat rental

**Location:** Fourques-sur-Garonne, France.

Self-steered small boats offer a water outing without joining a cruise.

**Why go:** Self-steered small boats offer a water outing without joining a cruise.

**Key attractions:** Boat rental.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.valdegaronne-tourisme.com/en/activities/emerald-rental/).

**Contact:** [Official visitor/contact route](https://www.valdegaronne-tourisme.com/en/activities/emerald-rental/).

**Evidence:** [Val de Garonne Tourism](https://www.valdegaronne-tourisme.com/en/activities/emerald-rental/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Estany des Peix lagoon paddling

**Location:** Formentera, Spain.

A lagoon-based alternative to an exposed coastal outing.

**Why go:** A lagoon-based alternative to an exposed coastal outing.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.formentera.es/en/explore/activities/water-sports/).

**Contact:** [Official visitor/contact route](https://www.formentera.es/en/explore/activities/water-sports/).

**Evidence:** [Formentera Tourism](https://www.formentera.es/en/explore/activities/water-sports/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Cala Saona coastal kayaking

**Location:** Formentera, Spain.

Explore the coastal setting by paddle rather than a general island bus tour.

**Why go:** Explore the coastal setting by paddle rather than a general island bus tour.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.formentera.es/en/explore/activities/water-sports/).

**Contact:** [Official visitor/contact route](https://www.formentera.es/en/explore/activities/water-sports/).

**Evidence:** [Formentera Tourism](https://www.formentera.es/en/explore/activities/water-sports/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Tabarca island diving

**Location:** Tabarca, Spain.

An island reef outing near the Costa Blanca, subject to local access and operator requirements.

**Why go:** An island reef outing near the Costa Blanca, subject to local access and operator requirements.

**Key attractions:** Scuba diving.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.comunitatvalenciana.com/en/be-inspired/water-activities-costa-blanca).

**Contact:** [Official visitor/contact route](https://www.comunitatvalenciana.com/en/be-inspired/water-activities-costa-blanca).

**Evidence:** [Valencian Community tourism](https://www.comunitatvalenciana.com/en/be-inspired/water-activities-costa-blanca). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Altea coastal paddling

**Location:** Altea, Spain.

A coastal paddle adds a different way to explore Altea.

**Why go:** A coastal paddle adds a different way to explore Altea.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.comunitatvalenciana.com/en/be-inspired/water-activities-costa-blanca).

**Contact:** [Official visitor/contact route](https://www.comunitatvalenciana.com/en/be-inspired/water-activities-costa-blanca).

**Evidence:** [Valencian Community tourism](https://www.comunitatvalenciana.com/en/be-inspired/water-activities-costa-blanca). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Albufeira cave and coastal boat trips

**Location:** Albufeira, Portugal.

Compare coastal boat tours separately from dolphin-focused trips; destinations vary by sea state.

**Why go:** Compare coastal boat tours separately from dolphin-focused trips; destinations vary by sea state.

**Key attractions:** Scenic cruises.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitalbufeira.pt/experiencias/experiencias-no-mar/en/).

**Contact:** [Official visitor/contact route](https://visitalbufeira.pt/experiencias/experiencias-no-mar/en/).

**Evidence:** [Albufeira Tourism](https://visitalbufeira.pt/experiencias/experiencias-no-mar/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Albufeira powered-water rental discovery

**Location:** Albufeira, Portugal.

An officially described activity category with provider, licence and tariff details still to collect.

**Why go:** An officially described activity category with provider, licence and tariff details still to collect.

**Key attractions:** Jet-ski outings.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Operator verification and access controls are unresolved, so this is held from highlights.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitalbufeira.pt/experiencias/experiencias-no-mar/en/).

**Contact:** [Official visitor/contact route](https://visitalbufeira.pt/experiencias/experiencias-no-mar/en/).

**Evidence:** [Albufeira Tourism](https://visitalbufeira.pt/experiencias/experiencias-no-mar/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Terceira coastal paddling

**Location:** Terceira, Portugal.

Use a paddle-based island outing as an alternative to offshore wildlife watching.

**Why go:** Use a paddle-based island outing as an alternative to offshore wildlife watching.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.exploreterceiraisland.com/en/experiencias/kayaking/).

**Contact:** [Official visitor/contact route](https://www.exploreterceiraisland.com/en/experiencias/kayaking/).

**Evidence:** [Explore Terceira](https://www.exploreterceiraisland.com/en/experiencias/kayaking/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lake Bled pletna boat outing

**Location:** Lake Bled, Slovenia.

A rowed traditional boat reaches the island without a motorised lake cruise.

**Why go:** A rowed traditional boat reaches the island without a motorised lake cruise.

**Key attractions:** Scenic cruises.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Confirm the actual route, seasonal programme, vessel and departure.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.slovenia.info/en/stories/let-s-take-a-trip-on-water).

**Contact:** [Official visitor/contact route](https://www.slovenia.info/en/stories/let-s-take-a-trip-on-water).

**Evidence:** [Slovenian Tourist Board](https://www.slovenia.info/en/stories/let-s-take-a-trip-on-water). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Kolpa river paddling

**Location:** Kolpa River, Slovenia.

A river-based day can combine paddling and time by the water, with local access checks.

**Why go:** A river-based day can combine paddling and time by the water, with local access checks.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.slovenia.info/en/stories/let-s-take-a-trip-on-water).

**Contact:** [Official visitor/contact route](https://www.slovenia.info/en/stories/let-s-take-a-trip-on-water).

**Evidence:** [Slovenian Tourist Board](https://www.slovenia.info/en/stories/let-s-take-a-trip-on-water). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Dugi Otok kayak and snorkel outing

**Location:** Dugi Otok, Croatia.

Combine coastal paddling with an optional shipwreck snorkel rather than a dive-only trip.

**Why go:** Combine coastal paddling with an optional shipwreck snorkel rather than a dive-only trip.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.zadar.hr/en/experience/explore/top-island-ideas-dugi-otok).

**Contact:** [Official visitor/contact route](https://www.zadar.hr/en/experience/explore/top-island-ideas-dugi-otok).

**Evidence:** [Zadar Region Tourist Board](https://www.zadar.hr/en/experience/explore/top-island-ideas-dugi-otok). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Nin Zdrijac kitesurf discovery

**Location:** Nin, Croatia.

A wind-driven water activity, distinct from calm-water swimming or SUP.

**Why go:** A wind-driven water activity, distinct from calm-water swimming or SUP.

**Key attractions:** Wind sports.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.zadar.hr/en/experience/nature-adventure/water-sports-on-sea).

**Contact:** [Official visitor/contact route](https://www.zadar.hr/en/experience/nature-adventure/water-sports-on-sea).

**Evidence:** [Zadar Region Tourist Board](https://www.zadar.hr/en/experience/nature-adventure/water-sports-on-sea). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Greek underwater archaeology and dry interpretation

**Location:** Greek accessible underwater archaeological sites, Greece.

Pair an authorised underwater heritage visit with dry interpretation for a mixed diving and non-diving group.

**Why go:** Pair an authorised underwater heritage visit with dry interpretation for a mixed diving and non-diving group.

**Key attractions:** Underwater heritage.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://euaculture.gr/en/).

**Contact:** [Official visitor/contact route](https://euaculture.gr/en/).

**Evidence:** [Greek Ephorate of Underwater Antiquities](https://euaculture.gr/en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Zakynthos Blue Caves kayak discovery

**Location:** Zakynthos, Greece.

A water-based discovery described by the destination organisation, requiring local operator and date confirmation.

**Why go:** A water-based discovery described by the destination organisation, requiring local operator and date confirmation.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.discovergreece.com/outdoor-activities-greece).

**Contact:** [Official visitor/contact route](https://www.discovergreece.com/outdoor-activities-greece).

**Evidence:** [Marketing Greece](https://www.discovergreece.com/outdoor-activities-greece). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Voidomatis river rafting

**Location:** Epirus, Greece.

A water-based discovery described by the destination organisation, requiring local operator and date confirmation.

**Why go:** A water-based discovery described by the destination organisation, requiring local operator and date confirmation.

**Key attractions:** Rafting.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.discovergreece.com/outdoor-activities-greece).

**Contact:** [Official visitor/contact route](https://www.discovergreece.com/outdoor-activities-greece).

**Evidence:** [Marketing Greece](https://www.discovergreece.com/outdoor-activities-greece). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Paros wind-sport discovery

**Location:** Paros, Greece.

A water-based discovery described by the destination organisation, requiring local operator and date confirmation.

**Why go:** A water-based discovery described by the destination organisation, requiring local operator and date confirmation.

**Key attractions:** Wind sports.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.discovergreece.com/outdoor-activities-greece).

**Contact:** [Official visitor/contact route](https://www.discovergreece.com/outdoor-activities-greece).

**Evidence:** [Marketing Greece](https://www.discovergreece.com/outdoor-activities-greece). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Pacuare river rafting

**Location:** Pacuare River, Costa Rica.

A distinct water-based activity identified by the national tourism board; local conditions and access vary.

**Why go:** A distinct water-based activity identified by the national tourism board; local conditions and access vary.

**Key attractions:** Rafting.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitcostarica.com/planning-your-trip/climate).

**Contact:** [Official visitor/contact route](https://www.visitcostarica.com/planning-your-trip/climate).

**Evidence:** [Costa Rican Tourism Board](https://www.visitcostarica.com/planning-your-trip/climate). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Gulf of Papagayo mangrove paddling

**Location:** Gulf of Papagayo, Costa Rica.

A distinct water-based activity identified by the national tourism board; local conditions and access vary.

**Why go:** A distinct water-based activity identified by the national tourism board; local conditions and access vary.

**Key attractions:** Kayaking.

**Season, regional conditions:** Dec, Jan, Feb, Mar, Apr. Pacific dry-season context; not the Caribbean coast or a river-flow assessment. [Season evidence](https://www.visitcostarica.com/planning-your-trip/climate).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitcostarica.com/planning-your-trip/climate).

**Contact:** [Official visitor/contact route](https://www.visitcostarica.com/planning-your-trip/climate).

**Evidence:** [Costa Rican Tourism Board](https://www.visitcostarica.com/planning-your-trip/climate); [Costa Rica Tourism Institute](https://www.visitcostarica.com/planning-your-trip/climate). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Punta Uva snorkel discovery

**Location:** Punta Uva, Costa Rica.

A distinct water-based activity identified by the national tourism board; local conditions and access vary.

**Why go:** A distinct water-based activity identified by the national tourism board; local conditions and access vary.

**Key attractions:** Snorkelling.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitcostarica.com/planning-your-trip/climate).

**Contact:** [Official visitor/contact route](https://www.visitcostarica.com/planning-your-trip/climate).

**Evidence:** [Costa Rican Tourism Board](https://www.visitcostarica.com/planning-your-trip/climate). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Puntarenas-Paquera Gulf of Nicoya crossing

**Location:** Gulf of Nicoya, Costa Rica.

A public crossing offers island views without requiring a dedicated tour.

**Why go:** A public crossing offers island views without requiring a dedicated tour.

**Key attractions:** Ferry crossings.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitcostarica.com/things-to-do/adventure).

**Contact:** [Official visitor/contact route](https://www.visitcostarica.com/things-to-do/adventure).

**Evidence:** [Costa Rican Tourism Board](https://www.visitcostarica.com/things-to-do/adventure). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Tortuguero waterways and turtle-season planning

**Location:** Tortuguero, Costa Rica.

Connect a waterways trip with a separately controlled turtle-observation visit.

**Why go:** Connect a waterways trip with a separately controlled turtle-observation visit.

**Key attractions:** Marine wildlife.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitcostarica.com/things-to-do/sustainable-tourism).

**Contact:** [Official visitor/contact route](https://www.visitcostarica.com/things-to-do/sustainable-tourism).

**Evidence:** [Costa Rican Tourism Board](https://www.visitcostarica.com/things-to-do/sustainable-tourism). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Boquete river-rafting discovery

**Location:** Boquete, Panama.

A mountain-river outing adds an inland water option to a Panama coast trip.

**Why go:** A mountain-river outing adds an inland water option to a Panama coast trip.

**Key attractions:** Rafting.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tourismpanama.com/outdoors-and-nature/outdoor-adventure/).

**Contact:** [Official visitor/contact route](https://www.tourismpanama.com/outdoors-and-nature/outdoor-adventure/).

**Evidence:** [PROMTUR Panama](https://www.tourismpanama.com/outdoors-and-nature/outdoor-adventure/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Malpelo specialist expedition diving

**Location:** Malpelo Sanctuary, Colombia.

A remote protected-area dive expedition, not a casual beach or beginner snorkel outing.

**Why go:** A remote protected-area dive expedition, not a casual beach or beginner snorkel outing.

**Key attractions:** Scuba diving.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.parquesnacionales.gov.co/nuestros-parques/sff-malpelo/).

**Contact:** [Official visitor/contact route](https://www.parquesnacionales.gov.co/nuestros-parques/sff-malpelo/).

**Evidence:** [Colombia National Natural Parks](https://www.parquesnacionales.gov.co/nuestros-parques/sff-malpelo/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Navua river tubing and village outing

**Location:** Pacific Harbour and Navua, Fiji.

A guided float-based river outing combines upstream transport and a downstream tube section.

**Why go:** A guided float-based river outing combines upstream transport and a downstream tube section.

**Key attractions:** River tubing.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fiji.travel/things-to-do/thrilling/unforgettable-river-adventures-in-fiji).

**Contact:** [Official visitor/contact route](https://www.fiji.travel/things-to-do/thrilling/unforgettable-river-adventures-in-fiji).

**Evidence:** [Tourism Fiji](https://www.fiji.travel/things-to-do/thrilling/unforgettable-river-adventures-in-fiji). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Upper Navua conservation-area rafting

**Location:** Upper Navua River, Fiji.

A guided canyon-and-river outing distinct from the coastal resort programme.

**Why go:** A guided canyon-and-river outing distinct from the coastal resort programme.

**Key attractions:** Rafting.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fiji.travel/things-to-do/thrilling/unforgettable-river-adventures-in-fiji).

**Contact:** [Official visitor/contact route](https://www.fiji.travel/things-to-do/thrilling/unforgettable-river-adventures-in-fiji).

**Evidence:** [Tourism Fiji](https://www.fiji.travel/things-to-do/thrilling/unforgettable-river-adventures-in-fiji). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Frigates Passage surf-boat discovery

**Location:** Beqa Lagoon outer reef, Fiji.

A boat-access surf experience with distinct ability and sea-state requirements.

**Why go:** A boat-access surf experience with distinct ability and sea-state requirements.

**Key attractions:** Ocean surfing.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.fiji.travel/places-to-go/pacific-harbour/locations/adventures-in-pacific-harbour).

**Contact:** [Official visitor/contact route](https://www.fiji.travel/places-to-go/pacific-harbour/locations/adventures-in-pacific-harbour).

**Evidence:** [Tourism Fiji](https://www.fiji.travel/places-to-go/pacific-harbour/locations/adventures-in-pacific-harbour). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Aganoa black-sand beach and boat approach

**Location:** Upolu, Samoa.

A swimming-led discovery with an unusually important road-versus-boat access decision.

**Why go:** A swimming-led discovery with an unusually important road-versus-boat access decision.

**Key attractions:** Swimming.

**Season, regional conditions:** May, Jun, Jul, Aug, Sep, Oct. Drier Samoan seasonal context; currents and local access need checking. [Season evidence](https://www.samoa.travel/samoa-travel-advice/climate-weather/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.samoa.travel/plan-book/activities/aganoa-black-sand-beach/).

**Contact:** [Official visitor/contact route](https://www.samoa.travel/plan-book/activities/aganoa-black-sand-beach/).

**Evidence:** [Samoa Tourism Authority](https://www.samoa.travel/plan-book/activities/aganoa-black-sand-beach/); [Samoa Tourism Authority](https://www.samoa.travel/samoa-travel-advice/climate-weather/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Niue tide-led west-coast snorkelling

**Location:** Niue west coast, Niue.

A year-round destination where tide windows and local spawning closures matter more than a generic month score.

**Why go:** A year-round destination where tide windows and local spawning closures matter more than a generic month score.

**Key attractions:** Snorkelling.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Published restriction:** Some sea tracks close for goatfish spawning. The dates and exact tracks were not established; consult local signage and the visitor centre. [Source](https://www.niueisland.com/discover-niue/blog/post/best-snorkelling-holidays-in-the-south-pacific).

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.niueisland.com/discover-niue/blog/post/best-snorkelling-holidays-in-the-south-pacific).

**Contact:** [Official visitor/contact route](https://www.niueisland.com/discover-niue/blog/post/best-snorkelling-holidays-in-the-south-pacific).

**Evidence:** [Niue Tourism](https://www.niueisland.com/discover-niue/blog/post/best-snorkelling-holidays-in-the-south-pacific). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Turtle Bay blue-hole kayak hire

**Location:** Espiritu Santo, Vanuatu.

Paddle to a freshwater swimming destination using a clearly separated equipment-hire price.

**Why go:** Paddle to a freshwater swimming destination using a clearly separated equipment-hire price.

**Key attractions:** Kayak rental.

**Season, regional conditions:** Apr, May, Jun, Jul, Aug, Sep. April-September is the cooler seasonal context. December-April is wetter with cyclone exposure; river levels and access need separate checks. [Season evidence](https://www.vanuatu.travel/en/things-to-know/travel-tips/weather).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Published price reference:** VUV 1500 / single_kayak_hire. published reference. Single kayak hire reference. Hire duration, blue-hole admission and other extras need confirmation. Not a live or all-in quote. [Publisher](https://www.turtlebaylodge.vu/kayaks-and-stand-up-paddleboards/).

**Tickets/access:** [Official ticket / operator information](https://www.turtlebaylodge.vu/kayaks-and-stand-up-paddleboards/).

**Contact:** [Official visitor/contact route](https://www.turtlebaylodge.vu/kayaks-and-stand-up-paddleboards/).

**Evidence:** [Turtle Bay Lodge](https://www.turtlebaylodge.vu/kayaks-and-stand-up-paddleboards/); [Vanuatu Tourism Office](https://www.vanuatu.travel/en/things-to-know/travel-tips/weather). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Abu Dhabi mangrove kayak discovery

**Location:** Mangrove National Park, United Arab Emirates.

A protected urban-coast habitat provides a paddle alternative to a beach day.

**Why go:** A protected urban-coast habitat provides a paddle alternative to a beach day.

**Key attractions:** Kayaking.

**Season, regional conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr. October-April is the cooler outdoor kayaking context. Tide, guide availability, heat and individual ability still need checking. [Season evidence](https://visitabudhabi.ae/things-to-do/water-activities/kayaking).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.ead.gov.ae/en/experience-green-abu-dhabi/places-to-go/mangrove-national-park).

**Contact:** [Official visitor/contact route](https://www.ead.gov.ae/en/experience-green-abu-dhabi/places-to-go/mangrove-national-park).

**Evidence:** [Environment Agency Abu Dhabi](https://www.ead.gov.ae/en/experience-green-abu-dhabi/places-to-go/mangrove-national-park); [Visit Abu Dhabi](https://visitabudhabi.ae/things-to-do/water-activities/kayaking). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Purple Island mangrove paddling

**Location:** Al Khor, Qatar.

Plan a tide-sensitive mangrove outing rather than treating the island as an all-tide kayak circuit.

**Why go:** Plan a tide-sensitive mangrove outing rather than treating the island as an all-tide kayak circuit.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitqatar.com/intl-en/things-to-do/beach-holiday/purple).

**Contact:** [Official visitor/contact route](https://visitqatar.com/intl-en/things-to-do/beach-holiday/purple).

**Evidence:** [Qatar Tourism](https://visitqatar.com/intl-en/things-to-do/beach-holiday/purple). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Yanbu Red Sea reef diving

**Location:** Yanbu, Saudi Arabia.

A Red Sea dive destination outside the already-covered Egyptian coast.

**Why go:** A Red Sea dive destination outside the already-covered Egyptian coast.

**Key attractions:** Scuba diving.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Qualification, currents, permits, operator and medical requirements need separate confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitsaudi.com/en/see-do/destinations/yanbu).

**Contact:** [Official visitor/contact route](https://www.visitsaudi.com/en/see-do/destinations/yanbu).

**Evidence:** [Saudi Tourism Authority](https://www.visitsaudi.com/en/see-do/destinations/yanbu). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lake Kivu coastal kayaking

**Location:** Lake Kivu, Rwanda.

An inland African water journey combining a lake coast and mountain landscape.

**Why go:** An inland African water journey combining a lake coast and mountain landscape.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://visitrwanda.com/interests/kayaking/).

**Contact:** [Official visitor/contact route](https://visitrwanda.com/interests/kayaking/).

**Evidence:** [Rwanda Development Board / Visit Rwanda](https://visitrwanda.com/interests/kayaking/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lake Malawi lakeshore kayak discovery

**Location:** Lake Malawi, Malawi.

A lake-paddling journey whose route and shore access depend on the selected lodge or operator.

**Why go:** A lake-paddling journey whose route and shore access depend on the selected lodge or operator.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.malawitourism.com/experiences/lake/kayaking-sailing/).

**Contact:** [Official visitor/contact route](https://www.malawitourism.com/experiences/lake/kayaking-sailing/).

**Evidence:** [Malawi Tourism](https://www.malawitourism.com/experiences/lake/kayaking-sailing/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Upper Zambezi guided canoe safari

**Location:** Upper Zambezi, Zambia.

A guided wildlife river journey above the falls, distinct from whitewater rafting below them.

**Why go:** A guided wildlife river journey above the falls, distinct from whitewater rafting below them.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.zambiatourism.com/safaris/canoeing-safaris/).

**Contact:** [Official visitor/contact route](https://www.zambiatourism.com/safaris/canoeing-safaris/).

**Evidence:** [Zambia Tourism](https://www.zambiatourism.com/safaris/canoeing-safaris/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lower Zambezi guided canoe safari

**Location:** Lower Zambezi, Zambia.

A protected-landscape canoe journey where wildlife viewing is part of the trip.

**Why go:** A protected-landscape canoe journey where wildlife viewing is part of the trip.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.zambiatourism.com/safaris/canoeing-safaris/).

**Contact:** [Official visitor/contact route](https://www.zambiatourism.com/safaris/canoeing-safaris/).

**Evidence:** [Zambia Tourism](https://www.zambiatourism.com/safaris/canoeing-safaris/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Trang An self-paddle discovery

**Location:** Trang An, Ninh Binh, Viet Nam.

An alternative to being rowed through the karst waterways, with current service confirmation still needed.

**Why go:** An alternative to being rowed through the karst waterways, with current service confirmation still needed.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://sodulich.ninhbinh.gov.vn/en/news-events/kayaking-service-rolls-out-new-way-to-discover-trang-an-complex-352.html).

**Contact:** [Official visitor/contact route](https://sodulich.ninhbinh.gov.vn/en/news-events/kayaking-service-rolls-out-new-way-to-discover-trang-an-complex-352.html).

**Evidence:** [Ninh Binh Department of Tourism](https://sodulich.ninhbinh.gov.vn/en/news-events/kayaking-service-rolls-out-new-way-to-discover-trang-an-complex-352.html). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Vang Vieng guided river-tubing discovery

**Location:** Vang Vieng, Lao People's Democratic Republic.

A river float must be planned around water level and local operating standards, not party-tour promotion.

**Why go:** A river float must be planned around water level and local operating standards, not party-tour promotion.

**Key attractions:** River tubing.

**Season, regional conditions:** Nov, Dec, Jan, Feb. November-February is the broad cooler visiting context. This is not a river-flow, pollution or operator calendar assessment. [Season evidence](https://www.tourismlaos.org/2025/12/31/laos-ranks-among-worlds-most-budget-friendly-destinations-for-2026/).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.tourismlaos.org/welcome/active/).

**Contact:** [Official visitor/contact route](https://www.tourismlaos.org/welcome/active/).

**Evidence:** [Laos Tourism](https://www.tourismlaos.org/welcome/active/); [Tourism Laos](https://www.tourismlaos.org/2025/12/31/laos-ranks-among-worlds-most-budget-friendly-destinations-for-2026/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Luang Prabang river kayaking

**Location:** Luang Prabang, Lao People's Democratic Republic.

Combine river scenery with a locally selected route; the same river changes character with the season.

**Why go:** Combine river scenery with a locally selected route; the same river changes character with the season.

**Key attractions:** Kayaking.

**Season, regional conditions:** Nov, Dec, Jan, Feb. November-February is the broad cooler visiting context. This is not a river-flow, pollution or operator calendar assessment. [Season evidence](https://www.tourismlaos.org/2025/12/31/laos-ranks-among-worlds-most-budget-friendly-destinations-for-2026/).

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://tourismluangprabang.org/things-to-do/activities/kayaking/).

**Contact:** [Official visitor/contact route](https://tourismluangprabang.org/things-to-do/activities/kayaking/).

**Evidence:** [Luang Prabang official tourism](https://tourismluangprabang.org/things-to-do/activities/kayaking/); [Tourism Laos](https://www.tourismlaos.org/2025/12/31/laos-ranks-among-worlds-most-budget-friendly-destinations-for-2026/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Xiuguluan River rafting

**Location:** Hualien County, Taiwan.

A river adventure provides a separate option from Taiwan offshore wildlife trips.

**Why go:** A river adventure provides a separate option from Taiwan offshore wildlife trips.

**Key attractions:** Rafting.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.eastcoast-nsa.gov.tw/en/travel/waters/boating/).

**Contact:** [Official visitor/contact route](https://www.eastcoast-nsa.gov.tw/en/travel/waters/boating/).

**Evidence:** [Taiwan East Coast National Scenic Area](https://www.eastcoast-nsa.gov.tw/en/travel/waters/boating/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Radhanagar Beach swimming discovery

**Location:** Swaraj Dweep / Havelock Island, India.

A beach-led discovery retains swimming as the main task within the wider experience catalogue.

**Why go:** A beach-led discovery retains swimming as the main task within the wider experience catalogue.

**Key attractions:** Swimming.

**Season, regional conditions:** Oct, Nov, Dec, Jan, Feb, Mar, Apr, May. October-May is the published beach/water-visit context. Current closures, currents and operator requirements remain separate. [Season evidence](https://tourism.andamannicobar.gov.in/experience_details.php?data=_qQxZPPpNZ98QHcAD-XpCpO2Rk7UZWUM8qqcE-td9OFlGx4IGJQc-CaD).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://southandaman.nic.in/tourism/).

**Contact:** [Official visitor/contact route](https://southandaman.nic.in/tourism/).

**Evidence:** [South Andaman district administration](https://southandaman.nic.in/tourism/); [Andaman and Nicobar Tourism](https://tourism.andamannicobar.gov.in/experience_details.php?data=_qQxZPPpNZ98QHcAD-XpCpO2Rk7UZWUM8qqcE-td9OFlGx4IGJQc-CaD). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Islands Brygge harbour bath

**Location:** Copenhagen, Denmark.

A city swimming destination where designated access and current bathing status matter.

**Why go:** A city swimming destination where designated access and current bathing status matter.

**Key attractions:** Swimming.

**Season, supervision window:** Jun, Jul, Aug. Named lifeguard window June 1-August 31. The page has inconsistent all-year versus May-March opening labels, so do not derive a guaranteed annual schedule. [Season evidence](https://www.visitdenmark.com/denmark/plan-your-trip/islands-brygge-harbour-bath-gdk482346).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitdenmark.com/denmark/things-to-do/outdoor-nature/harbour-baths).

**Contact:** [Official visitor/contact route](https://www.visitdenmark.com/denmark/things-to-do/outdoor-nature/harbour-baths).

**Evidence:** [VisitDenmark](https://www.visitdenmark.com/denmark/things-to-do/outdoor-nature/harbour-baths); [Visit Denmark / Wonderful Copenhagen](https://www.visitdenmark.com/denmark/plan-your-trip/islands-brygge-harbour-bath-gdk482346). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Sonderborg harbour swimming and sauna

**Location:** Sonderborg, Denmark.

A harbour bath combines outdoor swimming with a separate cold-season sauna option.

**Why go:** A harbour bath combines outdoor swimming with a separate cold-season sauna option.

**Key attractions:** Swimming.

**Season, regional conditions:** Jun, Jul, Aug, Sep. June-September is the broad harbour-bath summer context. Lifeguard dates and daily water-quality closures vary by site. [Season evidence](https://www.visitdenmark.com/denmark/things-to-do/outdoor-nature/harbour-baths).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitdenmark.com/denmark/things-to-do/outdoor-nature/harbour-baths).

**Contact:** [Official visitor/contact route](https://www.visitdenmark.com/denmark/things-to-do/outdoor-nature/harbour-baths).

**Evidence:** [VisitDenmark](https://www.visitdenmark.com/denmark/things-to-do/outdoor-nature/harbour-baths); [Visit Denmark](https://www.visitdenmark.com/denmark/things-to-do/outdoor-nature/harbour-baths). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Copenhagen GreenKayak clean-up paddle

**Location:** Copenhagen, Denmark.

A participatory water outing exchanges a clean-up contribution for kayak use.

**Why go:** The outing includes an active clean-up purpose rather than equipment hire alone. The zero-price offer has participation conditions, not unlimited free rental.

**Key attractions:** Clean-up paddling.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Published price reference:** DKK 0 / conditional_kayak_session. conditional free. No monetary charge under the waste-collection and sharing conditions. This is not the price of a guided group tour. Not a live or all-in quote. [Publisher](https://www.greenkayak.org/faq/).

**Tickets/access:** [Official ticket / operator information](https://www.greenkayak.org/faq/).

**Contact:** [Official visitor/contact route](https://www.greenkayak.org/faq/).

**Evidence:** [GreenKayak](https://www.greenkayak.org/faq/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Soomaa Holiday Village canoe rental

**Location:** Soomaa, Estonia.

Separate an equipment rental from the guided flood-season product and its group minimum.

**Why go:** Separate an equipment rental from the guided flood-season product and its group minimum.

**Key attractions:** Kayak rental.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Published price reference:** EUR 40 / canoe_hire. published reference. 40 EUR rental reference; hire period and transport scope need confirmation. Not a live or all-in quote. [Publisher](https://soomaa.com/canoe-rental/).

**Tickets/access:** [Official ticket / operator information](https://soomaa.com/canoe-rental/).

**Contact:** [Official visitor/contact route](https://soomaa.com/canoe-rental/).

**Evidence:** [Soomaa.com](https://soomaa.com/canoe-rental/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Biesbosch freshwater-tide paddling

**Location:** Biesbosch, Netherlands.

A wetland paddle where freshwater does not mean tides can be ignored.

**Why go:** A wetland paddle where freshwater does not mean tides can be ignored.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.beleefdebiesbosch.com/see-do/to-sail).

**Contact:** [Official visitor/contact route](https://www.beleefdebiesbosch.com/see-do/to-sail).

**Evidence:** [Biesbosch destination organisation](https://www.beleefdebiesbosch.com/see-do/to-sail). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Biesbosch quiet electric-boat outing

**Location:** Biesbosch, Netherlands.

A low-effort water alternative to a paddle trip through the wetland.

**Why go:** A low-effort water alternative to a paddle trip through the wetland.

**Key attractions:** Boat rental.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.beleefdebiesbosch.com/see-do/to-sail).

**Contact:** [Official visitor/contact route](https://www.beleefdebiesbosch.com/see-do/to-sail).

**Evidence:** [Biesbosch destination organisation](https://www.beleefdebiesbosch.com/see-do/to-sail). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Rotterdam-Dordrecht and Kinderdijk Waterbus

**Location:** Rotterdam region, Netherlands.

Public water transport can form a water-based heritage outing.

**Why go:** Public water transport can form a water-based heritage outing.

**Key attractions:** Ferry crossings.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.rotterdam.info/en/visit/finder-locations/waterbus).

**Contact:** [Official visitor/contact route](https://www.rotterdam.info/en/visit/finder-locations/waterbus).

**Evidence:** [Rotterdam Tourism](https://www.rotterdam.info/en/visit/finder-locations/waterbus). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Brussels-Vilvoorde canal Waterbus

**Location:** Brussels and Vilvoorde, Belgium.

A short canal transport outing is different from a dedicated sightseeing cruise.

**Why go:** A short canal transport outing is different from a dedicated sightseeing cruise.

**Key attractions:** Ferry crossings.

**Season, dated programme:** May, Jun, Jul, Aug, Sep, Oct. Published 2026 programme May 1-October 31 with limited weekdays outside summer; extra KANAL sailings November 25-29. Wheelchairs currently cannot be carried. Advance booking required. Published date window: {"start": "2026-05-01", "end": "2026-10-31"}. [Season evidence](https://www.waterbus.eu/en).

**Season, dated programme:** Nov. Extra KANAL service November 25-29, 2026. Modified timetable and booking apply. Published date window: {"start": "2026-11-25", "end": "2026-11-29"}. [Season evidence](https://www.waterbus.eu/en).

**Plan around:** Use the current timetable and actual vessel; this is not a guaranteed connection.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.waterbus.eu/EN/).

**Contact:** [Official visitor/contact route](https://www.waterbus.eu/EN/). Telephone: +3222185460.

**Evidence:** [Rivertours Waterbus](https://www.waterbus.eu/EN/); [Waterbus Brussels](https://www.waterbus.eu/en). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Rio Sucuri freshwater float

**Location:** Bonito, Brazil.

A flowing freshwater snorkel is a distinct experience from a beach or reef outing.

**Why go:** A flowing freshwater snorkel is a distinct experience from a beach or reef outing.

**Key attractions:** Snorkelling.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.visitbrasil.com/en/location/bonito-en/).

**Contact:** [Official visitor/contact route](https://www.visitbrasil.com/en/location/bonito-en/).

**Evidence:** [Embratur / Visit Brasil](https://www.visitbrasil.com/en/location/bonito-en/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Olho dAgua and Prata river float

**Location:** Jardim and Bonito region, Brazil.

Follow a guided river float with supplied equipment rather than free-swimming an unknown river.

**Why go:** Follow a guided river float with supplied equipment rather than free-swimming an unknown river.

**Key attractions:** Snorkelling.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Swimming ability, currents, access and equipment are not established by a seasonal score.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://feel.visitbrasil.com/en/flutuacao-no-rio-da-prata-2/).

**Contact:** [Official visitor/contact route](https://feel.visitbrasil.com/en/flutuacao-no-rio-da-prata-2/).

**Evidence:** [Embratur / Visit Brasil](https://feel.visitbrasil.com/en/flutuacao-no-rio-da-prata-2/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Maipo river rafting discovery

**Location:** Maipo Valley, Chile.

A distinct Chilean whitewater destination; route grade and operating conditions need specialist confirmation.

**Why go:** A distinct Chilean whitewater destination; route grade and operating conditions need specialist confirmation.

**Key attractions:** Rafting.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://chile.travel/en/activities/adventure-and-sports/river-experiences/).

**Contact:** [Official visitor/contact route](https://chile.travel/en/activities/adventure-and-sports/river-experiences/).

**Evidence:** [SERNATUR / Chile Travel](https://chile.travel/en/activities/adventure-and-sports/river-experiences/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Trancura river rafting discovery

**Location:** Pucon, Chile.

A distinct Chilean whitewater destination; route grade and operating conditions need specialist confirmation.

**Why go:** A distinct Chilean whitewater destination; route grade and operating conditions need specialist confirmation.

**Key attractions:** Rafting.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://chile.travel/en/activities/adventure-and-sports/river-experiences/).

**Contact:** [Official visitor/contact route](https://chile.travel/en/activities/adventure-and-sports/river-experiences/).

**Evidence:** [SERNATUR / Chile Travel](https://chile.travel/en/activities/adventure-and-sports/river-experiences/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Alumine River whitewater discovery

**Location:** Neuquen, Argentina.

A Patagonian river adventure with different conditions from the marine-wildlife coast.

**Why go:** A Patagonian river adventure with different conditions from the marine-wildlife coast.

**Key attractions:** Rafting.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Flow, guide requirements and participant eligibility override the attractiveness assessment.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.argentina.gob.ar/viaja-por-argentina/que-hacer/vivir-una-aventura-de-rafting-en-el-rio-alumine).

**Contact:** [Official visitor/contact route](https://www.argentina.gob.ar/viaja-por-argentina/que-hacer/vivir-una-aventura-de-rafting-en-el-rio-alumine).

**Evidence:** [Government of Argentina](https://www.argentina.gob.ar/viaja-por-argentina/que-hacer/vivir-una-aventura-de-rafting-en-el-rio-alumine). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lake Huaypo highland kayaking

**Location:** Cusco region, Peru.

A highland lake outing needs altitude and operator suitability considered separately from calm-looking water.

**Why go:** A highland lake outing needs altitude and operator suitability considered separately from calm-looking water.

**Key attractions:** Kayaking.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Launch conditions, exposure, route and supervision require local confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.peru.travel/experiences/kayaking-on-cusco-s-lakes).

**Contact:** [Official visitor/contact route](https://www.peru.travel/experiences/kayaking-on-cusco-s-lakes).

**Evidence:** [PROMPERU](https://www.peru.travel/experiences/kayaking-on-cusco-s-lakes). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Waco inland surfing and separate waterpark options

**Location:** Waco, Texas, United States.

Choose a surf lesson or session explicitly. The adjacent waterpark and beach passes are different products, not a cheap substitute for a surf booking.

**Why go:** Choose a surf lesson or session explicitly. The adjacent waterpark and beach passes are different products, not a cheap substitute for a surf booking.

**Key attractions:** Inland surf parks.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://wacosurf.com/surf/).

**Contact:** [Official visitor/contact route](https://wacosurf.com/surf/).

**Evidence:** [Waco Surf](https://wacosurf.com/surf/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Wild Wadi waterpark

**Location:** Jumeirah, Dubai, United Arab Emirates.

A waterpark option with resident and non-resident pricing. Do not turn unhydrated zero-value ticket fields into free admission.

**Why go:** A waterpark option with resident and non-resident pricing. Do not turn unhydrated zero-value ticket fields into free admission.

**Key attractions:** Water parks.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.wildwadi.com/en).

**Contact:** [Official visitor/contact route](https://www.wildwadi.com/en). Telephone: +97148200000.

**Evidence:** [Wild Wadi](https://www.wildwadi.com/en). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Surf Abu Dhabi discovery session

**Location:** Hudayriyat Island, Abu Dhabi, United Arab Emirates.

An introductory inland surf session. Treat check-in time and water time as separate itinerary items; this is not an unrestricted beach swim.

**Why go:** An introductory inland surf session. Treat check-in time and water time as separate itinerary items; this is not an unrestricted beach swim.

**Key attractions:** Inland surf parks.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.surfabudhabi.com/experiences/discovery).

**Contact:** [Official visitor/contact route](https://www.surfabudhabi.com/experiences/discovery).

**Evidence:** [Surf Abu Dhabi](https://www.surfabudhabi.com/experiences/discovery). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Suntago indoor waterpark

**Location:** Wrecza, near Warsaw, Poland.

An indoor waterpark option. Keep family swimming, relaxation and sauna zones distinct when checking age rules and ticket access.

**Why go:** An indoor waterpark option. Keep family swimming, relaxation and sauna zones distinct when checking age rules and ticket access.

**Key attractions:** Water parks.

**Season, operator pattern:** All months. Indoor pool facilities are listed as year-round while outdoor facilities are seasonal. This is not a guarantee that every attraction operates. [Season evidence](https://suntago.com/en/faq/129-bars-alcohol).

**Plan around:** Confirm height categories, maintenance closures, ticket inclusions and exact hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://suntago.com/en/).

**Contact:** [Official visitor/contact route](https://suntago.com/en/).

**Evidence:** [Suntago](https://suntago.com/en/); [Suntago](https://suntago.com/en/faq/129-bars-alcohol). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Alaia Bay alpine surf sessions

**Location:** Sion, Valais, Switzerland.

An inland surf option with session levels rather than open-water conditions. The retrieved promotional bundle has expired; use the operator for a current single-session quote.

**Why go:** An inland surf option with session levels rather than open-water conditions. The retrieved promotional bundle has expired; use the operator for a current single-session quote.

**Key attractions:** Inland surf parks.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://booking.alaiabay.ch/).

**Contact:** [Official visitor/contact route](https://booking.alaiabay.ch/). Telephone: +41273227171.

**Evidence:** [Alaia Bay](https://booking.alaiabay.ch/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: The Wave Bristol surf sessions

**Location:** Bristol, United Kingdom.

An inland venue for surf lessons and skill-level sessions. Book the correct session rather than assuming general site admission includes time in the surf lake.

**Why go:** An inland venue for surf lessons and skill-level sessions. Book the correct session rather than assuming general site admission includes time in the surf lake.

**Key attractions:** Inland surf parks.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.thewave.com/surf/).

**Contact:** [Official visitor/contact route](https://www.thewave.com/surf/).

**Evidence:** [The Wave](https://www.thewave.com/surf/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: URBNSURF Melbourne

**Location:** Melbourne, Australia.

A city-based inland surf venue with lessons and session levels. General admission, a lesson and an independent surf session are separate choices.

**Why go:** A city-based inland surf venue with lessons and session levels. General admission, a lesson and an independent surf session are separate choices.

**Key attractions:** Inland surf parks.

**Season, Activity season:** Not established. No defensible activity-season window in the supplied evidence. Do not replace this with a national climate guess.

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://urbnsurf.com/learn/).

**Contact:** [Official visitor/contact route](https://urbnsurf.com/learn/).

**Evidence:** [URBNSURF](https://urbnsurf.com/learn/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: URBNSURF Sydney

**Location:** Sydney, Australia.

A city-based inland surf venue with lessons and session levels. General admission, a lesson and an independent surf session are separate choices.

**Why go:** A city-based inland surf venue with lessons and session levels. General admission, a lesson and an independent surf session are separate choices.

**Key attractions:** Inland surf parks.

**Season, operator pattern:** All months. URBNSURF Sydney is described as year-round. Sessions are selected by ability and can be affected by maintenance or booking availability. [Season evidence](https://www.sydneyolympicpark.nsw.gov.au/things-to-see-and-do/urbnsurf-sydney).

**Plan around:** Check the exact programme, conditions, access and participation requirements; missing fields remain unknown.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://urbnsurf.com/learn/).

**Contact:** [Official visitor/contact route](https://urbnsurf.com/learn/).

**Evidence:** [URBNSURF](https://urbnsurf.com/learn/); [Sydney Olympic Park authority](https://www.sydneyolympicpark.nsw.gov.au/things-to-see-and-do/urbnsurf-sydney). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Cala Brandinchi beach

**Location:** San Teodoro, Sardinia, Italy.

Shallow coastal landscape. Exact seasonal guidance is not established by the reviewed place description.

**Why go:** Shallow coastal landscape. Exact seasonal guidance is not established by the reviewed place description.

**Key attractions:** Beaches.

**Season, regional conditions:** Not established. Shallow coastal landscape. Exact seasonal guidance is not established by the reviewed place description. [Season evidence](https://www.sardegnaturismo.it/it/esplora/cala-brandinchi?language=it).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.sardegnaturismo.it/it/esplora/cala-brandinchi?language=it).

**Contact:** [Official visitor/contact route](https://www.sardegnaturismo.it/it/esplora/cala-brandinchi?language=it).

**Evidence:** [Sardegna Turismo](https://www.sardegnaturismo.it/it/esplora/cala-brandinchi?language=it). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Coolum beach

**Location:** Sunshine Coast, Queensland, Australia.

Access equipment is a September-May weekend/public-holiday programme, subject to booking and current works.

**Why go:** Access equipment is a September-May weekend/public-holiday programme, subject to booking and current works.

**Key attractions:** Beaches.

**Season, regional conditions:** Oct, Nov. The official regional overview highlights October-November spring for a beach-region visit. This does not establish daily weather, swimming conditions or an equipment booking. [Season evidence](https://www.visitsunshinecoast.com/website-ai-overview-visit-sunshine-coast).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program).

**Contact:** [Official visitor/contact route](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program).

**Evidence:** [Sunshine Coast Council](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program); [Visit Sunshine Coast](https://www.visitsunshinecoast.com/website-ai-overview-visit-sunshine-coast). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Mooloolaba beach

**Location:** Sunshine Coast, Queensland, Australia.

Access equipment is a September-May weekend/public-holiday programme, subject to booking and current works.

**Why go:** Access equipment is a September-May weekend/public-holiday programme, subject to booking and current works.

**Key attractions:** Beaches.

**Season, regional conditions:** Oct, Nov. The official regional overview highlights October-November spring for a beach-region visit. This does not establish daily weather, swimming conditions or an equipment booking. [Season evidence](https://www.visitsunshinecoast.com/website-ai-overview-visit-sunshine-coast).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program).

**Contact:** [Official visitor/contact route](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program).

**Evidence:** [Sunshine Coast Council](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program); [Visit Sunshine Coast](https://www.visitsunshinecoast.com/website-ai-overview-visit-sunshine-coast). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Dicky Beach beach

**Location:** Sunshine Coast, Queensland, Australia.

Access equipment is a September-May weekend/public-holiday programme, subject to booking and current works.

**Why go:** Access equipment is a September-May weekend/public-holiday programme, subject to booking and current works.

**Key attractions:** Beaches.

**Season, regional conditions:** Oct, Nov. The official regional overview highlights October-November spring for a beach-region visit. This does not establish daily weather, swimming conditions or an equipment booking. [Season evidence](https://www.visitsunshinecoast.com/website-ai-overview-visit-sunshine-coast).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program).

**Contact:** [Official visitor/contact route](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program).

**Evidence:** [Sunshine Coast Council](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program); [Visit Sunshine Coast](https://www.visitsunshinecoast.com/website-ai-overview-visit-sunshine-coast). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Kings Beach beach

**Location:** Sunshine Coast, Queensland, Australia.

Access equipment is a September-May weekend/public-holiday programme, subject to booking and current works.

**Why go:** Access equipment is a September-May weekend/public-holiday programme, subject to booking and current works.

**Key attractions:** Beaches.

**Season, regional conditions:** Oct, Nov. The official regional overview highlights October-November spring for a beach-region visit. This does not establish daily weather, swimming conditions or an equipment booking. [Season evidence](https://www.visitsunshinecoast.com/website-ai-overview-visit-sunshine-coast).

**Published restriction:** Wheelchair bookings are reported unavailable from April 2026 during works; no reopening date established. [Source](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program).

**Contact:** [Official visitor/contact route](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program).

**Evidence:** [Sunshine Coast Council](https://www.sunshinecoast.qld.gov.au/living-and-community/community-support/access-inclusion-and-disability/accessible-beach-program); [Visit Sunshine Coast](https://www.visitsunshinecoast.com/website-ai-overview-visit-sunshine-coast). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Patong beach

**Location:** Phuket, Thailand.

Phuket west-coast beach with a November-April regional drier-season context. Daily flags and shore conditions override planning preferences.

**Why go:** Phuket west-coast beach with a November-April regional drier-season context. Daily flags and shore conditions override planning preferences.

**Key attractions:** Beaches.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. Phuket west-coast beach with a November-April regional drier-season context. Daily flags and shore conditions override planning preferences. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.andamandaphuket.com/promotions).

**Contact:** [Official visitor/contact route](https://www.andamandaphuket.com/promotions).

**Evidence:** [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/); [Andamanda Phuket](https://www.andamandaphuket.com/promotions); [Tourism Authority of Thailand](https://www.tourismthailand.org/Destinations/Provinces/Phuket/350). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Kata beach

**Location:** Phuket, Thailand.

Phuket west-coast beach with a November-April regional drier-season context. Daily flags and shore conditions override planning preferences.

**Why go:** Phuket west-coast beach with a November-April regional drier-season context. Daily flags and shore conditions override planning preferences.

**Key attractions:** Beaches.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. Phuket west-coast beach with a November-April regional drier-season context. Daily flags and shore conditions override planning preferences. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.andamandaphuket.com/promotions).

**Contact:** [Official visitor/contact route](https://www.andamandaphuket.com/promotions).

**Evidence:** [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/); [Andamanda Phuket](https://www.andamandaphuket.com/promotions); [Tourism Authority of Thailand](https://www.tourismthailand.org/Destinations/Provinces/Phuket/350). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Karon beach

**Location:** Phuket, Thailand.

Phuket west-coast beach with a November-April regional drier-season context. Daily flags and shore conditions override planning preferences.

**Why go:** Phuket west-coast beach with a November-April regional drier-season context. Daily flags and shore conditions override planning preferences.

**Key attractions:** Beaches.

**Season, regional conditions:** Nov, Dec, Jan, Feb, Mar, Apr. Phuket west-coast beach with a November-April regional drier-season context. Daily flags and shore conditions override planning preferences. [Season evidence](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official operator information](https://www.andamandaphuket.com/promotions).

**Contact:** [Official visitor/contact route](https://www.andamandaphuket.com/promotions).

**Evidence:** [Tourism Authority of Thailand](https://www.tatnews.org/2020/11/thailands-comfortable-cooler-months-of-november-february-are-a-fantastic-time-to-travel/); [Andamanda Phuket](https://www.andamandaphuket.com/promotions); [Tourism Authority of Thailand](https://www.tourismthailand.org/Destinations/Provinces/Phuket/350). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: Spiaggia dei Pini

**Location:** Riva del Garda, Italy.

Summer beach and green-space context on northern Lake Garda; wind and current bathing advice are separate.

**Why go:** Summer beach and green-space context on northern Lake Garda; wind and current bathing advice are separate.

**Key attractions:** Beaches.

**Season, editorial season mapping:** Jun, Jul, Aug. Summer beach and green-space context on northern Lake Garda; wind and current bathing advice are separate. [Season evidence](https://visitlagodigarda.it/en/lake-garda-beaches/).

**Plan around:** Water quality, flags, shorebreak, access and facilities need date-specific local checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official visitor / access information](https://www.gardatrentino.it/en/info/pine-beach_84063).

**Contact:** [Official visitor/contact route](https://www.gardatrentino.it/en/info/pine-beach_84063).

**Evidence:** [Garda Trentino](https://www.gardatrentino.it/en/info/pine-beach_84063); [Visit Lago di Garda](https://visitlagodigarda.it/en/lake-garda-beaches/). Retained prior research; original field dates remain. No image rights or exact entrance coordinates supplied.

### Additional discovery: 7132 Thermal Baths Vals

**Location:** Vals, Graubunden, Switzerland.

7132 Thermal Baths Vals in Vals, Graubunden brings together peter zumthor architecture, quartzite bathing rooms and indoor and outdoor pools.

**Why go:** Choose the stone, light and bathing sequence as the attraction, rather than expecting a slide-led family water park.

**Key attractions:** Peter Zumthor architecture; Quartzite bathing rooms; Indoor and outdoor pools.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.myswitzerland.com/en-us/experiences/7132-therme/).

**Plan around:** Tourism source lists access from age six with an adult and separate night-bathing rules. Its broad accessibility exclusion needs route-specific operator confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.7132.com/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/7132-therme/). Telephone: +41 58 713 20 10.

**Evidence:** [7132 Thermal Baths Vals / official publisher](https://www.myswitzerland.com/en-us/experiences/7132-therme/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Les Bains de Saillon

**Location:** Saillon, Valais, Switzerland.

Les Bains de Saillon in Saillon, Valais brings together thermal bathing, valais setting and historic village nearby.

**Why go:** Make the thermal baths the water element of a Saillon visit rather than duplicating a generic Valais destination page.

**Key attractions:** Thermal bathing; Valais setting; Historic village nearby.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.myswitzerland.com/en-us/experiences/saillon-thermal-baths/).

**Plan around:** Current pools, maintenance dates and day-admission conditions require the operator schedule.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.myswitzerland.com/en-us/experiences/saillon-thermal-baths/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/saillon-thermal-baths/).

**Evidence:** [Les Bains de Saillon / official publisher](https://www.myswitzerland.com/en-us/experiences/saillon-thermal-baths/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Sole uno wellness world

**Location:** Rheinfelden, Switzerland.

Sole uno wellness world in Rheinfelden brings together saltwater bathing, sauna programme and themed wellness areas.

**Why go:** The saltwater format offers a different experience from ordinary lap swimming or an unheated river bath.

**Key attractions:** Saltwater bathing; Sauna programme; Themed wellness areas.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.myswitzerland.com/en-us/experiences/sole-uno-wellness-world/).

**Plan around:** Confirm sauna age limits, textile rules and the ticket area before booking.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.myswitzerland.com/en-us/experiences/sole-uno-wellness-world/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/sole-uno-wellness-world/).

**Evidence:** [Sole uno wellness world / official publisher](https://www.myswitzerland.com/en-us/experiences/sole-uno-wellness-world/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: FORTYSEVEN thermal spa

**Location:** Baden, Aargau, Switzerland.

FORTYSEVEN thermal spa in Baden, Aargau brings together mario botta architecture, kosmos light-and-sound pool and limmat-facing outdoor bathing.

**Why go:** The architectural setting and sound-based pool distinguish this from a plain thermal soak.

**Key attractions:** Mario Botta architecture; Kosmos light-and-sound pool; Limmat-facing outdoor bathing.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.myswitzerland.com/en-us/experiences/fortyseven-thermal-wellness-spa/).

**Plan around:** Do not repeat the tourism page's 47-degree pool wording as a bathing temperature. It describes the spring identity; verify actual pool temperatures with the operator.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.fortyseven.ch/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/fortyseven-thermal-wellness-spa/). Telephone: +41 56 269 18 47.

**Evidence:** [FORTYSEVEN thermal spa / official publisher](https://www.myswitzerland.com/en-us/experiences/fortyseven-thermal-wellness-spa/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Leukerbad Therme

**Location:** Leukerbad, Valais, Switzerland.

Leukerbad Therme in Leukerbad, Valais brings together indoor and outdoor thermal pools, daubenhorn views and water slides.

**Why go:** A useful mixed-interest choice where mountain-view bathing and slides can serve different members of the same group.

**Key attractions:** Indoor and outdoor thermal pools; Daubenhorn views; Water slides.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.myswitzerland.com/en-us/experiences/leukerbad-thermal-spa/).

**Plan around:** Partial barrier-free provision is not access to every pool or slide. Use current operator hours, not cached daily times.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.leukerbad.ch/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/leukerbad-thermal-spa/). Telephone: +41 27 472 20 20.

**Evidence:** [Leukerbad Therme / official publisher](https://www.myswitzerland.com/en-us/experiences/leukerbad-thermal-spa/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Huerlimannbad and Spa Zurich

**Location:** Enge, Zurich, Switzerland.

Huerlimannbad and Spa Zurich in Enge, Zurich brings together former brewery vaults, rooftop bathing and roman-irish spa route.

**Why go:** Combine a city viewpoint with bathing, with a different atmosphere below the brewery vaults and on the roof.

**Key attractions:** Former brewery vaults; Rooftop bathing; Roman-Irish spa route.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.myswitzerland.com/en-us/experiences/thermal-baths-spa-zurich/).

**Plan around:** Thermal admission and the Roman-Irish ritual are distinct products. Child-access hours need a current check.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.huerlimannbad.ch/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/thermal-baths-spa-zurich/). Telephone: +41 44 205 96 50.

**Evidence:** [Huerlimannbad and Spa Zurich / official publisher](https://www.myswitzerland.com/en-us/experiences/thermal-baths-spa-zurich/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Tamina Therme

**Location:** Bad Ragaz, Switzerland.

Tamina Therme in Bad Ragaz brings together indoor and outdoor thermal pools, light-filled architecture and current channel.

**Why go:** An architectural bathing visit with an outdoor option, distinct from a walk into the Tamina Gorge.

**Key attractions:** Indoor and outdoor thermal pools; Light-filled architecture; Current channel.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.myswitzerland.com/en-us/experiences/tamina-therme-bad-ragaz-thermal-baths/).

**Plan around:** Day bathing and resort accommodation are separate purchases.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.taminatherme.ch/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/tamina-therme-bad-ragaz-thermal-baths/). Telephone: +41 81 303 27 40.

**Evidence:** [Tamina Therme / official publisher](https://www.myswitzerland.com/en-us/experiences/tamina-therme-bad-ragaz-thermal-baths/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Thermalbad Brigerbad

**Location:** Brigerbad, Valais, Switzerland.

Thermalbad Brigerbad in Brigerbad, Valais brings together thermal grotto, indoor and outdoor pools and water slide.

**Why go:** The grotto, bathing and slide options give a group more variety than a quiet spa-only visit.

**Key attractions:** Thermal grotto; Indoor and outdoor pools; Water slide.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.myswitzerland.com/en-us/experiences/thermal-spa-brigerbad/).

**Plan around:** The tourism office address is in Brig, not the pool entrance. Do not plot it as the bathing location.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.myswitzerland.com/en-us/experiences/thermal-spa-brigerbad/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/thermal-spa-brigerbad/).

**Evidence:** [Thermalbad Brigerbad / official publisher](https://www.myswitzerland.com/en-us/experiences/thermal-spa-brigerbad/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Aquandeer mineral spa

**Location:** Andeer, Graubunden, Switzerland.

Aquandeer mineral spa in Andeer, Graubunden brings together indoor and outdoor mineral pools, mountain setting and sauna.

**Why go:** A bathing stop in the Val de Schons with a public-transport approach, rather than another generic Alpine resort listing.

**Key attractions:** Indoor and outdoor mineral pools; Mountain setting; Sauna.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.myswitzerland.com/en-us/experiences/aquandeer-mineral-spa-andeer/).

**Plan around:** The source gives a broad accessibility label, not a verified assisted-water-access specification.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.myswitzerland.com/en-us/experiences/aquandeer-mineral-spa-andeer/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/aquandeer-mineral-spa-andeer/).

**Evidence:** [Aquandeer mineral spa / official publisher](https://www.myswitzerland.com/en-us/experiences/aquandeer-mineral-spa-andeer/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Therme Zurzach

**Location:** Bad Zurzach, Aargau, Switzerland.

Therme Zurzach in Bad Zurzach, Aargau brings together warm outdoor pools, indoor brine bath and unheated garden pool.

**Why go:** Compare the warm thermal pools with the separate unheated pool instead of assuming one water temperature throughout.

**Key attractions:** Warm outdoor pools; Indoor brine bath; Unheated garden pool.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.myswitzerland.com/en-us/experiences/therme-zurzach/).

**Plan around:** Winter thermal use does not establish year-round operation of the natural swimming pool.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.thermezurzach.ch/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/therme-zurzach/). Telephone: +41 56 265 28 28.

**Evidence:** [Therme Zurzach / official publisher](https://www.myswitzerland.com/en-us/experiences/therme-zurzach/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Les Bains d'Ovronnaz

**Location:** Ovronnaz, Valais, Switzerland.

Les Bains d'Ovronnaz in Ovronnaz, Valais brings together rhone valley panorama, two open-air thermal pools and indoor thermal pool.

**Why go:** Choose this for the elevated valley outlook while bathing, with both indoor and exposed options.

**Key attractions:** Rhone Valley panorama; Two open-air thermal pools; Indoor thermal pool.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.myswitzerland.com/en-us/experiences/thermal-baths-in-ovronnaz/).

**Plan around:** Year-round context is inferred from the source's summer and winter description; confirm the actual programme.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.bains-ovronnaz.ch/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/thermal-baths-in-ovronnaz/). Telephone: +41 27 305 11 11.

**Evidence:** [Les Bains d'Ovronnaz / official publisher](https://www.myswitzerland.com/en-us/experiences/thermal-baths-in-ovronnaz/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Les Bains de Lavey

**Location:** Lavey-les-Bains, Vaud, Switzerland.

Les Bains de Lavey in Lavey-les-Bains, Vaud brings together outdoor alpine views, indoor thermal water and sauna and hammam.

**Why go:** A water-focused stop at the foot of the Alps with a defined contrast between bathing and sauna spaces.

**Key attractions:** Outdoor Alpine views; Indoor thermal water; Sauna and hammam.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.myswitzerland.com/en-us/experiences/bains-de-lavey-thermal-spa/).

**Plan around:** Spring temperature is not pool temperature. Confirm package inclusions and age requirements.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.bains-lavey.ch/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/bains-de-lavey-thermal-spa/). Telephone: +41 24 486 15 55.

**Evidence:** [Les Bains de Lavey / official publisher](https://www.myswitzerland.com/en-us/experiences/bains-de-lavey-thermal-spa/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Mineralbad and Spa Samedan

**Location:** Samedan, Graubunden, Switzerland.

Mineralbad and Spa Samedan in Samedan, Graubunden brings together mineral bathing, village-centre spa and engadine setting.

**Why go:** An alternative to a distant resort transfer when a bathing stop in Samedan itself is the aim.

**Key attractions:** Mineral bathing; Village-centre spa; Engadine setting.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.myswitzerland.com/en-us/experiences/samedan-mineral-baths-amp-spa/).

**Plan around:** Operating months and detailed access are not established in the retrieved section.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.mineralbad-samedan.ch/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/samedan-mineral-baths-amp-spa/). Telephone: +41 81 851 19 19.

**Evidence:** [Mineralbad and Spa Samedan / official publisher](https://www.myswitzerland.com/en-us/experiences/samedan-mineral-baths-amp-spa/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Mineralbad and Spa Rigi Kaltbad

**Location:** Rigi Kaltbad, Lucerne, Switzerland.

Mineralbad and Spa Rigi Kaltbad in Rigi Kaltbad, Lucerne brings together mario botta pool design, lake lucerne panorama and indoor-outdoor bathing.

**Why go:** Combine the mountain journey with a distinctive pool view rather than treating the bath as an ordinary city pool.

**Key attractions:** Mario Botta pool design; Lake Lucerne panorama; Indoor-outdoor bathing.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.myswitzerland.com/en-us/experiences/mineral-baths-spa-rigikaltbad/).

**Plan around:** The spa area has a separate age-16 rule. Mountain transport and bath admission need separate checks.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aqua-spa-resorts.ch/).

**Contact:** [Official visitor/contact route](https://www.myswitzerland.com/en-us/experiences/mineral-baths-spa-rigikaltbad/). Telephone: +41 41 397 04 00.

**Evidence:** [Mineralbad and Spa Rigi Kaltbad / official publisher](https://www.myswitzerland.com/en-us/experiences/mineral-baths-spa-rigikaltbad/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Therme Laa

**Location:** Laa an der Thaya, Austria.

Therme Laa in Laa an der Thaya brings together thermal bathing, family facilities and separate silent spa.

**Why go:** Choose the family thermal area or the quieter premium product deliberately, not from one blended resort description.

**Key attractions:** Thermal bathing; Family facilities; Separate Silent Spa.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.therme-laa.at/en/).

**Plan around:** Silent Spa is listed for ages 16 and over. The separate villas are not a general-admission pool.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.therme-laa.at/en/).

**Contact:** [Official visitor/contact route](https://www.therme-laa.at/en/).

**Evidence:** [Therme Laa / official publisher](https://www.therme-laa.at/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: H2O Hotel-Therme-Resort

**Location:** Bad Waltersdorf, Styria, Austria.

H2O Hotel-Therme-Resort in Bad Waltersdorf, Styria brings together children's water-play areas, slides and thermal leisure pools.

**Why go:** An activity-led family bath rather than an adults-only retreat; that distinction matters when comparing thermal venues.

**Key attractions:** Children's water-play areas; Slides; Thermal leisure pools.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.hoteltherme.at/en/index.html).

**Plan around:** Day tickets, hotel packages and supervised activities can have different inclusions.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.hoteltherme.at/en/index.html).

**Contact:** [Official visitor/contact route](https://www.hoteltherme.at/en/index.html).

**Evidence:** [H2O Hotel-Therme-Resort / official publisher](https://www.hoteltherme.at/en/index.html). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Sonnentherme Lutzmannsburg

**Location:** Lutzmannsburg, Burgenland, Austria.

Sonnentherme Lutzmannsburg in Lutzmannsburg, Burgenland brings together baby-focused water areas, slide programme and swimming academy.

**Why go:** The baby facilities and teaching offer create a more specific family use case than a general spa label.

**Key attractions:** Baby-focused water areas; Slide programme; Swimming academy.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.sonnentherme.at/en/).

**Plan around:** Ride height and age rules are attraction-specific. Family branding is not universal toddler eligibility.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.sonnentherme.at/en/).

**Contact:** [Official visitor/contact route](https://www.sonnentherme.at/en/).

**Evidence:** [Sonnentherme Lutzmannsburg / official publisher](https://www.sonnentherme.at/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Aquapulco and Eurothermen Bad Schallerbach

**Location:** Bad Schallerbach, Upper Austria, Austria.

Aquapulco and Eurothermen Bad Schallerbach in Bad Schallerbach, Upper Austria brings together pirate-themed water world, wave pool and separate thermal and sauna areas.

**Why go:** Match an active water-park day or a quieter thermal visit to the correct admission area.

**Key attractions:** Pirate-themed water world; Wave pool; Separate thermal and sauna areas.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.eurothermen.at/en/bad-schallerbach/).

**Plan around:** Aquapulco, the thermal area and sauna areas are not interchangeable ticket products.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.eurothermen.at/en/bad-schallerbach/).

**Contact:** [Official visitor/contact route](https://www.eurothermen.at/en/bad-schallerbach/).

**Evidence:** [Aquapulco and Eurothermen Bad Schallerbach / official publisher](https://www.eurothermen.at/en/bad-schallerbach/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Parktherme Bad Radkersburg

**Location:** Bad Radkersburg, Styria, Austria.

Parktherme Bad Radkersburg in Bad Radkersburg, Styria brings together thermal pools, park outlook and sauna village.

**Why go:** A park-facing thermal option for a quieter water day, distinct from slide-centred family complexes.

**Key attractions:** Thermal pools; Park outlook; Sauna village.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.parktherme.at/en/).

**Plan around:** Published mineral-water descriptions are not medical treatment claims.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.parktherme.at/en/).

**Contact:** [Official visitor/contact route](https://www.parktherme.at/en/).

**Evidence:** [Parktherme Bad Radkersburg / official publisher](https://www.parktherme.at/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: KaerntenTherme

**Location:** Warmbad-Villach, Carinthia, Austria.

KaerntenTherme in Warmbad-Villach, Carinthia brings together sports pool, leisure-water areas and hammam and wellness.

**Why go:** Useful when a group wants an actual sports swim alongside leisure bathing rather than only warm soaking.

**Key attractions:** Sports pool; Leisure-water areas; Hammam and wellness.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.kaerntentherme.com/en/).

**Plan around:** Confirm which facilities the chosen tariff covers; wellness and sports routes can differ.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.kaerntentherme.com/en/).

**Contact:** [Official visitor/contact route](https://www.kaerntentherme.com/en/).

**Evidence:** [KaerntenTherme / official publisher](https://www.kaerntentherme.com/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Salzkammergut-Therme Bad Ischl

**Location:** Bad Ischl, Upper Austria, Austria.

Salzkammergut-Therme Bad Ischl in Bad Ischl, Upper Austria brings together brine bathing, lazy river and sauna retreat.

**Why go:** The brine focus provides a distinct water experience within a historic Salzkammergut town itinerary.

**Key attractions:** Brine bathing; Lazy river; Sauna retreat.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.eurothermen.at/en/bad-ischl/).

**Plan around:** Separate the public bathing product from hotel and treatment packages.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.eurothermen.at/en/bad-ischl/).

**Contact:** [Official visitor/contact route](https://www.eurothermen.at/en/bad-ischl/).

**Evidence:** [Salzkammergut-Therme Bad Ischl / official publisher](https://www.eurothermen.at/en/bad-ischl/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Therme Wien

**Location:** Oberlaa, Vienna, Austria.

Therme Wien in Oberlaa, Vienna brings together thermal and activity pools, waterfalls and relaxation zones.

**Why go:** A city-based thermal day without treating every Vienna visitor as a resort guest.

**Key attractions:** Thermal and activity pools; Waterfalls; Relaxation zones.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.thermewien.at/en/all-areas/).

**Plan around:** The retrieved area page is an older snapshot. Confirm current operation, tariffs and any partial closures.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.thermewien.at/en/all-areas/).

**Contact:** [Official visitor/contact route](https://www.thermewien.at/en/all-areas/).

**Evidence:** [Therme Wien / official publisher](https://www.thermewien.at/en/all-areas/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Thermal Resort Loipersdorf

**Location:** Loipersdorf, Styria, Austria.

Thermal Resort Loipersdorf in Loipersdorf, Styria brings together family water areas, baby areas and separate adult relaxation.

**Why go:** The separation of visitor zones is the reason to consider it, not a blanket claim that every space suits everyone.

**Key attractions:** Family water areas; Baby areas; Separate adult relaxation.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.therme.at/en/).

**Plan around:** The resort has multiple admission areas and age conditions; price comparisons must use the same product.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.therme.at/en/).

**Contact:** [Official visitor/contact route](https://www.therme.at/en/).

**Evidence:** [Thermal Resort Loipersdorf / official publisher](https://www.therme.at/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Rogner Bad Blumau

**Location:** Bad Blumau, Styria, Austria.

Rogner Bad Blumau in Bad Blumau, Styria brings together hundertwasser architecture, thermal bathing and landscaped resort.

**Why go:** The built landscape is part of the bathing experience, giving architecture-minded visitors a reason to choose it.

**Key attractions:** Hundertwasser architecture; Thermal bathing; Landscaped resort.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.blumau.com/en/no_cache.html).

**Plan around:** The retrieved operator page is old. Obtain the current day-visit conditions before presenting availability.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.blumau.com/en/no_cache.html).

**Contact:** [Official visitor/contact route](https://www.blumau.com/en/no_cache.html).

**Evidence:** [Rogner Bad Blumau / official publisher](https://www.blumau.com/en/no_cache.html). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: St. Martins Therme

**Location:** Frauenkirchen, Burgenland, Austria.

St. Martins Therme in Frauenkirchen, Burgenland brings together lakeside setting, indoor and outdoor pools and seewinkel nature context.

**Why go:** Pair managed thermal bathing with an interest in the surrounding wetland landscape, without implying unrestricted lake access.

**Key attractions:** Lakeside setting; Indoor and outdoor pools; Seewinkel nature context.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.stmartins.at/en).

**Plan around:** Resort nature programmes and thermal tickets are distinct. Wildlife excursions have their own schedules.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.stmartins.at/en).

**Contact:** [Official visitor/contact route](https://www.stmartins.at/en).

**Evidence:** [St. Martins Therme / official publisher](https://www.stmartins.at/en). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Linsberg Asia

**Location:** Bad Erlach, Lower Austria, Austria.

Linsberg Asia in Bad Erlach, Lower Austria brings together asian-inspired spa design, thermal bathing and adult-only setting.

**Why go:** A clearly adult-oriented alternative when calm rather than slides is the main objective.

**Key attractions:** Asian-inspired spa design; Thermal bathing; Adult-only setting.

**Season, indoor visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.linsbergasia.at/en/).

**Plan around:** The source sets a minimum age of 16. Do not include it in an unrestricted children's list.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.linsbergasia.at/en/).

**Contact:** [Official visitor/contact route](https://www.linsbergasia.at/en/).

**Evidence:** [Linsberg Asia / official publisher](https://www.linsbergasia.at/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Allas Pool

**Location:** Market Square, Helsinki, Finland.

Allas Pool in Market Square, Helsinki brings together warm pool, seawater pool and waterfront saunas.

**Why go:** An urban bathing stop with a genuine choice between heated water and seawater, rather than a single undifferentiated pool.

**Key attractions:** Warm pool; Seawater pool; Waterfront saunas.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.allaspool.fi/en/).

**Plan around:** The children's pool is described as a summer facility. Cached August notices and temperatures are not current conditions.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.allaspool.fi/en/).

**Contact:** [Official visitor/contact route](https://www.allaspool.fi/en/).

**Evidence:** [Allas Pool / official publisher](https://www.allaspool.fi/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lonna island sauna

**Location:** Lonna island, Helsinki, Finland.

Lonna island sauna in Lonna island, Helsinki brings together island ferry approach, wooden sauna and sea access.

**Why go:** The short island journey and sauna make a distinct half-day format rather than another city-centre spa.

**Key attractions:** Island ferry approach; Wooden sauna; Sea access.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.lonna.fi/en/services/sauna/).

**Plan around:** The restaurant's May-September dates do not prove the sauna operating season. Confirm the sauna and ferry together.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.lonna.fi/en/services/sauna/).

**Contact:** [Official visitor/contact route](https://www.lonna.fi/en/services/sauna/).

**Evidence:** [Lonna island sauna / official publisher](https://www.lonna.fi/en/services/sauna/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Loyly Helsinki

**Location:** Hernesaari, Helsinki, Finland.

Loyly Helsinki in Hernesaari, Helsinki brings together coastal sauna architecture, baltic-water setting and terraces.

**Why go:** Architecture and the sea-facing route are the reason to prefer it over a conventional indoor sauna.

**Key attractions:** Coastal sauna architecture; Baltic-water setting; Terraces.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.loylyhelsinki.fi/).

**Plan around:** Sea swimming is an optional separate exposure, not a safety consequence of a sauna ticket.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.loylyhelsinki.fi/).

**Contact:** [Official visitor/contact route](https://www.loylyhelsinki.fi/).

**Evidence:** [Loyly Helsinki / official publisher](https://www.loylyhelsinki.fi/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: FLOU sauna restaurant

**Location:** Tammerkoski, Tampere, Finland.

FLOU sauna restaurant in Tammerkoski, Tampere brings together floating log building, rapids-side outlook and sauna and food.

**Why go:** A floating building makes the water setting part of the visit even for guests who remain out of the water.

**Key attractions:** Floating log building; Rapids-side outlook; Sauna and food.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.flousauna.fi/).

**Plan around:** Rapids-side location is not permission to swim in the rapids. The tourism product page conflicts on duration: a two-hour header versus a 1.5-hour ticket. Confirm the selected session.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.flousauna.fi/).

**Contact:** [Official visitor/contact route](https://www.flousauna.fi/).

**Evidence:** [FLOU sauna restaurant / official publisher](https://www.flousauna.fi/); [FLOU sauna restaurant / official publisher](https://www.visitfinland.com/en/product/8a397051-9ff5-49c9-9bc2-d4515c1b1509/flou-public-sauna/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Saunaravintola Kuuma

**Location:** Tampere, Finland.

Saunaravintola Kuuma in Tampere brings together wood-fired sauna, smoke-sauna option and lake pyhajarvi setting.

**Why go:** A way to compare sauna traditions in one visit rather than treating all heat rooms as equivalent.

**Key attractions:** Wood-fired sauna; Smoke-sauna option; Lake Pyhajarvi setting.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.saunaravintolakuuma.fi/en/home/).

**Plan around:** Confirm the actual water-access area and current bathing instructions.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.saunaravintolakuuma.fi/en/home/).

**Contact:** [Official visitor/contact route](https://www.saunaravintolakuuma.fi/en/home/).

**Evidence:** [Saunaravintola Kuuma / official publisher](https://www.saunaravintolakuuma.fi/en/home/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Sataman Viilu

**Location:** Jyvaskyla harbour, Finland.

Sataman Viilu in Jyvaskyla harbour brings together lake jyvasjarvi waterfront, sauna facilities and restaurant.

**Why go:** A harbour-based sauna outing that can fit around a city visit without a separate wilderness transfer.

**Key attractions:** Lake Jyvasjarvi waterfront; Sauna facilities; Restaurant.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://satamanviilu.fi/in-english/).

**Plan around:** Use the operator's own access instructions, not an inferred route from a harbour map.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://satamanviilu.fi/in-english/).

**Contact:** [Official visitor/contact route](https://satamanviilu.fi/in-english/).

**Evidence:** [Sataman Viilu / official publisher](https://satamanviilu.fi/in-english/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Kuopion Saana

**Location:** Kuopio, Lake Kallavesi, Finland.

Kuopion Saana in Kuopio, Lake Kallavesi brings together outdoor pools, saunas and lake outlook.

**Why go:** Managed pools and a lake-facing setting offer a different option from an exposed natural-water swim.

**Key attractions:** Outdoor pools; Saunas; Lake outlook.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.kuopionsaana.fi/en/frontpage/).

**Plan around:** The retrieved operator snapshot is old. Current access, age limits and pool operation need confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.kuopionsaana.fi/en/frontpage/).

**Contact:** [Official visitor/contact route](https://www.kuopionsaana.fi/en/frontpage/).

**Evidence:** [Kuopion Saana / official publisher](https://www.kuopionsaana.fi/en/frontpage/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Luoto Kuopio

**Location:** Lake Kallavesi, Kuopio, Finland.

Luoto Kuopio in Lake Kallavesi, Kuopio brings together wooden waterfront architecture, sauna and lakeside terrace.

**Why go:** Choose it for the built relationship with the lake rather than assuming it is another aquarium or water park.

**Key attractions:** Wooden waterfront architecture; Sauna; Lakeside terrace.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.luotokuopio.fi/).

**Plan around:** A lakeside sauna description does not establish wheelchair water access or a supervised swim zone.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.luotokuopio.fi/).

**Contact:** [Official visitor/contact route](https://www.luotokuopio.fi/).

**Evidence:** [Luoto Kuopio / official publisher](https://www.luotokuopio.fi/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Kesarafla Sauna and WNTR Sauna

**Location:** Kemijoki, Rovaniemi, Finland.

Kesarafla Sauna and WNTR Sauna in Kemijoki, Rovaniemi brings together riverside sauna, summer terrace and winter-format programme.

**Why go:** A useful example of one place changing its experience with the season instead of needing duplicate summer and winter records.

**Key attractions:** Riverside sauna; Summer terrace; Winter-format programme.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.laplandhotels.com/en/hotels-and-destinations/rovaniemi/lapland-hotels-ounasvaara-chalets/kesarafla-sauna).

**Plan around:** Do not treat the summer and winter brands as two physical attractions. Current session dates remain unverified.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.laplandhotels.com/en/hotels-and-destinations/rovaniemi/lapland-hotels-ounasvaara-chalets/kesarafla-sauna).

**Contact:** [Official visitor/contact route](https://www.laplandhotels.com/en/hotels-and-destinations/rovaniemi/lapland-hotels-ounasvaara-chalets/kesarafla-sauna).

**Evidence:** [Kesarafla Sauna and WNTR Sauna / official publisher](https://www.laplandhotels.com/en/hotels-and-destinations/rovaniemi/lapland-hotels-ounasvaara-chalets/kesarafla-sauna). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Isokenkaisten Klubi smoke sauna

**Location:** Kuusamo, Finland.

Isokenkaisten Klubi smoke sauna in Kuusamo brings together smoke sauna, wilderness-water setting and local-food programme.

**Why go:** A quieter nature-led alternative to a city sauna, with the smoke-sauna format central to the choice.

**Key attractions:** Smoke sauna; Wilderness-water setting; Local-food programme.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.ikk.fi/).

**Plan around:** Confirm whether a public session or private group reservation is required.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.ikk.fi/).

**Contact:** [Official visitor/contact route](https://www.ikk.fi/).

**Evidence:** [Isokenkaisten Klubi smoke sauna / official publisher](https://www.ikk.fi/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Saunaravintola Kaarna

**Location:** Kaarina, near Turku, Finland.

Saunaravintola Kaarna in Kaarina, near Turku brings together seaside sauna, sandy shore and winter swimming programme.

**Why go:** The same coastal venue supports different warm- and cold-season experiences, provided the visitor chooses the appropriate session.

**Key attractions:** Seaside sauna; Sandy shore; Winter swimming programme.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://saunaravintolakaarna.fi/).

**Plan around:** Year-round operation does not make cold-water swimming suitable for every visitor.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://saunaravintolakaarna.fi/).

**Contact:** [Official visitor/contact route](https://saunaravintolakaarna.fi/).

**Evidence:** [Saunaravintola Kaarna / official publisher](https://saunaravintolakaarna.fi/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Cornish Seal Sanctuary

**Location:** Gweek, Cornwall, United Kingdom.

Cornish Seal Sanctuary in Gweek, Cornwall brings together grey-seal rehabilitation, resident seals and puffin interpretation.

**Why go:** Choose it to understand individual rescue stories and coastal wildlife rather than expect a wild-animal sighting cruise.

**Key attractions:** Grey-seal rehabilitation; Resident seals; Puffin interpretation.

**Season, rescue programme:** Sep, Oct, Nov, Dec, Jan, Feb, Mar. Publisher describes a September-March rescue-season focus. This is not the visitor opening season and does not promise an animal admission or encounter. Other visitor months need a separate opening-calendar check. [Season evidence](https://sealsanctuary.sealifetrust.org/en/).

**Plan around:** The stated September-March rehabilitation season is not the opening calendar. Captive wildlife care is described by the operator, not independently audited here.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://sealsanctuary.sealifetrust.org/en/).

**Contact:** [Official visitor/contact route](https://sealsanctuary.sealifetrust.org/en/).

**Evidence:** [Cornish Seal Sanctuary / official publisher](https://sealsanctuary.sealifetrust.org/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: The Lost Spring

**Location:** Whitianga, Coromandel, New Zealand.

The Lost Spring in Whitianga, Coromandel brings together geothermal lagoon pools, planted garden setting and separate treetop spa.

**Why go:** A garden-led adult bathing visit close to a coastal town, with a clear distinction between a pool session and a treatment package.

**Key attractions:** Geothermal lagoon pools; Planted garden setting; Separate treetop spa.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.thelostspring.co.nz/).

**Plan around:** The source describes year-round operation but only Thursday-Sunday hours. Adult-only wording needs its exact current age threshold checked.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.thelostspring.co.nz/).

**Contact:** [Official visitor/contact route](https://www.thelostspring.co.nz/).

**Evidence:** [The Lost Spring / official publisher](https://www.thelostspring.co.nz/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Onsen Hot Pools

**Location:** Arthurs Point, Queenstown, New Zealand.

Onsen Hot Pools in Arthurs Point, Queenstown brings together private cedar-lined pools, shotover river outlook and optional cold-plunge package.

**Why go:** The view and private session format distinguish it from a shared thermal complex.

**Key attractions:** Private cedar-lined pools; Shotover River outlook; Optional cold-plunge package.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.onsen.co.nz/).

**Plan around:** Soak-only, treatment-only and combined products differ. Treatment-only purchases explicitly omit a soak.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.onsen.co.nz/).

**Contact:** [Official visitor/contact route](https://www.onsen.co.nz/). Telephone: +64 3 442 5707.

**Evidence:** [Onsen Hot Pools / official publisher](https://www.onsen.co.nz/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Wai Ariki Hot Springs and Spa

**Location:** Rotorua lakefront, New Zealand.

Wai Ariki Hot Springs and Spa in Rotorua lakefront brings together ngati whakaue cultural context, geothermal bathing sequence and private pool options.

**Why go:** The cultural narrative and defined bathing sequence provide a reason to choose it beyond the number of pools.

**Key attractions:** Ngati Whakaue cultural context; Geothermal bathing sequence; Private pool options.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.wai-ariki.co.nz/).

**Plan around:** The page shows inconsistent prices for a similarly named massage-and-bathing package. Compare the exact booking product; do not publish a single reconciled price.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.wai-ariki.co.nz/).

**Contact:** [Official visitor/contact route](https://www.wai-ariki.co.nz/).

**Evidence:** [Wai Ariki Hot Springs and Spa / official publisher](https://www.wai-ariki.co.nz/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Ngawha Springs

**Location:** Ngawha, near Kaikohe, Northland, New Zealand.

Ngawha Springs in Ngawha, near Kaikohe, Northland brings together pools with differing mineral characteristics, ngapuhi cultural context and separate private-bathing area.

**Why go:** A locally rooted thermal visit where the differences between the pools are central to the experience.

**Key attractions:** Pools with differing mineral characteristics; Ngapuhi cultural context; Separate private-bathing area.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.ngawha.nz/).

**Plan around:** The Nga Waiariki and Nga Puna areas are within one destination, not separate attractions to inflate a ranking. No medical benefit is asserted.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.ngawha.nz/).

**Contact:** [Official visitor/contact route](https://www.ngawha.nz/).

**Evidence:** [Ngawha Springs / official publisher](https://www.ngawha.nz/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Tekapo Springs

**Location:** Lake Tekapo, Canterbury, New Zealand.

Tekapo Springs in Lake Tekapo, Canterbury brings together three hot pools, lake and mountain outlook and separate stargazing programme.

**Why go:** Adds an evening or cooler-weather water experience to a lake visit without implying that swimming in the lake itself is appropriate.

**Key attractions:** Three hot pools; Lake and mountain outlook; Separate stargazing programme.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://tekaposprings.co.nz/).

**Plan around:** The cached page reports a Deep Pool maintenance closure without an expiry. Check current status; winter skating and snow-tubing are not all-year features.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://tekaposprings.co.nz/).

**Contact:** [Official visitor/contact route](https://tekaposprings.co.nz/).

**Evidence:** [Tekapo Springs / official publisher](https://tekaposprings.co.nz/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Hot Tubs Omarama

**Location:** Omarama, Waitaki, New Zealand.

Hot Tubs Omarama in Omarama, Waitaki brings together private cedar tubs, fresh mountain-water supply and optional sauna pod.

**Why go:** Private groups can control the tub experience rather than share a large resort pool circuit.

**Key attractions:** Private cedar tubs; Fresh mountain-water supply; Optional sauna pod.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.hottubsomarama.co.nz/).

**Plan around:** These are heated fresh-water tubs, not a claim of naturally geothermal spring water. Capacity and session length depend on the selected product.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.hottubsomarama.co.nz/).

**Contact:** [Official visitor/contact route](https://www.hottubsomarama.co.nz/). Telephone: +64 21 2707 262.

**Evidence:** [Hot Tubs Omarama / official publisher](https://www.hottubsomarama.co.nz/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Waikite Valley Thermal Pools

**Location:** Waikite Valley, Rotorua region, New Zealand.

Waikite Valley Thermal Pools in Waikite Valley, Rotorua region brings together geothermal valley setting, public pool circuit and private bathing options.

**Why go:** The surrounding geothermal landscape gives the managed pools a clear relationship to their water source.

**Key attractions:** Geothermal valley setting; Public pool circuit; Private bathing options.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://www.hotpools.co.nz/).

**Plan around:** Choose a managed pool ticket. A geothermal valley description never authorises bathing at an undeveloped hot spring.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.hotpools.co.nz/).

**Contact:** [Official visitor/contact route](https://www.hotpools.co.nz/).

**Evidence:** [Waikite Valley Thermal Pools / official publisher](https://www.hotpools.co.nz/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Opuke Thermal Pools and Spa

**Location:** Methven, Canterbury, New Zealand.

Opuke Thermal Pools and Spa in Methven, Canterbury brings together warm lazy river, matariki cave and mountain-view observation pools.

**Why go:** The family Discovery area offers a different visit from the venue's adult-only Tranquility and private packages.

**Key attractions:** Warm lazy river; Matariki cave; Mountain-view observation pools.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://opuke.nz/soak/discovery/).

**Plan around:** Discovery age categories, caregiver ratios and two-hour/four-hour sessions are product-specific. Accessible toilet facilities do not establish assisted pool access.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://opuke.nz/soak/discovery/).

**Contact:** [Official visitor/contact route](https://opuke.nz/soak/discovery/). Telephone: +64 3 261 6800.

**Evidence:** [Opuke Thermal Pools and Spa / official publisher](https://opuke.nz/soak/discovery/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Hanmer Springs Thermal Pools and Spa

**Location:** Hanmer Springs, Canterbury, New Zealand.

Hanmer Springs Thermal Pools and Spa in Hanmer Springs, Canterbury brings together thermal pools, hydroslides and alpine setting.

**Why go:** A combined bathing-and-play destination that can serve a mixed-interest group without needing two separate venues.

**Key attractions:** Thermal pools; Hydroslides; Alpine setting.

**Season, heated or mixed visit format:** All months. All-month visit-format context is inferred from the indoor or heated facility. It is not an established operating calendar; outdoor areas, maintenance, tickets and specific sessions need confirmation. [Season evidence](https://hanmersprings.co.nz/).

**Plan around:** The retrieved August-September 2026 facial offer has expired. Do not confuse it with a current pool-admission price.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://hanmersprings.co.nz/).

**Contact:** [Official visitor/contact route](https://hanmersprings.co.nz/).

**Evidence:** [Hanmer Springs Thermal Pools and Spa / official publisher](https://hanmersprings.co.nz/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Garden Grove, California

**Location:** Garden Grove, California, United States.

Great Wolf Lodge water park: Garden Grove, California in Garden Grove, California brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A managed indoor water day near Anaheim, without tying the plan to ocean conditions.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/southern-california).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/southern-california).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/southern-california).

**Evidence:** [Great Wolf Lodge water park: Garden Grove, California / official publisher](https://www.greatwolf.com/southern-california). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: LaGrange, Georgia

**Location:** LaGrange, Georgia, United States.

Great Wolf Lodge water park: LaGrange, Georgia in LaGrange, Georgia brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A self-contained water-play outing south of Atlanta rather than another outdoor reservoir stop.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/georgia).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/georgia).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/georgia).

**Evidence:** [Great Wolf Lodge water park: LaGrange, Georgia / official publisher](https://www.greatwolf.com/georgia). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Perryville, Maryland

**Location:** Perryville, Maryland, United States.

Great Wolf Lodge water park: Perryville, Maryland in Perryville, Maryland brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A large indoor option for a Mid-Atlantic trip when the water activity matters more than accommodation.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/maryland).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/maryland).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/maryland).

**Evidence:** [Great Wolf Lodge water park: Perryville, Maryland / official publisher](https://www.greatwolf.com/maryland). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Concord, North Carolina

**Location:** Concord, North Carolina, United States.

Great Wolf Lodge water park: Concord, North Carolina in Concord, North Carolina brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A water-focused alternative close to Charlotte, with the day-pass product separated from the resort stay.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/concord).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/concord).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/concord).

**Evidence:** [Great Wolf Lodge water park: Concord, North Carolina / official publisher](https://www.greatwolf.com/concord). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Gurnee, Illinois

**Location:** Gurnee, Illinois, United States.

Great Wolf Lodge water park: Gurnee, Illinois in Gurnee, Illinois brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** An indoor alternative for the Chicago-Milwaukee area when an outdoor lake outing does not fit the day.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/illinois).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/illinois).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/illinois).

**Evidence:** [Great Wolf Lodge water park: Gurnee, Illinois / official publisher](https://www.greatwolf.com/illinois). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Mason, Ohio

**Location:** Mason, Ohio, United States.

Great Wolf Lodge water park: Mason, Ohio in Mason, Ohio brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A distinct water-park choice in the Cincinnati area, rather than treating a hotel booking as compulsory.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/mason).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/mason).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/mason).

**Evidence:** [Great Wolf Lodge water park: Mason, Ohio / official publisher](https://www.greatwolf.com/mason). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Colorado Springs, Colorado

**Location:** Colorado Springs, Colorado, United States.

Great Wolf Lodge water park: Colorado Springs, Colorado in Colorado Springs, Colorado brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** An indoor-water break within a mountain-city itinerary, without implying access to natural hot springs.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/colorado-springs).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/colorado-springs).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/colorado-springs).

**Evidence:** [Great Wolf Lodge water park: Colorado Springs, Colorado / official publisher](https://www.greatwolf.com/colorado-springs). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Grapevine, Texas

**Location:** Grapevine, Texas, United States.

Great Wolf Lodge water park: Grapevine, Texas in Grapevine, Texas brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A Dallas-area indoor option that can be planned independently of swimming conditions on nearby lakes.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/grapevine).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/grapevine).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/grapevine).

**Evidence:** [Great Wolf Lodge water park: Grapevine, Texas / official publisher](https://www.greatwolf.com/grapevine). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Grand Mound, Washington

**Location:** Grand Mound, Washington, United States.

Great Wolf Lodge water park: Grand Mound, Washington in Grand Mound, Washington brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A managed indoor play day on a western Washington itinerary, not a claim about nearby river conditions.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/grand-mound).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/grand-mound).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/grand-mound).

**Evidence:** [Great Wolf Lodge water park: Grand Mound, Washington / official publisher](https://www.greatwolf.com/grand-mound). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Webster, Texas

**Location:** Webster, Texas, United States.

Great Wolf Lodge water park: Webster, Texas in Webster, Texas brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A Houston-area alternative when the group wants slides and pools instead of a coastal excursion.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/webster).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/webster).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/webster).

**Evidence:** [Great Wolf Lodge water park: Webster, Texas / official publisher](https://www.greatwolf.com/webster). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Kansas City, Kansas

**Location:** Kansas City, Kansas, United States.

Great Wolf Lodge water park: Kansas City, Kansas in Kansas City, Kansas brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** An inland water experience where the venue, rather than a natural shoreline, supplies the main attraction.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/kansas-city).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/kansas-city).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/kansas-city).

**Evidence:** [Great Wolf Lodge water park: Kansas City, Kansas / official publisher](https://www.greatwolf.com/kansas-city). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Mashantucket, Connecticut

**Location:** Mashantucket, Connecticut, United States.

Great Wolf Lodge water park: Mashantucket, Connecticut in Mashantucket, Connecticut brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A purpose-built water outing in southeastern Connecticut with a separate decision between day use and a stay.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/connecticut).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/connecticut).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/connecticut).

**Evidence:** [Great Wolf Lodge water park: Mashantucket, Connecticut / official publisher](https://www.greatwolf.com/connecticut). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Bloomington, Minnesota

**Location:** Bloomington, Minnesota, United States.

Great Wolf Lodge water park: Bloomington, Minnesota in Bloomington, Minnesota brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A Twin Cities indoor-water option that does not depend on the seasonal operation of outdoor swimming sites.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/minnesota).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/minnesota).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/minnesota).

**Evidence:** [Great Wolf Lodge water park: Bloomington, Minnesota / official publisher](https://www.greatwolf.com/minnesota). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Naples, Florida

**Location:** Naples, Florida, United States.

Great Wolf Lodge water park: Naples, Florida in Naples, Florida brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** An alternative to a Gulf beach day for visitors who specifically want managed water-play attractions.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/naples).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/naples).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/naples).

**Evidence:** [Great Wolf Lodge water park: Naples, Florida / official publisher](https://www.greatwolf.com/naples). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Fitchburg, Massachusetts

**Location:** Fitchburg, Massachusetts, United States.

Great Wolf Lodge water park: Fitchburg, Massachusetts in Fitchburg, Massachusetts brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A water-park trip in central Massachusetts rather than a Boston-city-centre attraction.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/new-england).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/new-england).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/new-england).

**Evidence:** [Great Wolf Lodge water park: Fitchburg, Massachusetts / official publisher](https://www.greatwolf.com/new-england). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Niagara Falls, Ontario

**Location:** Niagara Falls, Ontario, Canada.

Great Wolf Lodge water park: Niagara Falls, Ontario in Niagara Falls, Ontario brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A participatory water activity to pair with sightseeing around Niagara, without suggesting swimming at the falls.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/niagara).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/niagara).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/niagara).

**Evidence:** [Great Wolf Lodge water park: Niagara Falls, Ontario / official publisher](https://www.greatwolf.com/niagara). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Scotrun, Pennsylvania

**Location:** Scotrun, Pennsylvania, United States.

Great Wolf Lodge water park: Scotrun, Pennsylvania in Scotrun, Pennsylvania brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A slides-and-pools day in the Pocono Mountains that is separate from nearby lake or river activities.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/poconos).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/poconos).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/poconos).

**Evidence:** [Great Wolf Lodge water park: Scotrun, Pennsylvania / official publisher](https://www.greatwolf.com/poconos). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Manteca, California

**Location:** Manteca, California, United States.

Great Wolf Lodge water park: Manteca, California in Manteca, California brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** An inland Northern California water-park alternative, correctly located in Manteca rather than San Francisco.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/northern-california).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/northern-california).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/northern-california).

**Evidence:** [Great Wolf Lodge water park: Manteca, California / official publisher](https://www.greatwolf.com/northern-california). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Sandusky, Ohio

**Location:** Sandusky, Ohio, United States.

Great Wolf Lodge water park: Sandusky, Ohio in Sandusky, Ohio brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** An indoor water choice in the Sandusky visitor area, distinct from both Lake Erie beaches and amusement-park admission.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/sandusky).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/sandusky).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/sandusky).

**Evidence:** [Great Wolf Lodge water park: Sandusky, Ohio / official publisher](https://www.greatwolf.com/sandusky). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Scottsdale / Salt River, Arizona

**Location:** Scottsdale / Salt River, Arizona, United States.

Great Wolf Lodge water park: Scottsdale / Salt River, Arizona in Scottsdale / Salt River, Arizona brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A water-play destination within the Salt River Pima-Maricopa Indian Community, not a natural desert spring.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/arizona).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/arizona).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/arizona).

**Evidence:** [Great Wolf Lodge water park: Scottsdale / Salt River, Arizona / official publisher](https://www.greatwolf.com/arizona). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Traverse City, Michigan

**Location:** Traverse City, Michigan, United States.

Great Wolf Lodge water park: Traverse City, Michigan in Traverse City, Michigan brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** An indoor alternative within a lakeshore itinerary when the group wants pools rather than a beach.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/traverse-city).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/traverse-city).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/traverse-city).

**Evidence:** [Great Wolf Lodge water park: Traverse City, Michigan / official publisher](https://www.greatwolf.com/traverse-city). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Williamsburg, Virginia

**Location:** Williamsburg, Virginia, United States.

Great Wolf Lodge water park: Williamsburg, Virginia in Williamsburg, Virginia brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** A water-focused break from the surrounding heritage attractions, with its own admission decision.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/williamsburg).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/williamsburg).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/williamsburg).

**Evidence:** [Great Wolf Lodge water park: Williamsburg, Virginia / official publisher](https://www.greatwolf.com/williamsburg). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Great Wolf Lodge water park: Wisconsin Dells, Wisconsin

**Location:** Wisconsin Dells, Wisconsin, United States.

Great Wolf Lodge water park: Wisconsin Dells, Wisconsin in Wisconsin Dells, Wisconsin brings together indoor water park, water-play attractions and resort dining and dry activities.

**Why go:** One specific indoor water-park venue in a region with several competing parks, not a generic Dells listing.

**Key attractions:** Indoor water park; Water-play attractions; Resort dining and dry activities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.greatwolf.com/wisconsin-dells).

**Plan around:** Check this location's dated day-pass inventory and attraction height rules. Hotel opening hours are not pool hours. The advertised 84 degrees describes the indoor environment, not every pool's water temperature. Promotions and room rates are not admission fares.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.greatwolf.com/wisconsin-dells).

**Contact:** [Official visitor/contact route](https://www.greatwolf.com/wisconsin-dells).

**Evidence:** [Great Wolf Lodge water park: Wisconsin Dells, Wisconsin / official publisher](https://www.greatwolf.com/wisconsin-dells). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Lainesauna public sauna raft

**Location:** Oulu River, Oulu, Finland.

Lainesauna public sauna raft in Oulu River, Oulu brings together river-based sauna raft, hourly shared sessions and optional hot tub.

**Why go:** The floating setting changes the experience from a conventional spa, with a clearly separated hot-tub supplement.

**Key attractions:** River-based sauna raft; Hourly shared sessions; Optional hot tub.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.visitfinland.com/en/product/7bdb051f-646b-4c88-93e7-9edbe3390209/sauna-ticket-for-public-sauna/).

**Plan around:** A sauna slot lasts one hour; hot-tub access is a separate EUR 3 addition or a EUR 20 combination. Do not treat a room-rate or raft capacity as a group ticket.

**Published price reference:** EUR 17 / one-hour public sauna ticket. published reference. A sauna slot lasts one hour; hot-tub access is a separate EUR 3 addition or a EUR 20 combination. Do not treat a room-rate or raft capacity as a group ticket. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/7bdb051f-646b-4c88-93e7-9edbe3390209/sauna-ticket-for-public-sauna/).

**Tickets/access:** [Official ticket / operator information](https://www.lainesauna.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/7bdb051f-646b-4c88-93e7-9edbe3390209/sauna-ticket-for-public-sauna/).

**Evidence:** [Lainesauna public sauna raft / official publisher](https://www.visitfinland.com/en/product/7bdb051f-646b-4c88-93e7-9edbe3390209/sauna-ticket-for-public-sauna/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Avantosauna Lauteet

**Location:** Siilinlahti, Siilinjarvi, Finland.

Avantosauna Lauteet in Siilinlahti, Siilinjarvi brings together public lakeside sauna, card-operated single-visit wristbands and seasonal membership option.

**Why go:** Single-visit access makes the sauna relevant to travellers, without requiring a local membership.

**Key attractions:** Public lakeside sauna; Card-operated single-visit wristbands; Seasonal membership option.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.visitfinland.com/en/product/f159762f-3ea9-419a-ac8a-ae774a672c95/sauna-and-ice-swimming-experience/).

**Plan around:** The published public week excludes Monday; private use follows different terms. Ice swimming remains an optional cold-water exposure.

**Published price reference:** EUR 8 / starting single-visit product. published reference. The published public week excludes Monday; private use follows different terms. Ice swimming remains an optional cold-water exposure. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/f159762f-3ea9-419a-ac8a-ae774a672c95/sauna-and-ice-swimming-experience/).

**Tickets/access:** [Official ticket / operator information](https://lauteetsauna.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/f159762f-3ea9-419a-ac8a-ae774a672c95/sauna-and-ice-swimming-experience/).

**Evidence:** [Avantosauna Lauteet / official publisher](https://www.visitfinland.com/en/product/f159762f-3ea9-419a-ac8a-ae774a672c95/sauna-and-ice-swimming-experience/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Olosauna shared sauna

**Location:** Oulu River delta, Oulu, Finland.

Olosauna shared sauna in Oulu River delta, Oulu brings together modern sauna architecture, river-delta swimming area and towel and basic toiletries included.

**Why go:** A practical city visit for someone without their own sauna kit, with the water setting central to the experience.

**Key attractions:** Modern sauna architecture; River-delta swimming area; Towel and basic toiletries included.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.visitfinland.com/en/product/3751499a-91b6-4c92-ae3a-e0b679ed3209/public-sauna-experience/).

**Plan around:** The source describes a 90-minute visit. Do not repeat equipment-related wellbeing claims as medical benefits.

**Published price reference:** EUR 33.5 / starting 90-minute shared-sauna product. published reference. The source describes a 90-minute visit. Do not repeat equipment-related wellbeing claims as medical benefits. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/3751499a-91b6-4c92-ae3a-e0b679ed3209/public-sauna-experience/).

**Tickets/access:** [Official ticket / operator information](https://www.olosauna.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/3751499a-91b6-4c92-ae3a-e0b679ed3209/public-sauna-experience/).

**Evidence:** [Olosauna shared sauna / official publisher](https://www.visitfinland.com/en/product/3751499a-91b6-4c92-ae3a-e0b679ed3209/public-sauna-experience/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Niemi-Kapee public smoke sauna

**Location:** Lake Nasijarvi, Tampere region, Finland.

Niemi-Kapee public smoke sauna in Lake Nasijarvi, Tampere region brings together traditional log smoke sauna, lake nasijarvi setting and public evening programme.

**Why go:** The smoke-sauna format and farm setting provide a distinct alternative to an urban spa.

**Key attractions:** Traditional log smoke sauna; Lake Nasijarvi setting; Public evening programme.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.visitfinland.com/en/product/04824583-b578-4e5b-afd5-3f8630d634ca/relaxing-public-smoke-sauna/).

**Plan around:** Public evenings are only a few times a month, not daily opening. Soup and desserts cost extra; confirm the booking date.

**Published price reference:** EUR 25 / per person; public smoke-sauna evening. published reference. Public evenings are only a few times a month, not daily opening. Soup and desserts cost extra; confirm the booking date. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/04824583-b578-4e5b-afd5-3f8630d634ca/relaxing-public-smoke-sauna/).

**Tickets/access:** [Official ticket / operator information](https://www.niemikapee.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/04824583-b578-4e5b-afd5-3f8630d634ca/relaxing-public-smoke-sauna/).

**Evidence:** [Niemi-Kapee public smoke sauna / official publisher](https://www.visitfinland.com/en/product/04824583-b578-4e5b-afd5-3f8630d634ca/relaxing-public-smoke-sauna/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Kairosmaja winter sauna

**Location:** Lake Pyhajarvi, Pelkosenniemi, Finland.

Kairosmaja winter sauna in Lake Pyhajarvi, Pelkosenniemi brings together lapland lakeside sauna, winter swimming format and alcohol-free setting.

**Why go:** A winter-specific lake experience that is different from the identically named Lake Pyhajarvi near Tampere.

**Key attractions:** Lapland lakeside sauna; Winter swimming format; Alcohol-free setting.

**Season, operator program:** Dec, Jan, Feb, Mar, Apr. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/57ad68ba-fba9-4e92-9354-5d2b010afc0c/sauna-and-ice-swimming/).

**Plan around:** Bring towel and swimsuit. Published selected-weekday hours and current ice access need confirmation.

**Published price reference:** EUR 14 / starting public-sauna product. published reference. Bring towel and swimsuit. Published selected-weekday hours and current ice access need confirmation. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/57ad68ba-fba9-4e92-9354-5d2b010afc0c/sauna-and-ice-swimming/).

**Tickets/access:** [Official ticket / operator information](https://www.kairosmaja.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/57ad68ba-fba9-4e92-9354-5d2b010afc0c/sauna-and-ice-swimming/).

**Evidence:** [Kairosmaja winter sauna / official publisher](https://www.visitfinland.com/en/product/57ad68ba-fba9-4e92-9354-5d2b010afc0c/sauna-and-ice-swimming/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Viikinsaari island public sauna

**Location:** Viikinsaari, Lake Pyhajarvi, Tampere, Finland.

Viikinsaari island public sauna in Viikinsaari, Lake Pyhajarvi, Tampere brings together wood-burning island sauna, pier access and short walk from the ship harbour.

**Why go:** The ferry-to-island format makes the journey part of the outing, unlike a roadside sauna.

**Key attractions:** Wood-burning island sauna; Pier access; Short walk from the ship harbour.

**Season, operator program:** May, Jun, Jul, Aug. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/b0ee3b3b-b90b-43a4-9686-2e3c48387970/viikinsaari-islands-public-sauna/).

**Plan around:** Check the sauna and return-boat calendars together. A sauna starting price does not establish that boat transport is included.

**Published price reference:** EUR 15 / published starting product price; party basis requires confirmation. published reference. Check the sauna and return-boat calendars together. A sauna starting price does not establish that boat transport is included. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/b0ee3b3b-b90b-43a4-9686-2e3c48387970/viikinsaari-islands-public-sauna/).

**Tickets/access:** [Official ticket / operator information](https://www.hopealinjat.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/b0ee3b3b-b90b-43a4-9686-2e3c48387970/viikinsaari-islands-public-sauna/).

**Evidence:** [Viikinsaari island public sauna / official publisher](https://www.visitfinland.com/en/product/b0ee3b3b-b90b-43a4-9686-2e3c48387970/viikinsaari-islands-public-sauna/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Vihkosaari beach and recreation area

**Location:** Illinsaari, Ii, Finland.

Vihkosaari beach and recreation area in Illinsaari, Ii brings together marked 25-metre swimming lanes, swimming dock and picnic and play facilities.

**Why go:** Marked lanes make this a different proposition from an undefined wild-swimming shoreline.

**Key attractions:** Marked 25-metre swimming lanes; Swimming dock; Picnic and play facilities.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.visitfinland.com/en/product/14236ce2-8f58-4573-83e9-0ea2ae4ef189/vihkosaari-beach-and-recreation-area/).

**Plan around:** The source allows winter swimming, not universally suitable winter conditions. The opened source is old; verify maintained facilities and local advice.

**Published price reference:** EUR 0 / published free public access. published reference. The source allows winter swimming, not universally suitable winter conditions. The opened source is old; verify maintained facilities and local advice. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/14236ce2-8f58-4573-83e9-0ea2ae4ef189/vihkosaari-beach-and-recreation-area/).

**Tickets/access:** [Official ticket / operator information](https://www.visitii.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/14236ce2-8f58-4573-83e9-0ea2ae4ef189/vihkosaari-beach-and-recreation-area/).

**Evidence:** [Vihkosaari beach and recreation area / official publisher](https://www.visitfinland.com/en/product/14236ce2-8f58-4573-83e9-0ea2ae4ef189/vihkosaari-beach-and-recreation-area/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Etela-Konnevesi three-day kayak journey

**Location:** Southern Konnevesi; transfer from Tampere, Finland.

Etela-Konnevesi three-day kayak journey in Southern Konnevesi; transfer from Tampere brings together island maze, rocky lake shorelines and guided camping itinerary.

**Why go:** A multi-day island route offers immersion that a brief equipment rental cannot, with the transfer origin clearly distinguished.

**Key attractions:** Island maze; Rocky lake shorelines; Guided camping itinerary.

**Season, operator program:** Jun, Jul, Aug. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/14392eb4-3021-4123-9e5f-19fe8f421cdd/kayaking-tour-from-tampere-to-etela-konnevesi-national-park/).

**Plan around:** This is a three-day trip, not a day idea. Camping-equipment rental may be extra; wind can change or cancel the route.

**Published price reference:** EUR 210 / published starting product price; party basis requires confirmation. published reference. This is a three-day trip, not a day idea. Camping-equipment rental may be extra; wind can change or cancel the route. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/14392eb4-3021-4123-9e5f-19fe8f421cdd/kayaking-tour-from-tampere-to-etela-konnevesi-national-park/).

**Tickets/access:** [Official ticket / operator information](https://treshombres.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/14392eb4-3021-4123-9e5f-19fe8f421cdd/kayaking-tour-from-tampere-to-etela-konnevesi-national-park/).

**Evidence:** [Etela-Konnevesi three-day kayak journey / official publisher](https://www.visitfinland.com/en/product/14392eb4-3021-4123-9e5f-19fe8f421cdd/kayaking-tour-from-tampere-to-etela-konnevesi-national-park/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Yyteri beach and dunes

**Location:** Pori, Finland.

Yyteri beach and dunes in Pori brings together long sandy shoreline, protected dune landscape and public recreation area.

**Why go:** The combination of dunes and open shore makes a land-based coastal walk worthwhile even when swimming is unsuitable.

**Key attractions:** Long sandy shoreline; Protected dune landscape; Public recreation area.

**Season, shore visit format:** Not established. The source describes recreation across the year. No all-year water-entry or swimming season is established. [Season evidence](https://www.visitfinland.com/en/product/a6e0f40d-5989-42da-9dd7-296b07ae2973/pori-yyteri-beach-soft-sand-and-the-warmth-of-the-sun/).

**Plan around:** The publisher states all-year recreation access. This is not an all-year swimming window, and an undated Blue Flag statement is not a current award check.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.visitfinland.com/en/product/a6e0f40d-5989-42da-9dd7-296b07ae2973/pori-yyteri-beach-soft-sand-and-the-warmth-of-the-sun/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/a6e0f40d-5989-42da-9dd7-296b07ae2973/pori-yyteri-beach-soft-sand-and-the-warmth-of-the-sun/).

**Evidence:** [Yyteri beach and dunes / official publisher](https://www.visitfinland.com/en/product/a6e0f40d-5989-42da-9dd7-296b07ae2973/pori-yyteri-beach-soft-sand-and-the-warmth-of-the-sun/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Jarven Taiga Pielisjoki kayaking

**Location:** Pielisjoki River, Joensuu, Finland.

Jarven Taiga Pielisjoki kayaking in Pielisjoki River, Joensuu brings together river paddling, guided instruction and departure transfer from hasaniemi.

**Why go:** The included transfer resolves the difference between the meeting place and the paddling departure.

**Key attractions:** River paddling; Guided instruction; Departure transfer from Hasaniemi.

**Season, operator program:** May, Jun, Jul, Aug, Sep. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/cdbe6b14-d4c8-4c6b-86c8-aed35542b59f/pielisjoki-kayaking/).

**Plan around:** The retrieved programme is older than one year. Confirm the route and dates; no live departure or price is established.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.kalastusretket.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/cdbe6b14-d4c8-4c6b-86c8-aed35542b59f/pielisjoki-kayaking/).

**Evidence:** [Jarven Taiga Pielisjoki kayaking / official publisher](https://www.visitfinland.com/en/product/cdbe6b14-d4c8-4c6b-86c8-aed35542b59f/pielisjoki-kayaking/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Stromma Beautiful Canal Cruise

**Location:** Market Square, Helsinki, Finland.

Stromma Beautiful Canal Cruise in Market Square, Helsinki brings together degero canal, suomenlinna sea views and icebreaker-fleet waterfront.

**Why go:** A route chosen for a narrow canal and contrasting maritime districts, not merely another generic harbour circuit.

**Key attractions:** Degero Canal; Suomenlinna sea views; Icebreaker-fleet waterfront.

**Season, operator program:** May, Jun, Jul, Aug, Sep. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/04c866b7-f882-4049-adad-696652401883/beautiful-canal-cruise/).

**Plan around:** Published route is about 90 minutes and departs by the yellow flags at Market Square. Landmarks are viewed from the water; no landing ticket is implied.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.stromma.com/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/04c866b7-f882-4049-adad-696652401883/beautiful-canal-cruise/).

**Evidence:** [Stromma Beautiful Canal Cruise / official publisher](https://www.visitfinland.com/en/product/04c866b7-f882-4049-adad-696652401883/beautiful-canal-cruise/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Natura Viva Helsinki City Kayak

**Location:** Kaisaniemenranta, Helsinki, Finland.

Natura Viva Helsinki City Kayak in Kaisaniemenranta, Helsinki brings together city shoreline, nearby island picnic and guide-selected weather-dependent route.

**Why go:** See Helsinki at paddle level rather than from a fixed sightseeing-boat route.

**Key attractions:** City shoreline; Nearby island picnic; Guide-selected weather-dependent route.

**Season, operator program:** Jun, Jul, Aug. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/58540267-5d03-48eb-a1b6-952d724c1ac3/helsinki-city-kayak/).

**Plan around:** Three-hour programme; the guide selects the actual route. A possible island is not a guaranteed stop, and a general beginner claim is not personal suitability clearance.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://naturaviva.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/58540267-5d03-48eb-a1b6-952d724c1ac3/helsinki-city-kayak/).

**Evidence:** [Natura Viva Helsinki City Kayak / official publisher](https://www.visitfinland.com/en/product/58540267-5d03-48eb-a1b6-952d724c1ac3/helsinki-city-kayak/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Nagu Seakayak guided archipelago trips

**Location:** Nagu, Archipelago Sea, Finland.

Nagu Seakayak guided archipelago trips in Nagu, Archipelago Sea brings together archipelago paddling, tailored guided routes and cold-season specialist trips.

**Why go:** A useful counterexample to a summer-only paddling calendar: this operator also describes equipped cold-season trips.

**Key attractions:** Archipelago paddling; Tailored guided routes; Cold-season specialist trips.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.visitfinland.com/en/product/8975ceb1-06b8-4ffd-a0e1-dc1b7a36aafd/guided-kayaking-tours/).

**Plan around:** The publisher explicitly conditions winter paddling on unfrozen water and suitable equipment. Confirm dates, group price and experience requirements.

**Published price reference:** EUR 100 / published starting product price; party basis requires confirmation. published reference. The publisher explicitly conditions winter paddling on unfrozen water and suitable equipment. Confirm dates, group price and experience requirements. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/8975ceb1-06b8-4ffd-a0e1-dc1b7a36aafd/guided-kayaking-tours/).

**Tickets/access:** [Official ticket / operator information](https://www.naguseakayak.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/8975ceb1-06b8-4ffd-a0e1-dc1b7a36aafd/guided-kayaking-tours/).

**Evidence:** [Nagu Seakayak guided archipelago trips / official publisher](https://www.visitfinland.com/en/product/8975ceb1-06b8-4ffd-a0e1-dc1b7a36aafd/guided-kayaking-tours/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Nallikari Oulu Delta kayaking safari

**Location:** Nallikari and Oulu River delta, Finland.

Nallikari Oulu Delta kayaking safari in Nallikari and Oulu River delta brings together mustasalmi channel, river-delta islands and guided introduction to kayaking.

**Why go:** The transition from seaside to river channels offers varied scenery within a local outing.

**Key attractions:** Mustasalmi channel; River-delta islands; Guided introduction to kayaking.

**Season, operator program:** Jun, Jul, Aug, Sep. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/c375399e-06b0-486d-a349-72d6c1864a75/kayaking-safari-nallikari-oulu/).

**Plan around:** The source is over one year old. Confirm meeting point at Nallikarinranta 10 and the actual route; Market Square is only a possible stop.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://nallikarisafaris.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/c375399e-06b0-486d-a349-72d6c1864a75/kayaking-safari-nallikari-oulu/).

**Evidence:** [Nallikari Oulu Delta kayaking safari / official publisher](https://www.visitfinland.com/en/product/c375399e-06b0-486d-a349-72d6c1864a75/kayaking-safari-nallikari-oulu/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Tres Hombres Archipelago National Park expedition

**Location:** Archipelago Sea; transfer from Tampere, Finland.

Tres Hombres Archipelago National Park expedition in Archipelago Sea; transfer from Tampere brings together five-day island route, rock-shore camping and fishing-village context.

**Why go:** A multi-day sea-kayak journey has a different purpose and commitment from a short inland-lake tour.

**Key attractions:** Five-day island route; Rock-shore camping; Fishing-village context.

**Season, operator program:** Jun, Jul, Aug. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/f852432b-af2d-4792-9143-f6ee6d9cd298/kayaking-tour-from-tampere-to-archipelago-national-park/).

**Plan around:** Five days; advertised daily paddling can reach about 35 km. Wind changes the itinerary. Camping equipment and transfer inclusions need confirmation.

**Published price reference:** EUR 420 / published starting product price; party basis requires confirmation. published reference. Five days; advertised daily paddling can reach about 35 km. Wind changes the itinerary. Camping equipment and transfer inclusions need confirmation. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/f852432b-af2d-4792-9143-f6ee6d9cd298/kayaking-tour-from-tampere-to-archipelago-national-park/).

**Tickets/access:** [Official ticket / operator information](https://treshombres.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/f852432b-af2d-4792-9143-f6ee6d9cd298/kayaking-tour-from-tampere-to-archipelago-national-park/).

**Evidence:** [Tres Hombres Archipelago National Park expedition / official publisher](https://www.visitfinland.com/en/product/f852432b-af2d-4792-9143-f6ee6d9cd298/kayaking-tour-from-tampere-to-archipelago-national-park/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Olo Center Saimaa guided paddling

**Location:** Matkolahti, Lake Saimaa, Enonkoski, Finland.

Olo Center Saimaa guided paddling in Matkolahti, Lake Saimaa, Enonkoski brings together lake cliffs, rock-painting context and guided paddling with lunch.

**Why go:** The interpretation and lunch make this a fuller outing than equipment hire, with an identified departure area.

**Key attractions:** Lake cliffs; Rock-painting context; Guided paddling with lunch.

**Season, operator program:** May, Jun, Jul, Aug, Sep. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/116afc2e-0031-4079-b01d-31c46936fab3/guided-paddling-tour-in-saimaa-kayak-canoe-sup/).

**Plan around:** The EUR 90 reference is the 4-5-hour product; the 7-8-hour product is EUR 135. Ringed-seal sightings are not guaranteed.

**Published price reference:** EUR 90 / per person; 4-5-hour guided programme. published reference. The EUR 90 reference is the 4-5-hour product; the 7-8-hour product is EUR 135. Ringed-seal sightings are not guaranteed. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/116afc2e-0031-4079-b01d-31c46936fab3/guided-paddling-tour-in-saimaa-kayak-canoe-sup/).

**Tickets/access:** [Official ticket / operator information](https://www.olo.center/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/116afc2e-0031-4079-b01d-31c46936fab3/guided-paddling-tour-in-saimaa-kayak-canoe-sup/). Telephone: +358 401 258 992. Email: info@olocentre.com.

**Evidence:** [Olo Center Saimaa guided paddling / official publisher](https://www.visitfinland.com/en/product/116afc2e-0031-4079-b01d-31c46936fab3/guided-paddling-tour-in-saimaa-kayak-canoe-sup/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Levi lake ferry and sauna outing

**Location:** Lakes Sirkkajarvi and Levijarvi, Levi, Finland.

Levi lake ferry and sauna outing in Lakes Sirkkajarvi and Levijarvi, Levi brings together lapland lake cruise, onboard sauna format and crepes and fireside coffee.

**Why go:** A lake-based summer or autumn alternative in a destination often associated with winter activities.

**Key attractions:** Lapland lake cruise; Onboard sauna format; Crepes and fireside coffee.

**Season, operator program:** Jun, Jul, Aug, Sep. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/cfbfd816-28cd-4f8f-a4f7-32b3a293c223/ferry-cruise/).

**Plan around:** This is an excursion, not a scheduled public transport ferry. The office address is not the boat departure. Aurora mentions are not a sighting promise.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.levi.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/cfbfd816-28cd-4f8f-a4f7-32b3a293c223/ferry-cruise/).

**Evidence:** [Levi lake ferry and sauna outing / official publisher](https://www.visitfinland.com/en/product/cfbfd816-28cd-4f8f-a4f7-32b3a293c223/ferry-cruise/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Saimaan Palju Repovesi kayak outing

**Location:** Lapinsalmi, Repovesi National Park, Finland.

Saimaan Palju Repovesi kayak outing in Lapinsalmi, Repovesi National Park brings together forest-fringed lakes, cliff scenery and campfire snack stop.

**Why go:** A short guided route makes a water perspective on Repovesi possible without committing to an expedition.

**Key attractions:** Forest-fringed lakes; Cliff scenery; Campfire snack stop.

**Season, operator program:** May, Jun, Jul, Aug, Sep. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/96b525f7-da78-4d36-9732-636f0b965d1f/kayaking-trip-in-repovesi-national-park/).

**Plan around:** Approximate duration three hours. The break location changes with weather and group needs; verify participation requirements.

**Published price reference:** EUR 65 / published starting product price; party basis requires confirmation. published reference. Approximate duration three hours. The break location changes with weather and group needs; verify participation requirements. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/96b525f7-da78-4d36-9732-636f0b965d1f/kayaking-trip-in-repovesi-national-park/).

**Tickets/access:** [Official ticket / operator information](https://www.saimaanpalju.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/96b525f7-da78-4d36-9732-636f0b965d1f/kayaking-trip-in-repovesi-national-park/).

**Evidence:** [Saimaan Palju Repovesi kayak outing / official publisher](https://www.visitfinland.com/en/product/96b525f7-da78-4d36-9732-636f0b965d1f/kayaking-trip-in-repovesi-national-park/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Jarven Taiga Kolovesi kayak day

**Location:** Kolovesi National Park; transfer from Joensuu, Finland.

Jarven Taiga Kolovesi kayak day in Kolovesi National Park; transfer from Joensuu brings together rock paintings, cliff-lined lake route and included joensuu transfer.

**Why go:** Useful for someone without their own vehicle or kayak, with travel time separated from time on the water.

**Key attractions:** Rock paintings; Cliff-lined lake route; Included Joensuu transfer.

**Season, operator program:** May, Jun, Jul, Aug, Sep. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/7a44e820-4712-4b32-afd1-7b07ca728ae2/kayaking-trip-to-kolovesi-national-park-from-joensuu/).

**Plan around:** Five to six hours total includes roughly three hours of paddling. Bring snacks; embarkation changes with conditions. The retrieved programme needs current confirmation.

**Published price reference:** EUR 120 / published starting product price; party basis requires confirmation. published reference. Five to six hours total includes roughly three hours of paddling. Bring snacks; embarkation changes with conditions. The retrieved programme needs current confirmation. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/7a44e820-4712-4b32-afd1-7b07ca728ae2/kayaking-trip-to-kolovesi-national-park-from-joensuu/).

**Tickets/access:** [Official ticket / operator information](https://www.kalastusretket.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/7a44e820-4712-4b32-afd1-7b07ca728ae2/kayaking-trip-to-kolovesi-national-park-from-joensuu/).

**Evidence:** [Jarven Taiga Kolovesi kayak day / official publisher](https://www.visitfinland.com/en/product/7a44e820-4712-4b32-afd1-7b07ca728ae2/kayaking-trip-to-kolovesi-national-park-from-joensuu/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Naawa Korpo introductory kayaking

**Location:** Korpo archipelago, Finland.

Naawa Korpo introductory kayaking in Korpo archipelago brings together near-island sea route, equipment introduction and cliffside coffee break.

**Why go:** A deliberately local archipelago route offers a different commitment from multi-day sea kayaking.

**Key attractions:** Near-island sea route; Equipment introduction; Cliffside coffee break.

**Season, operator program:** May, Jun, Jul, Aug, Sep. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/c30c1b42-1416-437d-8162-f21d6785c9fa/beginners-kayaking-tour/).

**Plan around:** The source describes three to four hours. Confirm age, ability, sea conditions and current starting price.

**Published price reference:** EUR 90 / published starting product price; party basis requires confirmation. published reference. The source describes three to four hours. Confirm age, ability, sea conditions and current starting price. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/c30c1b42-1416-437d-8162-f21d6785c9fa/beginners-kayaking-tour/).

**Tickets/access:** [Official ticket / operator information](https://www.naawanature.com/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/c30c1b42-1416-437d-8162-f21d6785c9fa/beginners-kayaking-tour/).

**Evidence:** [Naawa Korpo introductory kayaking / official publisher](https://www.visitfinland.com/en/product/c30c1b42-1416-437d-8162-f21d6785c9fa/beginners-kayaking-tour/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Hiukka beach and sand ridges

**Location:** Lake Sapsojarvi, Sotkamo, Finland.

Hiukka beach and sand ridges in Lake Sapsojarvi, Sotkamo brings together sandy lake shore, kainuu ridge landscape and nearby nature trails.

**Why go:** The sand-ridge setting gives the beach a landscape interest beyond a generic town swimming area.

**Key attractions:** Sandy lake shore; Kainuu ridge landscape; Nearby nature trails.

**Season, shore visit format:** Not established. The source describes recreation across the year. No all-year water-entry or swimming season is established. [Season evidence](https://www.visitfinland.com/en/product/5ffa065f-e7ba-4e83-8d38-b62e28a8edf1/hiukka-beach-in-sotkamo/).

**Plan around:** The all-year label covers the recreation area and winter trails, not an all-year swimming season. Summer cafe and services are seasonal.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://vuokatti.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/5ffa065f-e7ba-4e83-8d38-b62e28a8edf1/hiukka-beach-in-sotkamo/).

**Evidence:** [Hiukka beach and sand ridges / official publisher](https://www.visitfinland.com/en/product/5ffa065f-e7ba-4e83-8d38-b62e28a8edf1/hiukka-beach-in-sotkamo/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: MS Elviira Savonlinna archipelago cruise

**Location:** Savonlinna, Lake Saimaa, Finland.

MS Elviira Savonlinna archipelago cruise in Savonlinna, Lake Saimaa brings together olavinlinna viewed from the lake, island cottages and onboard cafe.

**Why go:** A compact way to see the castle in its waterside setting instead of assuming a castle-entry visit.

**Key attractions:** Olavinlinna viewed from the lake; Island cottages; Onboard cafe.

**Season, operator program:** May, Jun, Jul, Aug, Sep, Oct, Nov, Dec. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/e6d65d64-5042-4cf0-bca6-5630d210c919/cruise-to-the-savonlinna-archipelago-on-ms-elviira-lake-saimaa-region/).

**Plan around:** Publisher month tags include May-December, not a verified daily timetable. July opera-pier stops and languages vary; the EUR 12 starting category needs confirmation.

**Published price reference:** EUR 12 / published starting product price; party basis requires confirmation. published reference. Publisher month tags include May-December, not a verified daily timetable. July opera-pier stops and languages vary; the EUR 12 starting category needs confirmation. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/e6d65d64-5042-4cf0-bca6-5630d210c919/cruise-to-the-savonlinna-archipelago-on-ms-elviira-lake-saimaa-region/).

**Tickets/access:** [Official ticket / operator information](https://savonlinnaristeilyt.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/e6d65d64-5042-4cf0-bca6-5630d210c919/cruise-to-the-savonlinna-archipelago-on-ms-elviira-lake-saimaa-region/).

**Evidence:** [MS Elviira Savonlinna archipelago cruise / official publisher](https://www.visitfinland.com/en/product/e6d65d64-5042-4cf0-bca6-5630d210c919/cruise-to-the-savonlinna-archipelago-on-ms-elviira-lake-saimaa-region/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: MS J.L. Runeberg Helsinki-Porvoo cruise

**Location:** Linnanlaituri, Helsinki to Porvoo, Finland.

MS J.L. Runeberg Helsinki-Porvoo cruise in Linnanlaituri, Helsinki to Porvoo brings together historic vessel, archipelago passage and porvoo destination.

**Why go:** The destination-to-destination route can serve both sightseeing and a real change of place.

**Key attractions:** Historic vessel; Archipelago passage; Porvoo destination.

**Season, operator program:** May, Jun, Jul, Aug, Sep. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/ef972851-e246-431c-991e-1ab79550b4b4/cruise-from-helsinki-to-porvoo-on-historical-ms-j-l-runeberg/).

**Plan around:** Confirm whether the selected fare is one-way or return and allow for the actual sailing duration. Reduced ticket categories are separate.

**Published price reference:** EUR 33 / published starting product price; party basis requires confirmation. published reference. Confirm whether the selected fare is one-way or return and allow for the actual sailing duration. Reduced ticket categories are separate. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/ef972851-e246-431c-991e-1ab79550b4b4/cruise-from-helsinki-to-porvoo-on-historical-ms-j-l-runeberg/).

**Tickets/access:** [Official ticket / operator information](https://www.msjlruneberg.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/ef972851-e246-431c-991e-1ab79550b4b4/cruise-from-helsinki-to-porvoo-on-historical-ms-j-l-runeberg/).

**Evidence:** [MS J.L. Runeberg Helsinki-Porvoo cruise / official publisher](https://www.visitfinland.com/en/product/ef972851-e246-431c-991e-1ab79550b4b4/cruise-from-helsinki-to-porvoo-on-historical-ms-j-l-runeberg/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Harjun Portti cycling and Polaris 1 cruise

**Location:** Punkaharju, Lake Saimaa, Finland.

Harjun Portti cycling and Polaris 1 cruise in Punkaharju, Lake Saimaa brings together nature-reserve cycling, boat return with bikes and sauna and island stops.

**Why go:** The bike-out, boat-back format produces a genuinely different day from a circular sightseeing cruise.

**Key attractions:** Nature-reserve cycling; Boat return with bikes; Sauna and island stops.

**Season, operator program:** Jun, Jul, Aug. Publisher lists these activity months. Availability, weather and an individual departure still require confirmation. [Season evidence](https://www.visitfinland.com/en/product/02046198-5f19-49bc-ac79-06da7d12c6ca/cycling-adventure-cruise-in-punkaharju-lake-saimaa-region/).

**Plan around:** The published EUR 99 excludes bike rental and requires at least four participants. Selected summer weekdays only; 30 km cycling is not a universal family fit.

**Published price reference:** EUR 99 / per person cruise component; bicycle rental extra. published reference. The published EUR 99 excludes bike rental and requires at least four participants. Selected summer weekdays only; 30 km cycling is not a universal family fit. Not a live or all-in quote. [Publisher](https://www.visitfinland.com/en/product/02046198-5f19-49bc-ac79-06da7d12c6ca/cycling-adventure-cruise-in-punkaharju-lake-saimaa-region/).

**Tickets/access:** [Official ticket / operator information](https://www.harjunportti.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/02046198-5f19-49bc-ac79-06da7d12c6ca/cycling-adventure-cruise-in-punkaharju-lake-saimaa-region/).

**Evidence:** [Harjun Portti cycling and Polaris 1 cruise / official publisher](https://www.visitfinland.com/en/product/02046198-5f19-49bc-ac79-06da7d12c6ca/cycling-adventure-cruise-in-punkaharju-lake-saimaa-region/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Vesaniemi sauna and beach

**Location:** Lake Vesijarvi, Kangasala, Finland.

Vesaniemi sauna and beach in Lake Vesijarvi, Kangasala brings together municipal lakeside sauna, summer public sessions and winter swimming clubs.

**Why go:** One location with distinct summer and winter operators, rather than two artificially separate attractions.

**Key attractions:** Municipal lakeside sauna; Summer public sessions; Winter swimming clubs.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.visitfinland.com/en/product/4fa97c9e-998f-4c37-986f-197dbd16dde4/vesaniemen-uimaranta-ja-sauna/).

**Plan around:** Private rental is year-round. Public winter sessions run September-May; summer sessions have a different organiser. Confirm the correct booking channel.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.kangasala.fi/).

**Contact:** [Official visitor/contact route](https://www.visitfinland.com/en/product/4fa97c9e-998f-4c37-986f-197dbd16dde4/vesaniemen-uimaranta-ja-sauna/).

**Evidence:** [Vesaniemi sauna and beach / official publisher](https://www.visitfinland.com/en/product/4fa97c9e-998f-4c37-986f-197dbd16dde4/vesaniemen-uimaranta-ja-sauna/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: World Waterpark at West Edmonton Mall

**Location:** West Edmonton Mall, Edmonton, Alberta, Canada.

World Waterpark at West Edmonton Mall in West Edmonton Mall, Edmonton, Alberta brings together indoor wave pool, water slides and separately scheduled indoor surfing.

**Why go:** A genuine indoor water day within a shopping complex, with surfing as a separate planned experience rather than an assumed admission inclusion.

**Key attractions:** Indoor wave pool; Water slides; Separately scheduled indoor surfing.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.wem.ca/play/attractions/world-waterpark).

**Plan around:** The operator describes year-round indoor use. Surf sessions, lessons and cabanas need separate booking checks; do not reuse an expired summer multi-pass.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.wem.ca/play/attractions/world-waterpark).

**Contact:** [Official visitor/contact route](https://www.wem.ca/play/attractions/world-waterpark).

**Evidence:** [World Waterpark at West Edmonton Mall / official publisher](https://www.wem.ca/play/attractions/world-waterpark). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Valley of Waves

**Location:** Sun City, North West, South Africa.

Valley of Waves in Sun City, North West brings together roaring lagoon wave pool, temple of courage slide and dedicated children's area.

**Why go:** An inland wave-beach outing with a distinct choice between the lagoon and high-intensity slides.

**Key attractions:** Roaring Lagoon wave pool; Temple of Courage slide; Dedicated children's area.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.suninternational.com/sun-city/activities/valley-of-waves).

**Plan around:** Day visitors need the correct prepurchased ticket and capacity is limited. Resident or hotel-guest inclusions cannot be advertised as free access for everyone.

**Published price reference:** ZAR 415 / adult day visitor, weekday excluding public holidays. published reference. Weekend/public-holiday adult reference is ZAR 470; ticket availability and current tariff require confirmation. Not a live or all-in quote. [Publisher](https://www.suninternational.com/sun-city/activities/valley-of-waves).

**Tickets/access:** [Official ticket / operator information](https://suncity.ticketproshop.co.za/).

**Contact:** [Official visitor/contact route](https://www.suninternational.com/sun-city/activities/valley-of-waves).

**Evidence:** [Valley of Waves / official publisher](https://www.suninternational.com/sun-city/activities/valley-of-waves). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Oasiria Marrakech

**Location:** Marrakech, Morocco.

Oasiria Marrakech in Marrakech brings together garden setting, pools and slides and black hole double-tube ride.

**Why go:** The planted grounds give this a garden-and-water format rather than a slide-only park.

**Key attractions:** Garden setting; Pools and slides; Black Hole double-tube ride.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://oasiria.com/en/).

**Plan around:** Cached opening text and weather are not a live operating check. Confirm the date-specific park season and which pools or slides are available.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://oasiria.com/en/).

**Contact:** [Official visitor/contact route](https://oasiria.com/en/).

**Evidence:** [Oasiria Marrakech / official publisher](https://oasiria.com/en/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Ramayana Water Park

**Location:** Pattaya area, Thailand.

Ramayana Water Park in Pattaya area brings together aquacoaster, double wave pool and lazy river and children's zones.

**Why go:** A useful alternative to a sea excursion when a group wants several ride intensities in one managed venue.

**Key attractions:** Aquacoaster; Double wave pool; Lazy river and children's zones.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.ramayanawaterpark.com/).

**Published restriction:** Publisher lists Wednesday as its weekly closure. Confirm holiday exceptions and the current schedule. [Source](https://www.ramayanawaterpark.com/).

**Plan around:** Publisher says closed Wednesdays. Height, weight and participation rules apply by ride; the general family description is not an all-rides eligibility claim.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.ramayanawaterpark.com/).

**Contact:** [Official visitor/contact route](https://www.ramayanawaterpark.com/).

**Evidence:** [Ramayana Water Park / official publisher](https://www.ramayanawaterpark.com/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Vana Nava Water Jungle

**Location:** Hua Hin, Thailand.

Vana Nava Water Jungle in Hua Hin brings together lazy river through planted scenery, abyss group slide and double flowrider.

**Why go:** Combines a slow river circuit with group rides and a surf simulator, letting companions choose different activity levels.

**Key attractions:** Lazy river through planted scenery; Abyss group slide; Double FlowRider.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.vananavahuahin.com/).

**Plan around:** A resort-room benefit, day ticket, surf session and virtual-reality upgrade may have different terms. Current annual dates and weather interruptions need confirmation.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://booking.vananavahuahin.com/).

**Contact:** [Official visitor/contact route](https://www.vananavahuahin.com/).

**Evidence:** [Vana Nava Water Jungle / official publisher](https://www.vananavahuahin.com/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Aquaventure Waterpark Dubai

**Location:** Atlantis The Palm, Palm Jumeirah, Dubai, United Arab Emirates.

Aquaventure Waterpark Dubai in Atlantis The Palm, Palm Jumeirah, Dubai brings together trident tower slides, group tube rides and river circuits.

**Why go:** The spread of group rides and river experiences creates a different choice from a single pool or beach visit.

**Key attractions:** Trident Tower slides; Group tube rides; River circuits.

**Season, operator program:** All months. Publisher describes an all-year or recurring operating pattern. This is not a live calendar or confirmation of every date. [Season evidence](https://www.aquaventureworld.com/aquaventure-waterpark/discover-attractions).

**Plan around:** Use the operator's ride-specific height filters. The Lost World Aquarium has its own ticket unless explicitly bundled. Do not reuse an old October early-closing notice.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.aquaventureworld.com/tickets).

**Contact:** [Official visitor/contact route](https://www.aquaventureworld.com/aquaventure-waterpark/discover-attractions).

**Evidence:** [Aquaventure Waterpark Dubai / official publisher](https://www.aquaventureworld.com/aquaventure-waterpark/discover-attractions). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Yas Waterworld Abu Dhabi

**Location:** Yas Island, Abu Dhabi, United Arab Emirates.

Yas Waterworld Abu Dhabi in Yas Island, Abu Dhabi brings together water slides, family ride options and height-based eligibility information.

**Why go:** The operator's published height distinctions help families compare the actual visit rather than assume one family label fits every slide.

**Key attractions:** Water slides; Family ride options; Height-based eligibility information.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.yaswaterworld.com/en/faq).

**Plan around:** Children below 1.1 m cannot use every ride. Event-specific admission and multi-park bundles have separate terms; check date-specific hours.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.yaswaterworld.com/en/tickets/single-day-ticket).

**Contact:** [Official visitor/contact route](https://www.yaswaterworld.com/en/faq). Telephone: +971 2 496 8000.

**Evidence:** [Yas Waterworld Abu Dhabi / official publisher](https://www.yaswaterworld.com/en/faq); [Yas Waterworld Abu Dhabi / official publisher](https://www.yaswaterworld.com/en/tickets/single-day-ticket). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Beach Park Aqua Park

**Location:** Porto das Dunas, Aquiraz, Ceara, Brazil.

Beach Park Aqua Park in Porto das Dunas, Aquiraz, Ceara brings together wave pool, lazy river and insano and group raft rides.

**Why go:** The division between relaxed, family and high-intensity attractions makes this a full water-park day rather than another coastal bathing spot.

**Key attractions:** Wave pool; Lazy river; Insano and group raft rides.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://beachpark.com.br/en/experiences/aqua-park/attractions/).

**Plan around:** An attraction on the published list is not a guarantee that it is operating. Check the visit date and ride-specific restrictions; park and hotel purchases are separate.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://beachpark.com.br/).

**Contact:** [Official visitor/contact route](https://beachpark.com.br/en/experiences/aqua-park/attractions/).

**Evidence:** [Beach Park Aqua Park / official publisher](https://beachpark.com.br/en/experiences/aqua-park/attractions/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Universal Volcano Bay

**Location:** Universal Orlando Resort, Orlando, Florida, United States.

Universal Volcano Bay in Universal Orlando Resort, Orlando, Florida brings together krakatau volcano setting, kopiko wai winding river and multi-person raft rides.

**Why go:** The themed river and raft-ride mix makes a distinctive future water-park day, but it is not currently a go-now option.

**Key attractions:** Krakatau volcano setting; Kopiko Wai Winding River; Multi-person raft rides.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://www.universalorlando.com/web/en/us/theme-parks/volcano-bay).

**Published restriction:** Published maintenance closure; reopening needs confirmation, not an automatic calendar flip. Planned reopening is on or before 2027-04-01, subject to change. [Source](https://www.universalorlando.com/web/en/us/plan-your-visit/hours-information/park-hours).

**Plan around:** Operator reports maintenance closure, with planned reopening on or before 1 April 2027, subject to change. No automatic reopening or current ticket availability is inferred.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://www.universalorlando.com/web/en/us/theme-parks/volcano-bay).

**Contact:** [Official visitor/contact route](https://www.universalorlando.com/web/en/us/theme-parks/volcano-bay).

**Evidence:** [Universal Volcano Bay / official publisher](https://www.universalorlando.com/web/en/us/theme-parks/volcano-bay); [Universal Volcano Bay / official publisher](https://www.universalorlando.com/web/en/us/plan-your-visit/hours-information/park-hours). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Disney's Typhoon Lagoon

**Location:** Walt Disney World Resort, Florida, United States.

Disney's Typhoon Lagoon in Walt Disney World Resort, Florida brings together tropical storm theming, wave pool and raft rides and children's area.

**Why go:** A tropical-themed water-park alternative whose opening must be checked separately from Blizzard Beach.

**Key attractions:** Tropical storm theming; Wave pool; Raft rides and children's area.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://disneyworld.disney.go.com/destinations/water-parks/).

**Plan around:** The operator says to check which water park is open. A ticket valid for either park is not proof both are operating; refurbishment and weather can close individual venues.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://disneyworld.disney.go.com/destinations/typhoon-lagoon/).

**Contact:** [Official visitor/contact route](https://disneyworld.disney.go.com/destinations/water-parks/).

**Evidence:** [Disney's Typhoon Lagoon / official publisher](https://disneyworld.disney.go.com/destinations/water-parks/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.

### Additional discovery: Disney's Blizzard Beach

**Location:** Walt Disney World Resort, Florida, United States.

Disney's Blizzard Beach in Walt Disney World Resort, Florida brings together melting ski-resort theming, water slides and scaled-down children's attractions.

**Why go:** The snow-resort setting gives the water experience a different character from a conventional tropical park.

**Key attractions:** Melting ski-resort theming; Water slides; Scaled-down children's attractions.

**Season, operator program:** Not established. No dependable activity-month window established. No all-year assumption. [Season evidence](https://disneyworld.disney.go.com/destinations/water-parks/).

**Plan around:** The operator says to check which water park is open. A ticket valid for either park is not proof both are operating; refurbishment and weather can close individual venues.

**Cost:** No numeric price established. Use the official route; unknown is not free.

**Tickets/access:** [Official ticket / operator information](https://disneyworld.disney.go.com/destinations/blizzard-beach/).

**Contact:** [Official visitor/contact route](https://disneyworld.disney.go.com/destinations/water-parks/).

**Evidence:** [Disney's Blizzard Beach / official publisher](https://disneyworld.disney.go.com/destinations/water-parks/). New official-publisher desk research, including cached pages and search excerpts. No image rights or exact entrance coordinates supplied.
