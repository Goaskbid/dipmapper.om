/** Minimal cookie-only checklist. No accounts, localStorage, IndexedDB or device identifiers. */
export const COOKIE_NAME='dm_water_v3';
export const MAX_COOKIE_BYTES=3800;
export const MAX_IMPORT_BYTES=1000000;
export const RETENTION_DAYS=180;
export function fingerprint(s){let h=2166136261;for(const c of new TextEncoder().encode(s)){h^=c;h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
export function registryPrefix(registry,n){if(!Number.isInteger(n)||n<0||n>registry.slots.length)throw new RangeError('Invalid registry length.');return fingerprint(registry.slots.slice(0,n).map(s=>s.id).join('\n'));}
function to64(bytes){let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');}
function from64(s){if(!/^[A-Za-z0-9_-]*$/.test(s))throw new TypeError('Invalid cookie encoding.');const t=atob(s.replaceAll('-','+').replaceAll('_','/')+'='.repeat((4-s.length%4)%4));return Uint8Array.from(t,c=>c.charCodeAt(0));}
export function encodePassport(states,registry){
 if(states.length!==registry.slots.length)throw new Error('Registry/state mismatch.');
 const bytes=new Uint8Array(Math.ceil(states.length/4));
 states.forEach((v,i)=>{if(![0,1,2].includes(v))throw new RangeError('Unknown checklist flag.');bytes[Math.floor(i/4)]|=v<<((i%4)*2);});
 const body=`3.${states.length}.${registryPrefix(registry,states.length)}.${to64(bytes)}`;
 const value=body+'.'+fingerprint(body);
 if(new TextEncoder().encode(COOKIE_NAME+'='+value).length>MAX_COOKIE_BYTES)throw new RangeError('Checklist exceeds the cookie budget. Export it before adding more.');
 return value;
}
export function decodePassport(value,registry){
 if(typeof value!=='string'||value.length>MAX_COOKIE_BYTES)throw new RangeError('Invalid cookie size.');
 const p=value.split('.');if(p.length!==5||p[0]!=='3'||!/^\d+$/.test(p[1]))throw new TypeError('Unsupported checklist.');
 const n=Number(p[1]);if(n>registry.slots.length||n<0||p[2]!==registryPrefix(registry,n))throw new Error('Checklist registry does not match. Preserve this cookie and export before migration.');
 if(fingerprint(p.slice(0,4).join('.'))!==p[4])throw new Error('Checklist checksum failed.');
 const bytes=from64(p[3]);if(bytes.length!==Math.ceil(n/4))throw new Error('Checklist length mismatch.');
 const states=new Uint8Array(registry.slots.length);
 for(let i=0;i<bytes.length*4;i++){const v=(bytes[Math.floor(i/4)]>>((i%4)*2))&3;if(i>=n&&v!==0)throw new Error('Invalid padding.');if(v===3)throw new Error('Invalid flag.');if(i<n)states[i]=v;}
 return states;
}
export function readNamedCookie(text,name=COOKIE_NAME){const values=String(text||'').split(';').map(s=>s.trim()).filter(s=>s.startsWith(name+'='));if(values.length>1)throw new Error('Conflicting cookies with the same name.');return values.length?values[0].slice(name.length+1):null;}
export function exportPassport(states,registry){
 const wanted=[],visited=[];states.forEach((v,i)=>{if(v===1)wanted.push(registry.slots[i].id);if(v===2)visited.push(registry.slots[i].id);});
 return JSON.stringify({format:'dipmapper-water-passport-v3',registry_version:registry.version,wanted,visited},null,2);
}
export function parsePassportImport(text,registry){
 if(typeof text!=='string'||new TextEncoder().encode(text).length>MAX_IMPORT_BYTES)throw new RangeError('Import too large.');
 const d=JSON.parse(text);if(!d||d.format!=='dipmapper-water-passport-v3'||!Array.isArray(d.wanted)||!Array.isArray(d.visited))throw new TypeError('Not a compatible passport export.');
 const index=new Map(registry.slots.map(s=>[s.id,s.slot]));const states=new Uint8Array(registry.slots.length);
 for(const [list,v] of [[d.wanted,1],[d.visited,2]]){if(list.length>registry.slots.length)throw new RangeError('Too many saved IDs.');for(const id of list){if(typeof id!=='string'||!index.has(id))throw new Error('Unknown saved ID; import stopped without changing the current checklist: '+String(id).slice(0,80));states[index.get(id)]=v;}}
 return states;
}
export class CookiePassport{
 constructor(registry,{documentRef=typeof document!=='undefined'?document:null,canPersist=()=>false,protocol=typeof location!=='undefined'?location.protocol:'https:',path='/'}={}){
  if(!registry?.slots?.every((s,i)=>s.slot===i&&typeof s.id==='string')||new Set(registry.slots.map(s=>s.id)).size!==registry.slots.length)throw new Error('Invalid append-only registry.');
  if(path!=='/')throw new Error('This version uses one explicit root-path cookie.');
  this.registry=registry;this.document=documentRef;this.canPersist=canPersist;this.protocol=protocol;this.states=new Uint8Array(registry.slots.length);this.index=new Map(registry.slots.map(s=>[s.id,s.slot]));this.status='memory_only';this.error=null;this.enabled=false;this.corrupt=false;this.listeners=new Set();
  if(this.allowed()){this.read();if(this.status==='remembered')this.enabled=true;}
 }
 allowed(){return !!this.document&&this.protocol==='https:'&&this.canPersist()===true;}
 read(){
  try{const value=readNamedCookie(this.document?.cookie||'');if(!value)return false;this.states=decodePassport(value,this.registry);this.status='remembered';this.error=null;this.corrupt=false;return true;}
  catch(e){this.error=e.message;this.status='existing_cookie_needs_attention';this.corrupt=true;return false;}
 }
 onChange(fn){this.listeners.add(fn);return()=>this.listeners.delete(fn);}
 notify(){for(const f of this.listeners)f(this);}
 get(id){const i=this.index.get(id);return i===undefined?0:this.states[i];}
 ids(kind=1){return this.registry.slots.filter(s=>this.states[s.slot]===kind).map(s=>s.id);}
 remember(){
  if(this.corrupt)throw new Error('Existing checklist is damaged or from another registry. Reset explicitly before writing.');
  if(!this.allowed()){this.status='memory_only';this.error='Cookie storage is unavailable or not permitted. Your checklist lasts for this page only.';this.notify();return false;}
  this.enabled=true;return this.persist();
 }
 persist(){
  if(this.corrupt)throw new Error('Refusing to overwrite an unreadable checklist.');
  if(!this.enabled||!this.allowed()){this.status='memory_only';this.notify();return false;}
  try{
   const value=encodePassport(this.states,this.registry);
   this.document.cookie=`${COOKIE_NAME}=${value}; Max-Age=${RETENTION_DAYS*86400}; Path=/; SameSite=Lax; Secure`;
   if(readNamedCookie(this.document.cookie)!==value)throw new Error('Browser did not retain the cookie.');
   this.status='remembered';this.error=null;this.notify();return true;
  }catch(e){this.status='memory_only';this.error=e.message;this.notify();return false;}
 }
 set(id,state){
  if(!this.index.has(id)||![0,1,2].includes(state))throw new TypeError('Unknown record or flag.');
  if(this.corrupt)throw new Error('Reset or export the unreadable checklist before editing.');
  if(this.enabled&&this.allowed())this.read();
  if(this.corrupt)throw new Error('Another tab changed the registry. No data was overwritten.');
  this.states[this.index.get(id)]=state;this.persist();return state;
 }
 toggle(id,kind){if(![1,2].includes(kind))throw new TypeError('Use want or visited.');return this.set(id,this.get(id)===kind?0:kind);}
 merge(text){const imported=parsePassportImport(text,this.registry);if(this.corrupt)throw new Error('Reset damaged state before importing.');if(this.enabled&&this.allowed())this.read();if(this.corrupt)throw new Error('Existing cookie cannot be merged.');imported.forEach((v,i)=>{if(v)this.states[i]=Math.max(this.states[i],v);});this.persist();}
 export(){return exportPassport(this.states,this.registry);}
 reset(){
  if(this.document){try{this.document.cookie=`${COOKIE_NAME}=; Max-Age=0; Path=/; SameSite=Lax; Secure`;}catch{}}
  this.states=new Uint8Array(this.registry.slots.length);this.status='memory_only';this.error=null;this.corrupt=false;this.enabled=false;this.notify();
 }
 sync(){if(this.enabled&&this.allowed()){this.read();this.notify();}}
}
