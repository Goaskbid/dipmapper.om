#!/usr/bin/env python3
"""Build additive DipMapper V5 previews, reviewed SEO pages and lazy data shards.
No network, repository mutation or deployment. Python 3.10+, Node 20+.
"""
from __future__ import annotations
import argparse, collections, gzip, hashlib, html, json, re, subprocess, sys
from pathlib import Path
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parent
JSON_FILES=['03_catalogue.json','04_evidence_and_rules.json','05_geography.json']
MODULES=['06_ranking.mjs','07_cookie_passport.mjs','08_globe.mjs','18_host_adapter.mjs','09_explorer.mjs']

def read_data(root=ROOT):
    return [json.loads((root/name).read_text(encoding='utf-8')) for name in JSON_FILES]

def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def validate(root=ROOT):
    cat,rules,geo=read_data(root);checks=0
    def check(condition,message):
        nonlocal checks
        checks+=1
        if not condition: raise ValueError(message)
    records=cat['records'];ids={r['id'] for r in records};sources={s['source_id'] for s in rules['sources']};scopes={s['id']:s for s in geo['scopes']}
    check(len(ids)==len(records),'Duplicate experience IDs')
    check(set(cat['baseline_preserved_ids'])<=ids,'A V2 experience was lost')
    check(len(sources)==len(rules['sources']),'Duplicate source IDs')
    check([s['id'] for s in cat['registry']['slots']]==[r['id'] for r in records],'Registry order changed')
    check([s['slot'] for s in cat['registry']['slots']]==list(range(len(records))),'Registry is not append-only contiguous')
    for r in records:
        check(bool(r['season_profile_v3']),'Missing explicit season profile: '+r['id'])
        check(all(s in sources for s in r['source_ids']),'Unresolved evidence: '+r['id'])
        check(bool(r['source_ids']),'Unsourced record: '+r['id'])
        check(all(x in scopes for x in r['geo_v3']['scope_ids']),'Invalid named-water join: '+r['id'])
        check(r['geo_v3'].get('navigation_allowed') is False,'Research coordinate became navigable')
        check(0<=r['assessment_v3']['score']<=100,'Score range')
        check(all(0<=v<=4 for v in r['assessment_v3']['components'].values()),'Component range')
        check(r['assessment_v3']['score_kind']=='editorial_judgment_not_observed_metric','Score mislabelled')
        check(r['fit_v3']['family']['status'] in ['unknown','conditional','yes','no'],'Invalid family state')
        check(set(r['fit_v3']['accessibility'])=={'step_free_route','wheelchair_boarding','accessible_toilet','assisted_water_entry','sensory_support'},'Incomplete accessibility matrix')
    for layer in rules['seasons']:
        check(layer['experience_id'] in ids,'Orphan season')
        check(layer['source_id'] in sources,'Orphan season evidence')
        check(all(isinstance(m,int) and 1<=m<=12 for m in layer.get('months',[])),'Invalid month')
    for rule in rules['restrictions']:
        check(set(rule['experience_ids'])<=ids,'Orphan restriction')
        check(rule['source_id'] in sources,'Orphan restriction source')
    for scope in scopes.values():
        check(set(scope.get('parents',[]))<=set(scopes),'Missing geographic parent')
    known={s['experience_id'] for s in rules['seasons'] if s.get('months') and s.get('inside_state')!='unknown'}
    ranked=[r for r in records if r['v3_rank_eligibility']['all_time']]
    check(len(ranked)>=200,'Insufficient honest Top 200 pool')
    check(all(r['id'] in known for r in ranked),'Unseasoned ranked entry')
    # Deliberately do not convert an access-equipment calendar into general activity seasonality.
    activity_known={s['experience_id'] for s in rules['seasons'] if s.get('months') and s.get('inside_state')!='unknown' and s['dimension']!='access_equipment'}
    check(all(r['id'] in activity_known for r in ranked),'Equipment-only calendar in Top 200 pool')
    fit_counts={k:sum(r['fit_v3']['accessibility'][k]['status']!='unknown' for r in records) for k in records[0]['fit_v3']['accessibility']}
    return {'version':cat['version'],'research_date':cat['research_date'],'structural_assertions':checks,'records':len(records),'preserved_v2':len(cat['baseline_preserved_ids']),'new_beaches':sum(r.get('record_origin')=='new_v3_beach_research' for r in records),'countries':len(geo['countries']),'activity_types':len({r['primary_activity'] for r in records}),'geography_scopes':len(scopes),'sources':len(sources),'new_source_entries':len(rules.get('new_v5_source_ids',[])),'prior_v3_new_source_entries':len(rules['new_source_ids']),'season_layers':len(rules['seasons']),'with_any_month_window':len(known),'with_activity_month_window':len(activity_known),'season_still_unknown':len(records)-len(activity_known),'ranking_eligible':len(ranked),'family_facts':sum(r['fit_v3']['family']['status']!='unknown' for r in records),'accessibility_facts':fit_counts,'restrictions':len(rules['restrictions']),'source_methods':dict(collections.Counter(s.get('evidence_method','unknown') for s in rules['sources'])),'nonclaims':['Not independent editorial approval','Not live weather or availability','Not an exhaustive global inventory']}

def node_snapshot(root=ROOT):
    code=r'''
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const base=process.argv[1];
const {createModel,rankExperiences,globalHighlights}=await import(pathToFileURL(base+'/06_ranking.mjs'));
const read=n=>JSON.parse(fs.readFileSync(base+'/'+n,'utf8'));
const cat=read('03_catalogue.json'),rules=read('04_evidence_and_rules.json'),geo=read('05_geography.json');
const model=createModel(cat,rules,geo);
const short=x=>({aquarium_rank:x.aquariumRank||null,rank_kind:x.rankKind,id:x.record.id,name:x.record.name,position:x.position,tied_rank:x.tiedRank,editorial_score:x.score,season_status:x.season.status,countries:x.record.country_codes});
const pool=rankExperiences(model);const activities={};
for(const [id,label]of Object.entries(cat.activity_labels)){const a=rankExperiences(model,{activity:id});if(a.length)activities[id]={label,count:a.length,entries:a.map(short)};}
const months={};for(let m=1;m<=12;m++){const date=`2026-${String(m).padStart(2,'0')}-15`;const a=rankExperiences(model,{mode:'for_date',date});months[date]={count:a.length,entries:a.slice(0,200).map(short)};}
const waters={};for(const id of ['mediterranean','lake-garda','phuket','lake-zurich','lake-geneva','andaman-sea']){if(!model.scopes.has(id))continue;waters[id]={label:model.scopes.get(id).label,entries:rankExperiences(model,{scope:id}).map(short)};}
console.log(JSON.stringify({version:cat.version,curation_v5:cat.curation_v5,new_research:rankExperiences(model,{edition:'new_v5'}).map(short),aquarium_top_100:rankExperiences(model,{edition:'aquarium100',activity:'aquarium'}).map(short),aquarium_longlist:rankExperiences(model,{activity:'aquarium'}).map(short),mall_aquariums:rankExperiences(model,{edition:'mall',activity:'aquarium'}).map(short),research_date:cat.research_date,publication_status:'unapproved_editorial_research',not_a_complete_world_ranking:true,not_user_ratings:true,pool_size:pool.length,top_200:globalHighlights(model,200).map(short),activities,monthly_examples:months,water_examples:waters,rank_method:rules.methodology}));
'''
    proc=subprocess.run(['node','--input-type=module','-e',code,str(root)],capture_output=True,text=True,check=True)
    return json.loads(proc.stdout)

def compile_demo(root=ROOT):
    cat,rules,geo=read_data(root)
    chunks=[]
    for name in MODULES:
        s=(root/name).read_text(encoding='utf-8')
        s=re.sub(r'^import .*?;\s*$', '', s,flags=re.M)
        s=re.sub(r'\bexport\s+(?=(const|function|class)\b)','',s)
        chunks.append(s)
    payload=json.dumps({'catalogue':cat,'rules':rules,'geography':geo},ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
    css=json.dumps((root/'10_styles.css').read_text(),ensure_ascii=False).replace('<','\\u003c')
    boot="\nconst bundles="+payload+";\nwindow.__dipmapperPreview=mountRankings(document.getElementById('dipmapper-v3'),bundles,{cssText:"+css+",initialDate:bundles.catalogue.research_date,asOf:bundles.catalogue.research_date,canUseFunctionalCookie:()=>true,...(window.__DM_PREVIEW_OPTIONS||{}),onReturnToMap:()=>{document.getElementById('demo-host-note').textContent='Production integration returns to your existing map. This standalone preview does not replace it.';}});\n"
    code='\n'.join(chunks)+boot
    code=code.replace('</script','<\\/script')
    return '<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>DipMapper V5 | Rankings and water passport preview</title><style>html,body{margin:0;background:#fff;font-family:Arial,sans-serif}#demo-host-note{max-width:1320px;margin:12px auto;padding:0 20px;font-size:12px;color:#52616c}</style></head><body><p id="demo-host-note">Standalone research preview. The production map stays unchanged. Open on HTTPS to test the optional cookie; file previews keep the checklist only in memory.</p><main id="dipmapper-v3"></main><noscript><p>This interactive preview requires JavaScript. The separate reviewed-page builder produces crawlable static rankings.</p></noscript><script>\n(()=>{\n'+code+'\n})();\n</script></body></html>\n'

def fresh_directory(out):
    out=Path(out)
    if out.exists(): raise FileExistsError('Refusing to overwrite an existing directory: '+str(out))
    out.mkdir(parents=True);return out

def safe_publisher_url(value):
    try:
        parsed=urlsplit(str(value))
        return parsed.scheme in ('https','http') and bool(parsed.netloc) and not parsed.username and not parsed.password
    except ValueError:
        return False

def safe_link(url,label):
    return '<a href="'+html.escape(url,quote=True)+'" target="_blank" rel="noopener noreferrer">'+html.escape(label)+'</a>' if safe_publisher_url(url) else ''

def record_html(r,row,rules,sources):
    """Original, source-linked editorial card. No invented booking or ratings markup."""
    esc=html.escape;g=r['guide_v4'];c=g['contact'];aq=r['primary_activity']=='aquarium'
    rank=row.get('aquarium_rank') if aq else row.get('tied_rank')
    position=row.get('position');prefix=('#'+str(rank)+' ') if rank else ''
    note=('Global aquarium editorial position, not a measured quality gap.' if aq else 'Editorial score '+str(r['assessment_v3']['score'])+'/100. Equal scores share rank; list order is not a measured gap.')
    loc=g['location']['area']+' | '+', '.join(g['location']['countries'])
    relation=r.get('venue_v4',{}).get('complex_relation')
    if relation:loc+=' | '+relation.replace('_',' ')+((': '+r['venue_v4']['complex_name']) if r['venue_v4']['complex_name'] else '')
    seasons=[]
    for layer in g['season']:
        source=sources.get(layer.get('source_id'),{})
        dates='; dates '+json.dumps(layer['date_window']) if layer.get('date_window') else ''
        seasons.append('<p><strong>'+esc(layer['label'])+': '+esc(layer['month_text'])+'</strong>'+esc(dates)+'. '+esc(layer['explanation'])+' '+safe_link(source.get('url',''),'Season source')+'</p>')
    if not seasons:seasons=['<p>Seasonal window not established. This is not an all-year assumption.</p>']
    prices=[]
    for q in g['price_references']:
        if q['amount'] is None:continue
        value=f"{q['currency']} {q['amount']:g}" if isinstance(q['amount'],(int,float)) else str(q['amount'])
        prices.append('<p><strong>'+esc(value)+'</strong> / '+esc(q.get('unit') or 'unit needs confirmation')+'. '+esc(q.get('type') or 'reference')+'. '+esc(q.get('notes') or '')+' Reference date: '+esc(q.get('reference_date') or 'not recorded')+'. Not a live or all-in quote. '+safe_link(q.get('source_url',''),'Price source')+'</p>')
    price=''.join(prices) or '<p>No numeric price established. Use the official ticket or access page. Missing prices do not mean free admission.</p>'
    actions=' '.join(safe_link(a['url'],a['label']) for a in g['booking_actions'])
    contact=safe_link(c.get('official_page',''),'Official visitor/contact route')
    if c.get('phones'):contact+='<p>Published telephone: '+esc('; '.join(c['phones']))+'</p>'
    if c.get('emails'):contact+='<p>Published email: '+esc('; '.join(c['emails']))+'</p>'
    notices=[]
    for rule in rules['restrictions']:
        if r['id'] in rule['experience_ids']:
            notices.append('<p class="notice"><strong>Published restriction:</strong> '+esc(rule['text'])+' '+safe_link(sources.get(rule['source_id'],{}).get('url',''),'Restriction source')+'</p>')
    evidence=' '.join(safe_link(sources[x]['url'],sources[x].get('publisher',x)) for x in g['source_ids'] if x in sources)
    return '<li id="'+esc(r['id'],quote=True)+'"><article><p class="kicker">'+esc(loc)+'</p><h2>'+prefix+esc(r['name'])+'</h2><p class="small">'+note+'</p><p>'+esc(g['description'])+'</p><p><strong>Why go:</strong> '+esc(g['why_go'])+'</p><p><strong>Key attractions:</strong> '+esc(' / '.join(g['key_attractions']))+'</p><section class="season"><h3>Season and visit timing</h3>'+''.join(seasons)+'</section>'+''.join(notices)+'<p><strong>Plan around:</strong> '+esc(g['planning_caveat'])+'</p><h3>Tickets and published costs</h3>'+price+'<p class="actions">'+actions+'</p><h3>Contact and location</h3>'+contact+'<p>'+esc(r.get('departure_text') or loc)+'</p><p class="small">Location is approximate area context, not a verified entrance or departure point.</p><details><summary>Sources and evidence status</summary><p>'+evidence+'</p><p>Research reference date '+esc(g['source_review_date'])+'. '+('Retained prior research; original source dates remain.' if g['inherited_not_rechecked'] else 'Official-publisher desk research, including cached pages and search excerpts.')+' Not a live inventory, tested contact or independent welfare audit.</p></details></article></li>'

PAGE_STYLE="body{font:16px/1.65 Arial,sans-serif;color:#17323a;background:#f8fbfb;max-width:1000px;margin:auto;padding:24px}h1{font-size:clamp(30px,5vw,50px);line-height:1.12}h2{font-size:25px;line-height:1.25}h3{font-size:17px;margin-bottom:8px}a{color:#14646a;overflow-wrap:anywhere}ol{list-style:none;padding:0}li article{margin:24px 0;background:white;border:1px solid #d4e4e5;border-radius:12px;padding:24px}.kicker,.small{font-size:13px;color:#52686d}.notice{border-left:3px solid #aa6d17;padding:10px 14px;background:#fff8ed}.season{background:#eff7f6;border-radius:8px;padding:4px 16px}.actions a{display:inline-block;border:1px solid #8aabad;border-radius:6px;padding:8px 12px;margin:4px 6px 4px 0}nav{font-size:14px}details{margin-top:16px} @media(max-width:420px){body{padding:14px}li article{padding:16px}}"

def approval_check(ids,by,rules):
    for rid in ids:
        v=by[rid]['v3_review']
        if not(v.get('approved_for_indexing') is True and v.get('reviewer') and v.get('approved_at') and v.get('ranking_approved') is True):raise ValueError('Named evidence and ranking approval missing: '+rid)
    if not rules['methodology'].get('publication_approval',{}).get('reviewer'):raise ValueError('Methodology approval missing')

def page_html(page,by,rules,sources,cat,approved=False):
    esc=html.escape;url='https://dipmapper.com/discover/'+page['slug']+'/'
    meta='<link rel="canonical" href="'+url+'">' if approved else '<meta name="robots" content="noindex,nofollow">'
    payload={'@context':'https://schema.org','@type':'ItemList','name':page['title'],'numberOfItems':len(page['entries']),'itemListElement':[{'@type':'ListItem','position':i+1,'name':by[x['id']]['name'],'url':url+'#'+x['id']} for i,x in enumerate(page['entries'])]}
    structured='<script type="application/ld+json">'+json.dumps(payload,ensure_ascii=False).replace('<','\\u003c')+'</script>' if approved else ''
    method=('The aquarium order is a desk-researched editorial judgment about distinctive exhibits, regional interpretation, visit depth and itinerary usefulness. It is not based on first-hand visits, paid placement or visitor-rating averages. A position is an editorial choice, not a measured quality gap.' if page.get('aquarium') else 'Method: setting 40%, distinctiveness 35%, experience depth 25%, each assessed 0 to 4. Equal scores genuinely tie. These are subjective editorial assessments, not visitor ratings or safety certifications.')
    items=''.join(record_html(by[x['id']],x,rules,sources) for x in page['entries'])
    return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'+meta+'<title>'+esc(page['title'])+' | DipMapper</title><meta name="description" content="'+esc(page['intro'],quote=True)+'"><style>'+PAGE_STYLE+'</style>'+structured+'</head><body><main><nav><a href="../index.html">Explore all editions</a> | <a href="https://dipmapper.com/">DipMapper map</a></nav><p class="kicker">DIPMAPPER EDITORIAL EDITION / '+cat['research_date']+'</p><h1>'+esc(page['title'])+'</h1><p>'+esc(page['intro'])+'</p><p>'+esc(page['tradeoff'])+'</p><p>'+str(len(page['entries']))+' researched candidates in this edition. '+esc(method)+'</p><p class="small">'+('Publisher-approved edition.' if approved else 'Complete editorial copy for publisher review. This preview is not indexed.')+' Typical seasons and indoor visit formats are not live forecasts or opening guarantees. Source dates and ticket categories remain part of each card.</p><ol>'+items+'</ol></main></body></html>'

def static_rankings(out,root=ROOT,approved=False):
    cat,rules,geo=read_data(root);snapshot=node_snapshot(root);by={r['id']:r for r in cat['records']};sources={s['source_id']:s for s in rules['sources']}
    page={'slug':'top-water-experiences','title':'Top 200 water experiences','entries':snapshot['top_200'],'intro':'Compare a global editorial selection of swimming, diving, wildlife, paddle, boat and water-park experiences, with seasonal context and official planning routes.','tradeoff':'The existing swimming-first map remains the neutral way to find nearby options outside this selection.'}
    if approved:approval_check([x['id'] for x in page['entries']],by,rules)
    out=fresh_directory(out);(out/'index.html').write_text(page_html(page,by,rules,sources,cat,approved),encoding='utf-8')
    if approved:(out/'sitemap-fragment.xml').write_text('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>https://dipmapper.com/discover/top-water-experiences/</loc><lastmod>'+cat['research_date']+'</lastmod></url></urlset>')
    return {'approved':approved,'pages':1,'entries':len(page['entries']),'directory':str(out)}

def shards(out,root=ROOT):
    out=fresh_directory(out);cat,rules,geo=read_data(root)
    # Minimal catalogue list on opening Explore; sources/detail layers load per activity, not on the swimming homepage.
    index={k:cat[k] for k in ['version','research_date','registry','activity_labels']}
    keys=['id','name','country_codes','continent_codes','area','primary_activity','assessment_v3','geo_v3','v3_rank_eligibility','season_profile_v3']
    index['records']=[{**{k:r[k] for k in keys},**{k:r[k] for k in ['ranking_v4','venue_v4'] if k in r}} for r in cat['records']]
    index['editorial_editions_v4']=cat['editorial_editions_v4']
    dump(out/'ranking-index.json',index);dump(out/'geography.json',geo)
    stats=[]
    for activity in sorted({r['primary_activity'] for r in cat['records']}):
        rs=[r for r in cat['records'] if r['primary_activity']==activity];ids={r['id'] for r in rs};ss=[s for s in rules['seasons'] if s['experience_id'] in ids];restrictions=[s for s in rules['restrictions'] if set(s['experience_ids'])&ids];source_ids={s for r in rs for s in r['source_ids']}|{s['source_id'] for s in ss}|{s['source_id'] for s in restrictions}
        data={'records':rs,'seasons':ss,'restrictions':restrictions,'sources':[s for s in rules['sources'] if s['source_id'] in source_ids],'offers':[o for o in rules['offers']['records'] if o['experience_id'] in ids]}
        path=out/(activity+'.json');dump(path,data);stats.append({'activity':activity,'records':len(rs),'gzip_bytes':len(gzip.compress(path.read_bytes()))})
    manifest={'index_gzip_bytes':len(gzip.compress((out/'ranking-index.json').read_bytes())),'geography_gzip_bytes':len(gzip.compress((out/'geography.json').read_bytes())),'shards':stats,'integration':'These are build outputs. The reference UI accepts a complete model; production lazy-loading assembles required shards before mounting/reranking. Do not pass an incomplete model as if it were complete.'}
    dump(out/'manifest.json',manifest);return manifest

HUB_COPY = {
 'swim': ('Swimming discoveries', 'These swimming additions complement the existing DipMapper swimming directory. They are not a ranking of every pool or swimming place already in the production app.', 'Separate a scenic setting from access permission, current water quality and the facilities needed by your group.'),
 'scuba': ('Diving experiences', 'Compare named diving experiences by setting and underwater interest, then check the seasonal window of the actual region or itinerary. A year-round destination can still contain seasonal wildlife and access restrictions.', 'The score does not establish personal qualification, currents, permits, medical suitability or operator competence.'),
 'snorkel': ('Snorkelling discoveries', 'Look for different underwater experiences rather than treating all reef trips as interchangeable. Species calendars, park access and the exact entry method stay visible.', 'Confirm swimming requirements, current conditions and whether a boat, permit or equipment is included.'),
 'snorkel_excursion': ('Snorkelling boat excursions', 'These are outing-level choices, not promises that every departure visits every named site. Compare the seasonal setting before confirming the operator itinerary and starting point.', 'A destination pin is not a verified embarkation point. Published price references may omit transfers and park charges.'),
 'whale_watch': ('Whale-watching experiences', 'Choose a whale destination for the species and time of year, not only the overall scenic score. Resident populations, migrations and an operator timetable are different evidence layers.', 'Sightings are never guaranteed. A departure may be cancelled, and conduct rules still apply during a strong wildlife season.'),
 'kayak': ('Kayaking discoveries', 'Explore fjords, islands and sheltered waterways with their different seasonal patterns. Warmer weather does not automatically mean less wind or a more suitable paddling day.', 'Choose the actual route and operator format. Exposure, skill, group restrictions and launch conditions remain separate from attractiveness.'),
 'ferry': ('Ferry crossings worth exploring', 'A public crossing can be the experience itself. These selections value the water setting and route character without pretending that a ferry is a fully packaged cruise.', 'Use the current timetable and actual vessel. Boarding with a wheelchair and toilet access can vary between sailings.'),
 'scenic_cruise': ('Scenic boat journeys', 'Compare the landscape and the water-level perspective, then use the named programme dates. Winter and shoulder-season services are retained when the publisher supports them.', 'The ranking does not confirm a departure, seat or connection. Check the selected ship, stop pattern and operator notice.'),
 'thermal_bath': ('Warm-water experiences', 'Compare the setting and the experience beyond the water temperature. An indoor or year-round reference does not mean every pool and service is operating on your chosen day.', 'Admission categories, maintenance, family areas and access equipment need facility-specific confirmation.'),
 'sauna_swim': ('Sauna and water discoveries', 'A sauna by the water can work in a different season from an ordinary beach outing. The published operating pattern is separate from permission or suitability to enter adjacent water.', 'Check booking rules, supervision, steps, temperature exposure and the actual route to the water.'),
 'water_park': ('Water-park experiences', 'Compare venue-based water days as alternatives to open-water outings. Family fit depends on the actual height, age and supervision rules, not a generic family badge.', 'Separate park operation from individual ride availability. Temporary maintenance and ticket categories can change the practical choice.'),
 'rafting': ('River rafting discoveries', 'The attraction changes with the river and the water level. A published boating season is one constraint, while current flow, operator route and participant requirements are separate.', 'A favourable month or high score cannot establish the grade of a trip or an individual participant\'s suitability.'),
 'beach': ('Beach discoveries', 'Compare shore settings and seasonal context, then decide whether your visit means swimming, shore viewing or a supervised water activity. These are deliberately different uses of a beach.', 'Local flags, surf, water quality, tides and facilities take priority over the editorial score.'),
}
WATER_COPY = {
 'mediterranean': ('Mediterranean water discoveries', 'This basin view includes the explicitly joined Mediterranean sub-seas. It does not include every attraction in a country merely because that country has a Mediterranean coast.', 'Use a smaller region for day planning. The entire Mediterranean is not one itinerary or a uniform weather zone.'),
 'phuket': ('Phuket water discoveries', 'Start with a Phuket-area shortlist, then compare beaches, underwater trips and venue alternatives against your date. The filter does not silently extend to every Thai destination.', 'Confirm the actual pier, hotel transfer, island access and current sea conditions before allocating the day.'),
 'andaman-sea': ('Andaman Sea water discoveries', 'Compare the named experiences joined to the Andaman Sea rather than every activity offered in Thailand or neighbouring countries. Operational closures and seasonal context remain separate.', 'This is a regional discovery page. Travel times between islands and departure ports are not inferred from their ranking.'),
}

def hub_pages(snapshot,cat,geo):
    pages=[{'slug':'top-water-experiences','title':'Top 200 water experiences','entries':snapshot['top_200'],'intro':'A global editorial selection with reasons to go, key attractions, seasonal context and official visitor routes.','tradeoff':'Use the neutral DipMapper map for every nearby option, including places outside this edition.'}]
    for activity,copy in HUB_COPY.items():
        listing=snapshot['activities'].get(activity)
        if listing and listing['count']>=5:pages.append({'slug':activity.replace('_','-'),'title':copy[0],'entries':listing['entries'],'intro':copy[1],'tradeoff':copy[2]})
    for scope,copy in WATER_COPY.items():
        listing=snapshot['water_examples'].get(scope)
        if listing and len(listing['entries'])>=8:pages.append({'slug':scope,'title':copy[0],'entries':listing['entries'],'intro':copy[1],'tradeoff':copy[2]})
    pages.extend([
      {'slug':'best-public-aquariums','title':'Top 100 public aquariums: exhibits, seasons and tickets','entries':snapshot['aquarium_top_100'],'aquarium':True,'intro':'A researched editorial shortlist of public aquariums, from regional marine habitats to large ocean galleries. Each entry explains its distinctive attractions, venue setting and official ticket route.','tradeoff':'Public means open to visitors, not state-owned. This is not an animal-welfare audit. Captive-wildlife viewing and wild encounters are separate choices.'},
      {'slug':'aquariums-in-shopping-malls','title':'25 aquariums inside shopping malls','entries':snapshot['mall_aquariums'],'aquarium':True,'intro':'Find aquarium visits that genuinely sit inside shopping complexes, with the complex name, main attractions, seasonal interpretation and official contact route.','tradeoff':'A nearby mall does not qualify. Adjacent venues, convention-centre aquariums and standalone attractions are kept out of this inside-mall edition.'}
    ])
    # Deliberately no parallel Top 120 page: those extra profiles stay in Explore, avoiding a near-duplicate of the Top 100.
    pages.append({'slug':'new-curated-discoveries','title':'147 newly researched water discoveries','intro':'Individually written reasons, practical distinctions and official planning routes. These are additional discoveries, not a claim of 147 new world-leading attractions.','tradeoff':'Unresolved seasons, prices and access remain visible. Closure holds are not automatically cleared by a planned reopening date.','entries':snapshot['new_research'],'aquarium':False})
    return pages

def static_hubs(out,root=ROOT,approved=False):
    cat,rules,geo=read_data(root);snapshot=node_snapshot(root);by={r['id']:r for r in cat['records']};sources={s['source_id']:s for s in rules['sources']};pages=hub_pages(snapshot,cat,geo)
    if approved:approval_check({x['id'] for p in pages for x in p['entries']},by,rules)
    out=fresh_directory(out);links=[];site_urls=[]
    for page in pages:
        folder=out/page['slug'];folder.mkdir();(folder/'index.html').write_text(page_html(page,by,rules,sources,cat,approved),encoding='utf-8')
        links.append('<li><a href="'+page['slug']+'/">'+html.escape(page['title'])+'</a> ('+str(len(page['entries']))+')</li>');site_urls.append('https://dipmapper.com/discover/'+page['slug']+'/')
    overview='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'+('' if approved else '<meta name="robots" content="noindex,nofollow">')+'<title>DipMapper editorial discovery editions</title><style>'+PAGE_STYLE+'</style></head><body><main><h1>Explore by experience and region</h1><p>Written rankings with seasonal context, practical trade-offs and official planning routes. These are separate editorial editions, not every possible filter combination.</p><ul>'+''.join(links)+'</ul></main></body></html>'
    (out/'index.html').write_text(overview,encoding='utf-8')
    if approved:
        xml='<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join('<url><loc>'+u+'</loc><lastmod>'+cat['research_date']+'</lastmod></url>' for u in site_urls)+'</urlset>'
        (out/'sitemap-fragment.xml').write_text(xml)
    return {'approved':approved,'ranking_pages':len(pages),'navigation_pages':1,'pages':[{'slug':p['slug'],'count':len(p['entries'])} for p in pages],'output':str(out),'approval_requirement':'New generated content only. Never apply these draft directives to existing production URLs.'}

def markdown_guide(root=ROOT):
    cat,rules,geo=read_data(root);snap=node_snapshot(root);by={r['id']:r for r in cat['records']};sources={s['source_id']:s for s in rules['sources']}
    out=['# DipMapper: ready ranked discovery guide','Research edition: '+cat['research_date'],
    'This file contains the written ranking cards, not a content brief. The Top 100 aquariums is an authored editorial order. The Top 200 water selection retains the earlier edition and coarse score ties. There are 605 complete-format catalogue cards in the JSON, including 161 aquarium profiles. This edition adds 147 unique records and refreshes one existing venue. The 4,580 target is not complete. Some practical fields remain explicitly unknown; a contact route is supplied instead of an invented price or telephone.',
    'The aquarium order weighs distinctive exhibits, regional interpretation, visit depth and itinerary usefulness qualitatively. Close positions are judgments, not measured gaps. No first-hand visit, independent welfare inspection or visitor-rating average is claimed. Mall lists retain the global aquarium order, so their global ranks do not restart at one.',
    'An all-month aquarium visit-format label is an inference from the indoor or mixed setting, not a promise of 365-day opening. Source descriptions, conditions, currencies and partial closures remain part of the record. Existing water research is retained and clearly marked, not relabelled as newly verified.',
    '## Editions at a glance','| Edition | Actual records |','| --- | ---: |','| Top water experiences | 200 |','| Top public aquariums | 100 |','| Aquarium discovery directory | 161 |','| Inside shopping malls | 28 |',
    '## Top 100 public aquariums']
    def card(r,row):
        g=r['guide_v4'];rank=row.get('aquarium_rank') if r['primary_activity']=='aquarium' else row.get('tied_rank');heading=('Global aquarium #'+str(rank) if r['primary_activity']=='aquarium' else 'Water rank #'+str(rank)) if rank else 'Additional discovery'
        lines=['### '+heading+': '+r['name'],'**Location:** '+g['location']['area']+', '+', '.join(g['location']['countries'])+'.',g['description'],'**Why go:** '+g['why_go'],'**Key attractions:** '+'; '.join(g['key_attractions'])+'.']
        if r.get('venue_v4'):
            v=r['venue_v4'];lines+=['**Venue format:** '+v['setting']+'; '+v['complex_relation'].replace('_',' ')+(('; '+v['complex_name']) if v['complex_name'] else '')+'.']
        for q in g['season']:
            line='**Season, '+q['label']+':** '+q['month_text']+'. '+q['explanation']
            if q.get('date_window'):line+=' Published date window: '+json.dumps(q['date_window'])+'.'
            src=sources.get(q.get('source_id'));line+=(' [Season evidence]('+src['url']+').' if src else '')
            lines.append(line)
        if not g['season']:lines.append('**Season:** Not established. No all-year inference.')
        for rule in rules['restrictions']:
            if r['id'] in rule['experience_ids']:lines.append('**Published restriction:** '+rule['text']+' [Source]('+sources[rule['source_id']]['url']+').')
        lines.append('**Plan around:** '+g['planning_caveat'])
        if g['price_references']:
            for q in g['price_references']:
                lines.append('**Published price reference:** '+str(q['currency'])+' '+str(q['amount'])+' / '+str(q.get('unit') or 'unit needs confirmation')+'. '+str(q.get('type') or 'reference').replace('_',' ')+'. '+str(q.get('notes') or '')+' Not a live or all-in quote. [Publisher]('+str(q['source_url'])+').')
        else:lines.append('**Cost:** No numeric price established. Use the official route; unknown is not free.')
        lines.append('**Tickets/access:** '+'; '.join('['+a['label']+']('+a['url']+')' for a in g['booking_actions'])+'.')
        co=g['contact'];lines.append('**Contact:** [Official visitor/contact route]('+co['official_page']+').'+((' Telephone: '+'; '.join(co['phones'])+'.') if co.get('phones') else '')+((' Email: '+'; '.join(co['emails'])+'.') if co.get('emails') else ''))
        lines.append('**Evidence:** '+'; '.join('['+sources[x].get('publisher',x)+']('+sources[x]['url']+')' for x in g['source_ids'] if x in sources)+'. '+('Retained prior research; original field dates remain.' if g['inherited_not_rechecked'] else 'New official-publisher desk research, including cached pages and search excerpts.')+' No image rights or exact entrance coordinates supplied.')
        return lines
    for row in snap['aquarium_top_100']:out+=card(by[row['id']],row)
    out+=['## Further aquarium discoveries','The original positions 101 to 120 remain. New profiles are additional discoveries without an invented global position.']
    for row in snap['aquarium_longlist'][100:]:out+=card(by[row['id']],row)
    out+=['## Aquariums inside shopping malls','This list excludes mall-adjacent and convention-centre venues. Read the full card above using the global aquarium number.','| Global aquarium position | Aquarium | Mall | Location |','| ---: | --- | --- | --- |']
    for row in snap['mall_aquariums']:
        r=by[row['id']];out+=['| '+str(row['aquarium_rank'] or 'Discovery')+' | '+r['name']+' | '+r['venue_v4']['complex_name']+' | '+r['area']+' |']
    out+=['## Top 200 water experiences','This preserved selection spans multiple activity families. Coarse editorial scores tie; the list position does not imply a measured quality gap. Aquariums have a separate list, rather than displacing swimming and outdoor experiences.']
    for row in snap['top_200']:out+=card(by[row['id']],row)
    selected={x['id'] for x in snap['top_200']}|{x['id'] for x in snap['aquarium_longlist']}
    out+=['## Further water discoveries and explicit research gaps','These catalogue records have complete-format cards but are not included in the Top 200. An unknown season is not presented as a positive seasonal recommendation.']
    for r in cat['records']:
        if r['id'] not in selected:out+=card(r,{'tied_rank':None})
    # Keep Markdown table rows contiguous while retaining paragraph spacing.
    chunks=[]
    for i,line in enumerate(out):
        separator='\n' if i and line.startswith('|') and out[i-1].startswith('|') else '\n\n'
        chunks.append((separator if i else '')+line)
    return ''.join(chunks)+'\n'

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('command',choices=['validate','snapshot','demo','preview-pages','publish-pages','shards','review-queue','preview-hubs','publish-hubs','guide']);ap.add_argument('--out',required=True);args=ap.parse_args();out=Path(args.out)
    if args.command=='validate':dump(out,validate())
    elif args.command=='guide':out.write_text(markdown_guide(),encoding='utf-8')
    elif args.command=='snapshot':dump(out,node_snapshot())
    elif args.command=='demo':out.parent.mkdir(parents=True,exist_ok=True);out.write_text(compile_demo(),encoding='utf-8')
    elif args.command in ['preview-pages','publish-pages']:print(json.dumps(static_rankings(out,approved=args.command=='publish-pages')))
    elif args.command in ['preview-hubs','publish-hubs']:print(json.dumps(static_hubs(out,approved=args.command=='publish-hubs')))
    elif args.command=='shards':print(json.dumps(shards(out)))
    elif args.command=='review-queue':
        cat,rules,_=read_data();dump(out,[{'id':r['id'],'name':r['name'],'season':r['season_profile_v3']['status'],'missing_month_window':not r['v3_rank_eligibility']['all_time'],'family':r['fit_v3']['family']['status'],'access':{k:v['status'] for k,v in r['fit_v3']['accessibility'].items()},'human_review':r['v3_review']} for r in cat['records']])
    return 0
if __name__=='__main__':
    try:sys.exit(main())
    except (ValueError,FileExistsError,subprocess.CalledProcessError) as e:print(str(e),file=sys.stderr);sys.exit(2)
