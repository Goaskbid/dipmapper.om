# DipMapper V5: curated expansion and scale-readiness

Research edition: 13 November 2026. Exactly 20 files. This replaces the V4 handover, not the live website.

## Actual delivery, not the requested target

The user requested ten times the V4 catalogue: 458 x 10 = 4,580 distinct experiences. This package contains **605**, including **147 new unique experiences** and one existing venue enriched in place. The remaining shortfall is **3,975**. Do not call this a Top 1000, a tenfold expansion or a complete global inventory.

All 458 V4 IDs and passport slots remain. The existing Top 200 water selection and Top 100 aquarium order remain unchanged. The directory now has 161 aquarium profiles and 28 explicitly inside-mall aquariums. New aquarium discoveries have no fabricated global aquarium position. New research is exposed separately, including held and incomplete entries, rather than pretending every addition is a go-now recommendation.

## Preserve the product

Keep the swimming-first homepage, current map, normal search order, old favourites, languages, consent choices, guide URLs and sitemap. Add Explore beside them. Do not paste 11_demo.html over index.html. Inspect the actual production repository before binding any host adapter. No production source, deployment or Search Console account was changed here.

Do not load the full catalogue, sources or globe on the normal swimming route. Load the compact index and relevant activity shards after Explore opens. A partially loaded scope must not be labelled the whole world. Map stars require verified identity joins. No name-only join or approximate globe point establishes an entrance or embarkation point. New records have no supplied coordinates, so they remain list/area-context discoveries until properly joined.

## Curation and ranking contract

Every new entry has an authored reason to visit, source-based attractions, location context, season information or an explicit unresolved state, practical caveats and official planning/contact routes. These are model-assisted desk-researched cards, not first-hand reviews or an independent safety, welfare or accessibility audit.

The source register distinguishes 134 newly opened-page references from 18 search-excerpt references. Cached text is not live operation. Inherited sources retain their original dates. No source-prose, image or bulk database reuse licence is inferred from a publicly accessible page. New wording summarises facts and adds editorial judgment; photographs are not supplied.

The coarse 40% setting / 35% distinctiveness / 25% experience-depth model is retained for compatibility and thematic discovery. Scores need editorial ownership; they are not measured differences or visitor ratings. The authored aquarium Top 100 is a separate edition. Do not manufacture aggregateRating, reviewCount, accreditation or attendance figures.

## Integrate in this order

1. Capture the current production revision and representative map, favourites, privacy and mobile behaviour. Keep a rollback point.
2. Run the supplied tests. Inspect the new research page and representative source cards. Use curation_v5.new_ids for an exact change set; there are 147, not 148. Niihama updates sauna-niihama rather than adding a duplicate.
3. Merge catalogue, evidence, seasonal and practical fields. Preserve stable IDs, unresolved values, price categories and held references. The 119 catalogue records without a month window cannot become year-round recommendations.
4. Merge the optional Explore module. Add the New research shortcut beside the retained editions. Keep the original map neutral. The existing 18_host_adapter.mjs gives contracts, not names of production APIs.
5. Bind the cookie to the host's actual permission mechanism and test on real HTTPS. Never change the dm_water_v3 name or recycle registry slots. Only wanted/visited flags are stored. No age, access preference, coordinates or search history belongs in that cookie.
6. Review the authored pages and current exceptions. New draft publication requires a named reviewer; the build refuses unapproved publication. Never copy draft noindex to the production homepage, established guides, global head or robots.txt.
7. Merge approved static pages and sitemap entries through existing templates. Keep current URLs. Record the actual deployment date and examine real Search Console performance; no traffic gain is presumed.

## Specific blocking and product distinctions

Universal Volcano Bay has an unresolved maintenance/reopening hold. A planned date does not clear it automatically. Ramayana's published Wednesday closure is scoped to that venue. Linsberg's minimum age is 16. Opuke's Discovery family product is separate from its 18+ products; accessible toilets do not establish assisted water entry. Aquarium/resort/combination tickets remain separate. Unknown prices are not free. Cached summer promotions are not current quotes.

## Cookie scale change

The compact two-bit cookie was tested with 4,580 synthetic registry slots; the real registry has 605. The import byte ceiling rises from 100,000 to 1,000,000 bytes because a legitimate long-ID JSON export can exceed the former limit. Tests still reject oversize imports, unknown IDs and corruption. This is software capacity, not researched content. The host-only Secure, SameSite=Lax cookie lasts 180 days and travels to the same site with requests. Explicit Remember and host permission are required. File previews remain memory-only. Keep tombstones for retired slots and use explicit migrations.

## Commands

```sh
node --test 13_tests.mjs
python 14_tests.py
python 15_browser_tests.py --out /tmp/dipmapper-v5-browser
python 12_build.py validate --out /tmp/dipmapper-v5-validation.json
python 12_build.py snapshot --out /tmp/dipmapper-v5-snapshot.json
python 12_build.py guide --out /tmp/dipmapper-v5-guide.md
python 12_build.py demo --out /tmp/dipmapper-v5-demo.html
python 12_build.py shards --out /tmp/dipmapper-v5-shards
python 12_build.py preview-hubs --out /tmp/dipmapper-v5-pages
python 12_build.py review-queue --out /tmp/dipmapper-v5-review.json
```

Use fresh output directories for shards/pages. Build commands do not deploy, crawl or schedule updates. Intended interfaces are Python 3.10+ and Node 20+; the actual tested versions appear in 16_QA_AND_COVERAGE.md. Browser testing requires Playwright and Chromium.

## File map

| File | Purpose |
| --- | --- |
| 00 | Integration and preservation contract |
| 01 | All 605 written cards, retained ranking editions and further discoveries |
| 02 | Exact change report, evidence decisions and 147-item addition register |
| 03 | Catalogue, stable registry, assessment and field-specific provenance |
| 04 | Source register, seasons, restrictions, offers and retained journeys |
| 05 | Countries, water/region aliases and local globe geography |
| 06 | Ranking, season, fit and calendar logic |
| 07 | Cookie-only passport and bounded JSON import/export |
| 08 | Optional local Canvas globe |
| 09 | Explorer, comparison, detail cards, saved states and host events |
| 10 | Isolated responsive styles |
| 11 | Standalone preview, not a replacement homepage |
| 12 | Validation, static pages, guide, snapshots and shard builder |
| 13 | Node tests including 4,580-slot capacity fixtures |
| 14 | Python catalogue/build/publication tests |
| 15 | Browser tests with explicit native-cookie limitation |
| 16 | Actual executed QA, coverage and remaining work |
| 17 | Computed ranking snapshots and explicit incomplete-target metadata |
| 18 | Neutral-map, forecast and conservative day-planning adapter |
| 19 | SHA-256 manifest |

Return actual changed paths, tests, screenshots and a page | old paragraph or behaviour | new paragraph or behaviour | reason report. No background crawler, live forecast, ticket availability service, first-hand visits, editorial approvals or Google gains are claimed in this delivery.
