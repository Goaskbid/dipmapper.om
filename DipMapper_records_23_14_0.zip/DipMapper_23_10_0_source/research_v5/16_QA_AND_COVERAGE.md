# V5 executed QA and honest coverage

Research edition: 13 November 2026. The requested 4,580-record catalogue is **not complete**. This delivery contains 605 records, 147 more than V4, with a remaining gap of 3,975. Tests of 4,580 synthetic slots are not content research.

## Executed results

| Suite | Passed | Failed |
| --- | ---: | ---: |
| Node unit and integration contracts | 162 | 0 |
| Python catalogue/build/publication tests | 57 | 0 |
| Chromium interaction and layout checks | 69 | 0 |
| Total named tests/checks | 288 | 0 |
| Repeated structural assertions, reported separately | 7,898 | 0 |

The repeated structural assertions validate fields and joins, not independent editorial reviews. Tests were executed against this additive package, not the live DipMapper website. Earlier failed runs exposed outdated expected counts and timing-sensitive test assertions; the final run above is the successful result after fixes. The globe test waits for its requested animation frame; the search test waits for the intended debounced query rather than checking unrelated results.

Executed environment: Python 3.13.5, Node v22.16.0, Chromium 144.0.7559.96. Minimum intended versions were not separately tested.

## What was checked

All 458 V4 IDs and passport slots remain a prefix of the new registry. The original water Top 200 and aquarium Top 100 retain their supplied identities/order. New aquarium discoveries do not acquire invented global aquarium positions. Niihama is not duplicated. The new shortcut returns 147 distinct records. A held venue stays visible as research but is excluded from date-matched suggestions, even after a proposed reopening date. Ramayana's Wednesday rule is tested separately from Thursday.

Cookie round-trips include 4,580 slots and a long-ID JSON export exceeding the former 100 KB limit. The new 1 MB import bound still rejects oversized or malformed imports and unknown IDs. Existing saved state, consent boundaries, registry prefix, sequential cross-tab updates and unrelated cookies are covered. Cookies remain optional and host-only. No new localStorage, IndexedDB, account or advertising profile is used.

Browser interactions exercised filters, country/water aliases, source details, Top 100, the 28-item mall list, the 147-item supplement, held versus seasonal results, globe rotation, three-way comparison, saved states, JSON/ICS downloads, reduced motion, modal focus and responsive layouts including 320 pixels. Desktop and mobile screenshots were inspected. The final run recorded no page exceptions or external runtime requests. These are not formal WCAG certification or field Core Web Vitals.

## Native browser boundary

Normal intercepted HTTPS navigation failed: `blocked: Page.goto: net::ERR_BLOCKED_BY_ADMINISTRATOR at https://preview.dipmapper.test/`. Successful interactions used the compiled document via page.set_content. Native downloads worked. Persistence checks used an explicit controlled document.cookie adapter. **Native HTTPS persistence, Safari/iOS behaviour and the production consent integration remain unverified.** Test them on the actual staging domain; do not rewrite this outcome as a live-host pass.

## Actual catalogue and source depth

| Measure | Actual count |
| --- | ---: |
| Unique catalogue records | 605 |
| Retained V4 records | 458 |
| New distinct records | 147 |
| Existing record updated without duplication | 1 |
| Countries/territories across catalogue | 87 |
| Countries/territories represented by additions | 21 |
| Aquarium profiles / retained Top 100 | 161 / 100 |
| Inside-mall aquarium profiles | 28 |
| Retained water Top 200 | 200 |
| All evidence records / distinct URLs | 689 / 666 |
| New evidence records / distinct URLs | 152 / 151 |
| New opened-page / search-excerpt references | 134 / 18 |
| Records with a non-empty activity-month layer | 486 |
| Records with unresolved month windows | 119 |
| New records with month context / unresolved window | 127 / 20 |
| Ranking-eligible pool | 485 |
| New numeric price references with currency | 22 |
| New public telephone / email references | 16 / 1 |
| New exact verified entrance/departure coordinates | 0 |
| Licensed attraction photographs supplied | 0 |
| Human-approved new pages | 0 |
| Live weather/booking/inventory services | 0 |

Month context includes explicit inferences from indoor or heated venue format. It is not 486 verified opening calendars. The 119 unresolved windows include 99 inherited gaps and 20 new gaps. The new fields preserve source exceptions instead of applying a generic country season. Prices retain category, currency, starting/exact status, date and unresolved extras; unknown prices are not free. Source retrievals can be cached and public telephone details were not called. Prior research was preserved, not globally refreshed.

Family information exists for 20 records. Field-specific access coverage is 18 step-free, 11 wheelchair-boarding, seven accessible-toilet, 11 assisted-water-access and two sensory-support records. Most fit fields remain unknown. An aquarium or indoor pool is not automatically accessible to every visitor.

## Build and delivery

The builder generated 20 distinct ranking/discovery pages and one navigation page. The new supplement has 147 full cards; the aquarium edition has 100 and the mall page 28. No page is called Top 1000. All 605 records appear in the written guide. New previews are noindex and omitted from sitemaps until named approval. These directives apply only to new drafts, never existing production URLs. Unsafe URL schemes, duplicate IDs, invalid references and unapproved publication are rejected. Output directories cannot silently overwrite existing pages.

| Measured payload | Bytes |
| --- | ---: |
| Runtime JS/CSS, sum of individual gzip sizes | 28,205 |
| Compact ranking index, gzip | 128,988 |
| Geography bundle, gzip | 18,458 |
| Standalone preview, raw | 5,990,777 |
| Standalone preview, gzip | 460,792 |

The demo embeds research for portability and is not a production homepage payload. Shards are generated on demand. The production loader must assemble a complete declared scope before using the reference ranking model. No runtime external globe SDK is needed.

## Remaining work

The numerical target still lacks 3,975 curated records. New research does not expand whale/diving coverage materially in this batch; it concentrates on aquariums, thermal/sauna venues, water parks and selected Finnish water outings. It is not a balanced tenfold global expansion. Remaining factual work includes current full ticket quotes, specific access requirements, the 119 season gaps, verified entrances, photo rights and editorial score ownership. Integration still needs real host APIs, identity joins, consent, locale, favourites and deployed SEO checks. No traffic increase or Google recognition was measured.

The manifest hashes the 19 payload files. Rerun tests and regenerate it after changes.
