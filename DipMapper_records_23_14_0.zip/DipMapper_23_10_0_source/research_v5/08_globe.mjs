/** Dependency-free orthographic canvas globe. Local public-domain land, no tiles or network. */
const RAD=Math.PI/180;
export function project(lon,lat,centreLon=20,centreLat=20){
 const l=(lon-centreLon)*RAD,p=lat*RAD,p0=centreLat*RAD;
 return {x:Math.cos(p)*Math.sin(l),y:Math.cos(p0)*Math.sin(p)-Math.sin(p0)*Math.cos(p)*Math.cos(l),z:Math.sin(p0)*Math.sin(p)+Math.cos(p0)*Math.cos(p)*Math.cos(l)};
}
function clippedPolygon(points){
 const out=[];for(let i=0;i<points.length;i++){
  const a=points[(i+points.length-1)%points.length],b=points[i];
  if((a.z>=0)!==(b.z>=0)){const t=a.z/(a.z-b.z),x=a.x+t*(b.x-a.x),y=a.y+t*(b.y-a.y),n=Math.hypot(x,y)||1;out.push({x:x/n,y:y/n,z:0});}
  if(b.z>=0)out.push(b);
 }return out;
}
export function groupGlobePoints(records){
 const groups=new Map();
 for(const r of records){const p=r.geo_v3?.plot;if(!p||!Number.isFinite(p.latitude)||!Number.isFinite(p.longitude))continue;
  const key=p.scope==='approximate_area'?r.id:(p.cluster_id||r.id);
  if(!groups.has(key))groups.set(key,{id:key,latitude:p.latitude,longitude:p.longitude,scope:p.scope,label:p.label,records:[]});
  groups.get(key).records.push(r);
 }
 return [...groups.values()];
}
export function mountGlobe(canvas,geography,{records=[],passport=null,onSelect=()=>{},onStatus=()=>{}}={}){
 const ctx=canvas.getContext('2d');if(!ctx){onStatus('Globe unavailable. The complete ranked list remains below.');return {setRecords(){},setPassport(){},destroy(){}};}
 let lon=20,lat=20,width=600,height=430,dpr=1,points=groupGlobePoints(records),hit=[],raf=0,destroyed=false;
 canvas.tabIndex=0;canvas.setAttribute('role','img');canvas.setAttribute('aria-label','Interactive discovery globe. Arrow keys rotate it. The full accessible results list is below.');
 function schedule(){if(!raf&&!destroyed)raf=requestAnimationFrame(()=>{raf=0;draw();});}
 function path(points,fill=true){if(points.length<2)return;ctx.beginPath();ctx.moveTo(width/2+points[0].x*radius,height/2-points[0].y*radius);for(const p of points.slice(1))ctx.lineTo(width/2+p.x*radius,height/2-p.y*radius);if(fill)ctx.closePath();}
 let radius=180;
 function draw(){
  if(destroyed)return;
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,width,height);radius=Math.min(width*.40,height*.43);
  const cx=width/2,cy=height/2;
  const glow=ctx.createRadialGradient(cx,cy,radius*.7,cx,cy,radius*1.16);glow.addColorStop(0,'rgba(54,180,191,.12)');glow.addColorStop(1,'rgba(54,180,191,0)');ctx.fillStyle=glow;ctx.fillRect(0,0,width,height);
  ctx.save();ctx.beginPath();ctx.arc(cx,cy,radius,0,Math.PI*2);ctx.clip();
  const sea=ctx.createRadialGradient(cx-radius*.4,cy-radius*.4,radius*.1,cx,cy,radius*1.15);sea.addColorStop(0,'#174e60');sea.addColorStop(1,'#092b3c');ctx.fillStyle=sea;ctx.fillRect(cx-radius,cy-radius,radius*2,radius*2);
  ctx.strokeStyle='rgba(180,226,228,.13)';ctx.lineWidth=.6;
  for(let la=-60;la<=60;la+=30){const pts=[];for(let lo=-180;lo<=180;lo+=3){const p=project(lo,la,lon,lat);if(p.z>=0)pts.push(p);else if(pts.length){path(pts,false);ctx.stroke();pts.length=0;}}if(pts.length){path(pts,false);ctx.stroke();}}
  for(let lo=-180;lo<180;lo+=30){const pts=[];for(let la=-90;la<=90;la+=3){const p=project(lo,la,lon,lat);if(p.z>=0)pts.push(p);else if(pts.length){path(pts,false);ctx.stroke();pts.length=0;}}if(pts.length){path(pts,false);ctx.stroke();}}
  ctx.fillStyle='#55948f';ctx.strokeStyle='rgba(190,226,199,.35)';ctx.lineWidth=.55;
  for(const ring of geography.land_rings){const pp=clippedPolygon(ring.map(([lo,la])=>project(lo,la,lon,lat)));if(pp.length>2){path(pp);ctx.fill();ctx.stroke();}}
  const shade=ctx.createLinearGradient(cx-radius,cy-radius,cx+radius,cy+radius);shade.addColorStop(0,'rgba(255,255,255,.07)');shade.addColorStop(1,'rgba(0,12,25,.28)');ctx.fillStyle=shade;ctx.fillRect(cx-radius,cy-radius,radius*2,radius*2);
  hit=[];const visible=[];
  for(const g of points){const p=project(g.longitude,g.latitude,lon,lat);if(p.z<=.04)continue;visible.push({...g,p});}
  visible.sort((a,b)=>a.p.z-b.p.z);
  for(const g of visible){const x=cx+g.p.x*radius,y=cy-g.p.y*radius;const visited=g.records.filter(r=>passport?.get(r.id)===2).length,wanted=g.records.filter(r=>passport?.get(r.id)===1).length;
   const size=g.records.length>1?Math.min(10,4+Math.log2(g.records.length)):3.5;
   ctx.beginPath();ctx.arc(x,y,size+2,0,Math.PI*2);ctx.fillStyle='rgba(6,30,40,.55)';ctx.fill();
   ctx.beginPath();ctx.arc(x,y,size,0,Math.PI*2);ctx.fillStyle=visited?'#99e1c3':wanted?'#ffd28d':'#e5f5f2';ctx.fill();ctx.strokeStyle='#13414d';ctx.lineWidth=1;ctx.stroke();
   if(g.records.length>1){ctx.fillStyle='#123c45';ctx.font='bold 9px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(g.records.length>99?'99+':String(g.records.length),x,y);}
   hit.push({x,y,r:Math.max(size+5,10),group:g});
  }
  ctx.restore();ctx.beginPath();ctx.arc(cx,cy,radius,0,Math.PI*2);ctx.strokeStyle='rgba(133,208,214,.45)';ctx.lineWidth=1.3;ctx.stroke();
  onStatus(`${visible.length} markers or clusters on this hemisphere. Drag horizontally or use the rotation buttons. Approximate areas, not departure pins.`);
 }
 function resize(){const b=canvas.getBoundingClientRect();width=Math.max(250,b.width);height=Math.max(280,b.height);dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);schedule();}
 function rotate(dx,dy=0){lon=((lon+dx+540)%360)-180;lat=Math.max(-75,Math.min(75,lat+dy));schedule();}
 let start=null;
 const handlers={
  pointerdown(e){start={x:e.clientX,y:e.clientY,lon,lat,moved:false};},
  pointermove(e){if(!start)return;const dx=e.clientX-start.x,dy=e.clientY-start.y;if(Math.abs(dx)>6){start.moved=true;lon=start.lon-dx*.45;lat=Math.max(-75,Math.min(75,start.lat+dy*.2));schedule();}},
  pointerup(e){if(!start)return;const moved=start.moved;start=null;if(moved)return;const b=canvas.getBoundingClientRect(),x=e.clientX-b.left,y=e.clientY-b.top;const h=[...hit].reverse().find(h=>Math.hypot(h.x-x,h.y-y)<=h.r);if(h)onSelect(h.group.records.map(r=>r.id),h.group);},
  pointercancel(){start=null;},
  keydown(e){const commands={ArrowLeft:()=>rotate(-25),ArrowRight:()=>rotate(25),ArrowUp:()=>rotate(0,15),ArrowDown:()=>rotate(0,-15),Home:()=>{lon=20;lat=20;schedule();}};if(commands[e.key]){e.preventDefault();commands[e.key]();}}
 };
 for(const [type,fn] of Object.entries(handlers))canvas.addEventListener(type,fn);
 const observer=new ResizeObserver(resize);observer.observe(canvas);resize();
 return {rotate,reset(){lon=20;lat=20;schedule();},setRecords(r){points=groupGlobePoints(r);schedule();},setPassport(p){passport=p;schedule();},destroy(){destroyed=true;observer.disconnect();if(raf)cancelAnimationFrame(raf);for(const [type,fn] of Object.entries(handlers))canvas.removeEventListener(type,fn);}};
}
