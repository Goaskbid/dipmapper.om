#!/usr/bin/env python3
"""Data, preservation and build tests. No network calls."""
import importlib.util, json, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('builder',ROOT/'12_build.py');build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
C,R,G=build.read_data();IDS={r['id'] for r in C['records']};SRC={s['source_id']:s for s in R['sources']}
class DataTests(unittest.TestCase):
 def test_static_source_urls_reject_script(self):self.assertFalse(build.safe_publisher_url('javascript:alert(1)'))
 def test_static_source_urls_reject_credentials(self):self.assertFalse(build.safe_publisher_url('https://user:password@example.org/a'))
 def test_static_source_urls_accept_https(self):self.assertTrue(build.safe_publisher_url('https://example.org/evidence'))
 def test_actual_records(self):self.assertEqual(len(C['records']),605)
 def test_baseline_301_preserved(self):self.assertEqual(len(C['baseline_preserved_ids']),301);self.assertTrue(set(C['baseline_preserved_ids'])<=IDS)
 def test_new_beaches_37(self):self.assertEqual(sum(r.get('record_origin')=='new_v3_beach_research' for r in C['records']),37)
 def test_source_ids_unique(self):self.assertEqual(len(SRC),len(R['sources']))
 def test_source_new_register_joins(self):self.assertTrue(set(R['new_source_ids'])<=set(SRC))
 def test_no_inherited_research_count_in_new(self):self.assertTrue(all(SRC[x]['v3_review_status']=='new_research' for x in R['new_source_ids']))
 def test_all_explicit_season_profiles(self):self.assertTrue(all(r['season_profile_v3']['status'] for r in C['records']))
 def test_unknown_seasons_not_yearround(self):
  for r in C['records']:
   if r['season_profile_v3']['status']=='needs_research':self.assertFalse(r['v3_rank_eligibility']['all_time'])
 def test_geographic_areas_not_navigation(self):self.assertTrue(all(r['geo_v3']['navigation_allowed'] is False for r in C['records']))
 def test_country_set_78(self):self.assertEqual(len(G['countries']),87)
 def test_geographic_scopes_unique(self):self.assertEqual(len({s['id'] for s in G['scopes']}),len(G['scopes']))
 def test_no_departure_fabrication_for_new_beaches(self):self.assertTrue(all(r['departure_coordinates'] is None for r in C['records'] if r.get('record_origin')=='new_v3_beach_research'))
 def test_registry_contiguous(self):self.assertEqual([x['slot'] for x in C['registry']['slots']],list(range(605)))
 def test_rank_editorial_no_fake_ratings(self):self.assertTrue(all(r['assessment_v3']['score_kind']=='editorial_judgment_not_observed_metric' for r in C['records']))
 def test_weights_consistent(self):self.assertEqual(R['methodology']['components'],{'setting':40,'distinctiveness':35,'experience_depth':25})
 def test_score_arithmetic(self):
  for r in C['records']:
   a=r['assessment_v3'];v=a['components'];self.assertEqual(a['score'],round((40*v['setting']+35*v['distinctiveness']+25*v['experience_depth'])/4))
 def test_no_unearned_publication_approval(self):self.assertFalse(any(r['v3_review']['approved_for_indexing'] for r in C['records']))
 def test_existing_journeys_retained(self):self.assertIsInstance(R['journeys'],dict);self.assertGreater(len(json.dumps(R['journeys'])),1000)
 def test_existing_prices_retained(self):self.assertGreaterEqual(len(R['offers']['records']),58)
 def test_existing_restrictions_retained(self):self.assertGreaterEqual(len(R['restrictions']),17)
 def test_no_licensed_image_claim(self):self.assertTrue(all(not s.get('image_reuse','').startswith('permitted') for s in SRC.values()))
 def test_validate_actual(self):self.assertGreater(build.validate()['structural_assertions'],4000)
 def test_node_snapshot_top200(self):self.assertEqual(len(build.node_snapshot()['top_200']),200)
 def test_snapshot_each_month(self):self.assertEqual(len(build.node_snapshot()['monthly_examples']),12)
 def test_snapshots_are_unapproved(self):self.assertEqual(build.node_snapshot()['publication_status'],'unapproved_editorial_research')
 def test_demo_no_external_dependencies(self):
  s=build.compile_demo();self.assertNotIn('<script src=',s);self.assertNotIn('<link rel="stylesheet"',s);self.assertIn('noindex,nofollow',s)
 def test_demo_uses_same_methodology(self):self.assertIn('40% / 35% / 25%',build.compile_demo())
 def test_publish_unreviewed_refused(self):
  with tempfile.TemporaryDirectory() as t:
   with self.assertRaises(ValueError):build.static_rankings(Path(t)/'pub',approved=True)
   self.assertFalse((Path(t)/'pub').exists())
 def test_preview_has_200_crawlable_list_entries(self):
  with tempfile.TemporaryDirectory() as t:
   build.static_rankings(Path(t)/'page');s=(Path(t)/'page/index.html').read_text();self.assertEqual(s.count('<li id='),200);self.assertIn('noindex,nofollow',s);self.assertNotIn('sitemap-fragment',s)
 def test_preview_no_fake_aggregate_rating(self):
  with tempfile.TemporaryDirectory() as t:
   build.static_rankings(Path(t)/'page');s=(Path(t)/'page/index.html').read_text();self.assertNotIn('aggregateRating',s);self.assertNotIn('reviewCount',s)
 def test_build_refuses_overwrite(self):
  with tempfile.TemporaryDirectory() as t:
   with self.assertRaises(FileExistsError):build.fresh_directory(t)
 def test_shards_preserve_all_records(self):
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'shards';m=build.shards(target);self.assertEqual(sum(x['records'] for x in m['shards']),605);self.assertLess(m['index_gzip_bytes'],150000)
 def test_unknown_fields_remain_in_review_queue_source(self):self.assertGreater(sum(r['fit_v3']['family']['status']=='unknown' for r in C['records']),0)
 def test_hub_previews_have_separate_activity_pages(self):
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'hubs';v=build.static_hubs(target);self.assertEqual(v['ranking_pages'],20);self.assertTrue((target/'whale-watch/index.html').exists());self.assertTrue((target/'beach/index.html').exists())
 def test_hub_titles_do_not_fake_200_whales(self):
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'hubs';build.static_hubs(target);s=(target/'whale-watch/index.html').read_text();self.assertIn('27 researched candidates',s);self.assertNotIn('Top 200 whale',s)
 def test_hubs_do_not_publish_thin_garda_list(self):
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'hubs';build.static_hubs(target);self.assertFalse((target/'lake-garda').exists());self.assertTrue((target/'phuket/index.html').exists())
 def test_hubs_noindex_until_approval(self):
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'hubs';build.static_hubs(target);self.assertIn('noindex,nofollow',(target/'beach/index.html').read_text());self.assertFalse((target/'sitemap-fragment.xml').exists())
 def test_hubs_publication_gate(self):
  with tempfile.TemporaryDirectory() as t:
   with self.assertRaises(ValueError):build.static_hubs(Path(t)/'hubs',approved=True)
 def test_no_scheduled_workflow_in_package(self):self.assertFalse(any(p.suffix in ['.yml','.yaml'] for p in ROOT.iterdir()))

 def test_ready_aquarium_100(self):self.assertEqual(len(build.node_snapshot()['aquarium_top_100']),100)
 def test_full_aquarium_120(self):self.assertEqual(len(build.node_snapshot()['aquarium_longlist']),161)
 def test_inside_mall_25(self):self.assertEqual(len(build.node_snapshot()['mall_aquariums']),28)
 def test_all_guides_exist(self):self.assertTrue(all(r['guide_v4']['description'] and r['guide_v4']['why_go'] for r in C['records']))
 def test_new_descriptions_individual(self):self.assertEqual(len({r['guide_v4']['description'] for r in C['records'] if r['primary_activity']=='aquarium'}),161)
 def test_guide_is_not_only_titles(self):
  text=build.markdown_guide();self.assertEqual(text.count('**Why go:**'),605);self.assertEqual(text.count('**Tickets/access:**'),605);self.assertIn('Top 100 public aquariums',text);self.assertNotIn('| Edition | Actual records |\n\n|',text)
 def test_all_public_phone_and_email_fields_are_arrays(self):self.assertTrue(all(isinstance(r['guide_v4']['contact']['phones'],list) and isinstance(r['guide_v4']['contact']['emails'],list) for r in C['records']))
 def test_no_new_false_daily_opening_claim(self):self.assertTrue(all(r['guide_v4']['season'][0]['interpretation']=='editorial_inference_not_operating_calendar' for r in C['records'] if r['primary_activity']=='aquarium' and r.get('record_origin')!='new_v5_curated_research'))
 def test_existing_cards_not_marked_new_research(self):self.assertTrue(all(r['guide_v4']['inherited_not_rechecked'] for r in C['records'][:338]))
 def test_new_source_links_resolve(self):self.assertTrue(set(R['new_v4_source_ids'])<=set(SRC))
 def test_aquarium_hub_has_100_rich_cards(self):
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'hubs';build.static_hubs(target);s=(target/'best-public-aquariums/index.html').read_text();self.assertEqual(s.count('<li id='),100);self.assertEqual(s.count('Tickets and published costs'),100);self.assertIn('Key attractions:',s)
 def test_mall_hub_has_28_cards_and_excludes_cebu(self):
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'hubs';build.static_hubs(target);s=(target/'aquariums-in-shopping-malls/index.html').read_text();self.assertEqual(s.count('<li id='),28);self.assertNotIn('id="aquarium-cebu-ocean"',s)
 def test_detail_shards_retain_ticket_information(self):
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'shards';build.shards(target);s=json.loads((target/'aquarium.json').read_text());self.assertEqual(len(s['records']),161);self.assertGreaterEqual(len(s['offers']),120)
 def test_old_registry_prefix_matches_v3_order(self):self.assertEqual([x['id'] for x in C['registry']['slots'][:338]],C['v3_preserved_ids'])
 def test_no_false_aquarium_user_ratings(self):self.assertTrue(all(r['assessment_v3']['independent_visit'] is False for r in C['records'] if r['primary_activity']=='aquarium' and r.get('record_origin')!='new_v5_curated_research'))

if __name__=='__main__':unittest.main(verbosity=2)
